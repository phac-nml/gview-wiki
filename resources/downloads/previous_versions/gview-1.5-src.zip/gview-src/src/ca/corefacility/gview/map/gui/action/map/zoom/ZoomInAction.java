package ca.corefacility.gview.map.gui.action.map.zoom;

import ca.corefacility.gview.layout.sequence.ZoomException;
import ca.corefacility.gview.map.GViewMap;

/**
 * Zoom map in action.
 * 
 * @author Eric Marinier
 *
 */
public class ZoomInAction extends ZoomAction
{
	private final GViewMap gViewMap;
	
	/**
	 * 
	 * @param gViewMap The GView map object.
	 */
	public ZoomInAction(GViewMap gViewMap)
	{
		super(gViewMap, gViewMap.getZoomFactor());
		
		this.gViewMap = gViewMap;
	}
	
	@Override
	public void run() throws ActionRunException
	{
		double zoomFactor;
		
		zoomFactor = this.gViewMap.getZoomFactor();
		zoomFactor *= 1.1;
		try
        {
		    this.gViewMap.setZoomFactor(zoomFactor);
        }
		catch (ZoomException e)
        {
            throw new ActionRunException(e.getMessage());
        }
	}
}
