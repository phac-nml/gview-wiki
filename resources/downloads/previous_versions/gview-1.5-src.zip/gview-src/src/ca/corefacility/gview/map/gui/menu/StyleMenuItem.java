package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBoxMenuItem;

import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.editor.StyleEditorTree;

public class StyleMenuItem extends JCheckBoxMenuItem implements ActionListener
{
	private static final long serialVersionUID = 1L;
	
	private final GViewGUIFrame gViewGUIFrame;
	private final StyleEditorTree style;
	
	/**
	 * 
	 * @param gViewGUIFrame The related GUI frame.
	 * @param styleEditorTree The related style.
	 */
	public StyleMenuItem(GViewGUIFrame gViewGUIFrame, StyleEditorTree styleEditorTree)
	{
		super(styleEditorTree.getTreeName());
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.style = styleEditorTree;
		this.gViewGUIFrame = gViewGUIFrame;
		
		this.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(style == null)
			throw new NullPointerException("StyleEditorTree is null.");
		
		this.gViewGUIFrame.setCurrentStyle(this.style);
	}
}
