package ca.corefacility.gview.map.gui.action.map;

import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.GViewMap;

/**
 * The Fit Image to Map / Fit Map to Screen action.
 * 
 * Scales and centers the map / image so that it takes up the entire window.
 * 
 * @author Eric Marinier
 *
 */
public class FITMAction extends MapAction 
{
	private final GViewMap gViewMap;
	private final double previousScale;
	private final double previousPosition;
	
	/**
	 * 
	 * @param gViewMap The GView map object.
	 */
	public FITMAction(GViewMap gViewMap)
	{
		if(gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		this.gViewMap = gViewMap;
		this.previousPosition = gViewMap.getCenterBaseValue();
		this.previousScale = gViewMap.getZoomNormalFactor();
	}
	
	@Override
	public void undo() throws CannotUndoException 
	{
		this.gViewMap.setCenter((int)Math.round(this.previousPosition));
		this.gViewMap.zoomNormal(this.previousScale);
	}

	@Override
	public void redo() throws CannotRedoException 
	{
		this.run();
	}

	@Override
	public void run() 
	{
		this.gViewMap.scaleMapToScreen();
	}

}
