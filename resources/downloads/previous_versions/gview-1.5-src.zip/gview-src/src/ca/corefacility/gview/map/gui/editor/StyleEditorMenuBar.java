package ca.corefacility.gview.map.gui.editor;

import javax.swing.JMenuBar;

/**
 * The menu bar for the style editor.
 * 
 * @author Eric Marinier
 *
 */
public class StyleEditorMenuBar extends JMenuBar 
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private final FileMenu fileMenu;	//the file submenu
	private final StyleMenu styleMenu;	//the style submenu
	private final HelpMenu helpMenu;	//the help submenu

	/**
	 * 
	 * @param styleEditorFrame The style frame the menu will exist on.
	 */
	public StyleEditorMenuBar(StyleEditorFrame styleEditorFrame)
	{
		super();
		
		if(styleEditorFrame == null)
			throw new IllegalArgumentException("StyleEditorFrame is null");
		
		//Add the File Menu
		fileMenu = new FileMenu(styleEditorFrame);
		add(fileMenu);
		
		//Add the File Menu
		styleMenu = new StyleMenu(styleEditorFrame);
		add(styleMenu);
		
		//Add the help menu
		helpMenu = new HelpMenu();
		add(helpMenu);
	}
}
