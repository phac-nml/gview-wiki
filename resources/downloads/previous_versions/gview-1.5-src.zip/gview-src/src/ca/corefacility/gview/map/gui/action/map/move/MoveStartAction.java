package ca.corefacility.gview.map.gui.action.map.move;

import ca.corefacility.gview.map.GViewMap;

/**
 * Move to start action.
 * 
 * Moves the camera to the start of the genome.
 * 
 * @author Eric Marinier
 *
 */
public class MoveStartAction extends MoveAction 
{
	private final GViewMap gViewMap;

	/**
	 * 
	 * @param gViewMap The GView map object.
	 */
	public MoveStartAction(GViewMap gViewMap)
	{
		super(gViewMap);
		
		if(gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		this.gViewMap = gViewMap;
	}

	@Override
	public void run() 
	{
		this.gViewMap.setCenter(0);
	}

}
