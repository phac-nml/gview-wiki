package ca.corefacility.gview.map.gui.editor.node;

import java.util.Enumeration;

import org.biojava.bio.seq.FeatureFilter;

import ca.corefacility.gview.map.gui.editor.panel.SlotPanel;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;

/**
 * The node class for the slot styles. Intended to be used within a StyleEditorTree.
 * 
 * @author Eric Marinier
 *
 */
public class SlotNode extends FeatureContainerNode implements Slotable 
{
	private static final long serialVersionUID = 1L;	//requested by java
	private static final String SLOT = "Slot";
	
	private final SlotPanel slotPanel;
	private int slotNumber;

	/**
	 * 
	 * @param slotPanel The related panel.
	 */
	public SlotNode(SlotPanel slotPanel) 
	{
		super(slotPanel, SLOT);

		if(slotPanel == null)
		{
			throw new IllegalArgumentException("SlotPanel is null.");
		}
		else
		{
			this.slotPanel = slotPanel;			
			this.slotNumber = slotPanel.getStyle().getSlot();
			this.updateName();
		}
	}	

	@Override
	public SlotPanel getPanel() 
	{
		if(this.slotPanel == null)
			throw new IllegalArgumentException("SlotPanel is null.");
		
		return this.slotPanel;
	}
	
	/**
	 * Determines whether or not the slot node has a plot node child.
	 * 
	 * @return Whether or not the slot node has a plot node child.
	 */
	public boolean containsPlotNode()
	{
		boolean result = false;
		
		@SuppressWarnings("rawtypes")
		Enumeration nodes = this.children();	
		
		while(nodes.hasMoreElements() && result == false)
		{
			if(nodes.nextElement() instanceof PlotNode)
				result = true;
		}
		
		return result;
	}
	
	/**
	 * Determines whether or not the slot node has a set node child.
	 * 
	 * @return Whether or not the slot node has a set node child.
	 */
	public boolean containsSetNode()
	{
		boolean result = false;
		
		@SuppressWarnings("rawtypes")
		Enumeration nodes = this.children();	
		
		while(nodes.hasMoreElements() && result == false)
		{
			if(nodes.nextElement() instanceof SetNode)
				result = true;
		}
		
		return result;
	}

	@Override
	public void updateName()
	{
		updateSlotNumber();
		super.rename(SLOT + " " + this.slotNumber);
	}

	@Override
	public int getSlotNumber()
	{
		updateSlotNumber();
		
		return this.slotNumber;
	}

	@Override
	public boolean canAddSetNodeAsChild()
	{
		boolean result = true;
		
		if(this.containsPlotNode())
		{
			result = false;
		}
		
		return result;
	}

	@Override
	public FeatureHolderStyle createFeatureHolderStyle(FeatureFilter featureFilter)
	{
		return this.slotPanel.getStyle().createFeatureHolderStyle(featureFilter);
	}
	
	/**
	 * Updates the slot number by pulling the slot number from the associated style.
	 */
	private void updateSlotNumber()
	{
		this.slotNumber = this.slotPanel.getStyle().getSlot();
	}
}
