package ca.corefacility.gview.map.gui.action.map.scale;

import ca.corefacility.gview.map.GViewMap;

/**
 * Scale map out action.
 * 
 * @author Eric Marinier
 *
 */
public class ScaleOutAction extends ScaleAction 
{
	private final GViewMap gViewMap;
	
	/**
	 * 
	 * @param gViewMap The GView map object.
	 */
	public ScaleOutAction(GViewMap gViewMap)
	{
		super(gViewMap,gViewMap.getZoomNormalFactor());
		
		this.gViewMap = gViewMap;
	}
	
	public void run()
	{
		double scaleFactor;
		
		scaleFactor = this.gViewMap.getZoomNormalFactor();
		scaleFactor *= 0.9;
		this.gViewMap.zoomNormal(scaleFactor);
	}
}
