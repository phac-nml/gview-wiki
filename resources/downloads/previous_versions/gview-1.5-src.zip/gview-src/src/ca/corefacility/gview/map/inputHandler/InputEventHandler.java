package ca.corefacility.gview.map.inputHandler;

import java.awt.Desktop;
import java.awt.geom.Point2D;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.items.FeatureItem;
import ca.corefacility.gview.map.items.MapItem;

import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;

/**
 * Handles keyboard and mouse events on the GView map.
 * @author aaron
 *
 */
public class InputEventHandler extends PBasicInputEventHandler
{
	private PCamera camera;

	private ZoomSubject zoomSubject;
	private SelectHandler selectHandler;
	private MouseOverHandler mouseOverHandler;

	private GViewMap gviewMap;

	private Point2D lastPosition = new Point2D.Double(0,0);

	private static final char RE_CENTER = 'C';
	private static final char ZOOM_OUT = '-';
	private static final char ZOOM_IN = '=';
	private static final char EXPORT = 'E';
	private static final char VIEW_ALL = 'V';

	/**
	 * Handles all keyboard/mouse input events.
	 * @param camera  The camera used to view the GView map.
	 * @param gviewMap  The GView map itself.
	 * @param zoomSubject  The object used to handle zooming.
	 * @param selectHandler  The object used to handle selection of items.
	 * @param toolTipHandler  The object used to control the display of the tooltip.
	 */
	public InputEventHandler(PCamera camera, GViewMap gviewMap, ZoomSubject zoomSubject, SelectHandler selectHandler,
			ToolTipHandler toolTipHandler)
	{
		this.camera = camera;

		this.gviewMap = gviewMap;
		this.zoomSubject = zoomSubject;
		this.selectHandler = selectHandler;

		this.mouseOverHandler = new MouseOverHandler(toolTipHandler);
	}

	@Override
	public void keyPressed(PInputEvent event)
	{
		char keyChar = (char)event.getKeyCode(); // returns letters as capitals

		if (RE_CENTER == keyChar && event.isControlDown())
		{
			this.gviewMap.setCenter(0);
		}
		else if (ZOOM_IN == keyChar && event.isControlDown())
		{
			this.lastPosition = this.zoomSubject.zoomStretch(1.2, this.lastPosition);
		}
		else if (ZOOM_OUT == keyChar && event.isControlDown())
		{
			this.lastPosition = this.zoomSubject.zoomStretch(0.8, this.lastPosition);
		}
		else if (VIEW_ALL == keyChar && event.isControlDown())
		{
			this.gviewMap.scaleMapToScreen();
		}
		else if (EXPORT == keyChar && event.isControlDown() && event.isAltDown() )
		{
			ImageExportHandler.getInstance().performExport(this.gviewMap);
		}
//		else if (VIEW_LEGEND == keyChar && event.isControlDown())
//		{
//			legendHandler.toggleLegend();
//		}
	}

	// TODO properly handle these
	@Override
	public void keyboardFocusGained(PInputEvent event)
	{

	}

	@Override
	public void keyboardFocusLost(PInputEvent event)
	{

	}

	@Override
	public void mouseClicked(PInputEvent event)
	{
		if (null != event)
		{
			PNode clickedNode = event.getInputManager().getMouseOver().getPickedNode();

			if (clickedNode instanceof MapItem)
			{
				MapItem clickedItem = (MapItem)clickedNode;

				// only select the item clicked on, unless control is down
				if (event.isControlDown() && !event.isAltDown())
				{
					this.selectHandler.multiItemSelect(clickedItem);
				}
				else if ((event.isControlDown() && event.isAltDown()) || event.isMiddleMouseButton())
				{
					if (clickedItem instanceof FeatureItem)
					{
						FeatureItem clickedFeatureItem = (FeatureItem)clickedItem;
						String hyperlink = clickedFeatureItem.getHyperlink();
						
						if (hyperlink == null)
						{
							System.out.println("No hyperlink for feature");
						}
						else if (hyperlink != null && java.awt.Desktop.isDesktopSupported())
                        {
							System.out.println("Opening " + hyperlink);
                            Desktop desktop = Desktop.getDesktop();
                            if (desktop.isSupported(Desktop.Action.BROWSE))
                            {
                                try
                                {
                                    URI usageURI = new URI(hyperlink);
                                    desktop.browse(usageURI);
                                }
                                catch (URISyntaxException e1)
                                {
                                    System.err.println("invalid hyperlink " + hyperlink);
                                }
                                catch (IOException e1)
                                {
                                    e1.printStackTrace();
                                }
                            }
                        }
						
					}
				}
				else
				{
					this.selectHandler.singleItemSelect(clickedItem);
				}
			}
			else
			{
				this.selectHandler.unselectAll();
			}
		}
	}

	@Override
	public void mousePressed(PInputEvent event)
	{

	}

	@Override
	public void mouseWheelRotated(PInputEvent event)
	{
		// look at mouse wheel rotation more closely
		final double ROTATE_SCALE_DELTA = 0.1;
		final double INITAL_SCALE_FACTOR = 1.0;

		double scaleDelta = INITAL_SCALE_FACTOR - event.getWheelRotation()*ROTATE_SCALE_DELTA;

		Point2D zoomPoint = event.getPosition();

		if (!event.isControlDown())
		{
			this.zoomSubject.zoomStretch(scaleDelta, zoomPoint);
		}
		else
		{
			// TODO I probably don't want to pass camera into here
			this.zoomSubject.zoomNormalDelta(scaleDelta, zoomPoint, this.camera);
		}
	}

	@Override
	public void mouseMoved(PInputEvent event)
	{
		handleNode(event);

		event.getInputManager().setKeyboardFocus(this); // sets this class as the class to handle keyboard events

		this.lastPosition = event.getPosition();
	}

	@Override
	public void mouseDragged(PInputEvent event)
	{
		handleNode(event);

		this.lastPosition = event.getPosition();
	}

	/**
	 * Handles the node the current event is over.
	 * @param event  The current event to handle.
	 */
	private void handleNode(PInputEvent event)
	{
		PNode n = event.getInputManager().getMouseOver().getPickedNode();

		// not sure if this is the best way
		if (n instanceof MapItem)
		{
			MapItem item = (MapItem)n;

			Point2D itemCursorPosition = event.getCanvasPosition();
			event.getPath().canvasToLocal(itemCursorPosition, this.camera);

			this.mouseOverHandler.mouseOver(item, itemCursorPosition);
		}
		else
		{
			this.mouseOverHandler.mouseOver(null, null);
		}
	}
}
