package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.action.dialog.show.ShowRulerStyleDialogAction;
import ca.corefacility.gview.map.gui.dialog.StyleDialog;
import ca.corefacility.gview.map.gui.editor.panel.RulerPanel;
import ca.corefacility.gview.style.items.RulerStyle;

/**
 * The ruler style menu item.
 * Displays a dialog to allow global changes to the ruler style.
 * 
 * @author Eric Marinier
 *
 */
public class RulerStyleMenuItem extends JMenuItem implements ActionListener
{
	private static final long serialVersionUID = 1L; //requested by java	
	
	private final GViewGUIFrame gViewGUIFrame;
	
	/**
	 * 
	 * @param gViewGUIFrame The related GUI frame.
	 */
	public RulerStyleMenuItem(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.RULER_STYLE_TEXT);	
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;
		
		this.setActionCommand(GUIUtility.RULER_STYLE);
		this.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{	
		RulerStyle rulerStyle = this.gViewGUIFrame.getGViewMap().getMapStyle().getGlobalStyle().getRulerStyle();
		RulerPanel rulerPanel = new RulerPanel(rulerStyle);
		
		if(e.getActionCommand().equals(GUIUtility.RULER_STYLE))
		{
			this.gViewGUIFrame.doAction(new ShowRulerStyleDialogAction(new StyleDialog(gViewGUIFrame, rulerPanel)));
		}
	}
}
