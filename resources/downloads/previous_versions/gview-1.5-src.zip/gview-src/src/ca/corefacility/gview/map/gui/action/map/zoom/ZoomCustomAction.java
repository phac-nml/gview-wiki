package ca.corefacility.gview.map.gui.action.map.zoom;

import ca.corefacility.gview.layout.sequence.ZoomException;
import ca.corefacility.gview.map.GViewMap;

/**
 * Zoom map custom action class.
 * 
 * @author Eric Marinier
 *
 */
public class ZoomCustomAction extends ZoomAction 
{
	private final GViewMap gViewMap;
	private final double value;
	
	/**
	 * 
	 * @param gViewMap The GView map object.
	 * @param value The value to zoom to.
	 */
	public ZoomCustomAction(GViewMap gViewMap, double value)
	{
		super(gViewMap, gViewMap.getZoomFactor());
		
		this.gViewMap = gViewMap;
		this.value = value;
	}

	@Override
	public void run() throws ActionRunException 
	{
		try
        {
            this.gViewMap.setZoomFactor(value);
        }
		catch (ZoomException e)
        {
            throw new ActionRunException(e.getMessage());
        } 
	}
}
