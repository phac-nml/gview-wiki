package ca.corefacility.gview.map.gui.action.style;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.gui.editor.StyleEditorFrame;
import ca.corefacility.gview.map.gui.open.StyleDataFilter;
import ca.corefacility.gview.style.io.StyleIOGSS;

public class ExportStyleAction extends StyleEditorAction
{
	private static final String FILE_EXTENSION = ".gss";
	private final StyleEditorFrame styleEditorFrame;
	
	/**
	 * 
	 * @param styleEditorFrame The related style editor frame.
	 */
	public ExportStyleAction(StyleEditorFrame styleEditorFrame)
	{
		if(styleEditorFrame == null)
			throw new IllegalArgumentException("StyleEditorFrame is null.");

		this.styleEditorFrame = styleEditorFrame;
	}

	@Override
	public void undo() throws CannotUndoException
	{
		throw new CannotUndoException();
	}

	@Override
	public void redo() throws CannotRedoException 
	{
		throw new CannotRedoException();
	}
	
	@Override
	public boolean canUndo() 
	{
		return false;
	}
	
	@Override
	public boolean canRedo() 
	{
		return false;
	}

	@Override
	public void run()
	{
		StyleIOGSS styleIO = new StyleIOGSS();
		
		JFileChooser styleChooser = new JFileChooser(this.styleEditorFrame.getCurrentDirectory());	
		styleChooser.setSelectedFile(new File(this.styleEditorFrame.getCurrentStyle().getTreeName()));
		styleChooser.setFileFilter(new StyleDataFilter());
		
		File styleFile;
		Writer styleWriter;
		
		//Approved
		if(styleChooser.showSaveDialog(this.styleEditorFrame) == JFileChooser.APPROVE_OPTION)
		{
			try
			{
				//Set current directory
				this.styleEditorFrame.setCurrentDirectory(styleChooser.getCurrentDirectory());
				
				//Grab the file
				styleFile = styleChooser.getSelectedFile();
				
				//Auto append file extension
				if(!styleFile.getName().endsWith(FILE_EXTENSION))
				{
					styleFile = new File(styleFile.getAbsolutePath() + FILE_EXTENSION);
				}
				
				if(styleFile.exists())
				{
					//Overwrite?
					if(JOptionPane.showConfirmDialog(this.styleEditorFrame, "Are you sure you want to overwrite this file?") == JOptionPane.YES_OPTION)
					{
						styleWriter = new FileWriter(styleFile);				
						styleIO.writeMapStyle(this.styleEditorFrame.getGViewMap().getMapStyle(), styleWriter);
						
						//Set the new name
						this.styleEditorFrame.setStyleName(styleFile.getName());
					}
				}
				else
				//does not exist
				{
					styleWriter = new FileWriter(styleFile);				
					styleIO.writeMapStyle(this.styleEditorFrame.getGViewMap().getMapStyle(), styleWriter);
					
					//Set the new name
					this.styleEditorFrame.setStyleName(styleFile.getName());
				}
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}
}
