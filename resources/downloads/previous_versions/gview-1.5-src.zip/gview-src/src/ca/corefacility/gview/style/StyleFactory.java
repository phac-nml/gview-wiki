package ca.corefacility.gview.style;

import java.awt.Color;
import java.awt.Font;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;

import ca.corefacility.gview.data.Slot;
import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.LabelStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.items.BackboneStyle;
import ca.corefacility.gview.style.items.RulerStyle;
import ca.corefacility.gview.style.items.TooltipStyle;
import ca.corefacility.gview.textextractor.AnnotationExtractor;

/**
 * A class which stores/creates some styles that are used many times.
 * 
 * @author Aaron Petkau
 * 
 */
public class StyleFactory
{
	public static MapStyle createDefaultStyle()
	{
        MapStyle style = new MapStyle();

        // set the style
        GlobalStyle gStyle = style.getGlobalStyle();
        gStyle.setDefaultHeight(700);
        gStyle.setDefaultWidth(700);

        gStyle.setBackgroundPaint(Color.WHITE);
        gStyle.setShowBorder(true);
        gStyle.setTitlePaint(Color.BLACK);
        gStyle.setTitleFont(new Font("SansSerif", Font.PLAIN, 20));
        gStyle.setSlotSpacing(3.0);

        TooltipStyle tStyle = gStyle.getTooltipStyle();
        tStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
        tStyle.setTextPaint(Color.BLACK);
        tStyle.setBackgroundPaint(new Color(134, 134, 255));
        tStyle.setOutlinePaint(new Color(0.0f, 0.0f, 0.0f, 0.5f));

        BackboneStyle bStyle = gStyle.getBackboneStyle();
        bStyle.setPaint(Color.GRAY);
        bStyle.setThickness(3.0);
        bStyle.setShapeEffectRenderer(ShapeEffectRenderer.BASIC_RENDERER);

        RulerStyle rStyle = gStyle.getRulerStyle();
        rStyle.setMajorTickLength(5.0);
        rStyle.setMinorTickLength(2.0);
        rStyle.setTickDensity(0.7f);
        rStyle.setTickThickness(2.0);
        rStyle.setMinorTickPaint(Color.GREEN.darker().darker());
        rStyle.setMajorTickPaint(Color.GREEN.darker().darker());
        rStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
        rStyle.setTextPaint(Color.BLACK);
        rStyle.setTextBackgroundPaint( new Color( 255,255,255,200 ) );

        DataStyle dataStyle = style.getDataStyle();

        SlotStyle positive = dataStyle.createSlotStyle(Slot.FIRST_UPPER);

        positive.setPaint(Color.BLUE);
        positive.setThickness(15);
        positive.setTransparency(1.0f);

        FeatureHolderStyle positiveHolder = positive.createFeatureHolderStyle(new FeatureFilter.And(new FeatureFilter.StrandFilter(
                StrandedFeature.POSITIVE), new FeatureFilter.ByType("CDS")));
        positiveHolder.setToolTipExtractor(new AnnotationExtractor("product"));
        positiveHolder.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW);

        LabelStyle posLabels = positiveHolder.getLabelStyle();
        posLabels.setLabelExtractor(new AnnotationExtractor("gene"));
        posLabels.setShowLabels(true);
        posLabels.setInitialLineLength(50);
        posLabels.setTextPaint(Color.BLUE);
        posLabels.setBackgroundPaint( new Color( 255, 255, 255, 200 ) );

        SlotStyle negative = dataStyle.createSlotStyle(Slot.FIRST_LOWER);

        negative.setPaint(Color.RED);
        negative.setThickness(15);
        negative.setTransparency(1.0f);

        FeatureHolderStyle negativeHolder = negative.createFeatureHolderStyle(new FeatureFilter.And(new FeatureFilter.StrandFilter(
                StrandedFeature.NEGATIVE), new FeatureFilter.ByType("CDS")));
        negativeHolder.setToolTipExtractor(new AnnotationExtractor("product"));
        negativeHolder.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);

        LabelStyle negLabels = negativeHolder.getLabelStyle();
        negLabels.setLabelExtractor(new AnnotationExtractor("gene"));
        negLabels.setShowLabels(true);
        negLabels.setInitialLineLength(50);
        negLabels.setTextPaint(Color.BLUE);
        negLabels.setBackgroundPaint( new Color( 255, 255, 255, 200 ) );

        return style;
	}
}
