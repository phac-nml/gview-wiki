package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.GViewMapListener;
import ca.corefacility.gview.map.gui.action.map.FITMAction;

/**
 * Responsible for creating the "Fit Image to Map" menu item.
 * 
 * @author Eric Marinier
 *
 */
public class FitMapToScreenMenuItem extends JMenuItem implements ActionListener, GViewMapListener
{
	private static final long serialVersionUID = 1L;
	private final GViewGUIFrame gViewGUIFrame;
	
	/**
	 * @param gViewGUIFrame The related GUI frame.
	 */
	public FitMapToScreenMenuItem(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.FMTS_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;
		this.gViewGUIFrame.addGViewMapListener(this);
		
		this.setActionCommand(GUIUtility.FMTS);
		this.setAccelerator(KeyStroke.getKeyStroke(GUIUtility.FMTS_SHORTCUT));
		this.addActionListener(this);
	}

	@Override
	/**
	 * Listens for "Fit Image to Map" actions.
	 */
	public void actionPerformed(ActionEvent e) 
	{
		if (GUIUtility.FMTS.equals(e.getActionCommand()))
		{
			this.gViewGUIFrame.doAction(new FITMAction(gViewGUIFrame.getGViewMap()));
		}		
	}

	@Override
	public void setGViewMap(GViewMap gViewMap)
	{
		// TODO Auto-generated method stub		
	}
}
