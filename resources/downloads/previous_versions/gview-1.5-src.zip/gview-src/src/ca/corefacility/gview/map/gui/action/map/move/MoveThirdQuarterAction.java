package ca.corefacility.gview.map.gui.action.map.move;

import ca.corefacility.gview.map.GViewMap;

/**
 * Move to third quarter action.
 * 
 * Moves the camera to the third quarter of the genome.
 * 
 * @author Eric Marinier
 *
 */
public class MoveThirdQuarterAction extends MoveAction 
{
	private final GViewMap gViewMap;

	/**
	 * 
	 * @param gViewMap The GView map object.
	 */
	public MoveThirdQuarterAction(GViewMap gViewMap)
	{
		super(gViewMap);
		
		if(gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		this.gViewMap = gViewMap;
	}

	@Override
	public void run() 
	{
		this.gViewMap.setCenter((int)Math.round(3.0 * this.gViewMap.getMaxSequenceLength()/4.0));
	}

}
