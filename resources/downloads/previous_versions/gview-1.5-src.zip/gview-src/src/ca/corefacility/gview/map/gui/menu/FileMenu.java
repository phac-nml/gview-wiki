package ca.corefacility.gview.map.gui.menu;

import javax.swing.JMenu;
import javax.swing.JSeparator;

import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;

/**
 * Responsible for creating the File menu.
 * 
 * @author Eric Marinier
 *
 */
public class FileMenu extends JMenu
{
	private static final long serialVersionUID = 1L;
	
	//Items in the File menu.
	private final OpenMenuItem openItem;
	private final ExportMenuItem exportItem;
	private final ExitMenuItem exitItem;
	
	/**
	 * Creates a new FileMenu belonging the the specified frame.
	 * 
	 * @param gViewGUIFrame  The frame this FileMenu belongs to.
	 */
	public FileMenu(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.FILE_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		//Open Menu Item
		this.openItem = new OpenMenuItem(gViewGUIFrame);
		this.add(this.openItem);
		
		//Export Menu Item
		this.exportItem = new ExportMenuItem(gViewGUIFrame);
		this.add(this.exportItem);
		
		this.add(new JSeparator());
		
		//Exit Menu Item
		this.exitItem = new ExitMenuItem(gViewGUIFrame);
		this.add(this.exitItem);
	}
}
