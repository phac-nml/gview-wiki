package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBoxMenuItem;

import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.action.map.hide.HideAllAction;
import ca.corefacility.gview.map.gui.action.map.show.ShowAllAction;

/**
 * Responsible for creating and managing the "Show All" menu item.
 * 
 * @author Eric Marinier
 *
 */
public class ShowAllMenuItem extends JCheckBoxMenuItem implements ItemListener
{
	private static final long serialVersionUID = 1L;
	
	private final GViewGUIFrame gViewGUIFrame;
	
	private boolean updating = false;
	
	/**
	 * Creates a ShowAllMenuItem within the specified frame.
	 * @param gViewGUIFrame  The frame containing the ShowAllMenuItem.
	 */
	public ShowAllMenuItem(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.SHOW_ALL_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;		
		this.addItemListener(this);		
	}

	@Override
	/**
	 * Listens for the menu item.
	 */
	public void itemStateChanged(ItemEvent e)
	{
		if (e.getStateChange() == ItemEvent.SELECTED && !this.updating)
		{
			this.gViewGUIFrame.doAction(new ShowAllAction(this.gViewGUIFrame.getGViewMap().getElementControl()));
		}
		else if (e.getStateChange() == ItemEvent.DESELECTED && !this.updating)
		{
			if(this.gViewGUIFrame.getGViewMap().getElementControl().getAllDisplayed())
			{
				this.gViewGUIFrame.doAction(new HideAllAction(this.gViewGUIFrame.getGViewMap().getElementControl()));
			}
		}
	}
	
	/**
	 * Updates the selected state of the menu item.
	 */
	public void update()
	{
		if(this.gViewGUIFrame.getGViewMap().getElementControl().getAllDisplayed())
		{
			this.updating = true;
			this.setSelected(true);
			this.updating = false;
		}
		else
		{
			this.updating = true;
			this.setSelected(false);
			this.updating = false;
		}			
	}	
}
