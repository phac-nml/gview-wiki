package ca.corefacility.gview.map.gui.editor.node;

import ca.corefacility.gview.map.gui.editor.panel.LegendItemStylePanel;

/**
 * The node class for the legend item styles. Intended to be used within a StyleEditorTree.
 * 
 * @author Eric Marinier
 *
 */
public class LegendItemStyleNode extends StyleEditorNode 
{
	private static final long serialVersionUID = 1L;	//requested by java
	private static final String LEGEND_ITEM_STYLE = "Legend Item Style";
	
	private final LegendItemStylePanel legendItemStylePanel;	//the related legend item style panel
	
	/**
	 * 
	 * @param legendItemStylePanel The related panel.
	 */
	public LegendItemStyleNode(LegendItemStylePanel legendItemStylePanel)
	{
		super(legendItemStylePanel, LEGEND_ITEM_STYLE);
		
		if(legendItemStylePanel == null)
			throw new IllegalArgumentException("LegendItemStylePanel is null");
		
		this.legendItemStylePanel = legendItemStylePanel;		
		this.rename(this.legendItemStylePanel.getLegendText());
	}	
	
	@Override
	public LegendItemStylePanel getPanel() 
	{
		if(this.legendItemStylePanel == null)
			throw new IllegalArgumentException("legendItemStylePanel is null");
		
		return this.legendItemStylePanel;
	}
	
	@Override
	public void saveOccured()
	{
		this.rename(this.legendItemStylePanel.getLegendText());
	}
	
	@Override
	public LegendStyleNode getParent()
	{
		LegendStyleNode parent = null;
		
		if(super.getParent() instanceof LegendStyleNode)
		{
			parent = (LegendStyleNode)super.getParent();
		}
		else if(super.getParent() != null)
		{
			throw new ClassCastException("LegendItemStyleNode's parent is not a LegendStyleNode.");
		}
		
		return parent;
	}
}
