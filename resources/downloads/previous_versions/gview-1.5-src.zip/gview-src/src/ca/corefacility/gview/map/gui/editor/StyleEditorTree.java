package ca.corefacility.gview.map.gui.editor;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.net.MalformedURLException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

import javax.swing.DropMode;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import org.biojava.bio.seq.FeatureFilter;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.editor.featureFilter.FeatureFilterChooserDialog;
import ca.corefacility.gview.map.gui.editor.node.BackboneNode;
import ca.corefacility.gview.map.gui.editor.node.BackboneSlotNode;
import ca.corefacility.gview.map.gui.editor.node.FeatureContainerNode;
import ca.corefacility.gview.map.gui.editor.node.GlobalNode;
import ca.corefacility.gview.map.gui.editor.node.LabelNode;
import ca.corefacility.gview.map.gui.editor.node.LegendItemStyleNode;
import ca.corefacility.gview.map.gui.editor.node.LegendNode;
import ca.corefacility.gview.map.gui.editor.node.LegendStyleNode;
import ca.corefacility.gview.map.gui.editor.node.PlotNode;
import ca.corefacility.gview.map.gui.editor.node.PropertyMapperNode;
import ca.corefacility.gview.map.gui.editor.node.RulerNode;
import ca.corefacility.gview.map.gui.editor.node.SetNode;
import ca.corefacility.gview.map.gui.editor.node.SlotNode;
import ca.corefacility.gview.map.gui.editor.node.Slotable;
import ca.corefacility.gview.map.gui.editor.node.SlotsNode;
import ca.corefacility.gview.map.gui.editor.node.StyleEditorNode;
import ca.corefacility.gview.map.gui.editor.node.TooltipNode;
import ca.corefacility.gview.map.gui.editor.node.RootNode;
import ca.corefacility.gview.map.gui.editor.panel.BackbonePanel;
import ca.corefacility.gview.map.gui.editor.panel.FeatureContainerPanel;
import ca.corefacility.gview.map.gui.editor.panel.GlobalPanel;
import ca.corefacility.gview.map.gui.editor.panel.LabelPanel;
import ca.corefacility.gview.map.gui.editor.panel.LegendItemStylePanel;
import ca.corefacility.gview.map.gui.editor.panel.LegendPanel;
import ca.corefacility.gview.map.gui.editor.panel.LegendStylePanel;
import ca.corefacility.gview.map.gui.editor.panel.PlotPanel;
import ca.corefacility.gview.map.gui.editor.panel.RulerPanel;
import ca.corefacility.gview.map.gui.editor.panel.SaveListener;
import ca.corefacility.gview.map.gui.editor.panel.SetPanel;
import ca.corefacility.gview.map.gui.editor.panel.SlotPanel;
import ca.corefacility.gview.map.gui.editor.panel.SlotsPanel;
import ca.corefacility.gview.map.gui.editor.panel.TooltipPanel;
import ca.corefacility.gview.map.gui.editor.panel.RootPanel;
import ca.corefacility.gview.map.gui.editor.panel.propertyMapper.PropertyMapperPanel;
import ca.corefacility.gview.map.gui.editor.transfer.StyleTransferHandler;
import ca.corefacility.gview.style.GlobalStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureContainerStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.LabelStyle;
import ca.corefacility.gview.style.datastyle.PlotStyle;
import ca.corefacility.gview.style.datastyle.SlotItemStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.datastyle.mapper.PropertyMappable;
import ca.corefacility.gview.style.items.BackboneStyle;
import ca.corefacility.gview.style.items.LegendItemStyle;
import ca.corefacility.gview.style.items.LegendStyle;
import ca.corefacility.gview.style.items.RulerStyle;
import ca.corefacility.gview.style.items.TooltipStyle;
import ca.corefacility.gview.utils.FileLocationHandler;

/**
 * The style editor tree used in the StyleEditorFrame.
 * 
 * @author Eric Marinier
 *
 */
public class StyleEditorTree extends JTree implements MouseListener, SaveListener
{
	private static final long serialVersionUID = 1L;	//requested by java	
	private static final Hashtable<String, Integer> names = new Hashtable<String, Integer>();	//the hash table for used tree names
	
	private static final int BACKBONE = 0;	//the backbone slot number
	private static final int EXPECTED_FILE_NAME_TOKENS = 2;	//used with the string tokenizer b/c of fileName.fileExtension format
	private static final String FILE_EXTENSION_DELIM = ".";	//file extension delimiter
	
	private static final String LEGEND_STYLE = "Legend Style";
	private static final String LEGEND_ITEM_STYLE = "Legend Item Style";
		
	private int legendStyleID = 0;
	private int legendItemStyleID = 0;
	
	private final StyleEditorNode root  = new RootNode(StyleEditorUtility.STYLE_TEXT, new RootPanel());
	private final SlotsNode slotsNode = new SlotsNode(new SlotsPanel());
	private final LegendNode legendNode = new LegendNode(new LegendPanel());
	
	private final DefaultTreeModel treeModel;	//tree model used with the JTree
	
	private final GViewMap gViewMap;	//related GViewMap
	private final StyleEditorFrame styleEditorFrame;	//related style editor frame
	
	private final TreeRightClickMenu rightClickMenu;	//the trees right click menu
	
	private String treeName;	//the name of the tree
	
	/**
	 * Creates a style editor tree. The tree's nodes on creation are determined by the GView map object.
	 * 
	 * @param styleEditorFrame The frame the tree will be sitting on.
	 * @param gViewMap The GViewMap the tree relates to.
	 * @param file The file that the style is from. May be null.
	 */
	public StyleEditorTree(StyleEditorFrame styleEditorFrame, GViewMap gViewMap, URI file)
	{	
		if(styleEditorFrame == null)
			throw new IllegalArgumentException("StyleEditorFrame is null.");
		
		if(gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		this.gViewMap = gViewMap;
		this.styleEditorFrame = styleEditorFrame;
		
		this.setDragEnabled(true);
		this.setDropMode(DropMode.ON_OR_INSERT);
		this.setTransferHandler(new StyleTransferHandler(this));
		this.setScrollsOnExpand(true);
		
		nameTree(file);		
				
		this.treeModel = new DefaultTreeModel(this.root);		
		this.setModel(this.treeModel);
		this.setCellRenderer(new StyleEditorTreeRenderer());
		
		//Only allow for one item to be selected.
		this.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);		
		
		//create the nodes
		createNodesFromMap();		
		
		//Expanding the rows makes it look nicer on startup.
		this.expandPath(getPath(this.root));
		
		this.addTreeSelectionListener(styleEditorFrame);
		
		this.rightClickMenu = new TreeRightClickMenu(this.styleEditorFrame, this);
		this.addMouseListener(this);
	}
	
	/**
	 * Creates a style editor tree. The tree's nodes on creation are determined by the GView map object.
	 * 
	 * @param styleEditorFrame The frame the tree will be sitting on.
	 * @param gViewMap The GViewMap the tree relates to.
	 */
	public StyleEditorTree(StyleEditorFrame styleEditorFrame, GViewMap gViewMap)
	{	
		this(styleEditorFrame, gViewMap, null);
	}
	
	/**
	 * Names the tree appropriately.
	 * 
	 * @param file The file style is from. If null, the default name will be used.
	 */
	private void nameTree(URI file)
	{
		StringTokenizer tokenizer;
		String tempName;
		int number;
		
		if(StyleEditorTree.names == null)
			throw new NullPointerException("Hashtable is null.");
		
		if(file == null)
		{
			tempName = StyleEditorUtility.DEFAULT_STYLE_TREE_NAME;
		}
		else
		{
			try
			{
				tempName = FileLocationHandler.getFileName(file);
			}
			catch (MalformedURLException e)
			{
				tempName = StyleEditorUtility.DEFAULT_STYLE_TREE_NAME;
			}
			catch (IllegalArgumentException e)
			{
				tempName = StyleEditorUtility.DEFAULT_STYLE_TREE_NAME;
			}
		}			
		
		//handle adding the name to the hash table of used names
		// AND appending a number if needed
		if(StyleEditorTree.names.containsKey(tempName))
			//increment the number.. append the number to the file name
		{
			number = StyleEditorTree.names.get(tempName).intValue() + 1;
			StyleEditorTree.names.put(tempName, number);	//update the number
			
			//this is handling where to put the brackets; either before or after the '.'
			// in a file extension.
			if(tempName.equals(StyleEditorUtility.DEFAULT_STYLE_TREE_NAME))
				//default name.. just append to the end
			{
				tempName = tempName + "(" + number + ")";
			}
			else
				//put the '()' before the '.' if it has one
			{
				tokenizer = new StringTokenizer(tempName , FILE_EXTENSION_DELIM);
				
				if(tokenizer.countTokens() == EXPECTED_FILE_NAME_TOKENS)
				//expected format
				{
					tempName = tokenizer.nextToken() + "(" + number + ")" + FILE_EXTENSION_DELIM + tokenizer.nextToken();
				}
				else
				//not of fileName.fileExtension format..
				{
					tempName = tempName + " (" + number + ")";
				}				
			}			
		}
		else
			//just throw the name in as it is and leave the name alone
		{				
			StyleEditorTree.names.put(tempName, 1);
		}
		
		this.treeName = tempName;
		
		if(this.treeName == null)
			throw new NullPointerException("StyleEditorTree's name must be set.");
	}
	
	/**
	 * Creates the tree nodes.
	 */
	private void createNodesFromMap()
	{		
		BackbonePanel backbonePanel = createBackbonePanelFromMap();
		
		createGlobalNodeFromMap(backbonePanel);		
		createSlotNodesFromMap(backbonePanel);
	}
	
	/**
	 * Creates the global node. Adds it to the root node.
	 */
	private void createGlobalNodeFromMap(BackbonePanel backbonePanel)
	{
		GlobalStyle globalStyle = this.gViewMap.getMapStyle().getGlobalStyle();
		GlobalPanel globalPanel = new GlobalPanel(globalStyle);
		GlobalNode globalNode = new GlobalNode(globalPanel);
		
		this.root.add(globalNode);
		
		createBackboneNodeFromMap(globalNode, backbonePanel);
		createLegendNodeFromMap(globalNode);
		createRulerNodeFromMap(globalNode);
		createTooltipNodeFromMap(globalNode);
	}
	
	/**
	 * Creates the backbone panel.
	 * 
	 * @return  The BackbonePanel
	 */
	private BackbonePanel createBackbonePanelFromMap()
	{			
		BackboneStyle backboneStyle = this.gViewMap.getMapStyle().getGlobalStyle().getBackboneStyle();
		BackbonePanel backbonePanel = new BackbonePanel(backboneStyle);
		
		return backbonePanel;
	}
	
	/**
	 * Creates the backbone node. Adds it to the global node.
	 * 
	 * @param globalNode The global node to add the backbone node to.
	 */
	private void createBackboneNodeFromMap(GlobalNode globalNode, BackbonePanel backbonePanel)
	{
		if(globalNode == null)
			throw new IllegalArgumentException("GlobalNode is null.");
		
		BackboneNode backboneNode = new BackboneNode(backbonePanel);	
		
		globalNode.add(backboneNode);
	}
	
	/**
	 * Creates the ruler node. Adds it to the global node.
	 * 
	 * @param globalNode The global node to add the ruler node to.
	 */
	private void createRulerNodeFromMap(GlobalNode globalNode)
	{
		if(globalNode == null)
			throw new IllegalArgumentException("GlobalNode is null.");
		
		RulerStyle rulerStyle = this.gViewMap.getMapStyle().getGlobalStyle().getRulerStyle();
		RulerPanel rulerPanel = new RulerPanel(rulerStyle);
		RulerNode rulerNode = new RulerNode(rulerPanel);
		
		globalNode.add(rulerNode);
	}
	
	/**
	 * Creates the tool tip node. Adds it to the global node.
	 * 
	 * @param globalNode The global node to add the tool tip node to.
	 */
	private void createTooltipNodeFromMap(GlobalNode globalNode)
	{
		if(globalNode == null)
			throw new IllegalArgumentException("GlobalNode is null.");
		
		TooltipStyle tooltipStyle = this.gViewMap.getMapStyle().getGlobalStyle().getTooltipStyle();
		TooltipPanel tooltipPanel = new TooltipPanel(tooltipStyle);
		TooltipNode tooltipNode = new TooltipNode(tooltipPanel);
		
		globalNode.add(tooltipNode);
	}
	
	/**
	 * Creates the legend node. Adds it to the global node.
	 * 
	 * @param globalNode The global node to add the legend node to.
	 */
	private void createLegendNodeFromMap(GlobalNode globalNode)
	{	
		if(globalNode == null)
			throw new IllegalArgumentException("GlobalNode is null.");
		
		globalNode.add(this.legendNode);
		
		createLegendStyleNodesFromMap(this.legendNode);
	}
	
	/**
	 * Creates the legend style nodes. Adds them to the legend node.
	 * 
	 * @param legendNode The node to add the legend style nodes to.
	 */
	private void createLegendStyleNodesFromMap(LegendNode legendNode)
	{
		if(legendNode == null)
			throw new IllegalArgumentException("LegendNode is null.");
		
		LegendStyle legendStyle;
		LegendStylePanel legendPanel;
		LegendStyleNode legendStyleNode;
		
		GlobalStyle globalStyle = this.gViewMap.getMapStyle().getGlobalStyle();
		Iterator<LegendStyle> legendStyles = globalStyle.legendStyles();				
		
		while (legendStyles.hasNext())
		{
			legendStyle = legendStyles.next();
			legendPanel = new LegendStylePanel(legendStyle);
			legendStyleNode = new LegendStyleNode(legendPanel);
			
			//update name
			legendStyleNode.rename(LEGEND_STYLE + " " + giveLegendStyleID());
			
			legendNode.add(legendStyleNode);
			
			createLegendItemStyleNodesFromMap(legendStyleNode, legendStyle);
		}
	}
	
	/**
	 * Creates the legend item style nodes. Adds them to the passed legend style node.
	 * 
	 * @param legendStyleNode The node to add the legend item style nodes to.
	 * @param legendStyle The corresponding legend style information.
	 */
	private void createLegendItemStyleNodesFromMap(LegendStyleNode legendStyleNode, LegendStyle legendStyle)
	{
		if(legendStyleNode == null)
			throw new IllegalArgumentException("LegendStyleNode is null.");
		
		if(legendStyle == null)
			throw new IllegalArgumentException("LegendStyle is null.");
		
		LegendItemStyle legendItemStyle;
		LegendItemStylePanel legendItemStylePanel;
		LegendItemStyleNode legendItemStyleNode;
		
		Iterator<LegendItemStyle> legendItemStyles = legendStyle.legendItems();		
		
		while(legendItemStyles.hasNext())
		{
			legendItemStyle = legendItemStyles.next();
			legendItemStylePanel = new LegendItemStylePanel(legendItemStyle, legendStyle);
			legendItemStylePanel.addSaveListener(this);			
			legendItemStyleNode = new LegendItemStyleNode(legendItemStylePanel);
			
			legendStyleNode.add(legendItemStyleNode);
		}
	}
	
	/**
	 * Creates the slot nodes. Adds the slot nodes to the root node.
	 */
	private void createSlotNodesFromMap(BackbonePanel backbonePanel)
	{
		SlotStyle currentSlotStyle;
		SlotNode currentSlotNode;
		
		Iterator<SlotStyle> slotStyles = this.gViewMap.getMapStyle().getDataStyle().slots();		
		Iterator<SlotItemStyle> slotItemStyles;
		
		this.root.add(this.slotsNode);
		this.slotsNode.add(new BackboneSlotNode(backbonePanel));
		
		while(slotStyles.hasNext())
		{
			currentSlotStyle = slotStyles.next();
			currentSlotNode = createSlotNodeFromStyle(currentSlotStyle);
			
			this.slotsNode.add(currentSlotNode);			
			
			//create feature holder style or plot style nodes
			slotItemStyles = currentSlotStyle.styles();
			createRecursiveSetNodes(slotItemStyles, currentSlotNode);		
		}
		
		//sort
		sortSlotableNodes();
	}
	
	/**
	 * Creates an appropriate label style node under the feature container node.
	 * The label style is pulled from feature container's panel's style.
	 * 
	 * @param node The node to add the label style node to.
	 */
	private void createLabelStyleNode(FeatureContainerNode node)
	{
		if(node == null)
			throw new IllegalArgumentException("FeatureContainerNode is null.");
		
		if(!node.containsLabelStyleNode())
		//if it doesnt contain a label style node already
		{
			LabelStyle labelStyle = node.getPanel().getStyle().getLabelStyle();
			LabelPanel labelPanel = new LabelPanel(labelStyle);
			LabelNode labelNode = new LabelNode(labelPanel);		
			
			node.add(labelNode);
			labelNode.update();
		}
	}
	
	/**
	 * Recursive method for building set nodes.
	 * 
	 * @param sets The iterator of sets to recurse through.
	 * @param topNode The node to add the iterator sets to.
	 */
	private void createRecursiveSetNodes(Iterator<SlotItemStyle> sets, StyleEditorNode topNode)
	{
		if(sets == null)
			throw new IllegalArgumentException("Iterator<SlotItemStyle> is null.");
		
		if(topNode == null)
			throw new IllegalArgumentException("StyleEditorNode topNode is null.");
		
		SlotItemStyle currentItemStyle;
		
		PlotStyle plotStyle;
		PlotNode plotNode;
		
		FeatureHolderStyle setStyle;
		SetNode setNode;		
		
		while(sets.hasNext())
		{
			currentItemStyle = sets.next();
			
			//Plot Style
			if(currentItemStyle instanceof PlotStyle)
			{
				plotStyle = (PlotStyle)currentItemStyle;
				plotNode = createPlotNode(plotStyle);
				
				topNode.add(plotNode);
			}
			//Feature Holder Style
			else if(currentItemStyle instanceof FeatureHolderStyle)
			{	
				setStyle = (FeatureHolderStyle)currentItemStyle;
				setNode = createSetNode(setStyle);
				
				topNode.add(setNode);				
				
				//sub nodes		
				createRecursiveSetNodes(((FeatureHolderStyle) currentItemStyle).styles(), setNode);
			}
		}
	}
	
	/**
	 * Creates a plot node from the plot style.
	 * 
	 * @param plotStyle The plot style to create the node from.
	 * @return The create plot node.
	 */
	private PlotNode createPlotNode(PlotStyle plotStyle)
	{
		if(plotStyle == null)
			throw new IllegalArgumentException("PlotStyle is null.");
		
		PlotPanel plotPanel = new PlotPanel(plotStyle);
		PlotNode plotNode = new PlotNode(plotPanel);
		
		return plotNode;
	}
	
	/**
	 * Updates all of the nodes in the tree, which will forward the message to their panels.
	 */
	public void updateTree()
	{
		@SuppressWarnings("unchecked")
		Enumeration<StyleEditorNode> nodes = this.root.breadthFirstEnumeration();	
		
		while(nodes.hasMoreElements())
		{
			nodes.nextElement().update();
		}
	}
	
	/**
	 * 
	 * @return The top node of the tree.
	 */
	public StyleEditorNode getTop()
	{
		if(this.root == null)
			throw new NullPointerException("StyleTree's root is null.");
		
		return this.root;
	}	
	
	/**
	 * Checks to make sure that all children of the tree and style editor nodes
	 * and returns a breadth first enumeration of the nodes.
	 */
	@SuppressWarnings("unchecked")
	public Enumeration<StyleEditorNode> breadthFirstEnumeration()
	{
		 Enumeration<Object> objectEnum = this.root.breadthFirstEnumeration();		
		 
		 while(objectEnum.hasMoreElements())
		 {
			 if(!(objectEnum.nextElement() instanceof StyleEditorNode))
			 {
				 throw new ClassCastException("Non-StyleEditorNode a child of StyleEditorTree.");
			 }
		 }
		 
		 return this.root.breadthFirstEnumeration();
	 }
	
	/**
	 * Adds the slotable node to the root node.
	 * 
	 * @param slotableNode The slotable node to add.
	 */
	private void addSlotableNode(Slotable slotableNode)
	{
		if(slotableNode == null)
			throw new IllegalArgumentException("SlotableNode is null.");
		
		this.treeModel.insertNodeInto(slotableNode, this.slotsNode, this.slotsNode.getChildCount());
		updateSlotableNodes();
	}
	
	/**
	 * Adds the set node to the passed parent node.
	 * 
	 * @param setNode The set node to add.
	 * @param parentNode The parent node to add the set node to.
	 */
	private void addSetNode(SetNode setNode, FeatureContainerNode parentNode)
	{
		if(setNode == null)
			throw new IllegalArgumentException("SetNode is null.");
		
		if(parentNode == null)
			throw new IllegalArgumentException("FeatureContainerNode is null.");
		
		this.treeModel.insertNodeInto(setNode, parentNode, parentNode.getChildCount());
	}
	
	/**
	 * Adds the plot node to the passed parent node.
	 * 
	 * @param plotNode The plot node to add.
	 * @param parentNode The parent node to add the plot node to.
	 */
	private void addPlotNode(PlotNode plotNode, SlotNode parentNode)
	{
		if(plotNode == null)
			throw new IllegalArgumentException("PlotNode is null.");
		
		if(parentNode == null)
			throw new IllegalArgumentException("StyleEditorNode is null.");
		
		this.treeModel.insertNodeInto(plotNode, parentNode, parentNode.getChildCount());
	}
	
	/**
	 * Creates a new, default and empty slot node and adds it to the root node.
	 */
	public void createSlotNode()
	{
		DataStyle dataStyle = this.gViewMap.getMapStyle().getDataStyle();
		
		SlotStyle slotStyle;
		SlotNode slotNode;
		
		int slotNumber;
		String tempNumber;
		
		boolean finished = false;
		
		int lowerBounds = this.gViewMap.getMapStyle().getDataStyle().getLowerSlot() - 1;
		int upperBounds = this.gViewMap.getMapStyle().getDataStyle().getUpperSlot() + 1;
		
		while (!finished)
		{
			tempNumber = JOptionPane.showInputDialog(this.styleEditorFrame,
					"Enter a slot number from " + lowerBounds + " to " + upperBounds + ":", upperBounds);
			
			if (tempNumber != null)
			{
				try
				{
					slotNumber = Integer.parseInt(tempNumber);			
				
					if(validSlotNumber(slotNumber))
					{
						finished = true;
						slotStyle = dataStyle.createSlotStyle(slotNumber);
						slotNode = createSlotNodeFromStyle(slotStyle);
						
						addSlotableNode(slotNode);	
					}			
				}
				catch(NumberFormatException e)
				{
					JOptionPane.showMessageDialog(this.styleEditorFrame, "Unrecognized integer \"" + tempNumber + "\".");
				}
			}
			else
			{
				finished = true;
			}
		}
	}
	
	/**
	 * Verifies if the slot number is valid.
	 * 
	 * @param slotNumber The slot number to verify.
	 * 
	 * @return Whether or not the slot number is valid.
	 */
	private boolean validSlotNumber(int slotNumber)
	{		
		boolean result = true;
		//inclusive
		int lowerBounds = this.gViewMap.getMapStyle().getDataStyle().getLowerSlot() - 1;
		int upperBounds = this.gViewMap.getMapStyle().getDataStyle().getUpperSlot() + 1;
		
		if(slotNumber < lowerBounds || slotNumber > upperBounds)
		{
			result = false;
			
			JOptionPane.showMessageDialog(this.styleEditorFrame, "Slot=" + slotNumber + " out of range of [" + lowerBounds 
					+ ", " + upperBounds + "]");
		}
		else if(slotNumber == 0)
		{
			result = false;
			
			JOptionPane.showMessageDialog(this.styleEditorFrame, "The slot number cannot be zero.");
		}
		
		return result;
	}
	
	/**
	 * Creates a set node under the passed parent node.
	 * 
	 * @param parentNode The node to add the set node to.
	 */
	public void createSetNode(FeatureContainerNode parentNode)
	{
		if(parentNode == null)
			throw new IllegalArgumentException("StyleEditorNode is null.");
		
		if(parentNode.canAddSetNodeAsChild())
		{
			(new FeatureFilterChooserDialog(this, parentNode)).showDialog(this.styleEditorFrame);
		}
		else
		{
			JOptionPane.showMessageDialog(this.styleEditorFrame, "Cannot add set node.");
		}
	}
	
	/**
	 * Creates a set node from the passed feature filter and adds it under the passed parent node.
	 * 
	 * @param parentNode The parent node of the new set node.
	 * @param featureFilter The feature filter to use in the new set node.
	 */
	public void createSetNodeFromFeatureFilter(FeatureContainerNode parentNode, FeatureFilter featureFilter)
	{
		if(parentNode == null)
			throw new IllegalArgumentException("StyleEditorNode is null.");
		
		if(featureFilter == null)
			throw new IllegalArgumentException("FeatureFilter is null.");
		
		FeatureHolderStyle setStyle;
		SetNode setNode;
		
		if(parentNode.canAddSetNodeAsChild())
		{
			setStyle = parentNode.createFeatureHolderStyle(featureFilter);
			setNode = createSetNode(setStyle);
			addSetNode(setNode, parentNode);
		}
	}
	
	/**
	 * Creates a set node from the passed feature holder style.
	 * 
	 * @param featureHolderStyle The style to build the set node from.
	 * @return The created set node.
	 */
	private SetNode createSetNode(FeatureHolderStyle featureHolderStyle)
	{
		if(featureHolderStyle == null)
			throw new IllegalArgumentException("FeatureHolderStyle is null.");
		
		SetPanel setPanel = new SetPanel(featureHolderStyle);
		SetNode setNode = new SetNode(setPanel);
		setNode.update();
		
		createLabelStyleNode(setNode);
		
		if(featureHolderStyle.getPropertyStyleMapper() != null)
		{
			createPropertyMapper(setNode);
		}
		
		return setNode;
	}

	/**
	 * Creates a new default plot node and adds it to the passed slot node.
	 * 
	 * @param slotNode The slot node to add the plot node to.
	 */
	public void createPlotNode(SlotNode slotNode)
	{
		if(slotNode == null)
			throw new IllegalArgumentException("SlotNode is null.");
		
		PlotStyle plotStyle;
		PlotPanel plotPanel;
		PlotNode plotNode;
		
		SlotPanel slotPanel = slotNode.getPanel();		
		SlotStyle slotStyle;
		
		//if the slot node contains no plot node AND no set node(s) as a child already
		if(!slotNode.containsPlotNode() && !slotNode.containsSetNode())			
		{
			plotStyle = new PlotStyle();			
			slotPanel = slotNode.getPanel();
			
			StyleEditorUtility.setPlotStyleDefaults(plotStyle);	
			
			slotStyle = slotPanel.getStyle();
			slotStyle.addStyleItem(plotStyle);
			
			plotPanel = new PlotPanel(plotStyle);
			plotNode = new PlotNode(plotPanel);
			
			plotNode.update();
			
			addPlotNode(plotNode, slotNode);
		}	
		//there is a plot node already as a child of the slot node
		else
		{
			JOptionPane.showMessageDialog(this.styleEditorFrame, "The slot node already contains a plot node or set nodes.");
		}
	}
	
	/**
	 * Sorts the slot nodes in the tree according to their slot number.
	 * 
	 * Should only really be called by updateSlotableNodes().
	 */
	private void sortSlotableNodes()
	{
		Enumeration<Slotable> nodes = this.slotsNode.children();
		Slotable currentNode;
		
		ArrayList<Slotable> slotNodeList = new ArrayList<Slotable>();
		
		//remove slot nodes from tree; insert them (sorted) into array list
		while(nodes.hasMoreElements())
		{
			currentNode = nodes.nextElement();			
			slotNodeList.add(currentNode);
		}
		
		//remove
		for(int i = 0; i < slotNodeList.size(); i++)
			this.treeModel.removeNodeFromParent(slotNodeList.get(i));
		
		//sort
		Slotable[] slotNodeArray = new Slotable[slotNodeList.size()];
		Arrays.sort(slotNodeList.toArray(slotNodeArray), StyleTransferHandler.getSlotsComparator());
		
		//re-add the nodes
		for(int i = 0; i < slotNodeArray.length; i++)
		{
			this.treeModel.insertNodeInto(slotNodeArray[i], this.slotsNode, this.slotsNode.getChildCount());
		}
		
		this.expandPath(getPath(this.slotsNode));
	}
	
	/**
	 * Removes the slot node from the tree.
	 * 
	 * @param slotNode The slot node to remove.
	 */
	public void removeSlotNode(SlotNode slotNode)
	{	
		if(slotNode == null)
			throw new IllegalArgumentException("SlotNode is null.");
		
		DataStyle dataStyle = this.gViewMap.getMapStyle().getDataStyle();
		
		SlotPanel slotPanel = slotNode.getPanel();
		SlotStyle slotStyle = slotPanel.getStyle();
		
		dataStyle.removeSlotStyle(slotStyle);
		updateSlotableNodes();	
		
		selectNodesParent(slotNode);
		this.treeModel.removeNodeFromParent(slotNode);
	}
	
	/**
	 * Removes the plot node from the tree.
	 * 
	 * @param plotNode The plot node to remove.
	 */
	public void removePlotNode(PlotNode plotNode)
	{
		if(plotNode == null)
			throw new IllegalArgumentException("PlotNode is null.");
		
		SlotNode slotNode = plotNode.getParent();
		SlotPanel slotPanel = slotNode.getPanel();
		SlotStyle slotStyle = slotPanel.getStyle();		
		
		PlotPanel plotPanel = plotNode.getPanel();
		PlotStyle plotStyle = plotPanel.getPlotStyle();		
		
		slotStyle.removeSlotItemStyle(plotStyle);
		selectNodesParent(plotNode);
		this.treeModel.removeNodeFromParent(plotNode);
	}
	
	/**
	 * Removes the set node from the tree.
	 * 
	 * @param setNode The set node to remove.
	 */
	public void removeSetNode(SetNode setNode)
	{
		if(setNode == null)
			throw new IllegalArgumentException("SetNode is null.");
		
		FeatureContainerNode parentNode = setNode.getParent();
		FeatureContainerPanel parentPanel = parentNode.getPanel();
		FeatureContainerStyle parentStyle = parentPanel.getStyle();
		
		SetPanel setPanel = setNode.getPanel();
		FeatureHolderStyle setStyle = setPanel.getStyle();
		
		parentStyle.removeSlotItemStyle(setStyle);
		selectNodesParent(setNode);
		this.treeModel.removeNodeFromParent(setNode);
	}
	
	/**
	 * Creates a new default legend node and adds it to the tree under the legend node.
	 * Adds the new legend style to the GView map.
	 */
	public void createLegendNode()
	{
		LegendStyle legendStyle = new LegendStyle();
		LegendStylePanel legendStylePanel = new LegendStylePanel(legendStyle);
		LegendStyleNode legendStyleNode = new LegendStyleNode(legendStylePanel);
		
		if(this.legendNode == null)
		{
			throw new NullPointerException("LegendNode is null.");
		}
		else if(this.gViewMap == null)
		{
			throw new NullPointerException("GViewMap is null.");
		}
		else
		{
			//update name
			legendStyleNode.rename(LEGEND_STYLE + " " + giveLegendStyleID());
			
			//add to tree
			addLegendStyleNode(legendStyleNode);
			
			//add to map
			this.gViewMap.getMapStyle().getGlobalStyle().addLegendStyle(legendStyle);
		}
	}
	
	/**
	 * Adds the legend style node to the tree as appropriate.
	 * @param legendStyleNode The node to add.
	 */
	private void addLegendStyleNode(LegendStyleNode legendStyleNode)
	{
		if(legendStyleNode == null)
		{
			throw new IllegalArgumentException("LegendStyleNode is null.");
		}
		else
		{
			this.treeModel.insertNodeInto(legendStyleNode, this.legendNode, this.legendNode.getChildCount());			
		}
	}
	
	/**
	 * Creates a default legend item style node and adds it under the passed parent node.
	 * Adds the legend item style to the GView map.
	 * 
	 * @param parentNode The parent node of the new legend item style node.
	 */
	public void createLegendItemNode(LegendStyleNode parentNode)
	{
		if(parentNode == null)
		{
			throw new IllegalArgumentException("Parent node is null");
		}
		else if(this.gViewMap == null)
		{
			throw new NullPointerException("GViewMap is null.");
		}
		else
		{
			LegendStyle legendStyle = pullLegendStyle(parentNode);	
			
			LegendItemStyle legendItemStyle;
			LegendItemStylePanel legendItemStylePanel;
			LegendItemStyleNode legendItemStyleNode;
			
			if(legendStyle == null)
			{
				throw new NullPointerException("LegendStyle is null.");
			}
			else
			{
				//create the node
				legendItemStyle = new LegendItemStyle();
				legendItemStyle.setText(LEGEND_ITEM_STYLE + " " + giveLegendItemStyleID());
				
				legendItemStylePanel = new LegendItemStylePanel(legendItemStyle, legendStyle);
				legendItemStylePanel.addSaveListener(this);
				legendItemStyleNode = new LegendItemStyleNode(legendItemStylePanel);
				
				//add the node to the tree
				addLegendItemStyleNode(legendItemStyleNode, parentNode);
				
				//add to gview map
				legendStyle.addLegendItem(legendItemStyle);
			}
		}
	}
	
	/**
	 * Pulls the legend style from the legend style node.
	 * 
	 * @param legendStyleNode The node to pull the style from.
	 * @return The pulled legend style.
	 */
	private LegendStyle pullLegendStyle(LegendStyleNode legendStyleNode)
	{		
		LegendStyle legendStyle = legendStyleNode.getPanel().getLegendStyle();
		
		if(legendStyle == null)
		{
			throw new NullPointerException("LegendStyle is null.");
		}
		
		return legendStyle;
	}
	
	/**
	 * Adds the legend item style node to the tree as appropriate.
	 * @param legendItemStyleNode The node to add.
	 * @param parentNode The parent node of the legend item style node.
	 */
	private void addLegendItemStyleNode(LegendItemStyleNode legendItemStyleNode, LegendStyleNode parentNode)
	{
		if(legendItemStyleNode == null)
		{
			throw new IllegalArgumentException("LegendItemStyleNode is null.");
		}
		else if(parentNode == null)
		{
			throw new IllegalArgumentException("Parent node is null.");
		}
		else
		{
			this.treeModel.insertNodeInto(legendItemStyleNode, parentNode, parentNode.getChildCount());			
		}
	}
	
	
	/**
	 * Removes the legend style node from the tree.
	 * Removes the legend style from the GView map.
	 * 
	 * @param legendStyleNode The node to remove.
	 */
	public void removeLegend(LegendStyleNode legendStyleNode)
	{
		if(this.gViewMap == null)
		{
			throw new NullPointerException("GViewMap is null.");
		}
		else if(legendStyleNode == null)
		{
			throw new IllegalArgumentException("LegendStyleNode is null.");
		}
		else
		{
			LegendStylePanel legendStylePanel = legendStyleNode.getPanel();
			LegendStyle legendStyle = legendStylePanel.getLegendStyle();
			
			//remove from gview map
			if(this.gViewMap.getMapStyle().getGlobalStyle().removeLegendStyle(legendStyle) == true)				
			{
				//successful remove
				selectNodesParent(legendStyleNode);
				this.treeModel.removeNodeFromParent(legendStyleNode);				
			}			
		}			
	}
	
	public void removeLegendItem(LegendItemStyleNode legendItemStyleNode)
	{
		if(this.gViewMap == null)
		{
			throw new NullPointerException("GViewMap is null.");
		}
		else if(legendItemStyleNode == null)
		{
			throw new IllegalArgumentException("LegendStyleNode is null.");
		}
		else
		{			
			
			LegendStyleNode parentNode = legendItemStyleNode.getParent();
			LegendStyle legendStyle = pullLegendStyle(parentNode);
			
			LegendItemStylePanel legendItemStylePanel = legendItemStyleNode.getPanel();
			LegendItemStyle legendItemStyle = legendItemStylePanel.getLegendStyle();
			
			//remove from gview map
			if(legendStyle.removeLegendItem(legendItemStyle))				
			{
				//successful remove
				selectNodesParent(legendItemStyleNode);
				this.treeModel.removeNodeFromParent(legendItemStyleNode);
			}		
		}
	}
	
	/**
	 * Returns the tree model.
	 * 
	 * @return The tree model.
	 */
	public DefaultTreeModel getTreeModel()
	{
		if(this.treeModel == null)
			throw new NullPointerException("TreeModel is null.");
		
		return this.treeModel;
	}
	
	/**
	 * Returns the name of the tree.
	 * 
	 * @return The name of the tree.
	 */
	public String getTreeName()
	{
		if(this.treeName == null)
			this.treeName = StyleEditorUtility.DEFAULT_STYLE_TREE_NAME;
		
		return this.treeName;
	}
	
	/**
	 * Sets the name of the style tree. 
	 * This will not update any graphical components that rely on the style tree's name.
	 * 
	 * @param name The name to set.
	 */
	public void setTreeName(String name)
	{
		int number;
		
		if(name != null)
		{
			this.treeName = name;
			
			//insert the new name into the hash table
			if(StyleEditorTree.names.containsKey(name))
			{
				number = StyleEditorTree.names.get(name).intValue() + 1;
				StyleEditorTree.names.put(name, number);		
			}
			else
			{				
				StyleEditorTree.names.put(name, 1);
			}			
		}
	}
	
	/**
	 * Returns the GViewMap used.
	 * 
	 * @return The GViewMap used.
	 */
	public GViewMap getGViewMap()
	{
		if(this.gViewMap == null)
			throw new NullPointerException("GViewMap is null.");
		
		return this.gViewMap;
	}
	
	/**
	 * Moves the source slot to the destination slot. The source slot will replace the destination slot's position
	 * and the destination slot and all slots farther away from the backbone will be pushed away one slot. The gap that
	 * was created from moving the source slot will be collapsed as appropriate.
	 * 
	 * @param source The slot number of the source slot.
	 * @param destination The slot number of the destination slot.
	 * @return The result of the move.
	 */
	public boolean moveSlot(int source, int destination)
	{	
		boolean result = false;		
		
		//backbone source
		if(source == BACKBONE && validSlotNumber(destination) && source != destination)
		{
			this.gViewMap.getMapStyle().getDataStyle().moveBackbone(destination);
			updateSlotableNodes();
			
			result = true;
		}
		//non-backbone source
		else if(validSlotNumber(source) && validSlotNumber(destination) && source != destination)
		{
			this.gViewMap.getMapStyle().getDataStyle().moveSlot(source, destination);
			updateSlotableNodes();		
			
			result = true;
		}		
		
		return result;
	}
	
	/**
	 * Updates all slotable nodes under slots node in the tree and sorts 
	 * them so they remain in order.
	 */
	private void updateSlotableNodes()
	{
		Enumeration<Slotable> slotsNodeChildren = this.slotsNode.children();
		Slotable tempSlotableNode;
		
		//update slot node names
		while(slotsNodeChildren.hasMoreElements())
		{
			tempSlotableNode = slotsNodeChildren.nextElement();
			tempSlotableNode.updateName();
		}
		
		//sort nodes
		sortSlotableNodes();
	}
	
	/**
	 * Creates a slot node from the passed slot style.
	 * 
	 * @param slotStyle The slot style to create the node from.
	 * @return The created slot node.
	 */
	private SlotNode createSlotNodeFromStyle(SlotStyle slotStyle)
	{
		if(slotStyle == null)
			throw new IllegalArgumentException("SlotStyle is null.");		
		
		SlotPanel slotPanel = new SlotPanel(slotStyle);
		SlotNode slotNode = new SlotNode(slotPanel);
		
		if(slotStyle.getPropertyStyleMapper() != null)
		{
			createPropertyMapper(slotNode);	
		}
		
		createLabelStyleNode(slotNode);
		slotNode.update();
		
		return slotNode;		
	}
	
	// Returns a TreePath containing the specified node.
	public TreePath getPath(TreeNode node) {
	    List<TreeNode> list = new ArrayList<TreeNode>();

	    // Add all nodes to list
	    while (node != null) {
	        list.add(node);
	        node = node.getParent();
	    }
	    Collections.reverse(list);

	    // Convert array of nodes to TreePath
	    return new TreePath(list.toArray());
	}

	/**
	 * Moves the location of the source legend item style to the destination.
	 * 
	 * @param sourceLegendStyleIndex The source legend style index of the node to move.
	 * @param sourceLegendItemStyleIndex The source legend item style index of the node to move.
	 * @param destinationLegendStyleIndex The destination legend style index of the node to move.
	 * @param destinationLegendItemStyleIndex The destination legend item style index of the node to move.
	 * @return The result of the transfer.
	 */
	public boolean moveLegendItemStyle(int sourceLegendStyleIndex,
			int sourceLegendItemStyleIndex, int destinationLegendStyleIndex,
			int destinationLegendItemStyleIndex)
	{
		boolean result = false;
		
		GlobalStyle globalStyle = this.gViewMap.getMapStyle().getGlobalStyle();
		
		LegendStyleNode sourceLegendStyleNode;
		LegendStyleNode destinationLegendStyleNode;
		LegendItemStyleNode sourceLegendItemStyleNode;	
		
		//Check for valid indices
		if(sourceLegendStyleIndex < this.legendNode.getChildCount() 
				&& destinationLegendStyleIndex < this.legendNode.getChildCount()
				&& sourceLegendStyleIndex >= 0 && destinationLegendStyleIndex >= 0)
		{
			//grab the parent nodes
			sourceLegendStyleNode = (LegendStyleNode)this.legendNode.getChildAt(sourceLegendStyleIndex);
			destinationLegendStyleNode = (LegendStyleNode)this.legendNode.getChildAt(destinationLegendStyleIndex);
			
			//null check and index check
			if(sourceLegendStyleNode != null && destinationLegendStyleNode != null
					&& sourceLegendItemStyleIndex < sourceLegendStyleNode.getChildCount()
					&& destinationLegendItemStyleIndex <= destinationLegendStyleNode.getChildCount() // <= (less than or equal) so that we can add to an empty node
					&& sourceLegendItemStyleIndex >= 0 && destinationLegendItemStyleIndex >= 0)	
			{
				//grab the actual node to move
				sourceLegendItemStyleNode = (LegendItemStyleNode)sourceLegendStyleNode.getChildAt(sourceLegendItemStyleIndex);
				
				//perform the move internally
				globalStyle.moveLegendItemStyle(sourceLegendStyleIndex, sourceLegendItemStyleIndex, destinationLegendStyleIndex,
						destinationLegendItemStyleIndex);
				
				//move the nodes themselves
				this.treeModel.removeNodeFromParent(sourceLegendItemStyleNode);
				
				if(sourceLegendStyleIndex == destinationLegendStyleIndex && sourceLegendItemStyleIndex <= destinationLegendItemStyleIndex)
				{
					//adjust the destination index because of the remove (one less item now)
					//but ONLY if the source is less than or equal to the destination
					this.treeModel.insertNodeInto(sourceLegendItemStyleNode, destinationLegendStyleNode, destinationLegendItemStyleIndex - 1);
				}
				else
				{
					//normal
					this.treeModel.insertNodeInto(sourceLegendItemStyleNode, destinationLegendStyleNode, destinationLegendItemStyleIndex);
				}
				
				result = true;
			}
		}		
		
		return result;
	}
	
	/**
	 * Removes the property mapper node from its parent node and from its slot style or feature holder style.
	 * 
	 * @param propertyMapperNode The node to remove.
	 */
	public void removePropertyMapper(PropertyMapperNode propertyMapperNode)
	{
		FeatureContainerNode parentNode;
		FeatureContainerPanel parentPanel;
		FeatureContainerStyle parentStyle;
		
		if(propertyMapperNode == null)
		{
			throw new IllegalArgumentException("PropertyMapperNode is null.");
		}
		else
		{
			parentNode = propertyMapperNode.getParent();			
			parentPanel = parentNode.getPanel();
			parentStyle = parentPanel.getStyle();
			
			parentStyle.removePropertyMapper();
			selectNodesParent(propertyMapperNode);
			this.treeModel.removeNodeFromParent(propertyMapperNode);
		}
	}

	/**
	 * Creates the property mapper under the set node and adds it to the set node's feature holder style.
	 * 
	 * @param node The set node to add the property mapper to.
	 */
	public void createPropertyMapper(FeatureContainerNode node)
	{
		if(node == null)
			throw new IllegalArgumentException("FeatureContainerNode is null.");
		
		FeatureContainerStyle style = node.getPanel().getStyle();			
		PropertyMapperNode propertyMapperNode;
		
		if(!node.containsPropertyMapper())
		{
			propertyMapperNode = createPropertyMapperNode(style);
			this.treeModel.insertNodeInto(propertyMapperNode, node, 0);
		}
	}
	
	/**
	 * Creates a property mapper node from a property mappable style.
	 * 
	 * @param propertyMappable A style that is property mappable.
	 * @return The newly created property mapper node.
	 */
	private PropertyMapperNode createPropertyMapperNode(PropertyMappable propertyMappable)
	{
		PropertyMapperPanel propertyMapperPanel = new PropertyMapperPanel(propertyMappable);
		PropertyMapperNode propertyMapperNode = new PropertyMapperNode(propertyMapperPanel);
		
		return propertyMapperNode;
	}

	/**
	 * Sets the trees selection to the passed node's parent.
	 * 
	 * In the unlikely circumstance that the node's parent is null (which is shouldn't be), 
	 * the root node is selected instance.
	 * 
	 * @param node The node whose parent should be selected.
	 */
	private void selectNodesParent(TreeNode node)
	{
		//Change selection to the node's parent
		if(node.getParent() != null)
			this.setSelectionPath(this.getPath(node.getParent()));
		else if(this.root != null)
			this.setSelectionPath(this.getPath(this.root));
	}
	
	/**
	 * 
	 * @return The next available legend style ID.
	 */
	private int giveLegendStyleID()
	{
		this.legendStyleID++;
		return this.legendStyleID;		
	}
	
	/**
	 * 
	 * @return The next available legend item style ID.
	 */
	private int giveLegendItemStyleID()
	{
		this.legendItemStyleID++;
		return this.legendItemStyleID;	
	}
	
	//---------- Listeners ----------//
	
	@Override
	public void mousePressed(MouseEvent e) 
	{
        maybeShowPopup(e);
    }

	@Override
    public void mouseReleased(MouseEvent e) 
	{
        maybeShowPopup(e);
    }

	/**
	 * Decides whether or not to show the popup menu.
	 * 
	 * @param e
	 */
    private void maybeShowPopup(MouseEvent e) 
    {
    	TreePath selectedPath;
    	
        if (e.isPopupTrigger())         
        {
        	selectedPath = this.getPathForLocation(e.getX(), e.getY());
        	this.setSelectionPath(selectedPath);
        	
        	if(selectedPath != null)
        		this.rightClickMenu.show(e.getX(), e.getY(), selectedPath.getLastPathComponent());
        }
    }

	@Override
	public void mouseClicked(MouseEvent e) 
	{

	}

	@Override
	public void mouseEntered(MouseEvent e) 
	{
		
	}

	@Override
	public void mouseExited(MouseEvent e) 
	{
		
	}

	@Override
	/**
	 * A save has occurred. Update the tree appropriately.
	 */
	public void saveOccured()
	{
		Enumeration<StyleEditorNode> nodes = this.breadthFirstEnumeration();
		
		while(nodes.hasMoreElements())
		{
			this.treeModel.nodeChanged(nodes.nextElement());	//used to update the graphic of the node, such as a name change
		}
	}
	
	//---------- Private Classes ----------//
	
	/**
	 * Controls how to render the the tree.
	 * This is used so that the tree's nodes' .toString() isn't used when rendering.
	 * 
	 * @author Eric Marinier
	 *
	 */
	private class StyleEditorTreeRenderer extends DefaultTreeCellRenderer
	{
		private static final long serialVersionUID = 1L;

		public StyleEditorTreeRenderer()
		{
			super();
		}
		
		public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel,
                boolean expanded, boolean leaf, int row, boolean hasFocus) 
		{

			super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
			
			if(value instanceof StyleEditorNode)
			{
				this.setText(((StyleEditorNode)value).getNodeName());
			}

			return this;
		}
	}
}
