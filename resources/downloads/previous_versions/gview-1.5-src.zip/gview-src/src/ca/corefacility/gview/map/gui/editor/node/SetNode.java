package ca.corefacility.gview.map.gui.editor.node;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.seq.StrandedFeature.Strand;

import ca.corefacility.gview.map.gui.editor.panel.SetPanel;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.utils.AnnotationValueContains;
import ca.corefacility.gview.utils.SequenceNameFilter;

/**
 * The node class for the set styles. Intended to be used within a StyleEditorTree.
 * 
 * @author Eric Marinier
 *
 */
public class SetNode extends FeatureContainerNode
{
	private static final long serialVersionUID = 1L;	//requested by java
	private static final String SET = "Set";
	
	private static final String FEATURE_FILTER = "Feature Filter";
	private static final String ALL = "All";
	private static final String AND = "And";
	private static final String ANNOTATION_VALUE_CONTAINS = "Annotation Value Contains";
	private static final String ANNOTATION_VALUE_EQUALS = "Annotation Value Equals";
	private static final String BY_TYPE = "By Type";
	private static final String HAS_ANNOTATION = "Has Annotation";
	private static final String NOT = "Not";
	private static final String OR = "Or";
	private static final String OVERLAPS_LOCATION = "Overlaps Location";
	private static final String SEQUENCE_NAME = "Sequence Name";
	private static final String STRANDED = "Stranded";
	private static final String UNKNOWN_FEATURE = "Unknown";
	
	private static final String POSITIVE = "Positive";
	private static final String NEGATIVE = "Negative";
	private static final String UNKNOWN = "Unknown";
	
	private final SetPanel setPanel;

	/**
	 * 
	 * @param setPanel The related panel.
	 */
	public SetNode(SetPanel setPanel) 
	{
		super(setPanel, SET);
		
		if(setPanel == null)
			throw new IllegalArgumentException("SetPanel is null.");

		this.setPanel = setPanel;
		this.rename(getDefaultName(setPanel.getStyle().getFilter()));
	}
	
	/**
	 * Returns the default name of the set.
	 */
	private String getDefaultName(FeatureFilter featureFilter)
	{
		if(featureFilter == null)
			throw new IllegalArgumentException("FeatureFilter is null.");
		
		String result = (FEATURE_FILTER + "(" + UNKNOWN_FEATURE + ")");
		
		//ALL
		if(FeatureFilter.all.equals(featureFilter))
		{
			result = (FEATURE_FILTER + "(" + ALL + ")");
		}
		//AND
		else if(featureFilter instanceof FeatureFilter.And)
		{
			result = (FEATURE_FILTER + "(" + getDefaultName(((FeatureFilter.And)featureFilter).getChild1()) + " " + AND 
					+ " " + getDefaultName(((FeatureFilter.And)featureFilter).getChild2()) + ")");
		}
		//ANNOTATION VALUE CONTAINS
		else if(featureFilter instanceof AnnotationValueContains)
		{
			result = (FEATURE_FILTER + "(" + ANNOTATION_VALUE_CONTAINS + ": [" + 
					((AnnotationValueContains)featureFilter).getKey() + ", " +
					((AnnotationValueContains)featureFilter).getValue() + "]" + ")");
		}
		//ANNOTATION VALUE EQUALS
		else if(featureFilter instanceof FeatureFilter.ByAnnotation)
		{
			result = (FEATURE_FILTER + "(" + ANNOTATION_VALUE_EQUALS + ": [" + 
					((FeatureFilter.ByAnnotation)featureFilter).getKey() + ", " +
					((FeatureFilter.ByAnnotation)featureFilter).getValue() + "]" + ")");
		}
		//BY TYPE
		else if(featureFilter instanceof FeatureFilter.ByType)
		{
			result = (FEATURE_FILTER + "(" + BY_TYPE + ": [" 
					+ ((FeatureFilter.ByType)featureFilter).getType() + "]" + ")");
		}
		//HAS ANNOTATION
		else if(featureFilter instanceof FeatureFilter.HasAnnotation)
		{
			result = (FEATURE_FILTER + "(" + HAS_ANNOTATION + ": [" 
					+ ((FeatureFilter.HasAnnotation)featureFilter).getKey() + "]" + ")");
		}
		//NOT
		else if(featureFilter instanceof FeatureFilter.Not)
		{
			result = (FEATURE_FILTER + "(" + NOT + " " + getDefaultName(((FeatureFilter.Not)featureFilter).getChild()) + ")");
		}
		//OR
		else if(featureFilter instanceof FeatureFilter.Or)
		{
			result = (FEATURE_FILTER + "(" + getDefaultName(((FeatureFilter.Or)featureFilter).getChild1()) + " " + OR 
					+ " " + getDefaultName(((FeatureFilter.Or)featureFilter).getChild2()) + ")");
		}
		//OVERLAPS LOCATION
		else if(featureFilter instanceof FeatureFilter.OverlapsLocation)
		{
			result = (FEATURE_FILTER + "(" + OVERLAPS_LOCATION + ": [" + 
					((FeatureFilter.OverlapsLocation)featureFilter).getLocation().getMin() + ", " +
					((FeatureFilter.OverlapsLocation)featureFilter).getLocation().getMax() + "]" + ")");
		}
		//SEQUENCE NAME
		else if(featureFilter instanceof SequenceNameFilter)
		{
			result = (FEATURE_FILTER + "(" + SEQUENCE_NAME + ": [" 
					+ ((SequenceNameFilter)featureFilter).getSequenceName() + "]" + ")");
		}
		//STRANDED
		else if(featureFilter instanceof FeatureFilter.StrandFilter)
		{
			Strand strand = ((FeatureFilter.StrandFilter)featureFilter).getStrand();
			int strandValue = strand.getValue();
			
			if(strandValue == StrandedFeature.POSITIVE.getValue())
			{
				result = (FEATURE_FILTER + "(" + STRANDED + ": [" + POSITIVE + "]" + ")");
			}
			else if(strandValue == StrandedFeature.NEGATIVE.getValue())
			{
				result = (FEATURE_FILTER + "(" + STRANDED + ": [" + NEGATIVE + "]" + ")");
			}
			else if(strandValue == StrandedFeature.UNKNOWN.getValue())
			{
				result = (FEATURE_FILTER + "(" + STRANDED + ": [" + UNKNOWN + "]" + ")");
			}			
		}
		else
		{
			result = (FEATURE_FILTER + "(" + UNKNOWN_FEATURE + ")");
		}
		
		return result;
	}

	@Override
	public SetPanel getPanel() 
	{
		if(this.setPanel == null)
			throw new IllegalArgumentException("SetPanel is null.");
		
		return this.setPanel;
	}

	@Override
	public boolean canAddSetNodeAsChild()
	{
		return true;
	}

	@Override
	public FeatureHolderStyle createFeatureHolderStyle(FeatureFilter featureFilter)
	{
		return this.setPanel.getStyle().createFeatureHolderStyle(featureFilter);		
	}
	
	@Override
	public FeatureContainerNode getParent()
	{
		FeatureContainerNode parent = null;
		
		if(super.getParent() instanceof FeatureContainerNode)
		{
			parent = (FeatureContainerNode)super.getParent();
		}
		else if(super.getParent() != null)
		{
			throw new ClassCastException("SetNode's parent is not a FeatureContainerNode.");
		}
		
		return parent;
	}
}
