package ca.corefacility.gview.map.gui.action.map.move;

import ca.corefacility.gview.map.GViewMap;

/**
 * Move to half action.
 * 
 * Moves the camera to the halfway location on the genome.
 * 
 * @author Eric Marinier
 *
 */
public class MoveHalfAction extends MoveAction 
{
	private final GViewMap gViewMap;

	/**
	 * 
	 * @param gViewMap The GView map object.
	 */
	public MoveHalfAction(GViewMap gViewMap)
	{
		super(gViewMap);
		
		if(gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		this.gViewMap = gViewMap;
	}

	@Override
	public void run() 
	{
		this.gViewMap.setCenter((int)Math.round(this.gViewMap.getMaxSequenceLength()/2.0));
	}

}
