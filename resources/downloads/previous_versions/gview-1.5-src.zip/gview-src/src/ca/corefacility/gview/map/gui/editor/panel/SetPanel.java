package ca.corefacility.gview.map.gui.editor.panel;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Paint;

import javax.swing.JLabel;

import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.layout.feature.ForwardArrow2ShapeRealizer;
import ca.corefacility.gview.layout.feature.ForwardArrowShapeRealizer;
import ca.corefacility.gview.layout.feature.NoArrowShapeRealizer;
import ca.corefacility.gview.layout.feature.ReverseArrow2ShapeRealizer;
import ca.corefacility.gview.layout.feature.ReverseArrowShapeRealizer;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.map.gui.editor.StyleColoredButton;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility.ConversionException;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.io.gss.TextExtractorHandler;
import ca.corefacility.gview.textextractor.AnnotationExtractor;
import ca.corefacility.gview.textextractor.BlankExtractor;
import ca.corefacility.gview.textextractor.FeatureTextExtractor;
import ca.corefacility.gview.textextractor.LocationExtractor;
import ca.corefacility.gview.textextractor.SymbolsExtractor;
import ca.corefacility.gview.utils.Util;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.factories.FormFactory;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.border.TitledBorder;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.border.LineBorder;

/**
 * The panel for set styles.
 * 
 * @author Eric Marinier
 *
 */
public class SetPanel extends FeatureContainerPanel implements ActionListener
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private static final String COLOR = "Color";
	private static final String TOOLTIP_TEXT = "Tooltip Text";
	private static final String SET_STYLE_TEXT = "Set Style";
	
	private static final String THICKNESS_PROPORTION_LABEL_TEXT = "Thickness Proportion:";
	private static final String TOOLTIP_TEXT_LABEL_TEXT = "Tooltip Text:";
	private static final String FEATURE_SHAPE_LABEL_TEXT = "Feature Shape:";
	private static final String FEATURE_EFFECT_LABEL_TEXT = "Feature Effect:";
	private static final String COLOR_LABEL_TEXT = "Color:";
	
	private static final String BASIC = "basic";
	private static final String OUTLINE = "outline";
	private static final String SHADED = "shaded";
	private static final String STANDARD = "standard";
	
	private static final String[] featureEffects = {BASIC, OUTLINE, SHADED, STANDARD};
	
	private static final String INVALID_THICKNESS_PROPORTION = "Invalid thickness proportion.";
	private static final String FEATURE_HOLDER_STYLE_NULL = "FeatureHolderStyle is null.";
	
	private final StyleColoredButton color;
	
	private final JTextField thicknessProportion;
	private final JTextField tooltipTextField;
	
	private final JComboBox tooltipText;	
	private final JComboBox featureShape;
	private final JComboBox featureEffect;
	
	private final FeatureHolderStyle setStyle;

	/**
	 * Create the panel.
	 */
	public SetPanel(FeatureHolderStyle setStyle) 
	{	
		super();
		
		if(setStyle == null)
			throw new IllegalArgumentException(FEATURE_HOLDER_STYLE_NULL);
		
		this.setStyle = setStyle;
		
		//Layout
		setBorder(new EmptyBorder(10, 10, 10, 10));
		FormLayout formLayout = new FormLayout(new ColumnSpec[] {
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("center:default"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("left:min:grow"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,},
			new RowSpec[] {
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("15dlu"),
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,});
		formLayout.setRowGroups(new int[][]{new int[]{8, 6, 4, 2, 10}});
		
		JPanel inner = new JPanel();
		inner.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)),  SET_STYLE_TEXT, TitledBorder.LEADING, TitledBorder.TOP, null, new Color(51, 51, 51)));
		add(inner, BorderLayout.NORTH);
		
		inner.setLayout(formLayout);
		
		JPanel panel_4 = new JPanel();
		inner.add(panel_4, "2, 2, fill, fill");
		panel_4.setLayout(new BorderLayout(0, 0));
		
		JLabel lblThickness = new JLabel(THICKNESS_PROPORTION_LABEL_TEXT);
		panel_4.add(lblThickness, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		inner.add(panel, "6, 2, fill, fill");
		panel.setLayout(new BorderLayout(0, 0));
		
		//thickness proportion text field
		this.thicknessProportion = new JTextField();
		this.thicknessProportion.getDocument().addDocumentListener(this);
		panel.add(this.thicknessProportion, BorderLayout.WEST);
		this.thicknessProportion.setColumns(10);
		
		JPanel panel_5 = new JPanel();
		inner.add(panel_5, "2, 4, fill, fill");
		panel_5.setLayout(new BorderLayout(0, 0));
		
		JLabel lblTooltipText = new JLabel(TOOLTIP_TEXT_LABEL_TEXT);
		panel_5.add(lblTooltipText, BorderLayout.EAST);
		
		JPanel panel_1 = new JPanel();
		inner.add(panel_1, "6, 4, fill, fill");
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JPanel tooltipPanel = new JPanel();
		tooltipPanel.setLayout(new BorderLayout());
		panel_1.add(tooltipPanel, BorderLayout.WEST);
		
		//tooltip text combo box
		this.tooltipText = new JComboBox(StyleEditorUtility.textExtractorTexts);
		this.tooltipText.addActionListener(this);
		this.tooltipText.setActionCommand(TOOLTIP_TEXT);
		tooltipPanel.add(this.tooltipText, BorderLayout.WEST);
		
		//tooltip text field
		this.tooltipTextField = new JTextField();
		this.tooltipTextField.setColumns(15);
		this.tooltipTextField.getDocument().addDocumentListener(this);
		this.tooltipTextField.setVisible(false);
		tooltipPanel.add(this.tooltipTextField, BorderLayout.EAST);
		
		JPanel panel_6 = new JPanel();
		inner.add(panel_6, "2, 6, fill, fill");
		panel_6.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFeatureShape = new JLabel(FEATURE_SHAPE_LABEL_TEXT);
		panel_6.add(lblFeatureShape, BorderLayout.EAST);
		
		JPanel panel_2 = new JPanel();
		inner.add(panel_2, "6, 6, fill, fill");
		panel_2.setLayout(new BorderLayout(0, 0));
		
		//feature shape combo box
		this.featureShape = new JComboBox(StyleEditorUtility.featureShapes);
		this.featureShape.addActionListener(this);
		panel_2.add(this.featureShape, BorderLayout.WEST);
		
		JPanel panel_7 = new JPanel();
		inner.add(panel_7, "2, 8, fill, fill");
		panel_7.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFeatureEffect = new JLabel(FEATURE_EFFECT_LABEL_TEXT);
		panel_7.add(lblFeatureEffect, BorderLayout.EAST);
		
		JPanel panel_3 = new JPanel();
		inner.add(panel_3, "6, 8, fill, fill");
		panel_3.setLayout(new BorderLayout(0, 0));
		
		//feature effect combo box
		this.featureEffect = new JComboBox(featureEffects);
		this.featureEffect.addActionListener(this);
		panel_3.add(this.featureEffect, BorderLayout.WEST);
		
		JPanel panel_8 = new JPanel();
		inner.add(panel_8, "2, 10, fill, fill");
		panel_8.setLayout(new BorderLayout(0, 0));
		
		JLabel lblColor = new JLabel(COLOR_LABEL_TEXT);
		panel_8.add(lblColor, BorderLayout.EAST);
		
		JPanel panel_9 = new JPanel();
		inner.add(panel_9, "6, 10, fill, fill");
		panel_9.setLayout(new BorderLayout(0, 0));
		
		//color button
		this.color = new StyleColoredButton();
		panel_9.add(this.color, BorderLayout.WEST);
		this.color.setActionCommand(COLOR);
		this.color.addActionListener(this);
		
		this.update();
	}
	
	/**
	 * 
	 * @return The color of the set.
	 */
	private Paint getPaint()
	{
		Paint p = this.color.getRealPaint();
		
		return p;
	}
	
	/**
	 * Sets the color of the set.
	 * 
	 * @param c
	 */
	private void setPaint(Paint p)
	{
		this.color.setPaint(p);
	}
	
	/**
	 * 
	 * @return The text of the thickness field.
	 */
	private String getThicknessProportionText()
	{
		return this.thicknessProportion.getText();
	}
	
	/**
	 * Sets the text of the thickness field.
	 * 
	 * @param d
	 */
	private void setThicknessProportionText(double d)
	{
		this.thicknessProportion.setText(d + "");
	}
	
	/**
	 * 
	 * @return The item selected in the tooltip combo box.
	 */
	private String getTooltip()
	{
		Object temp;
		String result;
		
		temp = this.tooltipText.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Tooltip Text is not a String");
		}
		
		return result;
	}
	
	/**
	 * Sets the selection in the tooltip combo box.
	 * 
	 * @param text
	 */
	private void setTooltip(String text)
	{
		this.tooltipText.setSelectedItem(text);
	}
	
	/**
	 * 
	 * @return The text of the tooltip text field.
	 */
	private String getTooltipText()
	{
		return this.tooltipTextField.getText();
	}
	
	/**
	 * Sets the text of the tooltip text field.
	 * 
	 * @param string
	 */
	private void setTooltipText(String string)
	{
		this.tooltipTextField.setText(string);
	}
	
	/**
	 * 
	 * @return The selection in the feature shape combo box.
	 */
	private String getFeatureShape()
	{
		Object temp;
		String result;
		
		temp = this.featureShape.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Feature Shape is not a String");
		}
		
		return result;
	}
	
	/**
	 * Sets selection of the feature shape combo box.
	 * 
	 * @param shape 
	 */
	private void setFeatureShape(String shape)
	{
		this.featureShape.setSelectedItem(shape);
	}
	
	/**
	 * 
	 * @return The selection of the feature effect combo box.
	 */
	private String getFeatureEffect()
	{
		Object temp;
		String result;
		
		temp = this.featureEffect.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Feature Effect is not a String");
		}
		
		return result;
	}
	
	/**
	 * Sets the selection of the feature effect combo box.
	 * @param effect
	 */
	private void setFeatureEffect(String effect)
	{
		this.featureEffect.setSelectedItem(effect);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		Color c;		
		
		if(e.getActionCommand().equals(COLOR))
		{
			c = StyleEditorUtility.showColorPicker(this, this.color.getBackground());
			
			if(c != null)
				this.color.setPaint(c);
		}
		else if(e.getActionCommand().equals(TOOLTIP_TEXT))
		{
			if(this.tooltipText.getSelectedItem().equals(
			        StyleEditorUtility.ANNOTATION) || this.tooltipText.getSelectedItem().equals(StyleEditorUtility.STRING_BUILDER))
			{
				this.tooltipTextField.setVisible(true);
				this.revalidate();
			}
			else
			{
				this.tooltipTextField.setVisible(false);
			}
		}
		
		super.actionPerformed(e);
	}

	@Override
	/**
	 * Updates the panel.
	 */
	public void update() 
	{
		updateThicknessProportion();
		updateTooltipText();
		updateFeatureShape();
		updateFeatureEffect();
		updateColor();
	}
	
	/**
	 * Updates the thickness proportion.
	 */
	private void updateThicknessProportion()
	{
		setThicknessProportionText(this.setStyle.getThickness());
	}
	
	/**
	 * Updates the tool tip text.
	 */
	private void updateTooltipText()
	{
		FeatureTextExtractor textExtractor;
		
		textExtractor = this.setStyle.getToolTipExtractor();
		
		if(textExtractor instanceof AnnotationExtractor)
		{
			setTooltip(StyleEditorUtility.ANNOTATION);
			setTooltipText(((AnnotationExtractor)textExtractor).getAnnotation());
		}
		else if(textExtractor instanceof LocationExtractor)
		{
			setTooltip(StyleEditorUtility.LOCATION);
		}
		else if(textExtractor instanceof SymbolsExtractor)
		{
			setTooltip(StyleEditorUtility.SYMBOLS);
		}
		else if(textExtractor instanceof BlankExtractor)
		{
			setTooltip(StyleEditorUtility.BLANK);
		}
		else if(textExtractor instanceof ca.corefacility.gview.textextractor.StringBuilder)
		{
			setTooltip(StyleEditorUtility.STRING_BUILDER);
			setTooltipText(TextExtractorHandler.encode(textExtractor));
		}
	}

	/**
	 *  Updates the feature shape.
	 */
	private void updateFeatureShape()
	{
		FeatureShapeRealizer shapeRealizer = this.setStyle.getFeatureShapeRealizer();
		
		if(shapeRealizer instanceof ForwardArrowShapeRealizer)
		{
			setFeatureShape(StyleEditorUtility.CLOCKWISE_ARROW);
		}
		else if(shapeRealizer instanceof ForwardArrow2ShapeRealizer)
		{
			setFeatureShape(StyleEditorUtility.CLOCKWISE_ARROW_2);
		}
		else if(shapeRealizer instanceof ReverseArrowShapeRealizer)
		{
			setFeatureShape(StyleEditorUtility.COUNTERCLOCKWISE_ARROW);
		}
		else if(shapeRealizer instanceof ReverseArrow2ShapeRealizer)
		{
			setFeatureShape(StyleEditorUtility.COUNTERCLOCKWISE_ARROW_2);
		}
		else if(shapeRealizer instanceof NoArrowShapeRealizer)
		{
			setFeatureShape(StyleEditorUtility.BLOCK);
		}
	}
	
	/**
	 * Updates the feature effect.
	 */
	private void updateFeatureEffect()
	{
		ShapeEffectRenderer effectRenderer = this.setStyle.getShapeEffectRenderer();
		
		String effect = StyleEditorUtility.getFeatureEffectRenderer(effectRenderer);
		setFeatureEffect(effect);
	}
	
	/**
	 * Updates the color.
	 */
	private void updateColor()
	{
		Paint tempPaint;
		
		if(this.setStyle.getPaint().length == 0)
			throw new IllegalArgumentException("SetStyle paint array contains no elements.");
		else
		{
			tempPaint = this.setStyle.getPaint()[0];
			
			setPaint(tempPaint);
		}
	}

	@Override
	/**
	 * Applies the style.
	 */
	protected void doApply() 
	{
		applyThicknessProportion();
		applyTooltipText();
		applyFeatureShape();
		applyFeatureEffect();
		applyColor();		
	}
	
	/**
	 * Applies the thickness proportion.
	 */
	private void applyThicknessProportion()
	{
		double thicknessProportion;
		
		try
		{
			thicknessProportion = getThicknessProportion();
			
			this.setStyle.setThickness(thicknessProportion);			
		}
		catch(NumberFormatException nfe)
		{
			JOptionPane.showMessageDialog(this, INVALID_THICKNESS_PROPORTION);
		}
		catch (StyleEditorUtility.ConversionException e)
		{
            JOptionPane.showMessageDialog(this, e.getMessage());
		}
	}
	
	private double getThicknessProportion() throws ConversionException
	{
        double thicknessProportion = Double.parseDouble(getThicknessProportionText());
        
        if(thicknessProportion < 0)
        {
            throw new StyleEditorUtility.ConversionException("Thickness Proportion value must be non-negative.");
        }
        
        return thicknessProportion;
	}
	
	/**
	 * Applies the tool tip text.
	 */
	private void applyTooltipText()
	{
		FeatureTextExtractor featureTextExtractor;
        try
        {
            featureTextExtractor = StyleEditorUtility.getFeatureTextExtractor(this.getTooltip(), this.getTooltipText());
            this.setStyle.setToolTipExtractor(featureTextExtractor);
        }
        catch (ConversionException e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }	
	}

	/**
	 *  Applies the feature shape.
	 */
	private void applyFeatureShape()
	{
        FeatureShapeRealizer shapeRealizer;
        try
        {
            shapeRealizer = StyleEditorUtility.getShapeRealizer(getFeatureShape());
            this.setStyle.setFeatureShapeRealizer(shapeRealizer);
        }
        catch (ConversionException e)
        {
            e.printStackTrace();
        }
	}
	
	/**
	 * Applies the feature effect.
	 */
	private void applyFeatureEffect()
	{
        ShapeEffectRenderer shapeEffect;
        try
        {
            shapeEffect = StyleEditorUtility.getFeatureEffectRenderer(getFeatureEffect());
            this.setStyle.setShapeEffectRenderer(shapeEffect);
        }
        catch (ConversionException e)
        {
            e.printStackTrace();
        }
	}
	
	/**
	 * Applies the color.
	 */
	private void applyColor()
	{
		Paint color = getPaint();
		
		this.setStyle.setPaint(color);
	}
	
	/**
	 * Returns the associated feature holder style.
	 * 
	 * @return The associated feature holder style.
	 */
	public FeatureHolderStyle getStyle()
	{
		if(this.setStyle == null)
			throw new IllegalArgumentException("FeatureHolderStyle is null.");
		
		return setStyle;
	}

	@Override
	protected boolean modified()
	{
		boolean modified = false;
		
		try
        {
            modified = modified || !(Double.compare(this.setStyle.getThickness(),getThicknessProportion()) == 0);
        }
		catch (ConversionException e)
        {
        }
		
		try
        {
            modified = modified || !Util.isEqual(StyleEditorUtility.getFeatureTextExtractor(getTooltip(), getTooltipText()),
                    this.setStyle.getToolTipExtractor());
        }
		catch (ConversionException e)
        {
        }
		
		try
        {
            modified = modified || !Util.isEqual(StyleEditorUtility.getFeatureEffectRenderer(this.getFeatureEffect()),
                    this.setStyle.getShapeEffectRenderer());
        }
		catch (ConversionException e)
        {
        }
		
		try
        {
            modified = modified || !Util.isEqual(StyleEditorUtility.getShapeRealizer(this.getFeatureShape()),
                    this.setStyle.getFeatureShapeRealizer());
        }
		catch (ConversionException e)
        {
        }
		
		Paint[] setPaint = this.setStyle.getPaint();
		modified = modified || !(setPaint != null && setPaint.length == 1 && this.getPaint().equals(setPaint[0]));
		
		return modified;
	}
}
