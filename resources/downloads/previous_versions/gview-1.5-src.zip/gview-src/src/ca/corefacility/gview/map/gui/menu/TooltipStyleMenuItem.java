package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.action.dialog.show.ShowTooltipStyleDialogAction;
import ca.corefacility.gview.map.gui.dialog.StyleDialog;
import ca.corefacility.gview.map.gui.editor.panel.TooltipPanel;
import ca.corefacility.gview.style.items.TooltipStyle;

/**
 * The tool tip style menu item.
 * Displays a dialog to allow global changes to the tool tip style.
 * 
 * @author Eric Marinier
 *
 */
public class TooltipStyleMenuItem extends JMenuItem implements ActionListener
{
	private static final long serialVersionUID = 1L;	//requested by java

	private final GViewGUIFrame gViewGUIFrame;
	
	/**
	 * 
	 * @param gViewGUIFrame The related GUI frame.
	 */
	public TooltipStyleMenuItem(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.TOOLTIP_STYLE_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;
		
		this.setActionCommand(GUIUtility.TOOLTIP_STYLE);
		this.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		TooltipStyle tooltipStyle = this.gViewGUIFrame.getGViewMap().getMapStyle().getGlobalStyle().getTooltipStyle();
		TooltipPanel tooltipPanel = new TooltipPanel(tooltipStyle);
		
		if(e.getActionCommand().equals(GUIUtility.TOOLTIP_STYLE))
		{
			this.gViewGUIFrame.doAction(new ShowTooltipStyleDialogAction(new StyleDialog(gViewGUIFrame, tooltipPanel)));
		}
	}
}
