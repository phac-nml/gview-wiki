package ca.corefacility.gview.map.gui.editor.panel;

/**
 * The panel for the slots node.
 * The slots node is intended to group together the individual slot nodes.
 * 
 * @author Eric Marinier
 *
 */
public class SlotsPanel extends StylePanel
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	public SlotsPanel()
	{
		
	}

	@Override
	public void update()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void doApply()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	protected boolean modified()
	{
		return false;
	}
}
