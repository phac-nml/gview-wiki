package ca.corefacility.gview.map.gui.dialog;

import javax.swing.JOptionPane;

import ca.corefacility.gview.layout.sequence.ZoomException;
import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The custom zoom dialog box. Extends the abstract SliderDialog class.
 * 
 * @author Eric Marinier
 *
 */
public class ZoomDialog extends SliderDialog implements ActionListener
{	
	private static final long serialVersionUID = 1L;	
	
	/**
	 * @param gViewGUIFrame The frame the dialog will be attached to.
	 */
	public ZoomDialog(GViewGUIFrame gViewGUIFrame) 
	{	
		super(gViewGUIFrame, GUIUtility.ZOOM_MIN * GUIUtility.SCALE_FACTOR, 
				GUIUtility.ZOOM_MAX * GUIUtility.SCALE_FACTOR, -1, 
				"Enter a value between " + GUIUtility.ZOOM_MIN * GUIUtility.SCALE_FACTOR 
				+ "% and " + GUIUtility.ZOOM_MAX * GUIUtility.SCALE_FACTOR + "%:");
	}
	
	/**
	 * Shows the dialog.
	 */
	public void showZoomDialog()
	{		
		double zoomFactor = super.gViewGUIFrame.getGViewMap().getZoomFactor() * GUIUtility.SCALE_FACTOR;	//Needs to be scaled by a factor of 100.
		
		this.setVisible(true);	
		
		//Check to see if the zoomFactor is valid.
		if( zoomFactor >= MIN && zoomFactor <= MAX)
		{
			SLIDER.setValue((int)zoomFactor);
			TEXT_FIELD.setText((int)zoomFactor + "");
		}
		else if (zoomFactor < MIN)
		{
			SLIDER.setValue(MIN);
			TEXT_FIELD.setText(MIN + "");
		}
		else if (zoomFactor > MAX)
		{
			SLIDER.setValue(MAX);
			TEXT_FIELD.setText(MAX + "");			
		}
	}
	
	/**
	 * Listens for the buttons.
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		double zoomFactor;
		
		//OK button pressed.
		if(OK.equals(e.getActionCommand()))
		{	
			//try to parse the string as a double
			try
			{
				zoomFactor = Double.parseDouble(TEXT_FIELD.getText());
			}
			catch(NumberFormatException nfe)
			{
				//set to an invalid value
				zoomFactor = INVALID;				
			}
			
			//check to see if the input was invalid
			if(zoomFactor < MIN || zoomFactor > MAX)
			{
				JOptionPane.showMessageDialog(null, TEXT_FIELD.getText() + " is not within " + MIN + " to " + MAX, "Invalid Number", JOptionPane.WARNING_MESSAGE);
				
				//reset the text field to the slider's value
				TEXT_FIELD.setText(SLIDER.getValue() + "");
			}
			else
			//valid input
			{
				try
                {
                    super.gViewGUIFrame.getGViewMap().setZoomFactor(zoomFactor/GUIUtility.SCALE_FACTOR);
                    setVisible(false);          
                }
				catch (ZoomException e1)
                {
	                JOptionPane.showMessageDialog(null, e1.getMessage(), "Invalid Number", JOptionPane.WARNING_MESSAGE);
                }				
			}
		}
		//Cancel button pressed.
		else if(CANCEL.equals(e.getActionCommand()))
		{
			setVisible(false);
		}
	}
}
