package ca.corefacility.gview.map.gui.editor.panel;

import ca.corefacility.gview.style.datastyle.FeatureContainerStyle;

/**
 * This abstract class represents panels that contain / represent styles that can have features
 * in them, such as slots and sets.
 * 
 * @author Eric Marinier
 *
 */
public abstract class FeatureContainerPanel extends StylePanel
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	/**
	 * 
	 * @return The panel's (FeatureContainer) style.
	 */
	public abstract FeatureContainerStyle getStyle();
}
