package ca.corefacility.gview.main;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;

import javax.imageio.ImageIO;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.open.OpenDialog;
import ca.corefacility.gview.utils.FileLocationHandler;

public class GUIManager
{
	private SplashScreen splash;
	private static GUIManager instance = null;
	
	private static final String splashPath = "/images/splash.png";
	
	private GUIManager()
	{
		setLookAndFeel();
	}
	
	public static GUIManager getInstance()
	{
		if (instance == null)
		{
			instance = new GUIManager();
		}
		
		return instance;
	}
	
	// attempt to set native look-and-feel if possible
	private static void setLookAndFeel()
	{
		String currentLookAndFeel = UIManager.getSystemLookAndFeelClassName();		
		
		if(currentLookAndFeel.contains("GTKLookAndFeel"))
		{
			try 
			{
			    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) 
			    {
			        if ("Nimbus".equals(info.getName()))
		        	{
			            UIManager.setLookAndFeel(info.getClassName());
			            break;
			        }
			    }
			}
			catch(Exception e)
			{
				System.err.println("Could not set Nimbus Look and Feel" + e);
			}
			
		}
		else
		{
			try
			{
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			}
		    catch(Exception e)
		    {
		        System.err.println("Could not set native Look and Feel: " + e);
		        try
				{
					UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
				}
		        catch (Exception e1)
		        {
			        System.err.println("Could not set cross platform Look and Feel: " + e1);
			        try
					{
						UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
					}
			        catch (Exception e2)
			        {
				        System.err.println("Could not set Motif Look and Feel: " + e2);
			        }
		        }
		    }
		}
		


	}
	
	private BufferedImage getImageForSplash()
	{
		BufferedImage image = null;
	
		InputStream imageStream = GUIManager.class.getResourceAsStream(splashPath);
		
		if (imageStream != null)
		{
			try
			{
				image = ImageIO.read(imageStream);
			}
			catch (IOException e)
			{
				System.err.println("[error] - io error loading splash image " + splashPath + ": " + e);
			}
		}
		else
		{
			System.err.println("[warning] - image " + splashPath + " not found in jar");
			
			// read image from filesystem
			// for testing without jaring
			try
			{
				image = ImageIO.read(new File("images/splash.png"));
			}
			catch (IOException e)
			{
				System.err.println("[error] - io error loading splash image " + splashPath + ": " + e);
			}
		}
		
		return image;
	}
	
	public GViewGUIFrame buildGUIFrame(String title, GViewMap map)
	{
		return new GViewGUIFrame(title, false, map);
	}
	
	public GViewGUIFrame buildGUIFrame(String title, GViewMap map, String fileName)
	{
		URI uri = null;
		
		if (fileName != null)
		{
    		try
    		{
    			uri = FileLocationHandler.getURI(fileName);
    		}
    		catch (IOException e)
    		{
    			e.printStackTrace();
    		}
		}
		
		return new GViewGUIFrame(title, false, map, uri);
	}
	
	public GViewGUIFrame buildGUIFrame(String title, GViewMap map, URI uri)
	{
		return new GViewGUIFrame(title, false, map, uri);
	}
	
	public SplashScreen getSplashScreen()
	{
		if (splash == null)
		{
			BufferedImage image = getImageForSplash();
			splash = new SplashScreen(image);
		}
		
		return splash;
	}

	public void showOpenDialog()
	{
		OpenDialog.showOpenDialog();
	}
}
