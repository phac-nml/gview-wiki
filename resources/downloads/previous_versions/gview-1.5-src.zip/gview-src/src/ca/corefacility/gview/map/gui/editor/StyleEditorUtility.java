package ca.corefacility.gview.map.gui.editor;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Paint;
import java.awt.Window;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;

import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import com.bric.swing.ColorPicker;

import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.layout.feature.ForwardArrow2ShapeRealizer;
import ca.corefacility.gview.layout.feature.ForwardArrowShapeRealizer;
import ca.corefacility.gview.layout.feature.NoArrowShapeRealizer;
import ca.corefacility.gview.layout.feature.ReverseArrow2ShapeRealizer;
import ca.corefacility.gview.layout.feature.ReverseArrowShapeRealizer;
import ca.corefacility.gview.layout.sequence.LayoutFactory;
import ca.corefacility.gview.layout.sequence.circular.LayoutFactoryCircular;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.map.effects.StandardEffect;
import ca.corefacility.gview.style.datastyle.PlotBuilderType;
import ca.corefacility.gview.style.datastyle.PlotDrawerType;
import ca.corefacility.gview.style.datastyle.PlotStyle;
import ca.corefacility.gview.style.io.gss.TextExtractorHandler;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.style.items.LegendAlignment;
import ca.corefacility.gview.textextractor.AnnotationExtractor;
import ca.corefacility.gview.textextractor.BlankExtractor;
import ca.corefacility.gview.textextractor.FeatureTextExtractor;
import ca.corefacility.gview.textextractor.LocationExtractor;
import ca.corefacility.gview.textextractor.StringExtractor;
import ca.corefacility.gview.textextractor.SymbolsExtractor;

/**
 * Contains many constants, methods and other utility for the style editor.
 * 
 * @author Eric Marinier
 *
 */
public class StyleEditorUtility 
{
	public static final String GLOBAL_TEXT = "Global";
	public static final String RULER_TEXT = "Ruler";
	public static final String BACKBONE_TEXT = "Backbone";
	public static final String LEGEND_TEXT = "Legend";
	public static final String TOOLTIP_TEXT = "Tooltip";
	public static final String STYLE_TEXT = "Style";
	public static final String LEGEND_STYLE_TEXT = "Legend Style";
	public static final String LEGEND_ITEM_TEXT = "Legend Item";
	
	public static final String[] FONT_NAMES = {"Default", "Dialog", "DialogInput", "Monospaced", "Serif", "SansSerif"};
	
	public static final String PLAIN = "Plain";
	public static final String BOLD = "Bold";
	public static final String ITALIC = "Italic";
	public static final String BOLD_ITALIC = "Bold-Italic";
	
	public static final String[] FONT_STYLES = {PLAIN, BOLD, ITALIC, BOLD_ITALIC};
	
	public static final HashMap<String, LegendAlignment> ALIGNMENT_MAP_STRINGS_TO_ALIGN = new HashMap<String, LegendAlignment>();
	public static final HashMap<LegendAlignment, String> ALIGNMENT_MAP_ALIGN_TO_STRINGS = new HashMap<LegendAlignment, String>();
	
	public static final String UPPER_LEFT = "Upper Left";
	public static final String UPPER_CENTER = "Upper Center";
	public static final String UPPER_RIGHT = "Upper Right";
	public static final String MIDDLE_LEFT = "Middle Left";
	public static final String MIDDLE_CENTER = "Middle Center";
	public static final String MIDDLE_RIGHT = "Middle Right";
	public static final String LOWER_LEFT = "Lower Left";
	public static final String LOWER_CENTER = "Lower Center";
	public static final String LOWER_RIGHT = "Lower Right";
	
	public static final String[] LEGEND_ALIGNMENT_STRINGS = {UPPER_LEFT, UPPER_CENTER, UPPER_RIGHT, MIDDLE_LEFT, MIDDLE_CENTER, MIDDLE_RIGHT,
		LOWER_LEFT, LOWER_CENTER, LOWER_RIGHT};
	
	public static final LegendAlignment[] LEGEND_ALIGNMENTS = {LegendAlignment.UPPER_LEFT, LegendAlignment.UPPER_CENTER, 
		LegendAlignment.UPPER_RIGHT, LegendAlignment.MIDDLE_LEFT, LegendAlignment.MIDDLE_CENTER, LegendAlignment.MIDDLE_RIGHT,
		LegendAlignment.LOWER_LEFT, LegendAlignment.LOWER_CENTER, LegendAlignment.LOWER_RIGHT};
	
	public static final Color DEFAULT_COLOR = Color.WHITE;
	public static final Color DEFAULT_GRID_COLOR = Color.BLACK;
	public static final Color DEFAULT_PLOT_COLOR_1 = Color.black;//new Color(0,153,0);
	public static final Color DEFAULT_PLOT_COLOR_2 = Color.black;//new Color(153,0,153);
	
	public static final String WELCOME 
		= "<p>Welcome to the GView Style Editor!</p>" +
		"<p>Press the save button to save your modifications." +
		"<br>Press the apply button to apply saved changes.</p>";
	
	public static final String LEGEND_PANEL_TEXT = "The Legend Panel!";
	
	public static final String APPLY_CHANGES = "Apply Changes";
	public static final String REVERT_CHANGES = "Revert Changes";
	public static final String SAVE = "Save";
	public static final String FILE_TEXT = "File";
	public static final String HELP_TEXT = "Help";
	public static final String HELP_PAGE_TEXT = "Help Page";
	public static final String EXIT_TEXT = "Exit";
	public static final String SLOT_TEXT = "Slot";
	public static final String PLOT_TEXT = "Plot";
	public static final String SET_TEXT = "Set";
	public static final String LABEL_TEXT = "Label Style";
	
	public static final String FEATURE_ALL = "All";
	public static final String FEATURE_AND = "And";
	public static final String FEATURE_ANNOTATION_VALUE_CONTAINS = "Annotation Value Contains";
	public static final String FEATURE_ANNOTATION_VALUE_EQUALS = "Annotation Value Equals";
	public static final String FEATURE_BY_TYPE = "By Type";
	public static final String FEATURE_HAS_ANNOTATION = "Has Annotation";
	public static final String FEATURE_NOT = "Not";
	public static final String FEATURE_OR = "Or";
	public static final String FEATURE_OVERLAPS_LOCATION = "Overlaps Location";
	public static final String FEATURE_SEQUENCE_NAME = "Sequence Name";
	public static final String FEATURE_STRANDED = "Stranded";
	public static final String FEATURE_GSS_STRING = "GSS String";
	
	public static final String[] FEATURE_FILTERS = {FEATURE_ALL, FEATURE_AND, FEATURE_NOT, FEATURE_OR, FEATURE_ANNOTATION_VALUE_CONTAINS, FEATURE_ANNOTATION_VALUE_EQUALS, FEATURE_BY_TYPE,
		FEATURE_HAS_ANNOTATION, FEATURE_OVERLAPS_LOCATION, FEATURE_SEQUENCE_NAME, FEATURE_STRANDED, FEATURE_GSS_STRING};
	
	public static final String POSITIVE = "Positive";
	public static final String NEGATIVE = "Negative";
	public static final String UNKNOWN = "Unknown";
	public static final String[] STRANDED = {POSITIVE, NEGATIVE, UNKNOWN};
	
	public static final LayoutFactory DEFAULT_LAYOUT = new LayoutFactoryCircular();
	
	public static final String DEFAULT_STYLE_NODE_NAME = "Node";
	public static final String DEFAULT_STYLE_TREE_NAME = "untitled";
	
	public static final String COG_TO_COLOR_MAPPER = "COG Category to Color";
	public static final String AUTO_POPULATE_COG_CATEGORIES = "Auto Populate COG Categories";
	public static final String SCORE_TO_OPACITY = "Score to Opacity";
	
	public static final String[] PROPERTY_MAPPERS = {SCORE_TO_OPACITY, COG_TO_COLOR_MAPPER, AUTO_POPULATE_COG_CATEGORIES};
	
	public static String[] COG_CATEGORIES = {"A","B","C","D","E","F","G","H","I","J","K","L","M",
        "N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
	
	public static final String BASIC = "basic";
	public static final String OUTLINE = "outline";
	public static final String SHADED = "shaded";
	public static final String STANDARD = "standard";
	public static final String[] featureEffects = {BASIC, OUTLINE, SHADED, STANDARD};
	   
    public static final String LOCATION = "location";
    public static final String SYMBOLS = "symbols";
    public static final String ANNOTATION = "annotation";
    public static final String STRING_BUILDER = "stringbuilder";
    public static final String BLANK = "blank";
    public static final String[] textExtractorTexts = {LOCATION, SYMBOLS, ANNOTATION, STRING_BUILDER, BLANK};
    
    public static final String CLOCKWISE_ARROW = "clockwise-arrow";
    public static final String COUNTERCLOCKWISE_ARROW = "counterclockwise-arrow";
    public static final String CLOCKWISE_ARROW_2 = "clockwise-arrow2";
    public static final String COUNTERCLOCKWISE_ARROW_2 = "counterclockwise-arrow2";
    public static final String BLOCK = "block";
    public static final String[] featureShapes = {CLOCKWISE_ARROW, COUNTERCLOCKWISE_ARROW, CLOCKWISE_ARROW_2, COUNTERCLOCKWISE_ARROW_2, BLOCK};
	
	public static Color[] COG_COLORS = {new Color(255,0,0,255), new Color(255,98,71,255),
        new Color(0,255,255,255), new Color(240,230,140,255),
        new Color(70,130,180,255), new Color(0,191,255,255),
        new Color(0,206,209,255), new Color(0,0,255,255),
        new Color(105,90,205,255), new Color(240,128,128,255),
        new Color(255,136,0,255), new Color(255,20,147,255),
        new Color(108,142,35,255), new Color(33,139,33,255),
        new Color(189,182,107,255), new Color(154,205,50,255),
        new Color(0,0,128,255), new Color(190,190,190,255),
        new Color(105,105,105,255), new Color(50,205,50,255),
        new Color(175,255,47,255), new Color(0,250,150,255),
        new Color(143,188,143,255), new Color(255,0,0,255),
        new Color(59,179,111,255), new Color(255,255,0,255)};
	
	static
	{		
		ALIGNMENT_MAP_STRINGS_TO_ALIGN.put(UPPER_LEFT, LegendAlignment.UPPER_LEFT);
		ALIGNMENT_MAP_STRINGS_TO_ALIGN.put(UPPER_CENTER, LegendAlignment.UPPER_CENTER);
		ALIGNMENT_MAP_STRINGS_TO_ALIGN.put(UPPER_RIGHT, LegendAlignment.UPPER_RIGHT);
		ALIGNMENT_MAP_STRINGS_TO_ALIGN.put(MIDDLE_LEFT, LegendAlignment.MIDDLE_LEFT);
		ALIGNMENT_MAP_STRINGS_TO_ALIGN.put(MIDDLE_CENTER, LegendAlignment.MIDDLE_CENTER);
		ALIGNMENT_MAP_STRINGS_TO_ALIGN.put(MIDDLE_RIGHT, LegendAlignment.MIDDLE_RIGHT);
		ALIGNMENT_MAP_STRINGS_TO_ALIGN.put(LOWER_LEFT, LegendAlignment.LOWER_LEFT);
		ALIGNMENT_MAP_STRINGS_TO_ALIGN.put(LOWER_CENTER, LegendAlignment.LOWER_CENTER);
		ALIGNMENT_MAP_STRINGS_TO_ALIGN.put(LOWER_RIGHT, LegendAlignment.LOWER_RIGHT);
		
		ALIGNMENT_MAP_ALIGN_TO_STRINGS.put(LegendAlignment.UPPER_LEFT, UPPER_LEFT);
		ALIGNMENT_MAP_ALIGN_TO_STRINGS.put(LegendAlignment.UPPER_CENTER, UPPER_CENTER);
		ALIGNMENT_MAP_ALIGN_TO_STRINGS.put(LegendAlignment.UPPER_RIGHT, UPPER_RIGHT);
		ALIGNMENT_MAP_ALIGN_TO_STRINGS.put(LegendAlignment.MIDDLE_LEFT, MIDDLE_LEFT);
		ALIGNMENT_MAP_ALIGN_TO_STRINGS.put(LegendAlignment.MIDDLE_CENTER, MIDDLE_CENTER);
		ALIGNMENT_MAP_ALIGN_TO_STRINGS.put(LegendAlignment.MIDDLE_RIGHT, MIDDLE_RIGHT);
		ALIGNMENT_MAP_ALIGN_TO_STRINGS.put(LegendAlignment.LOWER_LEFT, LOWER_LEFT);
		ALIGNMENT_MAP_ALIGN_TO_STRINGS.put(LegendAlignment.LOWER_CENTER, LOWER_CENTER);
		ALIGNMENT_MAP_ALIGN_TO_STRINGS.put(LegendAlignment.LOWER_RIGHT, LOWER_RIGHT);
	}
	
    private static final PlotBuilderType plotBuilderDefault = new PlotBuilderType.GCContent();
    private static final PlotDrawerType plotDrawerDefault = new PlotDrawerType.Center();
    private static final Paint plotPaintDefault[] = {StyleEditorUtility.DEFAULT_PLOT_COLOR_1, StyleEditorUtility.DEFAULT_PLOT_COLOR_2};
	
	/**
	 * Sets the passed plot style's internal components to default.
	 * 
	 * @param plotStyle The plot style to set to default.
	 */
	public static void setPlotStyleDefaults(PlotStyle plotStyle)
	{
		final int NUM_GRID_LINES = 1;
		
		Paint gridColor = StyleEditorUtility.DEFAULT_GRID_COLOR;
		
		plotStyle.setPlotBuilderType(plotBuilderDefault);
		plotStyle.setPlotDrawerType(plotDrawerDefault);
		plotStyle.setGridLines(NUM_GRID_LINES);
		plotStyle.setGridPaint(gridColor);
		plotStyle.setPaint(plotPaintDefault);
		
	}

	/**
	 * Extracts the feature text extractor from the passed string.
	 * 
	 * @param text The text to extract the filter from.
	 */
	public static FeatureTextExtractor decodeFeatureTextExtractor(String text)
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		InputSource currEncodedString = new InputSource(new StringReader(text));
		LexicalUnit textExtractor;
		FeatureTextExtractor featureTextExtractor = null;
		
		if(text != null)
		{
			try
			{
				textExtractor = parser.parsePropertyValue(currEncodedString);
				featureTextExtractor = TextExtractorHandler.decode(textExtractor);
			}
			catch (CSSException e)
			{
				e.printStackTrace();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
			catch (ParseException e)
			{
				e.printStackTrace();
			}	
		}		
		
		return featureTextExtractor;
	}
	
	public static Font getFont(String fontFamily, String fontStyle, String fontSize) throws ConversionException
	{
		Font f = null;
		
		int tempFontStyle = 0;
		int tempInt;
		
		if(StyleEditorUtility.BOLD_ITALIC.equals(fontStyle))
		{
			tempFontStyle = Font.BOLD | Font.ITALIC;
		}
		else if(StyleEditorUtility.BOLD.equals(fontStyle))
		{
			tempFontStyle = Font.BOLD;
		}
		else if(StyleEditorUtility.ITALIC.equals(fontStyle))
		{
			tempFontStyle = Font.ITALIC;
		}
		else if(StyleEditorUtility.PLAIN.equals(fontStyle))
		{
			tempFontStyle = Font.PLAIN;
		}
		
		try
		{
			tempInt = Integer.parseInt(fontSize);
			
			if(tempInt <= 0)
			{
				throw new ConversionException("Font Size value " + tempInt + " must be greater than zero.");
			}
			else
			{
				f = new Font(fontFamily, tempFontStyle, tempInt);
			}
		}
		catch (NumberFormatException e)
		{
			throw new ConversionException("Font size value " + fontSize + " is not a valid integer");
		}
		
		return f;
	}
	
	public static ShapeEffectRenderer getFeatureEffectRenderer(String effectText) throws ConversionException
	{	
		if(effectText.equals(OUTLINE))
		{
			return ShapeEffectRenderer.OUTLINE_RENDERER;
		}
		else if(effectText.equals(SHADED))
		{
			return ShapeEffectRenderer.SHADING_RENDERER;
		}
		else if(effectText.equals(STANDARD))
		{
			return ShapeEffectRenderer.STANDARD_RENDERER;
		}
		else if (effectText.equals(BASIC))
		{
		    return new StandardEffect();
		}
		else
		{
			throw new ConversionException("invalid ShapeEffectRenderer " + effectText);
		}
	}
	
	public static String getFeatureEffectRenderer(ShapeEffectRenderer effect)
	{
       if(effect.equals(ShapeEffectRenderer.OUTLINE_RENDERER))
        {
            return OUTLINE;
        }
        else if(effect.equals(ShapeEffectRenderer.SHADING_RENDERER))
        {
            return SHADED;
        }
        else if(effect.equals(ShapeEffectRenderer.STANDARD_RENDERER))
        {
            return STANDARD;
        }
        else if (effect.equals(new StandardEffect()))
        {
            return BASIC;
        }
        else
        {
            return "Unknown";
        }
	}
	
   public static FeatureShapeRealizer getShapeRealizer(String effectText) throws ConversionException
    {   
       FeatureShapeRealizer featureShapeRealizer = null;
       
       if(effectText.equals(CLOCKWISE_ARROW))
       {
           featureShapeRealizer = new ForwardArrowShapeRealizer();
       }
       else if(effectText.equals(CLOCKWISE_ARROW_2))
       {
           featureShapeRealizer = new ForwardArrow2ShapeRealizer();
       }
       else if(effectText.equals(COUNTERCLOCKWISE_ARROW))
       {
           featureShapeRealizer = new ReverseArrowShapeRealizer();
       }
       else if(effectText.equals(COUNTERCLOCKWISE_ARROW_2))
       {
           featureShapeRealizer = new ReverseArrow2ShapeRealizer();
       }
       else if(effectText.equals(BLOCK))
       {
           featureShapeRealizer = new NoArrowShapeRealizer();
       }
       else
       {
           throw new ConversionException("Unknown shape effect renderer " + effectText);
       }
       
       return featureShapeRealizer;
    }
	
	public static FeatureTextExtractor getFeatureTextExtractor(String textType, String textString) throws ConversionException
	{
        FeatureTextExtractor featureTextExtractor;
        
        if(textType.equals(ANNOTATION))
        {
            featureTextExtractor = new AnnotationExtractor(textString);
        }
        else if(textType.equals(LOCATION))
        {
            featureTextExtractor = new LocationExtractor();
        }
        else if(textType.equals(SYMBOLS))
        {
            featureTextExtractor = new SymbolsExtractor();
        }
        else if(textType.equals(STRING_BUILDER))
        {   
            featureTextExtractor = StyleEditorUtility.decodeFeatureTextExtractor(textString);
            
            if(featureTextExtractor == null)
                featureTextExtractor = new StringExtractor(textString);
        }
        else if (textType.equals(BLANK))
        {
            return new BlankExtractor();
        }
        else
        {
            throw new ConversionException("Invalid text extractor type " + textType);
        }
        
        return featureTextExtractor;
	}
	
	public static class ConversionException extends Exception
	{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public ConversionException() {
			super();
			// TODO Auto-generated constructor stub
		}

		public ConversionException(String message, Throwable cause) {
			super(message, cause);
			// TODO Auto-generated constructor stub
		}

		public ConversionException(String message) {
			super(message);
			// TODO Auto-generated constructor stub
		}

		public ConversionException(Throwable cause) {
			super(cause);
			// TODO Auto-generated constructor stub
		}
	}
	
	/**
	 * Shows the ColorPicker above the passed component's closest parent window 
	 * with the starting color of the color picker being the passed color.
	 * 
	 * This will show an option for editing the color's alpha value.
	 * 
	 * @param component The component to show the color picker over.
	 * @param color The starting color of the color picker.	 * 
	 * @return The user selected color. May be null.
	 */
	public static Color showColorPicker(Component component, Color color)
	{
		Window parentWindow = null;
		Component current = component;
		
		//while current is not an instance of window and current isn't null
		while (!(current instanceof Window) && current != null)
		{
			current = current.getParent();
		}
		
		if(current instanceof Window)
		{
			parentWindow = (Window)current;
		}
		
		//parent window will either be a window or be null
		return ColorPicker.showDialog(parentWindow, color, true);
	}
	
	/**
	 * Shows the ColorPicker above the passed component's closest parent window.
	 * 
	 * This will show an option for editing the color's alpha value.
	 * 
	 * @param component The component to show the color picker over.	 * 
	 * @return The user selected color. May be null.
	 */
	public static Color showColorPicker(Component component)
	{
		return showColorPicker(component, null);
	}
}
