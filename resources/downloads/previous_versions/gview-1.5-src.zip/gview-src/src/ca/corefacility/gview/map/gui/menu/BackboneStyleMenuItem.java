package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.action.dialog.show.ShowBackboneStyleDialogAction;
import ca.corefacility.gview.map.gui.dialog.StyleDialog;
import ca.corefacility.gview.map.gui.editor.panel.BackbonePanel;
import ca.corefacility.gview.style.items.BackboneStyle;

/**
 * The backbone style menu item.
 * Displays a dialog to allow global changes to the backbone style.
 * 
 * @author Eric Marinier
 *
 */
public class BackboneStyleMenuItem extends JMenuItem implements ActionListener
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private final GViewGUIFrame gViewGUIFrame;

	/**
	 * Creates a new BackboneStyleMenuItem
	 * @param gViewGUIFrame The related GUI frame.
	 */
	public BackboneStyleMenuItem(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.BACKBONE_STYLE_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;
		
		this.setActionCommand(GUIUtility.BACKBONE_STYLE);
		this.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		BackboneStyle backboneStyle = this.gViewGUIFrame.getGViewMap().getMapStyle().getGlobalStyle().getBackboneStyle();
		BackbonePanel backbonePanel = new BackbonePanel(backboneStyle);
		
		if(e.getActionCommand().equals(GUIUtility.BACKBONE_STYLE))
		{
			this.gViewGUIFrame.doAction(new ShowBackboneStyleDialogAction(new StyleDialog(this.gViewGUIFrame, backbonePanel)));
		}
	}
}
