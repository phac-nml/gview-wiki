package ca.corefacility.gview.map.gui.editor.panel;

import javax.swing.JPanel;
import java.awt.BorderLayout;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import ca.corefacility.gview.map.gui.editor.StyleEditorTree;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * The abstract class for style panels.
 * 
 * @author Eric Marinier
 *
 */
public abstract class StylePanel extends JPanel implements ActionListener, DocumentListener
{
	private static final long serialVersionUID = 1L;
	
	private final ArrayList<SaveListener> saveListeners = new ArrayList<SaveListener>();
	
	private boolean updating; //updating variable is used to stop the action listener from firing on an update.
	
	/**
	 * Used to keep track of whether or not the style elements have been modified.
	 */
	private boolean modified;

	/**
	 * Create the panel.
	 */
	public StylePanel() 
	{
		super();
		
		this.updating = true;
		
		setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.SOUTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1, BorderLayout.EAST);
		panel_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));		
		
		this.updating = false;
	}
	
	/**
	 * Sets the 'modified' variable to indicate that the style held by this panel has been modified.
	 */
	protected void setModified()
	{
		this.modified = true;
	}
	
	/**
	 * Updates the panel.
	 */
	public void updatePanel()
	{
		//updating variable is used to stop the action listener from firing on an update.
		this.updating = true;
		update();
		this.updating = false;
	}
	
	public abstract void update();
	
	/**
	 * Saves the panel.
	 * 
	 * @return  True if we made changes to the style, false otherwise.
	 */
	public boolean save()
	{
		boolean modified = apply();
		
		//notify listeners
		for(int i = 0; i < this.saveListeners.size(); i++)
		{
			this.saveListeners.get(i).saveOccured();
		}
		
		return modified;
	}
	
	/**
	 * Applies the panel's properties to the appropriate style.
	 * 
	 * @return  True if we made changes to the style, false otherwise.
	 */
	public boolean apply()
	{
		if(modified())
		{
			doApply();
			
			return true;
		}
		
		return false;
	}
	
	protected abstract boolean modified();
	protected abstract void doApply();
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(!this.updating)
		{
			if(e.getActionCommand().equals(StyleEditorUtility.SAVE))
			{
				save();
			}
			else
			{
			}
		}
	}
	

	@Override
	public void insertUpdate(DocumentEvent e) 
	{
	}

	@Override
	public void removeUpdate(DocumentEvent e) 
	{

	}

	@Override
	public void changedUpdate(DocumentEvent e) 
	{

	}

	/**
	 * Adds an action listener for the save button.
	 * 
	 * @param listener The action listener.
	 */
	public void addSaveListener(SaveListener listener)
	{
		if(listener != null)
		{	
			//If the style editor tree is acting as a listener, it needs to be notified last
			//I really dislike this approach, but I feel its better than explicitly having a pointer 
			//to the style editor tree.
			if(listener instanceof StyleEditorTree)
			{
				this.saveListeners.add(this.saveListeners.size(), listener);
			}				
			else
			{
				this.saveListeners.add(0, listener);
			}			
		}			
	}

	public void unsetModified()
	{
		this.modified = false;
	}

	public boolean isModified()
	{
		return modified;
	}
}
