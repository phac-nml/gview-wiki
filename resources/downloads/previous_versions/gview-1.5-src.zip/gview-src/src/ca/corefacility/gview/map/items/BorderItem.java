package ca.corefacility.gview.map.items;

import org.biojava.bio.symbol.Location;

// not needed?
public class BorderItem extends AbstractBackboneShapeItem
{
	//private GlobalStyle globalStyle;
	
	private static final long serialVersionUID = 7419127315921505452L;


	public BorderItem(/*GlobalStyle globalStyle*/)
	{
		/*this.globalStyle = globalStyle;
		
		setPaint(globalStyle.getBackgroundPaint());
		
		if (globalStyle.showBorder())
		{
			setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL)); // TODO put this in style?
			setStrokePaint(globalStyle.getBorderPaint());
		}
		else
		{
			setStroke(null);
		}*/
	}

	
	public Location getLocation()
	{
		// TODO Auto-generated method stub
		return null;
	}

	
	public void updateClippedLocation(Location clipLocation)
	{
		// TODO Auto-generated method stub
		
	}
}
