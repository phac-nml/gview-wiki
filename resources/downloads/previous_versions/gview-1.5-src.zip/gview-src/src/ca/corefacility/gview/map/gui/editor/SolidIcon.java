package ca.corefacility.gview.map.gui.editor;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import ca.corefacility.gview.map.gui.GUIUtility;

/**
 * An implementation of Icon that is a checkerboard pattern with a color painted overtop.
 * 
 * @author Eric Marinier
 *
 */
public class SolidIcon implements Icon
{
	private Paint paint;
	
	private static final ImageIcon checkerboard = new ImageIcon(GUIUtility.loadImage("images/icons/checkerboard.png"));
	
	/**
	 * Creates a default color SolidIcon.
	 */
	public SolidIcon()
	{
		this.paint = StyleEditorUtility.DEFAULT_COLOR;
	}
	
	/**
	 * Creates a SolidIcon.
	 * 
	 * @param paint The paint of the icon.
	 */
	public SolidIcon(Paint paint)
	{
		if(paint == null)
		    paint = StyleEditorUtility.DEFAULT_COLOR;
		
		this.paint = paint;
	}

	@Override
	public void paintIcon(Component c, Graphics g, int x, int y) 
	{
	    Graphics2D gg = null;
	    if (g instanceof Graphics2D)
	    {
	        gg = (Graphics2D)g;
	        gg.setPaint(paint);
	    }
	    else
	    {
	        if (paint instanceof Color)
	        {
	            g.setColor((Color)paint);
	        }
	        else
	        {
	            g.setColor(Color.white);
	            System.err.println("Graphics class " + g.getClass() + " not of type "
	                    + Graphics2D.class + " : cannot support icon with paint type " + paint.getClass());
	        }
	    }
	    
		checkerboard.paintIcon(c, g, x, y);
		

		g.fillRect(0, 0, c.getWidth(), c.getHeight());
		
		g.setColor(new Color(0, 0, 0, 200));
		
		g.drawLine(0, 0, 0, c.getHeight() - 1);
		g.drawLine(0, 0, c.getWidth() - 1, 0);
		g.drawLine(c.getWidth() - 1, c.getHeight() - 1, 0, c.getHeight() - 1);
		g.drawLine(c.getWidth() - 1, c.getHeight() - 1, c.getWidth() - 1, 0);
	}

	@Override
	public int getIconWidth() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getIconHeight() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	/**
	 * 
	 * @return The Paint of the icon.
	 */
	public Paint getPaint()
	{
		return paint;
	}
	
	public Color getColor()
	{
	    if (paint instanceof Color)
	    {
	        return (Color)paint;
	    }
	    else
	    {
	        return StyleEditorUtility.DEFAULT_COLOR;
	    }
	}
	
	/**
	 * 
	 * @param p The Paint to set the icon.
	 */
	public void setPaint(Paint p)
	{	
		if(p == null)
		{
			p = StyleEditorUtility.DEFAULT_COLOR;
		}
		
		this.paint = p;
	}

}
