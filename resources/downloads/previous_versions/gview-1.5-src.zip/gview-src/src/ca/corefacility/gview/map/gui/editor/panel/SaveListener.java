package ca.corefacility.gview.map.gui.editor.panel;

/**
 * This is interface is used to inform implementors that a save has occurred.
 * 
 * @author Eric Marinier
 *
 */
public interface SaveListener
{
	public abstract void saveOccured();
}
