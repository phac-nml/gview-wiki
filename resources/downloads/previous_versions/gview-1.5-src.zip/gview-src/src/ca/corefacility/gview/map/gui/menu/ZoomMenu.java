package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;

import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.action.dialog.show.ShowZoomDialogAction;
import ca.corefacility.gview.map.gui.action.map.zoom.ZoomCustomAction;
import ca.corefacility.gview.map.gui.action.map.zoom.ZoomInAction;
import ca.corefacility.gview.map.gui.action.map.zoom.ZoomOutAction;

/**
 * Responsible for creating and managing the Zoom menu on GView's menu bar.
 * 
 * @author Eric Marinier
 *
 */
public class ZoomMenu extends JMenu implements ActionListener 
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private final GViewGUIFrame gViewGUIFrame;	
	private final JCheckBoxMenuItem[] checkItems; 

	/**
	 * Creates a new Zoom menu within the specified frame. 
	 * @param gViewGUIFrame The frame the menu will be sitting on. Required for the custom scale dialog.
	 */
	public ZoomMenu(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.ZOOM_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;	
		this.checkItems = new JCheckBoxMenuItem[GUIUtility.specificZoomItems.length];
		
		addMenuItems();
	}
	
	/**
	 * Adds the individual menu items to the zoom sub menu.
	 */
	private void addMenuItems()
	{
		JMenuItem currMenuItem;
		
		currMenuItem = new JMenuItem(GUIUtility.ZOOM_IN);
		currMenuItem.addActionListener(this);		
		this.add(currMenuItem);
		
		currMenuItem = new JMenuItem(GUIUtility.ZOOM_OUT);		
		currMenuItem.addActionListener(this);
		this.add(currMenuItem);
		
		this.add(new JSeparator());		
		
		//Add the items to the menu and checkItems
		for (int i = 0; i < GUIUtility.specificZoomItems.length; i++)
		{
			currMenuItem = new JCheckBoxMenuItem(GUIUtility.specificZoomItems[i]);
			currMenuItem.addActionListener(this);
			this.add(currMenuItem);
			
			if(currMenuItem instanceof JCheckBoxMenuItem)
				checkItems[i] = (JCheckBoxMenuItem)currMenuItem;
		}
		
		this.add(new JSeparator());
		
		currMenuItem = new JMenuItem(GUIUtility.CUSTOM_TEXT);
		currMenuItem.setActionCommand(GUIUtility.ZOOM_CUSTOM);
		currMenuItem.addActionListener(this);
		this.add(currMenuItem);
	}
	
	/**
	 * Updates the menu by comparing all of the 'checkable' items against the current zoom level and sets the 'check' state appropriately for each.
	 */
	public void updateMenu()
	{
		int currZoomLevel = (int)(gViewGUIFrame.getGViewMap().getZoomFactor() * GUIUtility.SCALE_FACTOR); // to coordinate with %'s, also rounding to ints
		
		for (int i = 0; i < GUIUtility.specificZoomLevels.length; i++)
		{	
			if(currZoomLevel != GUIUtility.specificZoomLevels[i])
			{
				checkItems[i].setSelected(false);
			}
			else
			{
				checkItems[i].setSelected(true);
			}
		}		
	}

	@Override
	/**
	 * Listens for the menu items.
	 */
	public void actionPerformed(ActionEvent e)
	{		
		if (GUIUtility.ZOOM_IN.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ZoomInAction(gViewGUIFrame.getGViewMap()));
		}
		else if (GUIUtility.ZOOM_OUT.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ZoomOutAction(gViewGUIFrame.getGViewMap()));
		}
		else if (GUIUtility.ZOOM_100.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ZoomCustomAction(gViewGUIFrame.getGViewMap(), 100.0/GUIUtility.SCALE_FACTOR));
		}
		else if (GUIUtility.ZOOM_200.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ZoomCustomAction(gViewGUIFrame.getGViewMap(), 200.0/GUIUtility.SCALE_FACTOR));
		}
		else if (GUIUtility.ZOOM_400.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ZoomCustomAction(gViewGUIFrame.getGViewMap(), 400.0/GUIUtility.SCALE_FACTOR));
		}
		else if (GUIUtility.ZOOM_800.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ZoomCustomAction(gViewGUIFrame.getGViewMap(), 800.0/GUIUtility.SCALE_FACTOR));
		}
		else if (GUIUtility.ZOOM_1600.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ZoomCustomAction(gViewGUIFrame.getGViewMap(), 1600.0/GUIUtility.SCALE_FACTOR));
		}
		else if (GUIUtility.ZOOM_3200.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ZoomCustomAction(gViewGUIFrame.getGViewMap(), 3200.0/GUIUtility.SCALE_FACTOR));
		}
		else if (GUIUtility.ZOOM_CUSTOM.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ShowZoomDialogAction(gViewGUIFrame.getZoomDialog()));
		}	
	}
}
