package ca.corefacility.gview.map.gui.dialog;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.GViewMapListener;

/**
 * Abstract custom slider dialog.
 * 
 * @author Eric Marinier
 *
 */
public abstract class SliderDialog extends JDialog implements ChangeListener, ActionListener, GViewMapListener
{
	private static final long serialVersionUID = 1L; //requested by java
	
	protected final int MIN;	//the min value of the slider
	protected final int MAX;	//the max value of the slider
	protected final int INVALID;	//an invalid value on the slider
	
	protected final GViewGUIFrame gViewGUIFrame;
	
	protected final JPanel CONTENT_PANEL;	//the panel the dialog box 	
	protected final JTextField TEXT_FIELD;
	protected final JSlider SLIDER;
	
	protected final String DIALOG_MESSAGE;
	
	protected final JButton OK_BUTTON;
	protected final JButton CANCEL_BUTTON;
	
	protected final String OK = "OK";
	protected final String CANCEL = "Cancel";
	
	protected String textFieldMessage;

	/**
	 * @param gViewGUIFrame The related GUI frame.
	 * @param min	Min value of the slider.
	 * @param max	Max value of the slider.
	 * @param invalid	An invalid value.
	 * @param message	The message the dialog should display.
	 */
	SliderDialog(GViewGUIFrame gViewGUIFrame, int min, int max, int invalid, String message)
	{
		super(gViewGUIFrame);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;
		this.gViewGUIFrame.addGViewMapListener(this);
		
		MIN = min;
		MAX = max;
		INVALID = invalid;
		
		CONTENT_PANEL = new JPanel();
		TEXT_FIELD = new JTextField("");
		SLIDER = new JSlider(MIN, MAX, MIN);
		
		DIALOG_MESSAGE = message;
		textFieldMessage = MIN + "";
		
		OK_BUTTON = new JButton(OK);
		CANCEL_BUTTON = new JButton(CANCEL);
		
		createDialog();
	}	
	
	/**
	 * Creates the dialog. Much of the code was generated using WindowBuilderPro.
	 */
	private void createDialog()
	{	
		setVisible(false);		
		setResizable(false);
		setBounds(100, 100, 394, 165);
		getContentPane().setLayout(new BorderLayout());
		CONTENT_PANEL.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(CONTENT_PANEL, BorderLayout.CENTER);
		CONTENT_PANEL.setLayout(new BoxLayout(CONTENT_PANEL, BoxLayout.X_AXIS));
		{
			JPanel panel = new JPanel();
			CONTENT_PANEL.add(panel);
			panel.setLayout(new BorderLayout(0, 0));
			{
				JPanel panel_1 = new JPanel();
				panel.add(panel_1, BorderLayout.PAGE_START);
				panel_1.setLayout(new GridLayout(0, 1, 0, 0));
				{
					JLabel lblEnterAScale = new JLabel(DIALOG_MESSAGE);
					panel_1.add(lblEnterAScale);
				}
				{
					TEXT_FIELD.setText(textFieldMessage);
					panel_1.add(TEXT_FIELD);
					TEXT_FIELD.setColumns(10);
				}
			}
			{
				Box horizontalBox = Box.createHorizontalBox();
				panel.add(horizontalBox, BorderLayout.PAGE_END);
				{
					Component verticalStrut = Box.createVerticalStrut(20);
					verticalStrut.setMinimumSize(new Dimension(0, 30));
					horizontalBox.add(verticalStrut);
				}
				{
					JPanel panel_1 = new JPanel();
					horizontalBox.add(panel_1);
					panel_1.setLayout(new BorderLayout(0, 0));
					{
						SLIDER.addChangeListener(this);
						panel_1.add(SLIDER, BorderLayout.SOUTH);
					}
				}
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				OK_BUTTON.setActionCommand(OK);
				buttonPane.add(OK_BUTTON);
				getRootPane().setDefaultButton(OK_BUTTON);
				OK_BUTTON.addActionListener(this);
			}
			{
				CANCEL_BUTTON.setActionCommand(CANCEL);
				buttonPane.add(CANCEL_BUTTON);
				CANCEL_BUTTON.addActionListener(this);
			}
		}
	}
	
	/**
	 * Displays the dialog.
	 */
	public void showDialog()
	{
		this.setVisible(true);
	}
	
	/**
	 * Listens for the buttons being pressed.
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{		
		//OK button pressed.
		if(OK.equals(e.getActionCommand()))
		{	
			setVisible(false);
		}
		//Cancel button pressed.
		else if(CANCEL.equals(e.getActionCommand()))
		{
			setVisible(false);
		}
	}
	
	@Override
	/**
	 * Listens for the slider; updates the text field.
	 */
	public void stateChanged(ChangeEvent e) 
	{
		TEXT_FIELD.setText(SLIDER.getValue() + "");		
	}
	
	@Override
	public void setGViewMap(GViewMap gViewMap)
	{
		
	}
}
