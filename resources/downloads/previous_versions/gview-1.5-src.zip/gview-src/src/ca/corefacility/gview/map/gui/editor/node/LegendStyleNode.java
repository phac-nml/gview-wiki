package ca.corefacility.gview.map.gui.editor.node;

import ca.corefacility.gview.map.gui.editor.panel.LegendStylePanel;

/**
 * The node class for the legend style. 
 * 
 * Intended to be used within a StyleEditorTree.
 * 
 * @author Eric Marinier
 *
 */
public class LegendStyleNode extends StyleEditorNode 
{
	private static final long serialVersionUID = 1L;	//requested by java
	private static final String LEGEND_STYLE = "Legend Style";
	
	private final LegendStylePanel legendStylePanel;
	
	/**
	 * 
	 * @param legendStylePanel The related panel.
	 */
	public LegendStyleNode(LegendStylePanel legendStylePanel)
	{
		super(legendStylePanel, LEGEND_STYLE);
		
		if(legendStylePanel == null)
			throw new IllegalArgumentException("LegendStylePanel is null");

		this.legendStylePanel = legendStylePanel;		
	}

	@Override
	public LegendStylePanel getPanel() 
	{
		if(this.legendStylePanel == null)
			throw new IllegalArgumentException("LegendStylePanel is null");
		
		return this.legendStylePanel;
	}
}
