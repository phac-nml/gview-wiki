package ca.corefacility.gview.map.gui.menu;

import javax.swing.JMenu;
import javax.swing.JSeparator;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;

/**
 * Responsible for creating and managing the View menu on GView's menu bar.
 * 
 * @author Eric Marinier
 *
 */
public class ViewMenu extends JMenu implements MenuListener
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	//Items in the View menu.
	private final ShowLegendMenuItem legendItem;
	private final ShowLabelsMenuItem labelsItem;
	private final ShowRulerMenuItem rulerItem;
	private final ShowAllMenuItem allItem;
	
	private final BEVMenuItem BEVItem;
	private final ZoomMenu zoomMenu;
	private final ScaleMenu scaleMenu;
	private final MoveMenu moveMenu;
	private final FitMapToScreenMenuItem fitMapToScreenItem;
	private final FullScreenMenuItem fullScreenItem;
	
	/**
	 * Creates a new ViewMenu within the specified frame. 
	 * @param gViewGUIFrame The frame the menu will be sitting on.
	 */
	public ViewMenu(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.VIEW_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
	
		this.addMenuListener(this);

		//Show Legend Menu Item
		this.legendItem = new ShowLegendMenuItem(gViewGUIFrame);
		this.add(this.legendItem);
		
		//Show Labels Menu Item
		this.labelsItem = new ShowLabelsMenuItem(gViewGUIFrame);
		this.add(this.labelsItem);
		
		//Show Ruler Menu Item
		this.rulerItem = new ShowRulerMenuItem(gViewGUIFrame);
		this.add(this.rulerItem);
		
		//Show All Menu Item
		this.allItem = new ShowAllMenuItem(gViewGUIFrame);
		this.add(this.allItem);
		
		//Separator.
		this.add(new JSeparator());
		
		//Bird's Eye View Menu Item.
		this.BEVItem = new BEVMenuItem(gViewGUIFrame);
		this.add(this.BEVItem);
		
		//Separator.
		this.add(new JSeparator());
		
		//Zoom Sub Menu
		this.zoomMenu = new ZoomMenu(gViewGUIFrame);
		this.add(this.zoomMenu);
		
		//Scale Sub Menu
		this.scaleMenu = new ScaleMenu(gViewGUIFrame);
		this.add(this.scaleMenu);
		
		//Move Sub Menu
		this.moveMenu = new MoveMenu(gViewGUIFrame);
		this.add(this.moveMenu);
		
		//Separator.
		this.add(new JSeparator());
		
		//Fit Map to Screen Menu Item
		this.fitMapToScreenItem = new FitMapToScreenMenuItem(gViewGUIFrame);
		this.add(this.fitMapToScreenItem);
		
		//Full Screen Menu Item
		this.fullScreenItem = new FullScreenMenuItem(gViewGUIFrame);
		this.add(this.fullScreenItem);
	}

	@Override
	/**
	 * Listens for the menu being selected and causes sub menus' and sub items' states to be updated.
	 */
	public void menuSelected(MenuEvent e) 
	{
		//This allows for the correct values to be checked off in their respective sub menus.
		zoomMenu.updateMenu();
		scaleMenu.updateMenu();
		fullScreenItem.update();
		
		rulerItem.update();
		labelsItem.update();
		legendItem.update();
		allItem.update();
		BEVItem.update();
	}

	@Override
	/**
	 * no effect
	 */
	public void menuDeselected(MenuEvent e) 
	{
		// TODO Auto-generated method stub		
	}

	@Override
	/**
	 * no effect
	 */
	public void menuCanceled(MenuEvent e) 
	{
		// TODO Auto-generated method stub		
	}
}
