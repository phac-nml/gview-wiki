package ca.corefacility.gview.map.gui.editor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.tree.TreeNode;

import ca.corefacility.gview.map.gui.action.style.NewPlotAction;
import ca.corefacility.gview.map.gui.action.style.NewSetAction;
import ca.corefacility.gview.map.gui.action.style.NewSlotAction;
import ca.corefacility.gview.map.gui.editor.node.FeatureContainerNode;
import ca.corefacility.gview.map.gui.editor.node.LegendItemStyleNode;
import ca.corefacility.gview.map.gui.editor.node.LegendNode;
import ca.corefacility.gview.map.gui.editor.node.LegendStyleNode;
import ca.corefacility.gview.map.gui.editor.node.PlotNode;
import ca.corefacility.gview.map.gui.editor.node.PropertyMapperNode;
import ca.corefacility.gview.map.gui.editor.node.SetNode;
import ca.corefacility.gview.map.gui.editor.node.SlotNode;
import ca.corefacility.gview.map.gui.editor.node.SlotsNode;
import ca.corefacility.gview.map.gui.editor.node.StyleEditorNode;
import ca.corefacility.gview.map.gui.editor.node.RootNode;

/**
 * The right click menu for the StyleTree.
 * 
 * @author Eric Marinier
 *
 */
public class TreeRightClickMenu extends JPopupMenu implements ActionListener
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private static final String RENAME_TEXT = "Rename";
	private static final String RENAME = "Rename Node";
	
	private static final String CLONE_SLOT = "Clone Slot";
	private static final String CLONE_SLOT_TEXT = "Clone";
	private static final String CLONE_SET = "Clone Set";
	private static final String CLONE_SET_TEXT = "Clone";
	
	private static final String NEW_SLOT = "New Slot";
	private static final String NEW_SLOT_TEXT = "New Slot";
	private static final String NEW_SET = "New Set";
	private static final String NEW_SET_TEXT = "New Set";
	private static final String NEW_PLOT = "New Plot";
	private static final String NEW_PLOT_TEXT = "New Plot";
	private static final String NEW_LEGEND = "Add Legend";
	private static final String NEW_LEGEND_TEXT = "Add Legend";
	private static final String NEW_LEGEND_ITEM = "Add Legend Item";
	private static final String NEW_LEGEND_ITEM_TEXT = "Add Legend Item";
	private static final String NEW_PROPERTY_MAPPER = "New Property Mapper";
	private static final String NEW_PROPERTY_MAPPER_TEXT = "New Property Mapper";
	
	private static final String REMOVE_SLOT = "Remove Slot";
	private static final String REMOVE_PLOT = "Remove Plot";
	private static final String REMOVE_SET = "Remove Set";
	private static final String REMOVE_SLOT_TEXT = "Remove Slot";
	private static final String REMOVE_PLOT_TEXT = "Remove Plot";
	private static final String REMOVE_SET_TEXT = "Remove Set";
	private static final String REMOVE_LEGEND = "Remove Legend";
	private static final String REMOVE_LEGEND_TEXT = "Remove Legend";
	private static final String REMOVE_LEGEND_ITEM = "Remove Legend Item";
	private static final String REMOVE_LEGEND_ITEM_TEXT = "Remove Legend Item";
	private static final String REMOVE_PROPERTY_MAPPER = "Remove Property Mapper";
	private static final String REMOVE_PROPERTY_MAPPER_TEXT = "Remove Property Mapper";
	
	private final JMenuItem rename;
	
	private final JMenuItem cloneSlot;
	private final JMenuItem cloneSet;
	
	private final JMenuItem newSlot;
	private final JMenuItem newSet;
	private final JMenuItem newPlot;
	private final JMenuItem newLegend;
	private final JMenuItem newLegendItem;
	private final JMenuItem newPropertyMapper;
	
	private final JMenuItem removeSlot;
	private final JMenuItem removePlot;
	private final JMenuItem removeSet;
	private final JMenuItem removeLegend;
	private final JMenuItem removeLegendItem;
	private final JMenuItem removePropertyMapper;
	
	private final StyleEditorFrame styleEditorFrame;
	private final StyleEditorTree styleEditorTree;
	
	/**
	 * The right click menu unique to the passed style editor tree. That is, each style editor tree
	 * is expected to have its own right click menu.
	 * 
	 * @param styleEditorFrame The related editor frame.
	 * @param styleEditorTree The style tree the right click menu will be working with.
	 */
	public TreeRightClickMenu(StyleEditorFrame styleEditorFrame, StyleEditorTree styleEditorTree)
	{
		super();
		
		if(styleEditorFrame == null)
			throw new IllegalArgumentException("StyleEditorFrame is null");
		
		if(styleEditorTree == null)
			throw new IllegalArgumentException("StyleTree is null");
		
		this.styleEditorFrame = styleEditorFrame;
		this.styleEditorTree = styleEditorTree;
		
		this.rename = new JMenuItem(RENAME_TEXT);
		this.rename.setActionCommand(RENAME);
		this.rename.addActionListener(this);
		
		this.cloneSlot = new JMenuItem(CLONE_SLOT_TEXT);
		this.cloneSlot.setActionCommand(CLONE_SLOT);
		this.cloneSlot.addActionListener(this);
		
		this.cloneSet = new JMenuItem(CLONE_SET_TEXT);
		this.cloneSet.setActionCommand(CLONE_SET);
		this.cloneSet.addActionListener(this);
		
		this.newSlot = new JMenuItem(NEW_SLOT_TEXT);
		this.newSlot.setActionCommand(NEW_SLOT);
		this.newSlot.addActionListener(this);
		
		this.newSet = new JMenuItem(NEW_SET_TEXT);
		this.newSet.setActionCommand(NEW_SET);
		this.newSet.addActionListener(this);
		
		this.newPlot = new JMenuItem(NEW_PLOT_TEXT);
		this.newPlot.setActionCommand(NEW_PLOT);
		this.newPlot.addActionListener(this);
		
		this.newLegend = new JMenuItem(NEW_LEGEND_TEXT);
		this.newLegend.setActionCommand(NEW_LEGEND);
		this.newLegend.addActionListener(this);
		
		this.newLegendItem = new JMenuItem(NEW_LEGEND_ITEM_TEXT);
		this.newLegendItem.setActionCommand(NEW_LEGEND_ITEM);
		this.newLegendItem.addActionListener(this);
		
		this.newPropertyMapper = new JMenuItem(NEW_PROPERTY_MAPPER_TEXT);
		this.newPropertyMapper.setActionCommand(NEW_PROPERTY_MAPPER);
		this.newPropertyMapper.addActionListener(this);
		
		this.removeSlot = new JMenuItem(REMOVE_SLOT_TEXT);
		this.removeSlot.setActionCommand(REMOVE_SLOT);
		this.removeSlot.addActionListener(this);
		
		this.removePlot = new JMenuItem(REMOVE_PLOT_TEXT);
		this.removePlot.setActionCommand(REMOVE_PLOT);
		this.removePlot.addActionListener(this);
		
		this.removeSet = new JMenuItem(REMOVE_SET_TEXT);
		this.removeSet.setActionCommand(REMOVE_SET);
		this.removeSet.addActionListener(this);
		
		this.removeLegend = new JMenuItem(REMOVE_LEGEND_TEXT);
		this.removeLegend.setActionCommand(REMOVE_LEGEND);
		this.removeLegend.addActionListener(this);
		
		this.removeLegendItem = new JMenuItem(REMOVE_LEGEND_ITEM_TEXT);
		this.removeLegendItem.setActionCommand(REMOVE_LEGEND_ITEM);
		this.removeLegendItem.addActionListener(this);
		
		this.removePropertyMapper = new JMenuItem(REMOVE_PROPERTY_MAPPER_TEXT);
		this.removePropertyMapper.setActionCommand(REMOVE_PROPERTY_MAPPER);
		this.removePropertyMapper.addActionListener(this);
	}
	
	/**
	 * Shows the right click menu.
	 * 
	 * @param x The x location to show at.
	 * @param y The y location to show at.
	 * @param node The node that was right clicked.
	 */
	public void show(int x, int y, Object node)
	{
		if(node != null)
		{
			this.setMenuItems(node);
			super.show(this.styleEditorTree, x, y);
		}		
	}

	/**
	 * Shows only the appropriate menu items for the node.
	 * 
	 * @param node The (right) clicked node.
	 */
	private void setMenuItems(Object node) 
	{
		this.removeAll();
		
		//All
		if(node instanceof StyleEditorNode)
		{

		}
		
		//Welcome Node (top node)
		if(node instanceof RootNode)
		{
			this.add(this.rename);
		}
		
		//Slots (the collection of slots)
		if(node instanceof SlotsNode)
		{
			this.add(this.newSlot);
		}
		
		//Slot
		if(node instanceof SlotNode)
		{
			//if the slot node DOESNT contain a PlotNode or SetNode child
			//that is, you can add a new set or a new plot to a slot that is empty
			if(!((SlotNode)node).containsPlotNode() && !((SlotNode)node).containsSetNode())
			{
				this.add(this.newSet);
				this.add(this.newPlot);
			}
			//if the slot node DOESNT contain a PlotNode
			//that is, you can add a set to a slot node that doesn't contain a plot node
			else if(!((SlotNode)node).containsPlotNode())
			{
				this.add(this.newSet);
			}
			
			this.add(this.removeSlot);
		}
		
		//Set
		if(node instanceof SetNode)
		{
			this.add(this.newSet);
			
			//if the set node does NOT contain a property mapper already
			//that is, you can add a property mapper to a set that doesnt contain a property mapper already
			if( !((SetNode)node).containsPropertyMapper())
			{
				this.add(this.newPropertyMapper);
			}
			
			this.add(this.removeSet);
			this.add(this.rename);
		}
		
		//Plot
		if(node instanceof PlotNode)
		{
			this.add(this.removePlot);
			this.add(this.rename);
		}
		
		//Legend (collection node for legends)
		if(node instanceof LegendNode)
		{
			this.add(this.newLegend);
		}
		
		//Legend Style (the legend itself)
		if(node instanceof LegendStyleNode)
		{
			this.add(this.newLegendItem);
			this.add(this.removeLegend);
		}
		
		//Legend Item Style (the sub items under legend style)
		if(node instanceof LegendItemStyleNode)
		{
			this.add(this.removeLegendItem);
		}
		
		//Property Mapper
		if(node instanceof PropertyMapperNode)
		{
			this.add(this.removePropertyMapper);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		Object selectedNode = this.styleEditorTree.getLastSelectedPathComponent();
		
		//RENAME
		if(e.getActionCommand().equals(RENAME))
		{			
			if(selectedNode instanceof StyleEditorNode)
			{
				((StyleEditorNode)selectedNode).rename();
				this.styleEditorTree.getTreeModel().nodeChanged((TreeNode)selectedNode);
			}
		}
		//NEW SLOT
		else if(e.getActionCommand().equals(NEW_SLOT))
		{
			if(selectedNode instanceof SlotsNode)
			{
				this.styleEditorFrame.doAction(new NewSlotAction(this.styleEditorTree));
			}
		}
		//NEW SET
		else if(e.getActionCommand().equals(NEW_SET))
		{
			this.styleEditorFrame.doAction(new NewSetAction(this.styleEditorTree));
		}
		//NEW PLOT
		else if(e.getActionCommand().equals(NEW_PLOT))
		{
			this.styleEditorFrame.doAction(new NewPlotAction(this.styleEditorTree));
		}
		//NEW LEGEND
		else if(e.getActionCommand().equals(NEW_LEGEND))
		{
			this.styleEditorTree.createLegendNode();
		}
		//NEW LEGEND ITEM
		else if(e.getActionCommand().equals(NEW_LEGEND_ITEM))
		{
			if(selectedNode instanceof LegendStyleNode)
			{
				this.styleEditorTree.createLegendItemNode((LegendStyleNode)selectedNode);
			}
		}
		//NEW PROPERTY MAPPER
		else if(e.getActionCommand().equals(NEW_PROPERTY_MAPPER))
		{
			if(selectedNode instanceof FeatureContainerNode)
			{
				if( !((FeatureContainerNode)selectedNode).containsPropertyMapper())
					this.styleEditorTree.createPropertyMapper((FeatureContainerNode)selectedNode);
			}
		}
		//REMOVE SLOT
		else if(e.getActionCommand().equals(REMOVE_SLOT))
		{
			if(selectedNode instanceof SlotNode)
			{
				this.styleEditorTree.removeSlotNode((SlotNode)selectedNode);				
			}
		}
		//REMOVE SET
		else if(e.getActionCommand().equals(REMOVE_SET))
		{
			if(selectedNode instanceof SetNode)
			{
				this.styleEditorTree.removeSetNode((SetNode)selectedNode);
			}
		}
		//REMOVE PLOT
		else if(e.getActionCommand().equals(REMOVE_PLOT))
		{
			if(selectedNode instanceof PlotNode)
			{
				this.styleEditorTree.removePlotNode((PlotNode)selectedNode);
			}
		}
		//REMOVE LEGEND
		else if(e.getActionCommand().equals(REMOVE_LEGEND))
		{
			if(selectedNode instanceof LegendStyleNode)
			{				
				this.styleEditorTree.removeLegend((LegendStyleNode)selectedNode);
			}			
		}
		//REMOVE LEGEND ITEM
		else if(e.getActionCommand().equals(REMOVE_LEGEND_ITEM))
		{
			if(selectedNode instanceof LegendItemStyleNode)
			{				
				this.styleEditorTree.removeLegendItem((LegendItemStyleNode)selectedNode);
			}
		}
		//REMOVE PROPERTY MAPPER
		else if(e.getActionCommand().equals(REMOVE_PROPERTY_MAPPER))
		{
			if(selectedNode instanceof PropertyMapperNode)
			{
				this.styleEditorTree.removePropertyMapper((PropertyMapperNode)selectedNode);
			}
		}
		
		this.styleEditorTree.repaint();	//The tree won't refresh itself otherwise
	}
}
