package ca.corefacility.gview.map.gui.editor.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import ca.corefacility.gview.map.gui.editor.StyleColoredButton;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility.ConversionException;
import ca.corefacility.gview.style.datastyle.LabelStyle;
import ca.corefacility.gview.textextractor.AnnotationExtractor;
import ca.corefacility.gview.textextractor.BlankExtractor;
import ca.corefacility.gview.textextractor.FeatureTextExtractor;
import ca.corefacility.gview.textextractor.LocationExtractor;
import ca.corefacility.gview.textextractor.StringExtractor;
import ca.corefacility.gview.textextractor.SymbolsExtractor;
import ca.corefacility.gview.utils.Util;

import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.JCheckBox;

/**
 * The panel for the label properties.
 * 
 * @author Eric Marinier
 *
 */
public class LabelPanel extends StylePanel implements ActionListener
{
	private static final long serialVersionUID = 1L;
	
	private static final String TEXT_COLOR = "Text Color";
	private static final String BACKGROUND_COLOR = "Background Color";
	private static final String FONT_FAMILY = "Font Family";
	private static final String FONT_STYLE = "Font Style";
	private static final String LABEL_TEXT = "Label Text";
	private static final String SHOW_LABELS = "Show Labels";
	private static final String LABEL_STYLE_TEXT = "Label Style";
	
	private static final String TEXT_COLOR_LABEL_TEXT = "Text Color:";
	private static final String BACKGROUND_COLOR_LABEL_TEXT = "Background Color:";
	private static final String FONT_FAMILY_LABEL_TEXT = "Font Family:";
	private static final String FONT_STYLE_LABEL_TEXT = "Font Style:";
	private static final String FONT_SIZE_LABEL_TEXT = "Font Size";
	private static final String LABEL_TEXT_LABEL_TEXT = "Label Text:";	//Yeah, I know..
	private static final String SHOW_LABELS_LABEL_TEXT = "Show Labels:";
	
	private static final String LOCATION = "location";
	private static final String SYMBOLS = "symbols";
	private static final String ANNOTATION = "annotation";
	private static final String STRING_BUILDER = "stringbuilder";
	private static final String BLANK = "blank";
	
	private static final String[] LABEL_TEXTS = {LOCATION, SYMBOLS, ANNOTATION, STRING_BUILDER};
	
	private static final String LABEL_STYLE_NULL = "LabelStyle is null.";

	private final StyleColoredButton textColor;
	private final StyleColoredButton backgroundColor;
	
	private final JComboBox fontFamily;
	private final JComboBox fontStyle;
	private final JComboBox labelText;
	
	private final JTextField fontSize;
	private final JTextField labelTextField;
	
	private final JCheckBox showLabels;
	
	private final LabelStyle labelStyle;

	/**
	 * Create the panel.
	 */
	public LabelPanel(LabelStyle labelStyle)
	{
		super();
		
		if(labelStyle == null)
			throw new IllegalArgumentException(LABEL_STYLE_NULL);
		
		this.labelStyle = labelStyle;
		
		//Layout
		setBorder(new EmptyBorder(10, 10, 10, 10));
		FormLayout formLayout = new FormLayout(new ColumnSpec[] {
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("center:default"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("left:min:grow"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,},
			new RowSpec[] {
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("15dlu"),
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("default:grow"),
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("default:grow"),
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,});
		formLayout.setRowGroups(new int[][]{new int[]{12, 6, 4, 2, 14, 8, 10}});
		
		JPanel inner = new JPanel();
		inner.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), LABEL_STYLE_TEXT, TitledBorder.LEADING, TitledBorder.TOP, null, new Color(51, 51, 51)));
		add(inner, BorderLayout.NORTH);
		
		inner.setLayout(formLayout);
		
		JPanel panel_4 = new JPanel();
		inner.add(panel_4, "2, 2, fill, fill");
		panel_4.setLayout(new BorderLayout(0, 0));
		
		JLabel lblThickness = new JLabel(TEXT_COLOR_LABEL_TEXT);
		panel_4.add(lblThickness, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		inner.add(panel, "6, 2, fill, fill");
		panel.setLayout(new BorderLayout(0, 0));
		
		//Text Color Button
		this.textColor = new StyleColoredButton();
		panel.add(textColor, BorderLayout.WEST);
		this.textColor.setActionCommand(TEXT_COLOR);
		this.textColor.addActionListener(this);
		
		JPanel panel_5 = new JPanel();
		inner.add(panel_5, "2, 4, fill, fill");
		panel_5.setLayout(new BorderLayout(0, 0));
		
		JLabel lblTooltipText = new JLabel(BACKGROUND_COLOR_LABEL_TEXT);
		panel_5.add(lblTooltipText, BorderLayout.EAST);
		
		JPanel panel_1 = new JPanel();
		inner.add(panel_1, "6, 4, fill, fill");
		panel_1.setLayout(new BorderLayout(0, 0));
		
		//Background Color Button
		this.backgroundColor = new StyleColoredButton();
		panel_1.add(backgroundColor, BorderLayout.WEST);
		this.backgroundColor.setActionCommand(BACKGROUND_COLOR);
		this.backgroundColor.addActionListener(this);	
		
		JPanel panel_6 = new JPanel();
		inner.add(panel_6, "2, 6, fill, fill");
		panel_6.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFeatureShape = new JLabel(FONT_FAMILY_LABEL_TEXT);
		panel_6.add(lblFeatureShape, BorderLayout.EAST);
		
		JPanel panel_2 = new JPanel();
		inner.add(panel_2, "6, 6, fill, fill");
		panel_2.setLayout(new BorderLayout(0, 0));
		
		//Font Family Combo Box
		this.fontFamily = new JComboBox(StyleEditorUtility.FONT_NAMES);
		this.fontFamily.setActionCommand(FONT_FAMILY);
		this.fontFamily.addActionListener(this);
		panel_2.add(fontFamily, BorderLayout.WEST);
		
		JPanel panel_10 = new JPanel();
		inner.add(panel_10, "2, 8, fill, fill");
		panel_10.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFontStyle = new JLabel(FONT_STYLE_LABEL_TEXT);
		panel_10.add(lblFontStyle, BorderLayout.EAST);
		
		JPanel panel_11 = new JPanel();
		inner.add(panel_11, "6, 8, fill, fill");
		panel_11.setLayout(new BorderLayout(0, 0));
		
		//Font Style Combo Box
		this.fontStyle = new JComboBox(StyleEditorUtility.FONT_STYLES);
		this.fontStyle.setActionCommand(FONT_STYLE);
		this.fontStyle.addActionListener(this);
		panel_11.add(fontStyle, BorderLayout.WEST);
		
		JPanel panel_12 = new JPanel();
		inner.add(panel_12, "2, 10, fill, fill");
		panel_12.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFontSize = new JLabel(FONT_SIZE_LABEL_TEXT);
		panel_12.add(lblFontSize, BorderLayout.EAST);
		
		JPanel panel_13 = new JPanel();
		inner.add(panel_13, "6, 10, fill, fill");
		panel_13.setLayout(new BorderLayout(0, 0));
		
		//font size text field
		this.fontSize = new JTextField();
		this.fontSize.setColumns(10);
		panel_13.add(fontSize, BorderLayout.WEST);
		this.fontSize.getDocument().addDocumentListener(this);
		
		JPanel panel_7 = new JPanel();
		inner.add(panel_7, "2, 12, fill, fill");
		panel_7.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFeatureEffect = new JLabel(LABEL_TEXT_LABEL_TEXT);
		panel_7.add(lblFeatureEffect, BorderLayout.EAST);
		
		JPanel panel_3 = new JPanel();
		inner.add(panel_3, "6, 12, fill, fill");
		panel_3.setLayout(new BorderLayout(0, 0));
		
		//Label Text (Extractor)
		
		JPanel labelTextPanel = new JPanel();
		labelTextPanel.setLayout(new BorderLayout());
		panel_3.add(labelTextPanel, BorderLayout.WEST);
		
		//Combo Box
		this.labelText = new JComboBox(LABEL_TEXTS);
		this.labelText.addActionListener(this);
		this.labelText.setActionCommand(LABEL_TEXT);
		labelTextPanel.add(this.labelText, BorderLayout.WEST);
		
		//Text Field
		this.labelTextField = new JTextField();
		this.labelTextField.setColumns(10);
		this.fontSize.getDocument().addDocumentListener(this);
		this.labelTextField.setVisible(true);
		labelTextPanel.add(this.labelTextField, BorderLayout.EAST);
		
		//
		
		JPanel panel_8 = new JPanel();
		inner.add(panel_8, "2, 14, fill, fill");
		panel_8.setLayout(new BorderLayout(0, 0));
		
		JLabel lblColor = new JLabel(SHOW_LABELS_LABEL_TEXT);
		panel_8.add(lblColor, BorderLayout.EAST);
		
		JPanel panel_9 = new JPanel();
		inner.add(panel_9, "6, 14, fill, fill");
		panel_9.setLayout(new BorderLayout(0, 0));
		
		//Show Labels Check Box
		this.showLabels = new JCheckBox("");
		this.showLabels.setActionCommand(SHOW_LABELS);
		panel_9.add(this.showLabels, BorderLayout.WEST);
		
		this.update();
	}
	
	/**
	 * Gets the color of the label text.
	 * 
	 */
	private Paint getTextPaint()
	{
		Paint p = this.textColor.getRealPaint();
		
		return p;
	}
	
	/**
	 * Gets the color of the label background.
	 * 
	 */
	private Paint getBackgroundPaint()
	{
		Paint p = this.backgroundColor.getRealPaint();
		
		return p;
	}
	
	/**
	 * Gets the font family.
	 *
	 */
	private String getFontFamily()
	{
		Object temp;
		String result;
		
		temp = this.fontFamily.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Font Family is not a String");
		}
		
		return result;
	}
	
	/**
	 * 
	 * @return The selected label font style as a string.
	 */
	private String getFontStyle()
	{
		Object temp;
		String result;
		
		temp = this.fontStyle.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Font Style is not a String");
		}
		
		return result;
	}
	
	/**
	 * 
	 * @return The text in the font size field.
	 */
	private String getFontSizeText()
	{
		return this.fontSize.getText();
	}
	
	/**
	 * Gets the text of the label text field.
	 * 
	 */
	private String getLabelTextField()
	{
		return this.labelTextField.getText();
	}
	
	/**
	 * Gets the selection in the label text combo box. 
	 */
	private String getLabelText()
	{
		Object temp;
		String result;
		
		temp = this.labelText.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Label Text is not a String");
		}
		
		return result;
	}
	

	/**
	 * 
	 * @return Whether or not show labels is selected.
	 */
	private boolean getShowLabels()
	{
		return this.showLabels.isSelected();
	}
	
	/**
	 * Sets the color of the label text.
	 * 
	 * @param c
	 */
	private void setTextPaint(Paint p)
	{	
		this.textColor.setPaint(p);
	}
	
	/**
	 * Sets the color of the label background.
	 * 
	 * @param c
	 */
	private void setBackgroundPaint(Paint p)
	{
		this.backgroundColor.setPaint(p);
	}
	
	/**
	 * Sets the font family.
	 * 
	 * @param font
	 */
	private void setFontFamily(String font)
	{
		this.fontFamily.setSelectedItem(font);
	}
	
	/**
	 * Sets the font style.
	 * 
	 * @param font
	 */
	private void setFontStyle(String font)
	{
		this.fontStyle.setSelectedItem(font);
	}
	
	/**
	 * Sets the text field of the font size.
	 * 
	 * @param i
	 */
	private void setFontSizeText(int i)
	{
		this.fontSize.setText(Integer.toString(i));
	}
	
	/**
	 * Sets the text of the label text field.
	 * 
	 * @param string
	 */
	private void setLabelTextField(String string)
	{
		this.labelTextField.setText(string);
	}
	
	/**
	 * Sets the selection in the label text combo box.
	 * 
	 * @param text
	 */
	private void setLabelText(String text)
	{
		this.labelText.setSelectedItem(text);
	}
	
	/**
	 * Sets the show labels check box.
	 * 
	 * @param show Whether or not to show the labels.
	 */
	private void setShowLabels(boolean show)
	{
		this.showLabels.setSelected(show);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		Color c;
		
		if(e.getActionCommand().equals(TEXT_COLOR))
		{
			c = StyleEditorUtility.showColorPicker(this, this.textColor.getBackground());
			
			if(c != null)
				this.textColor.setPaint(c);
		}
		else if(e.getActionCommand().equals(BACKGROUND_COLOR))
		{
			c = StyleEditorUtility.showColorPicker(this, this.backgroundColor.getBackground());
			
			if(c != null)
				this.backgroundColor.setPaint(c);
		}
		else if(e.getActionCommand().equals(LABEL_TEXT))
		{
			if(this.labelText.getSelectedItem().equals(ANNOTATION) || labelText.getSelectedItem().equals(STRING_BUILDER))
			{
				this.labelTextField.setVisible(true);
				this.revalidate();
			}
			else
			{
				this.labelTextField.setVisible(false);
			}
		}
		
		super.actionPerformed(e);	
	}

	@Override
	/**
	 * Updates the panel.
	 */
	public void update()
	{
		updateTextColor();
		updateBackgroundColor();
		updateFont();
		updateLabelText();
		updateShowLabels();
	}
	
	/**
	 * Updates the text color button.
	 */
	private void updateTextColor()
	{
		Paint tempPaint = this.labelStyle.getTextPaint();
		
		setTextPaint(tempPaint);
	}
	
	/**
	 * Updates the background color button.
	 */
	private void updateBackgroundColor()
	{
		Paint tempPaint = this.labelStyle.getBackgroundPaint();
			
		setBackgroundPaint(tempPaint);
	}
	
	/**
	 * Updates the font components.
	 */
	private void updateFont()
	{
		Font tempFont = this.labelStyle.getFont();
		
		if(tempFont != null)
		{
			setFontFamily(tempFont.getFamily());
			
			if(tempFont.isBold() && tempFont.isItalic())
			{
				setFontStyle(StyleEditorUtility.BOLD_ITALIC);
			}			
			else if(tempFont.isBold())
			{
				setFontStyle(StyleEditorUtility.BOLD);
			}
			else if(tempFont.isItalic())
			{
				setFontStyle(StyleEditorUtility.ITALIC);
			}
			else if(tempFont.isPlain())
			{
				setFontStyle(StyleEditorUtility.PLAIN);
			}
			
			setFontSizeText(tempFont.getSize());
		}
	}
	
	/**
	 * Updates the label text components.
	 */
	private void updateLabelText()
	{
		FeatureTextExtractor textExtractor;
		
		textExtractor = this.labelStyle.getLabelExtractor();
		
		if(textExtractor instanceof AnnotationExtractor)
		{
			setLabelText(ANNOTATION);
			setLabelTextField(((AnnotationExtractor)textExtractor).getAnnotation());
		}
		else if(textExtractor instanceof LocationExtractor)
		{
			setLabelText(LOCATION);
		}
		else if(textExtractor instanceof SymbolsExtractor)
		{
			setLabelText(SYMBOLS);
		}
		else if(textExtractor instanceof StringExtractor)
		{
			setLabelText(STRING_BUILDER);
			setLabelTextField(((StringExtractor)textExtractor).getDisplayText());
		}
		else if(textExtractor instanceof BlankExtractor)
		{
			setLabelText(BLANK);
		}
	}
	
	/**
	 * Updates the show labels check box.
	 */
	private void updateShowLabels()
	{
		setShowLabels(this.labelStyle.showLabels());
	}

	@Override
	/**
	 * Applies the style to the labelStyle.
	 */
	protected void doApply()
	{
		applyTextColor();
		applyBackgroundColor();
		applyFont();
		applyLabelText();
		applyShowLabels();
	}
	
	/**
	 * Applies the text color.
	 */
	private void applyTextColor()
	{
		this.labelStyle.setTextPaint(getTextPaint());
	}
	
	/**
	 * Applies the background color.
	 */
	private void applyBackgroundColor()
	{
		this.labelStyle.setBackgroundPaint(getBackgroundPaint());
	}
	
	/**
	 * Applies the font.
	 */
	private void applyFont()
	{		
		//font size
		try
		{
			Font f = StyleEditorUtility.getFont(getFontFamily(),getFontStyle(),getFontSizeText());
			this.labelStyle.setFont(f);
		}
		catch (StyleEditorUtility.ConversionException e)
		{
			JOptionPane.showMessageDialog(this, e.getMessage());
		}
	}
	
	private FeatureTextExtractor getLabelTextExtractor()
	{
		String labelTextSelected = getLabelText();
		FeatureTextExtractor textExtractor = null;

		if(labelTextSelected.equals(ANNOTATION))
		{
			textExtractor = new AnnotationExtractor(getLabelTextField());
		}
		else if(labelTextSelected.equals(LOCATION))
		{
			textExtractor = new LocationExtractor();
		}
		else if(labelTextSelected.equals(SYMBOLS))
		{
			textExtractor = new SymbolsExtractor();
		}
		else if(labelTextSelected.equals(STRING_BUILDER))
		{
			textExtractor = new StringExtractor(getLabelTextField());
		}
		else if(labelTextSelected.equals(BLANK))
		{
			textExtractor = new BlankExtractor();
		}
		
		return textExtractor;
	}
	
	/**
	 * Applies the label text.
	 */
	private void applyLabelText()
	{
		FeatureTextExtractor textExtractor = getLabelTextExtractor();

		if (textExtractor != null)
		{
			this.labelStyle.setLabelExtractor(textExtractor);
		}
	}
	
	/**
	 * Applies the show labels check box.
	 */
	private void applyShowLabels()
	{
		this.labelStyle.setShowLabels(getShowLabels());
	}

	@Override
	protected boolean modified()
	{
		boolean modified = false;
		
		modified = modified || !Util.isEqual(getTextPaint(),this.labelStyle.getTextPaint());
		modified = modified || !Util.isEqual(getBackgroundPaint(),this.labelStyle.getBackgroundPaint());
		try
		{
			modified = modified || !Util.isEqual(this.labelStyle.getFont(),StyleEditorUtility.getFont(getFontFamily(),getFontStyle(),getFontSizeText()));
		}
		catch (ConversionException e)
		{
		}
		modified = modified || !Util.isEqual(this.labelStyle.getLabelExtractor(),this.getLabelTextExtractor());
		modified = modified || !(this.getShowLabels() == this.labelStyle.showLabels());
		
		return modified;
	}
}
