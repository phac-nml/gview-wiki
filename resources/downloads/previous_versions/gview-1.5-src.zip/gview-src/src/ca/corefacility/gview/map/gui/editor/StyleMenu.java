package ca.corefacility.gview.map.gui.editor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;


/**
 * The style menu class.
 * 
 * This style menu is intended to exist on a StyleEditorFrame menu.
 * 
 * @author Eric Marinier
 *
 */
public class StyleMenu extends JMenu implements ActionListener
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private static final String RENAME_STYLE_TEXT = "Rename Style";	//style text
	private static final String RENAME_STYLE = "Rename Style";	//style action command
	
	private final StyleEditorFrame styleEditorFrame;	//the style editor frame	
	private final JMenuItem renameStyleItem;	//the exit menu item
	
	/**
	 * Creates the file menu.
	 * 
	 * @param styleEditorFrame The style editor frame the menu will exist on.
	 */
	public StyleMenu(StyleEditorFrame styleEditorFrame)
	{
		super(StyleEditorUtility.STYLE_TEXT);
		
		if(styleEditorFrame == null)
			throw new IllegalArgumentException("StyleEditorFrame is null");
		
		this.styleEditorFrame = styleEditorFrame;
		
		//Style item
		this.renameStyleItem = new JMenuItem(RENAME_STYLE_TEXT);
		this.renameStyleItem.setActionCommand(RENAME_STYLE);
		this.renameStyleItem.addActionListener(this);
		add(this.renameStyleItem);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getActionCommand().equals(RENAME_STYLE))
		{
			renameCurrentStyle();
		}		
	}

	/**
	 * Renames the current style.
	 * Prompts the user with an input dialog.
	 */
	private void renameCurrentStyle()
	{
		String name = JOptionPane.showInputDialog(null,"Enter a new name:", "Rename Style", JOptionPane.PLAIN_MESSAGE);
		
		if(name != null)
			this.styleEditorFrame.setStyleName(name);
	}
	
}
