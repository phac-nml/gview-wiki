package ca.corefacility.gview.map.gui.menu;

import java.util.Iterator;

import javax.swing.JMenu;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.editor.StyleEditorTree;

/**
 * The Style menu.
 * 
 * @author Eric Marinier
 *
 */
public class StyleMenu extends JMenu implements MenuListener
{
	private static final long serialVersionUID = 1L;
	private static final String STYLES_TEXT = "Styles";
	
	private final JMenu stylesMenu;
	
//	private final GlobalStyleMenuItem globalStyle;
//	private final BackboneStyleMenuItem backboneStyle;
//	private final RulerStyleMenuItem rulerStyle;
//	private final TooltipStyleMenuItem tooltipStyle;
	
	//Items in the File menu.
	private final StyleEditorMenuItem styleEditorItem;
	
	private final GViewGUIFrame gViewGUIFrame;
	
	/**
	 * 
	 * @param gViewGUIFrame The related GUI frame.
	 */
	public StyleMenu(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.STYLE_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;
		
		//Styles Sub Menu
		this.stylesMenu = new JMenu(STYLES_TEXT);
		this.add(this.stylesMenu);
		
//		this.addSeparator();
//		
//		//Global Menu Item
//		this.globalStyle = new GlobalStyleMenuItem(gViewGUIFrame);
//		this.add(this.globalStyle);
//		
//		//Backbone Menu Item
//		this.backboneStyle = new BackboneStyleMenuItem(gViewGUIFrame);
//		this.add(this.backboneStyle);
//		
//		//Ruler Style Menu Item
//		this.rulerStyle = new RulerStyleMenuItem(gViewGUIFrame);
//		this.add(this.rulerStyle);
//		
//		//Tooltip Style Menu Item
//		this.tooltipStyle = new TooltipStyleMenuItem(gViewGUIFrame);
//		this.add(this.tooltipStyle);
		
		this.addSeparator();
		
		//Style Editor Menu Item
		this.styleEditorItem = new StyleEditorMenuItem(gViewGUIFrame);
		this.add(this.styleEditorItem);
		
		this.addMenuListener(this);
	}
	
	/**
	 * Updates the styles menu.
	 */
	private void updateStylesMenu()
	{
		StyleMenuItem currentMenuItem;
		StyleEditorTree currentStyle;
		Iterator<StyleEditorTree> styles = this.gViewGUIFrame.getStyles();
		
		this.stylesMenu.removeAll();
		
		while(styles.hasNext())
		{
			currentStyle = styles.next();
			currentMenuItem = new StyleMenuItem(this.gViewGUIFrame, currentStyle);			
			
			if(currentStyle.equals(this.gViewGUIFrame.getCurrentStyle()))
			{
				currentMenuItem.setSelected(true);
			}
			else
			{
				currentMenuItem.setSelected(false);
			}
			
			this.stylesMenu.add(currentMenuItem);
		}
	}

	@Override
	public void menuSelected(MenuEvent e)
	{
		updateStylesMenu();	
	}

	@Override
	public void menuDeselected(MenuEvent e)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void menuCanceled(MenuEvent e)
	{
		// TODO Auto-generated method stub
		
	}
}
