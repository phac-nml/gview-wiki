package ca.corefacility.gview.map.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.action.dialog.show.ShowBEVDialogAction;
import ca.corefacility.gview.map.gui.action.dialog.show.ShowScaleDialogAction;
import ca.corefacility.gview.map.gui.action.dialog.show.ShowZoomDialogAction;
import ca.corefacility.gview.map.gui.action.map.FITMAction;
import ca.corefacility.gview.map.gui.action.map.move.MoveEndAction;
import ca.corefacility.gview.map.gui.action.map.move.MoveHalfAction;
import ca.corefacility.gview.map.gui.action.map.move.MoveStartAction;
import ca.corefacility.gview.map.gui.action.map.scale.ScaleInAction;
import ca.corefacility.gview.map.gui.action.map.scale.ScaleOutAction;
import ca.corefacility.gview.map.gui.action.map.zoom.ZoomInAction;
import ca.corefacility.gview.map.gui.action.map.zoom.ZoomOutAction;

/**
 * The default tool bar for the GUI frame.
 * 
 * @author Eric Marinier
 *
 */
public class GViewToolBar extends JToolBar implements ActionListener, GViewMapListener
{
	private static final long serialVersionUID = 1L;
	
	private final String magnifierPath = "images/icons/magnifier.png";
	private final String magnifierPlusPath = "images/icons/magnifier--plus.png";
	private final String magnifierMinusPath = "images/icons/magnifier--minus.png";
	private final String magnifierZoomPath = "images/icons/magnifier-zoom.png";
	private final String magnifierZoomInPath = "images/icons/magnifier-zoom-in.png";
	private final String magnifierZoomOutPath = "images/icons/magnifier-zoom-out.png";
	private final String moveStartPath = "images/icons/control-180.png";
	private final String moveEndPath = "images/icons/control.png";
	private final String moveMiddlePath = "images/icons/control-270.png";
	private final String fitImageToScreenPath = "images/icons/layer-resize.png";
	private final String birdsEyeViewPath = "images/icons/eye.png";
	
	private final JButton magnifier;
	private final JButton magnifierPlus;
	private final JButton magnifierMinus;
	private final JButton magnifierZoom;
	private final JButton magnifierZoomIn;
	private final JButton magnifierZoomOut;
	private final JButton moveStart;
	private final JButton moveEnd;
	private final JButton moveMiddle;
	private final JButton fitImageToScreen;
	private final JButton birdsEyeView;
	
	private final GViewGUIFrame gViewGUIFrame;
	
	/**
	 * @param gViewGUIFrame The frame on which the tool bar will be placed.
	 */
	public GViewToolBar(GViewGUIFrame gViewGUIFrame)
	{
		super();
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null");
		
		this.gViewGUIFrame = gViewGUIFrame;
		this.gViewGUIFrame.addGViewMapListener(this);
		
		this.setFloatable(false);
		
		this.magnifier = new JButton(new ImageIcon(GUIUtility.loadImage(magnifierPath)));
		this.magnifier.setToolTipText(GUIUtility.SCALE_CUSTOM);
		this.magnifier.setActionCommand(GUIUtility.SCALE_CUSTOM);
		this.magnifier.addActionListener(this);
		
		this.magnifierPlus = new JButton(new ImageIcon(GUIUtility.loadImage(magnifierPlusPath)));
		this.magnifierPlus.setToolTipText(GUIUtility.SCALE_IN);
		this.magnifierPlus.setActionCommand(GUIUtility.SCALE_IN);
		this.magnifierPlus.addActionListener(this);
		
		this.magnifierMinus = new JButton(new ImageIcon(GUIUtility.loadImage(magnifierMinusPath)));
		this.magnifierMinus.setToolTipText(GUIUtility.SCALE_OUT);
		this.magnifierMinus.setActionCommand(GUIUtility.SCALE_OUT);
		this.magnifierMinus.addActionListener(this);
		
		this.magnifierZoom = new JButton(new ImageIcon(GUIUtility.loadImage(magnifierZoomPath)));
		this.magnifierZoom.setToolTipText(GUIUtility.ZOOM_CUSTOM);
		this.magnifierZoom.setActionCommand(GUIUtility.ZOOM_CUSTOM);
		this.magnifierZoom.addActionListener(this);
		
		this.magnifierZoomIn = new JButton(new ImageIcon(GUIUtility.loadImage(magnifierZoomInPath)));
		this.magnifierZoomIn.setToolTipText(GUIUtility.ZOOM_IN);
		this.magnifierZoomIn.setActionCommand(GUIUtility.ZOOM_IN);
		this.magnifierZoomIn.addActionListener(this);
		
		this.magnifierZoomOut = new JButton(new ImageIcon(GUIUtility.loadImage(magnifierZoomOutPath)));
		this.magnifierZoomOut.setToolTipText(GUIUtility.ZOOM_OUT);
		this.magnifierZoomOut.setActionCommand(GUIUtility.ZOOM_OUT);
		this.magnifierZoomOut.addActionListener(this);
		
		this.moveStart = new JButton(new ImageIcon(GUIUtility.loadImage(moveStartPath)));
		this.moveStart.setToolTipText(GUIUtility.START);
		this.moveStart.setActionCommand(GUIUtility.START);
		this.moveStart.addActionListener(this);
		
		this.moveMiddle = new JButton(new ImageIcon(GUIUtility.loadImage(moveMiddlePath)));
		this.moveMiddle.setToolTipText(GUIUtility.HALF);
		this.moveMiddle.setActionCommand(GUIUtility.HALF);
		this.moveMiddle.addActionListener(this);
		
		this.moveEnd = new JButton(new ImageIcon(GUIUtility.loadImage(moveEndPath)));
		this.moveEnd.setToolTipText(GUIUtility.END);
		this.moveEnd.setActionCommand(GUIUtility.END);
		this.moveEnd.addActionListener(this);
		
		this.fitImageToScreen = new JButton(new ImageIcon(GUIUtility.loadImage(fitImageToScreenPath)));
		this.fitImageToScreen.setToolTipText(GUIUtility.FMTS_TEXT);
		this.fitImageToScreen.setActionCommand(GUIUtility.FMTS_TEXT);
		this.fitImageToScreen.addActionListener(this);
		
		this.birdsEyeView = new JButton(new ImageIcon(GUIUtility.loadImage(birdsEyeViewPath)));
		this.birdsEyeView.setToolTipText(GUIUtility.BEV);
		this.birdsEyeView.setActionCommand(GUIUtility.BEV);
		this.birdsEyeView.addActionListener(this);
		
		this.add(magnifierPlus);
		this.add(magnifierMinus);
		this.add(magnifier);
		
		this.addSeparator();
		
		this.add(magnifierZoomIn);
		this.add(magnifierZoomOut);
		this.add(magnifierZoom);
		
		this.addSeparator();
		
		this.add(fitImageToScreen);
		this.add(birdsEyeView);
		
		this.addSeparator();
		
		this.add(moveStart);
		this.add(moveMiddle);
		this.add(moveEnd);
		
		this.addSeparator();

	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(GUIUtility.SCALE_IN.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ScaleInAction(gViewGUIFrame.getGViewMap()));
		}
		else if(GUIUtility.SCALE_OUT.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ScaleOutAction(gViewGUIFrame.getGViewMap()));
		}
		else if(GUIUtility.SCALE_CUSTOM.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ShowScaleDialogAction(gViewGUIFrame.getScaleDialog()));
		}
		else if(GUIUtility.ZOOM_IN.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ZoomInAction(gViewGUIFrame.getGViewMap()));
		}
		else if(GUIUtility.ZOOM_OUT.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ZoomOutAction(gViewGUIFrame.getGViewMap()));
		}
		else if(GUIUtility.ZOOM_CUSTOM.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ShowZoomDialogAction(gViewGUIFrame.getZoomDialog()));
		}
		else if(GUIUtility.START.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new MoveStartAction(gViewGUIFrame.getGViewMap()));
		}
		else if(GUIUtility.HALF.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new MoveHalfAction(gViewGUIFrame.getGViewMap()));
		}
		else if(GUIUtility.END.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new MoveEndAction(gViewGUIFrame.getGViewMap()));
		}
		else if(GUIUtility.FMTS_TEXT.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new FITMAction(gViewGUIFrame.getGViewMap()));
		}
		else if(GUIUtility.BEV.equals(e.getActionCommand()))
		{
			gViewGUIFrame.doAction(new ShowBEVDialogAction(gViewGUIFrame.getBEVDialog()));
		}
	}

	@Override
	public void setGViewMap(GViewMap gViewMap)
	{
			
	}
}
