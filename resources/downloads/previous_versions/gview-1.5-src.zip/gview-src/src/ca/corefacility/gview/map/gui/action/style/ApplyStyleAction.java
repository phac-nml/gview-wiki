package ca.corefacility.gview.map.gui.action.style;

import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.layout.sequence.ZoomException;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.GViewGUIFrame;

public class ApplyStyleAction extends StyleAction
{
	private final GViewGUIFrame gViewGUIFrame;
	
	public ApplyStyleAction(GViewGUIFrame gViewGUIFrame)
	{
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null");	
		
		this.gViewGUIFrame = gViewGUIFrame;
	}
	
	@Override
	public void undo() throws CannotUndoException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void redo() throws CannotRedoException
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void run()
	{
		if(this.gViewGUIFrame == null)
			throw new NullPointerException("GViewGUIFrame is null.");
		
		if(this.gViewGUIFrame.getGViewMap() != null)
		{
		    GViewMap gviewMap = this.gViewGUIFrame.getGViewMap();
		    double centerBase = gviewMap.getCenterBaseValue();
		    double zoomValue = gviewMap.getZoomFactor();
		    double zoomNormalFactor = gviewMap.getZoomNormalFactor();
		    
			this.gViewGUIFrame.getGViewMap().setMapStyle(this.gViewGUIFrame.getGViewMap().getMapStyle());
			gviewMap.setCenter((int)centerBase);
			try
            {
                gviewMap.setZoomFactor(zoomValue);
            }
			catch (ZoomException e)
            {
			    System.err.println(e);
            }
			gviewMap.zoomNormal(zoomNormalFactor);
			this.gViewGUIFrame.getBEVDialog().setGViewMap(this.gViewGUIFrame.getGViewMap());
		}
	}
}
