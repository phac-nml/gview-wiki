

package ca.corefacility.gview.map.gui.editor.featureFilter;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.StringReader;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

import ca.corefacility.gview.map.gui.editor.StyleEditorTree;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility;
import ca.corefacility.gview.map.gui.editor.node.FeatureContainerNode;
import ca.corefacility.gview.style.io.gss.FeatureFilterHandler;
import ca.corefacility.gview.utils.AnnotationValueContains;
import ca.corefacility.gview.utils.SequenceNameFilter;

import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.RangeLocation;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

/**
 * A subclass of JDialog, used for returning a new FeatureFilter. 
 * 
 * Intended to be called from a StyleEditorTree.
 * 
 * @author Eric Marinier
 *
 */
public class FeatureFilterChooserDialog extends JDialog implements ActionListener
{
	private static final long serialVersionUID = 1L;	//requested by java	
	
	private static final String TITLE = "Feature Filter Chooser";
	private static final String OK = "OK";
	private static final String CANCEL = "Canel";
	
	private static final String FEATURE_FILTER_COMBO_BOX = "Feature Filter Combo Box";
	
	private final JButton okButton;
	private final JButton cancelButton;
	
	private final JPanel contentPanel;
	private final JPanel specificContent;
	
	//allows the user to choose their feature filter
	private final JComboBox featureFilterComboBox;
	
	private final AnnotationValueContainsPanel annotationValueContainsPanel = new AnnotationValueContainsPanel(); 
	private final AnnotationValueEqualsPanel annotationValueEqualsPanel = new AnnotationValueEqualsPanel(); 
	private final ByTypePanel byTypePanel = new ByTypePanel();
	private final GSSStringPanel gssStringPanel = new GSSStringPanel();
	private final HasAnnotationPanel hasAnnotationPanel = new HasAnnotationPanel();
	private final OverlapsLocationPanel overlapsLocationPanel = new OverlapsLocationPanel();
	private final SequenceNamePanel sequenceNamePanel = new SequenceNamePanel();
	private final StrandedPanel strandedPanel = new StrandedPanel();
	
	private final StyleEditorTree styleTree;
	private final FeatureContainerNode parentNode;

	/**
	 * 
	 * @param styleEditorTree The related style editor tree.
	 * @param parentNode The parent node to create the set under.
	 */
	public FeatureFilterChooserDialog(StyleEditorTree styleEditorTree, FeatureContainerNode parentNode)
	{		
		if(styleEditorTree == null)
		{
			throw new IllegalArgumentException("StyleEditorTree is null.");
		}
		
		if(parentNode == null)
		{
			throw new IllegalArgumentException("FeatureContainerNode is null.");
		}
		
		this.styleTree = styleEditorTree;
		this.parentNode = parentNode;
		
		this.setTitle(TITLE);
		this.setModal(true);	//blocks interaction with GUI components underneath.
		
		//initialize
		this.okButton = createOKButton();
		this.cancelButton = createCancelButton();
		this.featureFilterComboBox = createFeatureFilterComboBox();
		
		this.specificContent  = createSpecificContentPanel();
		this.contentPanel = createContentPanel();	
		
		layoutComponents();
		
		this.setModal(true);
		
		updateSpecificContent();	
	}
	
	/**
	 * Layout the components of the dialog.
	 */
	private void layoutComponents()
	{
		JPanel comboBoxPanel = createComboBoxPanel();
		
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(this.contentPanel, BorderLayout.CENTER);
		
		this.contentPanel.add(comboBoxPanel, BorderLayout.NORTH);
		this.contentPanel.add(this.specificContent, BorderLayout.SOUTH);		
		
		this.getContentPane().add(createButtonPanel(), BorderLayout.SOUTH);		
	}
	
	/**
	 * 
	 * @return A new JPanel for the specific content panel variable.
	 */
	private JPanel createSpecificContentPanel()
	{
		JPanel specificContentPanel = new JPanel();
		
		specificContentPanel.setLayout(new BoxLayout(specificContentPanel, BoxLayout.Y_AXIS));
		
		return specificContentPanel;
	}
	
	/**
	 * 
	 * @return A new JPanel for the combo box panel variable.
	 */
	private JPanel createComboBoxPanel()
	{
		JPanel comboBoxPanel = new JPanel();
		
		comboBoxPanel.setBorder(new TitledBorder(null, "Mapper Type", TitledBorder.LEADING, TitledBorder.ABOVE_TOP, null, null));
		FlowLayout flowLayout = (FlowLayout) comboBoxPanel.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		
		comboBoxPanel.add(this.featureFilterComboBox);
		
		return comboBoxPanel;
	}
	
	/**
	 * 
	 * @return A new JComboBox for the feature filter combo box variable.
	 */
	private JComboBox createFeatureFilterComboBox()
	{
		JComboBox propertyMapperComboBox = new JComboBox(StyleEditorUtility.FEATURE_FILTERS);
		
		propertyMapperComboBox.setActionCommand(FEATURE_FILTER_COMBO_BOX);
		propertyMapperComboBox.addActionListener(this);
		
		return propertyMapperComboBox;
	}
	
	/**
	 * 
	 * @return A new JPanel for the content panel variable.
	 */
	private JPanel createContentPanel()
	{
		JPanel contentPanel = new JPanel();
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));		
		contentPanel.setLayout(new BorderLayout(0, 0));
		
		return contentPanel;
	}
	
	/**
	 * 
	 * @return A new JButton - ok button.
	 */
	private JButton createOKButton()
	{
		JButton okButton = new JButton(OK);
		okButton.setActionCommand(OK);
		okButton.addActionListener(this);
		
		return okButton;
	}
	
	/**
	 * 
	 * @return A new JButton - cancel button.
	 */
	private JButton createCancelButton()
	{
		JButton cancelButton = new JButton(CANCEL);
		cancelButton.setActionCommand(CANCEL);
		cancelButton.addActionListener(this);
		
		return cancelButton;
	}
	
	/**
	 * 
	 * @return A new JPanel - the button panel for the buttons.
	 */
	private JPanel createButtonPanel()
	{
		JPanel buttonPanel = new JPanel();
		
		buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
		buttonPanel.add(this.okButton);
		buttonPanel.add(this.cancelButton);
		
		getRootPane().setDefaultButton(okButton);
		
		return buttonPanel;
	}
	
	/**
	 * Updates the content specific portion of the panel with GUI components that are appropriate to the current
	 * combo box selection.
	 */
	private void updateSpecificContent()
	{
		this.specificContent.removeAll();
		
		if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_ALL))
		{			
			//nothing
		}
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_AND))
		{			
			this.specificContent.add(this.gssStringPanel);
		}
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_ANNOTATION_VALUE_CONTAINS))
		{			
			this.specificContent.add(this.annotationValueContainsPanel);
		}
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_ANNOTATION_VALUE_EQUALS))
		{			
			this.specificContent.add(this.annotationValueEqualsPanel);
		}
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_BY_TYPE))
		{			
			this.specificContent.add(this.byTypePanel);
		}
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_GSS_STRING))
		{			
			this.specificContent.add(this.gssStringPanel);
		}
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_HAS_ANNOTATION))
		{			
			this.specificContent.add(this.hasAnnotationPanel);
		}
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_NOT))
		{			
			this.specificContent.add(this.gssStringPanel);
		}
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_OR))
		{			
			this.specificContent.add(this.gssStringPanel);
		}
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_OVERLAPS_LOCATION))
		{			
			this.specificContent.add(this.overlapsLocationPanel);
		}
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_SEQUENCE_NAME))
		{			
			this.specificContent.add(this.sequenceNamePanel);
		}
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_STRANDED))
		{			
			this.specificContent.add(this.strandedPanel);
		}		
		
		this.pack();
	}
	
	/**
	 * Shows the dialog over the passed frame.
	 * 
	 * @param frame The frame to show the dialog over.
	 */
	public void showDialog(JFrame frame)
	{
		if(frame == null)
			throw new IllegalArgumentException("JFrame is null.");
		
		this.setLocationRelativeTo(frame);	
		this.setVisible(true);		
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		FeatureFilter featureFilter = null;
		
		//OK
		if(e.getActionCommand().equals(OK))
		{
			featureFilter = createFeatureFilter();
			
			if(featureFilter != null)
			{
				this.styleTree.createSetNodeFromFeatureFilter(this.parentNode, featureFilter);				
				this.setVisible(false);
			}				
		}
		//CANCEL
		else if(e.getActionCommand().equals(CANCEL))
		{			
			this.setVisible(false);
		}
		//COMBO BOX
		else if(e.getActionCommand().equals(FEATURE_FILTER_COMBO_BOX))
		{
			updateSpecificContent();
		}
	}	

	/**
	 * Creates and returns a feature filter depending on the user input.
	 * 
	 * @return The user defined FeatureFilter object.
	 */
	private FeatureFilter createFeatureFilter()
	{
		FeatureFilter featureFilter = null;		
		
		//ALL
		if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_ALL))
		{
			featureFilter = createFeatureFilterAll();
		}
		//ANNOTATION VALUE CONTAINS
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_ANNOTATION_VALUE_CONTAINS))
		{
			featureFilter = createFeatureFilterAnnotationValueContains();
		}
		//ANNOTATION VALUE EQUALS
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_ANNOTATION_VALUE_EQUALS))
		{
			featureFilter = createFeatureFilterAnnotationValueEquals();
		}
		//BY TYPE
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_BY_TYPE))
		{
			featureFilter = createFeatureFilterByType();
		}
		//HAS ANNOTATION
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_HAS_ANNOTATION))
		{
			featureFilter = createFeatureFilterHasAnnotation();
		}
		//OVERLAPS LOCATION
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_OVERLAPS_LOCATION))
		{
			featureFilter = createFeatureFilterOverlapsLocation();		
		}
		//SEQUENCE NAME
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_SEQUENCE_NAME))
		{
			featureFilter = createFeatureFilterSequenceName();
		}
		//STRANDED
		else if(this.featureFilterComboBox.getSelectedItem().equals(StyleEditorUtility.FEATURE_STRANDED))
		{
			featureFilter = createFeatureFilterStranded();		
		}
		//TRY TO PARSE IT
		else
		{	
			featureFilter = createFeatureFilterParsed();
		}
		
		return featureFilter;
	}
	
	/**
	 * 
	 * @return An 'all' feature filter.
	 */
	private FeatureFilter createFeatureFilterAll()
	{
		return FeatureFilter.all;
	}
	
	/**
	 * 
	 * @return An annotation value contains feature filter.
	 */
	private FeatureFilter createFeatureFilterAnnotationValueContains()
	{		
		return new AnnotationValueContains(this.annotationValueContainsPanel.getAnnotation(), this.annotationValueContainsPanel.getValue());
	}
	
	/**
	 * 
	 * @return An annotation value equals feature filter.
	 */
	private FeatureFilter createFeatureFilterAnnotationValueEquals()
	{		
		return new FeatureFilter.ByAnnotation(this.annotationValueEqualsPanel.getAnnotation(), this.annotationValueEqualsPanel.getValue());
	}
	
	/**
	 * 
	 * @return A by type feature filter.
	 */
	private FeatureFilter createFeatureFilterByType()
	{
		return new FeatureFilter.ByType(this.byTypePanel.getType());
	}
	
	/**
	 * 
	 * @return A has annotation feature filter.
	 */
	private FeatureFilter createFeatureFilterHasAnnotation()
	{
		return new FeatureFilter.HasAnnotation(this.hasAnnotationPanel.getAnnotation());
	}
	
	/**
	 * 
	 * @return A overlaps location feature filter.
	 */
	private FeatureFilter createFeatureFilterOverlapsLocation()
	{	
		FeatureFilter result = null;
		
		try
		{
			result = new FeatureFilter.OverlapsLocation(new RangeLocation(Integer.parseInt(this.overlapsLocationPanel.getStart()), 
					Integer.parseInt(this.overlapsLocationPanel.getEnd())));
		}
		catch (NumberFormatException nfe)
		{
			JOptionPane.showMessageDialog(this, "Invalid numbers.");
		}
		
		return result;		
	}
	
	/**
	 * 
	 * @return A sequence name feature filter.
	 */
	private FeatureFilter createFeatureFilterSequenceName()
	{
		return new SequenceNameFilter(this.sequenceNamePanel.getSequenceName());
	}
	
	/**
	 * 
	 * @return A stranded feature filter.
	 */
	private FeatureFilter createFeatureFilterStranded()
	{
		FeatureFilter featureFilter = null;
		
		String stranded = this.strandedPanel.getStranded();
		
		if(stranded.equalsIgnoreCase(StyleEditorUtility.POSITIVE))
		{
			featureFilter = new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE);
		}
		else if(stranded.equalsIgnoreCase(StyleEditorUtility.NEGATIVE))
		{
			featureFilter = new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE);
		}
		else if(stranded.equalsIgnoreCase(StyleEditorUtility.UNKNOWN))
		{
			featureFilter = new FeatureFilter.StrandFilter(StrandedFeature.UNKNOWN);
		}
		else
		{
			JOptionPane.showMessageDialog(this, "Unrecognized input. (Expects '" + StyleEditorUtility.POSITIVE 
					+ "', '" + StyleEditorUtility.NEGATIVE +"' or '" + StyleEditorUtility.UNKNOWN + "')");
		}
		
		return featureFilter;
	}
	
	/**
	 * 
	 * @return A feature filter determined by parsing.
	 */
	private FeatureFilter createFeatureFilterParsed()
	{
		FeatureFilter featureFilter = null;
		
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		InputSource inputSource;
		LexicalUnit lexicalUnit;		
		
		JTextArea textArea = new JTextArea();
		textArea.setLineWrap(true);
		
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setPreferredSize(new Dimension(250, 150));
		
		
		try
		{
			inputSource = new InputSource(new StringReader(this.gssStringPanel.getGSS()));
			lexicalUnit = parser.parsePropertyValue(inputSource);
			
			featureFilter = FeatureFilterHandler.decode(lexicalUnit);
		}
		catch (CSSException e)
		{
			textArea.setText(e.toString());
			JOptionPane.showMessageDialog(this, scrollPane, "Parse Error", JOptionPane.WARNING_MESSAGE);			
		}
		catch (IOException e)
		{
			textArea.setText(e.toString());
			JOptionPane.showMessageDialog(this, scrollPane, "Parse Error", JOptionPane.WARNING_MESSAGE);	
		}
		
		return featureFilter;
	}
}
