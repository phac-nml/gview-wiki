package ca.corefacility.gview.map.gui;


import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.DisplayMode;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.net.URI;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.event.GViewEvent;
import ca.corefacility.gview.map.event.GViewEventListener;
import ca.corefacility.gview.map.event.PopUpEvent;
import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.Action.ActionRunException;
import ca.corefacility.gview.map.gui.action.map.FullScreenAction;
import ca.corefacility.gview.map.gui.action.map.show.ShowStyleEditorAction;
import ca.corefacility.gview.map.gui.dialog.AboutDialog;
import ca.corefacility.gview.map.gui.dialog.BEVDialog;
import ca.corefacility.gview.map.gui.dialog.MoveDialog;
import ca.corefacility.gview.map.gui.dialog.ScaleDialog;
import ca.corefacility.gview.map.gui.dialog.ZoomDialog;
import ca.corefacility.gview.map.gui.editor.StyleEditorFrame;
import ca.corefacility.gview.map.gui.editor.StyleEditorTree;
import ca.corefacility.gview.map.gui.menu.FileMenu;
import ca.corefacility.gview.map.gui.menu.HelpMenu;
import ca.corefacility.gview.map.gui.menu.MapRightClickMenu;
import ca.corefacility.gview.map.gui.menu.StyleMenu;
import ca.corefacility.gview.map.gui.menu.ViewMenu;
import edu.umd.cs.piccolox.PFrame;

/**
 * The GUI frame for GView.
 * 
 * @author Eric Marinier
 *
 */
public class GViewGUIFrame extends PFrame implements WindowListener, GViewEventListener
{
	private static final long serialVersionUID = 1L;
	
	//Default window size.
	private final int DEFAULT_WIDTH = 800;
	private final int DEFAULT_HEIGHT = 600;
	
	//Number of GUI frames open.
	private static volatile int guiFrameCount = 0;
	
	private GViewMap gViewMap;	//the current GViewMap object
	private JPanel windowPanel;	//the main window area of the GUI, where the GViewMap is displayed
	
	//The menu bar for the frame.
	private JMenuBar menuBar;
	
	//The menus on the menu bar.
	private FileMenu fileMenu;
	private ViewMenu viewMenu;
	private HelpMenu helpMenu;
	private StyleMenu styleMenu;
	
	//Dialogs
	private ZoomDialog zoomDialog;
	private MoveDialog moveDialog;
	private ScaleDialog scaleDialog;
	private BEVDialog bevDialog;
	private AboutDialog aboutDialog;

	//The tool bar.
	private GViewToolBar toolBar;
	
	//The style editor
	private StyleEditorFrame styleEditorFrame;	//don't create a get() method for this!
	
	//Right click menu:
	private JPopupMenu rightClickMenu;
	
	//Listener Collection
	private final ArrayList<GViewMapListener> listeners = new ArrayList<GViewMapListener>();
	
    //Flag for loading the GUI
    private boolean loading = true;
    
	/**
     * Creates a new GViewGUIFrame
     * @param title The title displayed on the frame.
     * @param fullScreenMode Whether or not to launch GView in full screen mode.
     * @param gViewMap The GView map that the frame will be related to.
     * @param gssFile  The URI to the gssFile.
     */
	public GViewGUIFrame(String title, boolean fullScreenMode, GViewMap gViewMap, URI gssFile)
	{
		if (gViewMap == null)
		{
			throw new IllegalArgumentException("gViewMap is null");
		}
		
		if(title == null)
		{
			title = "GView";
		}		
		
		buildFrame(title, fullScreenMode, gViewMap);
		buildComponents(gssFile);
		initializeComponents();
		addComponents();
	    
        this.loading = false;
	}
	
	/**
	 * Creates a new GViewGUIFrame
	 * @param title The title displayed on the frame.
	 * @param fullScreenMode Whether or not to launch GView in full screen mode.
	 * @param gviewMap The GView map that the frame will be related to.
	 */
	public GViewGUIFrame(String title, boolean fullScreenMode, GViewMap gviewMap)
	{
		this(title, fullScreenMode, gviewMap, null);
	}
	
	/**
	 * 
	 * @param gViewMap The related GView Map.
	 */
	public GViewGUIFrame(GViewMap gViewMap)
	{
		this(null, false, gViewMap, null);
	}

	/**
	 * Sets the size of the frame and canvas.
	 * 
	 * @param width
	 * @param height
	 */
	public void setFrameSize(int width, int height)
	{
		//Catch very, very small windows.
		if(width < 100)
			width = 100;
		
		if(height < 100)
			height = 100;
		
		this.setSize(width, height);
		this.gViewMap.setViewSize(width, height);
	}
	
	/**
	 * Returns the current GViewMap.
	 * @return The current GViewMap.
	 */
	public GViewMap getGViewMap()
	{
		if(this.gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		return this.gViewMap;
	}
	
	/**
	 * Returns the number of displayed frames.
	 * 
	 * @return The number of GUI frames currently displayed.
	 */
	public static synchronized int getDisplayedFrames()
	{
		return guiFrameCount;
	}
	
	/**
	 * Sets whether or not the bird's eye view dialog box is visible.
	 * 
	 * @param b Whether or not the bird's eye view dialog is visible.
	 */
	public void setBirdsEyeView(boolean b) 
	{
		this.bevDialog.setVisible(b);
	}

	@Override
	/**
	 * no effect
	 */
	public void windowOpened(WindowEvent e)
	{
			
	}

	@Override
	/**
	 * Updates the number of frames that currently open.
	 */
	public void windowClosing(WindowEvent e)
	{
		guiFrameCount--;
				
		if (guiFrameCount <= 0)
		{
			System.exit(0);
		}
		else
		{
			this.dispose();
		}
	}

	@Override
	/**
	 * no effect
	 */
	public void windowClosed(WindowEvent e)
	{
		
	}

	@Override
	/**
	 * no effect
	 */
	public void windowIconified(WindowEvent e)
	{
				
	}

	@Override
	/**
	 * no effect
	 */
	public void windowDeiconified(WindowEvent e)
	{
				
	}

	@Override
	/**
	 * no effect
	 */
	public void windowActivated(WindowEvent e)
	{
				
	}

	@Override
	/**
	 * no effect
	 */
	public void windowDeactivated(WindowEvent e)
	{
				
	}
	
	/**
	 * Creates the menu bar.
	 * 
	 * @return
	 * 	A JMenuBar.
	 */
	private JMenuBar createMenuBar()
	{
		JMenuBar menuBar = new JMenuBar();		
		
		return menuBar;
	}
	
	/**
	 * Initialises the dialog boxes used by the frame.
	 * 
	 */
	private void initializeDialogs()
	{
		this.zoomDialog = new ZoomDialog(this);
		this.scaleDialog = new ScaleDialog(this);
		this.moveDialog = new MoveDialog(this);
		this.aboutDialog = new AboutDialog(this);
	}
	
	/**
	 * Returns the current Bird's Eye View dialog.
	 * @return  The current bird's eye view dialog.
	 */
	public BEVDialog getBEVDialog()
	{
		if(this.bevDialog == null)
			throw new IllegalArgumentException("BEVDialog is null.");
		
		return this.bevDialog;
	}
	
//	/**
//	 * Returns the Style Editor.
//	 * @return The Style Editor.
//	 */
//	public StyleEditorFrame getStyleEditor()
//	{
//		if(this.styleEditorFrame == null)
//			throw new IllegalArgumentException("StyleEditor is null.");
//		
//		return this.styleEditorFrame;
//	}
	
	/**
	 * 
	 * @return The scale dialog (tradition scaling).
	 */
	public ScaleDialog getScaleDialog()
	{
		if(this.scaleDialog == null)
			throw new IllegalArgumentException("ScaleDialog is null.");
		
		return this.scaleDialog;
	}
	
	/**
	 * 
	 * @return The move dialog. Allows users to move to a specific base pair.
	 */
	public MoveDialog getMoveDialog()
	{
		if(this.moveDialog == null)
			throw new IllegalArgumentException("MoveDialog is null.");
		
		return this.moveDialog;
	}
	
	/**
	 * 
	 * @return The zoom dialog (expanding zoom).
	 */
	public ZoomDialog getZoomDialog()
	{
		if(this.zoomDialog == null)
			throw new IllegalArgumentException("ZoomDialog is null.");
		
		return this.zoomDialog;
	}
	
	/**
	 * 
	 * @return The about dialog, which contains information about the program.
	 */
	public AboutDialog getAboutDialog()
	{
		if(this.aboutDialog == null)
			throw new IllegalArgumentException("AboutDialog is null.");
		
		return this.aboutDialog;
	}
	
	/**
	 * Returns the right click menu used when right clicking the GViewMap.
	 * @return The right click menu.
	 */
	public JPopupMenu getRightClickMenu() 
	{
		if(this.rightClickMenu == null)
			throw new IllegalArgumentException("RightClickMenu is null.");
		
		return this.rightClickMenu;
	}
	
	/**
	 * Instructs the frame to run the passed action. The action will be added to its undo manager.
	 * @param action The action to run.
	 */
	public void doAction (Action action)
	{
		if(action == null)
			throw new IllegalArgumentException("Action is null.");
		
		try
        {
            action.run();
        }
		catch (ActionRunException e)
        {
            System.err.println(e);
        }
	}
	
	/**
	 * Builds the GViewGUIFrame frame.
	 * 
	 * @param title The title of the frame.
	 * @param fullScreenMode Whether or not to launch the GUI in full screen mode.
	 * @param gViewMap The GViewMap object to use on launch.
	 */
	private void buildFrame(String title, boolean fullScreenMode, GViewMap gViewMap)
	{	
		if(title == null)
			title = "GView";
		
		if(gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		this.setTitle(title);		
		this.gViewMap = gViewMap;
		
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		this.addWindowListener(this);
		guiFrameCount++;
		
		setFrameSizeAndPosition();		
		
		//Check full screen mode
		if(fullScreenMode)
			new FullScreenAction(this).run();		
		
		this.gViewMap.setVisible(true);
		this.gViewMap.scaleMapToScreen();
	}
	
	/**
	 * Sets the frame size and position.
	 */
	private void setFrameSizeAndPosition()
	{
		// get screen size for displaying splash screen
		// assumes possibility of more than one display
		int screenWidth, screenHeight;
		
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice[] gd = ge.getScreenDevices();
		if (gd == null || gd.length == 0)
		{
			System.err.println("[warning] - could not get screen resolution");
			screenWidth = 800;
			screenHeight = 600;
		}
		else
		{
			DisplayMode d = gd[0].getDisplayMode();
			
			if(d != null)
			{
				screenWidth = d.getWidth();
				screenHeight = d.getHeight();	
			}
			else
			{
				System.err.println("[warning] - could not get screen resolution");
				screenWidth = 800;
				screenHeight = 600;
			}	
		}
		
		this.setFrameSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
		this.setLocation((screenWidth - DEFAULT_WIDTH) / 2,(screenHeight - DEFAULT_HEIGHT) / 2);
	}

	/**
	 * Builds the internal components.
	 */
	private void buildComponents(URI gssFile)
	{
		this.menuBar = createMenuBar();
		
		this.bevDialog = new BEVDialog(this);
		
		this.fileMenu = new FileMenu(this);
		this.viewMenu = new ViewMenu(this);
		this.styleMenu = new StyleMenu(this);
		this.helpMenu = new HelpMenu(this);	
		
		this.toolBar = new GViewToolBar(this);
		this.rightClickMenu = new MapRightClickMenu(this);
		this.rightClickMenu.add(viewMenu);
		
		this.styleEditorFrame = new StyleEditorFrame(this, gViewMap, gssFile);		
	}
	
	/**
	 * Adds the internal components to the frame.
	 */
	private void addComponents()
	{
		this.windowPanel = new JPanel();
		
		this.menuBar.add(fileMenu);
		this.menuBar.add(viewMenu);		
		this.menuBar.add(styleMenu);			
		this.menuBar.add(helpMenu);
		
		this.windowPanel.setLayout(new BorderLayout());		
		this.windowPanel.add((Component)gViewMap, BorderLayout.CENTER);
		
		this.setJMenuBar(menuBar);
		this.setContentPane(windowPanel);
		this.getContentPane().add(toolBar, BorderLayout.NORTH);	
	}
	
	/**
	 * Initializes the internal components.
	 */
	private void initializeComponents()
	{
		initializeDialogs();
		
		this.styleEditorFrame.setVisible(false);
	}
	
	/**
	 * Sets a new GViewMap. Informs all GViewMap listeners of the change.
	 * 
	 * @param gViewMap The new GViewMap to use.
	 */
	public void setGViewMap(GViewMap gViewMap)
	{
		if(gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		// if previous gview map
		if (this.gViewMap != null)
		{
		    this.gViewMap.removeEventListener(this);
		}
		
		this.gViewMap = gViewMap;
		
		this.gViewMap.addEventListener(this);
		
		//Inform listeners.
		for(int i = 0; i < this.listeners.size(); i++)
			this.listeners.get(i).setGViewMap(gViewMap);
		
		this.windowPanel = new JPanel();			
		this.windowPanel.setLayout(new BorderLayout());		
		this.windowPanel.add((Component)gViewMap, BorderLayout.CENTER);
		this.windowPanel.setVisible(true);
		
		this.setContentPane(windowPanel);
		this.getContentPane().add(toolBar, BorderLayout.NORTH);				
		
		this.gViewMap.setVisible(true);		
		
		this.repaint();
		this.validate();
		
		this.gViewMap.scaleMapToScreen();
	}
	
	/**
	 * Adds a GViewMapListener to the GUI frame that will be notified when the GViewMap is changed.
	 * 
	 * @param listener The listener to add.
	 */
	public void addGViewMapListener(GViewMapListener listener)
	{
		if(listener == null)
			throw new IllegalArgumentException("GViewMapListener is null.");
		
		this.listeners.add(listener);
	}
	
	/**
	 * Returns an iterator of all the styles.
	 * 
	 * @return Iterator of all the styles.
	 */
	public Iterator<StyleEditorTree> getStyles()
	{
		if(this.styleEditorFrame == null)
			throw new NullPointerException("StyleEditorFrame is null.");
		
		return this.styleEditorFrame.getStyles();
	}
	
	/**
	 * Returns the current style.
	 * 
	 * @return The current style.
	 */
	public StyleEditorTree getCurrentStyle()
	{
		if(this.styleEditorFrame == null)
			throw new NullPointerException("StyleEditorFrame is null.");
		
		return this.styleEditorFrame.getCurrentStyle();
	}

	/**
	 * Displays the style editor.
	 */
	public void showStyleEditor()
	{
		this.doAction(new ShowStyleEditorAction(this.styleEditorFrame));			
	}

	/**
	 * Sets the current style.
	 * 
	 * @param style The new current style.
	 */
	public void setCurrentStyle(StyleEditorTree style)
	{
		if(style == null)
			throw new IllegalArgumentException("Style is null.");
		
		this.styleEditorFrame.setCurrentStyle(style);		
	}

    @Override
    public void eventOccured(GViewEvent event)
    {
        if (event instanceof PopUpEvent)
        {
            PopUpEvent p = (PopUpEvent)event;
            this.getRightClickMenu().show(p.getComponent(),p.getX(),p.getY());
        }
    }
}