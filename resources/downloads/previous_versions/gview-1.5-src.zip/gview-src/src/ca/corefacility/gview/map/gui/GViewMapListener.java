package ca.corefacility.gview.map.gui;

import ca.corefacility.gview.map.GViewMap;

/**
 * An interface for GViewMap listeners. The listeners will be notified when the GViewMap object has changed.
 * 
 * @author Eric Marinier
 *
 */
public interface GViewMapListener
{
	public void setGViewMap(GViewMap gViewMap);
}
