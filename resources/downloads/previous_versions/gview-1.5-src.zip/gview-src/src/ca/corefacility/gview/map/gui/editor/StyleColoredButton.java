package ca.corefacility.gview.map.gui.editor;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Paint;

import javax.swing.JButton;

import ca.corefacility.gview.utils.Gradient;

/**
 * A button that displays a solid color in the space that the JButton it is extending would normally take up.
 * 
 * Overrides JButton's getBackground, setBackground and paint methods.
 * 
 * @author Eric Marinier
 *
 */
public class StyleColoredButton extends JButton
{
	private static final long serialVersionUID = 1L;	//requested by java	
	private final SolidIcon icon;	//a custom icon class that displays a solid color
	private Paint displayedPaint;
	
	/**
	 * Default coloured button.
	 */
	public StyleColoredButton()
	{
		super();
		
		this.icon = new SolidIcon(StyleEditorUtility.DEFAULT_COLOR);		
		this.setIcon(icon);
		
		displayedPaint = StyleEditorUtility.DEFAULT_COLOR;
	}
	
	@Override
	public void paint(Graphics g)
	{
		//forwards the paint to the icon, does NOT paint the button itself
		this.icon.paintIcon(this, g, 0, 0);
	}
	
//	@Override
	public void setPaint(Paint p)
	{
	    displayedPaint = p;
	    
		if(p == null)
			p = StyleEditorUtility.DEFAULT_COLOR;
		
		if(this.icon != null)
		{
			this.icon.setPaint(p);
			this.setIcon(this.icon);
		}
		
		if (p instanceof Color)
		{
		    super.setBackground((Color)p);
		}
		else if (p instanceof Gradient)
		{
		    Gradient g = (Gradient)p;
		    super.setBackground(g.getColor1());
		}
		else
		{
		    System.err.println("Paint " + p.getClass() + " not of correct type to be displayed, setting to default");
		    super.setBackground(StyleEditorUtility.DEFAULT_COLOR);
		}
	}
	
	@Override
	public void setBackground(Color c)
	{   
	    setPaint(c);
	}
	
//	@Override
	public Paint getPaint()
	{
		if(this.icon != null)
		{
			return this.icon.getPaint();
		}
		else
		{
			return StyleEditorUtility.DEFAULT_COLOR;
		}
	}
	
	public Paint getRealPaint()
	{
	    return displayedPaint;
	}
}
