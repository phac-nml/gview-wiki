package ca.corefacility.gview.map.gui.action.map.zoom;

import ca.corefacility.gview.layout.sequence.ZoomException;
import ca.corefacility.gview.map.GViewMap;

/**
 * Zoom map out action class.
 * 
 * @author Eric Marinier
 *
 */
public class ZoomOutAction extends ZoomAction
{
	private final GViewMap gViewMap;
	
	/**
	 * 
	 * @param gViewMap The GView map object.
	 */
	public ZoomOutAction(GViewMap gViewMap)
	{
		super(gViewMap, gViewMap.getZoomFactor());
		
		this.gViewMap = gViewMap;
	}
	
	@Override
	public void run() throws ActionRunException
	{
		double zoomFactor;
		
		zoomFactor = this.gViewMap.getZoomFactor();
		zoomFactor *= 0.9;
		try
        {
            this.gViewMap.setZoomFactor(zoomFactor);
        }
		catch (ZoomException e)
        {
            throw new ActionRunException(e.getMessage());
        }
	}
}
