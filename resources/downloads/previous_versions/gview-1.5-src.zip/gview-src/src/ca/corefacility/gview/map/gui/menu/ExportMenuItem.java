package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.GViewMapListener;
import ca.corefacility.gview.map.gui.action.map.ExportAction;

/**
 * Responsible for creating the Export menu item.
 * 
 * @author Eric Marinier
 *
 */
public class ExportMenuItem extends JMenuItem implements ActionListener, GViewMapListener
{
	private static final long serialVersionUID = 1L;
	private final GViewGUIFrame gViewGUIFrame;

	/**
	 * @param gViewGUIFrame The related GUI frame.
	 */
	public ExportMenuItem(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.EXPORT_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;
		this.gViewGUIFrame.addGViewMapListener(this);
		
		this.setActionCommand(GUIUtility.EXPORT);
		this.setAccelerator(KeyStroke.getKeyStroke(GUIUtility.EXPORT_SHORTCUT));
		this.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(GUIUtility.EXPORT.equals(e.getActionCommand()))
		{
			this.gViewGUIFrame.doAction(new ExportAction(gViewGUIFrame.getGViewMap()));
		}
	}

	@Override
	public void setGViewMap(GViewMap gViewMap)
	{
		// TODO Auto-generated method stub		
	}
}
