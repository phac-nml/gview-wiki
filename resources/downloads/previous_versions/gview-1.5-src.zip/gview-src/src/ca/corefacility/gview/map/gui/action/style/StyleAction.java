package ca.corefacility.gview.map.gui.action.style;

import ca.corefacility.gview.map.gui.action.Action;

/**
 * Style action class.
 * 
 * @author Eric Marinier
 *
 */
public abstract class StyleAction extends Action 
{

}
