package ca.corefacility.gview.map.gui.editor;

import javax.swing.JMenu;
import javax.swing.JMenuItem;

/**
 * The help menu for the style editor.
 * 
 * @author Eric Marinier
 *
 */
public class HelpMenu extends JMenu 
{
	private static final long serialVersionUID = 1L;	//requested by java	
	private final JMenuItem helpPageItem;	//help page menu item
	
	public HelpMenu()
	{
		super(StyleEditorUtility.HELP_TEXT);
		
		this.helpPageItem = new JMenuItem(StyleEditorUtility.HELP_PAGE_TEXT);
		add(this.helpPageItem);
	}	
}
