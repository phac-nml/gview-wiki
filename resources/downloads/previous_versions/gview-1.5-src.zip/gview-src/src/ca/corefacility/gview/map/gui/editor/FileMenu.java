package ca.corefacility.gview.map.gui.editor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import ca.corefacility.gview.map.gui.action.style.ExportStyleAction;
import ca.corefacility.gview.map.gui.action.style.ImportStyleAction;
import ca.corefacility.gview.map.gui.action.style.NewPlotAction;
import ca.corefacility.gview.map.gui.action.style.NewSetAction;
import ca.corefacility.gview.map.gui.action.style.NewSlotAction;
import ca.corefacility.gview.map.gui.action.style.NewStyleAction;


/**
 * The file menu class.
 * 
 * This file menu is intended to exist on a StyleEditorFrame menu.
 * 
 * @author Eric Marinier
 *
 */
public class FileMenu extends JMenu implements ActionListener
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private static final String EXIT_TEXT = "Exit";	//exit text
	private static final String EXIT = "Exit";	//exit action command
	private static final String OPEN_TEXT = "Open";	//load text
	private static final String OPEN = "Open";	//load action command
	private static final String SAVE_TEXT = "Save";	//save text
	private static final String SAVE = "Save";	//save action command
	private static final String NEW_TEXT = "New";	//the new menu text
	private static final String NEW_STYLE_TEXT = "Style";	//new style text
	private static final String NEW_STYLE = "New Style";	//new style action command
	private static final String NEW_SLOT_TEXT = "Slot";	//new slot text
	private static final String NEW_SLOT = "New Slot";	//new slot action command
	private static final String NEW_SET_TEXT = "Set";	//new set text
	private static final String NEW_SET = "New Set";	//new set action command
	private static final String NEW_PLOT_TEXT = "Plot";	//new plot text
	private static final String NEW_PLOT = "New Plot";	//new plot action command

	private static final String LOAD_SHORTCUT = "ctrl O";
	private static final String SAVE_SHORTCUT = "ctrl S";
	private static final String NEW_STYLE_SHORTCUT = "ctrl N";
	
	private final StyleEditorFrame styleEditorFrame;
	
	private final JMenuItem exitItem;
	private final JMenuItem loadItem;
	private final JMenuItem saveItem;
	
	private final JMenu newMenu;
	private final JMenuItem newStyleItem;
	private final JMenuItem newSlotItem;
	private final JMenuItem newSetItem;
	private final JMenuItem newPlotItem;
	
	/**
	 * Creates the file menu.
	 * 
	 * @param styleEditorFrame The style editor frame the menu will exist on.
	 */
	public FileMenu(StyleEditorFrame styleEditorFrame)
	{
		super(StyleEditorUtility.FILE_TEXT);
		
		if(styleEditorFrame == null)
			throw new IllegalArgumentException("StyleEditorFrame is null");
		
		this.styleEditorFrame = styleEditorFrame;
		
		//Exit item
		this.exitItem = new JMenuItem(EXIT_TEXT);
		this.exitItem.setActionCommand(EXIT);
		this.exitItem.addActionListener(this);
		
		//Load item
		this.loadItem = new JMenuItem(OPEN_TEXT);
		this.loadItem.setActionCommand(OPEN);
		this.loadItem.addActionListener(this);
		this.loadItem.setAccelerator(KeyStroke.getKeyStroke(LOAD_SHORTCUT));
		
		//Save item
		this.saveItem = new JMenuItem(SAVE_TEXT);
		this.saveItem.setActionCommand(SAVE);
		this.saveItem.addActionListener(this);
		this.saveItem.setAccelerator(KeyStroke.getKeyStroke(SAVE_SHORTCUT));
		
		//New Menu
		this.newMenu = new JMenu(NEW_TEXT);
		
		//New Style item
		this.newStyleItem = new JMenuItem(NEW_STYLE_TEXT);
		this.newStyleItem.setActionCommand(NEW_STYLE);
		this.newStyleItem.addActionListener(this);
		this.newStyleItem.setAccelerator(KeyStroke.getKeyStroke(NEW_STYLE_SHORTCUT));
		
		//New Slot item
		this.newSlotItem = new JMenuItem(NEW_SLOT_TEXT);
		this.newSlotItem.setActionCommand(NEW_SLOT);
		this.newSlotItem.addActionListener(this);
		
		//New Set item
		this.newSetItem = new JMenuItem(NEW_SET_TEXT);
		this.newSetItem.setActionCommand(NEW_SET);
		this.newSetItem.addActionListener(this);
		
		//New Plot item
		this.newPlotItem = new JMenuItem(NEW_PLOT_TEXT);
		this.newPlotItem.setActionCommand(NEW_PLOT);
		this.newPlotItem.addActionListener(this);
		
		//add items to new menu
		this.newMenu.add(this.newStyleItem);
		this.newMenu.add(this.newSlotItem);
		this.newMenu.add(this.newSetItem);
		this.newMenu.add(this.newPlotItem);
		
		//add items to file menu
		this.add(this.newMenu);
		this.add(this.loadItem);
		this.add(this.saveItem);
		this.add(this.exitItem);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{		
		if(e.getActionCommand().equals(EXIT))
		{
			this.styleEditorFrame.setVisible(false);
		}	
		else if(e.getActionCommand().equals(OPEN))
		{
			this.styleEditorFrame.doAction(new ImportStyleAction(this.styleEditorFrame));
		}
		else if(e.getActionCommand().equals(SAVE))
		{
			this.styleEditorFrame.doAction(new ExportStyleAction(this.styleEditorFrame));
		}
		else if(e.getActionCommand().equals(NEW_STYLE))
		{
			this.styleEditorFrame.doAction(new NewStyleAction(this.styleEditorFrame));
		}
		else if(e.getActionCommand().equals(NEW_SLOT))
		{
			this.styleEditorFrame.doAction(new NewSlotAction(this.styleEditorFrame.getCurrentStyle()));
		}
		else if(e.getActionCommand().equals(NEW_SET))
		{
			this.styleEditorFrame.doAction(new NewSetAction(this.styleEditorFrame.getCurrentStyle()));
		}
		else if(e.getActionCommand().equals(NEW_PLOT))
		{
			this.styleEditorFrame.doAction(new NewPlotAction(this.styleEditorFrame.getCurrentStyle()));
		}
	}	
}
