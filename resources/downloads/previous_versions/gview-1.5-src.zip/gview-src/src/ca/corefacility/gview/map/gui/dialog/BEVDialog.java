package ca.corefacility.gview.map.gui.dialog;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JSlider;
import javax.swing.JToolBar;

import ca.corefacility.gview.map.BirdsEyeViewImp;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.GViewMapListener;

/**
 * The bird's eye view dialog box.
 * 
 * @author Eric Marinier, Aaron Petkau
 *
 */
public class BEVDialog extends JDialog implements GViewMapListener
{
	private static final long serialVersionUID = 1L;
	
	private final String magnifierPlusPath = "images/icons/magnifier--plus.png";
	private final String magnifierMinusPath = "images/icons/magnifier--minus.png";	
	
	private final JSlider slider;
	private final JButton plusButton;
	private final JButton minusButton;
	
	private final GViewGUIFrame gViewGUIFrame;	
	
	private JToolBar toolBar;
	private BEVDialogListener bevDialogListener;
	private BirdsEyeViewImp BEV;	
	
	/**
	 * 
	 * @param gViewGUIFrame The related GUI frame.
	 */
	public BEVDialog(GViewGUIFrame gViewGUIFrame)
	{
		super();
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;
		this.gViewGUIFrame.addGViewMapListener(this);
		
		this.setTitle(GUIUtility.BEV_TEXT);
		
		this.BEV = new BirdsEyeViewImp(gViewGUIFrame);	
		
		this.slider = new JSlider((int)GUIUtility.SCALE_SLIDER_MIN, (int)GUIUtility.SCALE_SLIDER_MAX);
		this.slider.setValue(GUIUtility.convertScaleToSlider(gViewGUIFrame.getGViewMap().getZoomNormalFactor()));
		
		this.plusButton = new JButton(new ImageIcon(GUIUtility.loadImage(magnifierPlusPath)));		
		this.minusButton = new JButton(new ImageIcon(GUIUtility.loadImage(magnifierMinusPath)));
		
		this.bevDialogListener = new BEVDialogListener(gViewGUIFrame, this.BEV, this.slider);
		
		this.addWindowListener(this.bevDialogListener);				
		this.addComponentListener(this.bevDialogListener);	
		this.setSize(300, 300);
		
		//Create the content of the dialog.
		create(this.getContentPane());
		
		this.setVisible(false);		
	}
	
	/**
	 * Creates the content of the BEVDialog.
	 * 
	 * @param contentPane The pane the dialog will be created on.
	 */
	private void create(Container contentPane)
	{
		this.toolBar = new JToolBar();
		
		this.toolBar.setFloatable(false);
		this.toolBar.setLayout(new BoxLayout(this.toolBar, BoxLayout.X_AXIS));
		
		contentPane.setLayout(new BorderLayout());
		contentPane.add((JComponent)this.BEV, BorderLayout.CENTER);
		
		contentPane.add(this.toolBar, BorderLayout.SOUTH);
		
		this.minusButton.setActionCommand(GUIUtility.SCALE_OUT);
		this.minusButton.setToolTipText(GUIUtility.SCALE_OUT);
		this.minusButton.addActionListener(this.bevDialogListener);
		this.toolBar.add(this.minusButton);	
		
		this.slider.addChangeListener(this.bevDialogListener);
		this.toolBar.add(this.slider);
		
		this.plusButton.setActionCommand(GUIUtility.SCALE_IN);
		this.plusButton.setToolTipText(GUIUtility.SCALE_IN);
		this.plusButton.addActionListener(this.bevDialogListener);
		this.toolBar.add(this.plusButton);
	}

	@Override
	public void setGViewMap(GViewMap gViewMap)
	{	
		if(gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		this.BEV = new BirdsEyeViewImp(gViewGUIFrame);
		
		this.bevDialogListener = new BEVDialogListener(gViewGUIFrame, BEV, slider);
		this.addWindowListener(this.bevDialogListener);				
		this.addComponentListener(this.bevDialogListener);	
		
		this.slider.setValue(GUIUtility.convertScaleToSlider(gViewGUIFrame.getGViewMap().getZoomNormalFactor()));
		
		this.getContentPane().removeAll();
		this.getContentPane().add((JComponent)BEV, BorderLayout.CENTER);
		this.getContentPane().add(this.toolBar, BorderLayout.SOUTH);
		
		this.repaint();
		this.validate();
		
		this.BEV.updateFromViewed();
	}
}
