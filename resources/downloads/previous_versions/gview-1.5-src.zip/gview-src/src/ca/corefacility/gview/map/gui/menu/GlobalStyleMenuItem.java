package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.action.dialog.show.ShowGlobalStyleDialogAction;
import ca.corefacility.gview.map.gui.dialog.StyleDialog;
import ca.corefacility.gview.map.gui.editor.panel.GlobalPanel;
import ca.corefacility.gview.style.GlobalStyle;

/**
 * The global style menu item.
 * Displays a dialog to allow global changes to the global style.
 * 
 * @author Eric Marinier
 *
 */
public class GlobalStyleMenuItem extends JMenuItem implements ActionListener
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private final GViewGUIFrame gViewGUIFrame;
	
	/**
	 * 
	 * @param gViewGUIFrame The related GUI frame.
	 */
	public GlobalStyleMenuItem(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.GLOBAL_STYLE_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;
		
		this.setActionCommand(GUIUtility.GLOBAL_STYLE);
		this.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		GlobalStyle globalStyle = this.gViewGUIFrame.getGViewMap().getMapStyle().getGlobalStyle();
		GlobalPanel globalPanel = new GlobalPanel(globalStyle);
		
		if(e.getActionCommand().equals(GUIUtility.GLOBAL_STYLE))
		{
			this.gViewGUIFrame.doAction(new ShowGlobalStyleDialogAction(new StyleDialog(gViewGUIFrame, globalPanel)));
		}
	}
}
