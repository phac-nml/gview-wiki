package ca.corefacility.gview.map.gui.editor.panel;

/**
 * The panel for the legend node.
 * 
 * @author Eric Marinier
 *
 */
public class LegendPanel extends StylePanel
{
	private static final long serialVersionUID = 1L;	//requested by java

	/**
	 * Create the panel.
	 */
	public LegendPanel() 
	{
		
	}

	@Override
	public void update()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void doApply()
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	protected boolean modified()
	{
		return false;
	}
}
