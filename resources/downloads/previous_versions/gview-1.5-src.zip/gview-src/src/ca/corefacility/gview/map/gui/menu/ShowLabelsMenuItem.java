package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBoxMenuItem;

import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.action.map.hide.HideLabelsAction;
import ca.corefacility.gview.map.gui.action.map.show.ShowLabelsAction;

/**
 * Responsible for creating and managing the "Show Labels" menu item.
 * 
 * @author Eric Marinier
 *
 */
public class ShowLabelsMenuItem extends JCheckBoxMenuItem implements ItemListener
{
	private static final long serialVersionUID = 1L;
	
	private final GViewGUIFrame gViewGUIFrame;
	
	/**
	 * Creates a new ShowLabelsMenuItem within the specified frame.
	 * @param gViewGUIFrame The frame the ShowLabels menu item is applies to.
	 */
	public ShowLabelsMenuItem(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.SHOW_LABELS_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;
		
		this.addItemListener(this);		
	}

	@Override
	/**
	 * Listens for the menu item.
	 */
	public void itemStateChanged(ItemEvent e)
	{		
		if (e.getStateChange() == ItemEvent.SELECTED)
		{
			this.gViewGUIFrame.doAction(new ShowLabelsAction(this.gViewGUIFrame.getGViewMap().getElementControl()));
		}
		else if (e.getStateChange() == ItemEvent.DESELECTED)
		{
			this.gViewGUIFrame.doAction(new HideLabelsAction(this.gViewGUIFrame.getGViewMap().getElementControl()));
		}
	}
	
	/**
	 * Updates the selected state of the menu item.
	 */
	public void update()
	{
		if(this.gViewGUIFrame.getGViewMap().getElementControl().getLabelsDisplayed())
		{
			this.setSelected(true);
		}
		else
		{
			this.setSelected(false);
		}			
	}	
}
