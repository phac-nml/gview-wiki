package ca.corefacility.gview.map.gui.editor.panel;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Paint;

import javax.swing.JLabel;

import ca.corefacility.gview.map.gui.editor.StyleColoredButton;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility;
import ca.corefacility.gview.style.items.LegendAlignment;
import ca.corefacility.gview.style.items.LegendStyle;
import ca.corefacility.gview.utils.Util;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.factories.FormFactory;
import javax.swing.JComboBox;
import javax.swing.border.TitledBorder;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.border.LineBorder;
import javax.swing.JTextField;

/**
 * The legend style panel.
 * 
 * @author Eric Marinier
 *
 */
public class LegendStylePanel extends StylePanel implements ActionListener 
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private static final String BACKGROUND_COLOR = "Background Color";
	private static final String BORDER_COLOR = "Border Color";
	private static final String TEXT_COLOR = "Text Color";
	
	private static final String LEGEND_STYLE_TEXT = "Legend Style";
	
	private static final String INVALID_FONT_SIZE = "Invalid font size.";
	private static final String LEGEND_STYLE_NULL = "LegendStyle is null.";
	
	private static final String FONT_FAMILY_LABEL_TEXT = "Font Family:";
	private static final String FONT_STYLE_LABEL_TEXT = "Font Style:";
	private static final String FONT_SIZE_LABEL_TEXT = "Font Size:";
	private static final String TEXT_COLOR_LABEL_TEXT = "Text Color:";
	private static final String ALIGNMENT_LABEL_TEXT = "Alignment:";
	private static final String BACKGROUND_COLOR_LABEL_TEXT = "Background Color:";
	private static final String BORDER_COLOR_LABEL_TEXT = "Border Color:";
	
	private final StyleColoredButton backgroundColor;
	private final StyleColoredButton borderColor;
	private final StyleColoredButton textColor;
	
	private final JComboBox fontFamily;
	private final JComboBox fontStyle;
	private final JComboBox alignment;
	
	private final JTextField fontSize;
	
	private final LegendStyle legendStyle;

	/**
	 * Create the panel.
	 */
	public LegendStylePanel(LegendStyle legendStyle) 
	{
		super();
		
		if(legendStyle == null)
			throw new IllegalArgumentException(LEGEND_STYLE_NULL);
		
		this.legendStyle = legendStyle;
		
		//Layout
		setBorder(new EmptyBorder(10, 10, 10, 10));
		FormLayout formLayout = new FormLayout(new ColumnSpec[] {
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("center:default"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("left:min:grow"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,},
			new RowSpec[] {
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("15dlu"),
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("default:grow"),
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("default:grow"),
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,});
		formLayout.setRowGroups(new int[][]{new int[]{8, 6, 4, 2, 14, 10, 12}});
		
		JPanel inner = new JPanel();
		inner.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), LEGEND_STYLE_TEXT, TitledBorder.LEADING, TitledBorder.TOP, null, new Color(51, 51, 51)));
		add(inner, BorderLayout.NORTH);
		
		inner.setLayout(formLayout);
		
		JPanel panel_4 = new JPanel();
		inner.add(panel_4, "2, 2, fill, fill");
		panel_4.setLayout(new BorderLayout(0, 0));
		
		JLabel label_1 = new JLabel(BACKGROUND_COLOR_LABEL_TEXT);
		panel_4.add(label_1, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		inner.add(panel, "6, 2, fill, fill");
		panel.setLayout(new BorderLayout(0, 0));
		
		//background color button
		this.backgroundColor = new StyleColoredButton();
		this.backgroundColor.setActionCommand(LegendStylePanel.BACKGROUND_COLOR);
		panel.add(this.backgroundColor, BorderLayout.WEST);
		this.backgroundColor.addActionListener(this);
		this.backgroundColor.setToolTipText(LegendStylePanel.BACKGROUND_COLOR);
		
		JPanel panel_5 = new JPanel();
		inner.add(panel_5, "2, 4, fill, fill");
		panel_5.setLayout(new BorderLayout(0, 0));
		
		JLabel label_2 = new JLabel(BORDER_COLOR_LABEL_TEXT);
		panel_5.add(label_2, BorderLayout.EAST);
		
		JPanel panel_1 = new JPanel();
		inner.add(panel_1, "6, 4, fill, fill");
		panel_1.setLayout(new BorderLayout(0, 0));
		
		//border color button
		this.borderColor = new StyleColoredButton();
		this.borderColor.setActionCommand(LegendStylePanel.BORDER_COLOR);
		panel_1.add(this.borderColor, BorderLayout.WEST);
		this.borderColor.addActionListener(this);
		this.borderColor.setToolTipText(LegendStylePanel.BORDER_COLOR);
		
		JPanel panel_6 = new JPanel();
		inner.add(panel_6, "2, 6, fill, fill");
		panel_6.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel(TEXT_COLOR_LABEL_TEXT);
		panel_6.add(label, BorderLayout.EAST);
		
		JPanel panel_2 = new JPanel();
		inner.add(panel_2, "6, 6, fill, fill");
		panel_2.setLayout(new BorderLayout(0, 0));
		
		//text color button
		this.textColor = new StyleColoredButton();
		this.textColor.setActionCommand(LegendStylePanel.TEXT_COLOR);
		panel_2.add(this.textColor, BorderLayout.WEST);
		this.textColor.addActionListener(this);
		this.textColor.setToolTipText(LegendStylePanel.TEXT_COLOR);
		
		JPanel panel_7 = new JPanel();
		inner.add(panel_7, "2, 8, fill, fill");
		panel_7.setLayout(new BorderLayout(0, 0));
		
		JLabel label_3 = new JLabel(FONT_FAMILY_LABEL_TEXT);
		panel_7.add(label_3, BorderLayout.EAST);
		
		JPanel panel_3 = new JPanel();
		inner.add(panel_3, "6, 8, fill, fill");
		panel_3.setLayout(new BorderLayout(0, 0));
		
		//font family combo box
		this.fontFamily = new JComboBox(StyleEditorUtility.FONT_NAMES);
		this.fontFamily.addActionListener(this);
		panel_3.add(this.fontFamily, BorderLayout.WEST);
		
		JPanel panel_10 = new JPanel();
		inner.add(panel_10, "2, 10, fill, fill");
		panel_10.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFontStyle = new JLabel(FONT_STYLE_LABEL_TEXT);
		panel_10.add(lblFontStyle, BorderLayout.EAST);
		
		JPanel panel_12 = new JPanel();
		inner.add(panel_12, "6, 10, fill, fill");
		panel_12.setLayout(new BorderLayout(0, 0));
		
		//font style combo box
		this.fontStyle = new JComboBox(StyleEditorUtility.FONT_STYLES);
		this.fontStyle.addActionListener(this);
		panel_12.add(this.fontStyle, BorderLayout.WEST);
		
		JPanel panel_11 = new JPanel();
		inner.add(panel_11, "2, 12, fill, fill");
		panel_11.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFontSize = new JLabel(FONT_SIZE_LABEL_TEXT);
		panel_11.add(lblFontSize, BorderLayout.EAST);
		
		JPanel panel_13 = new JPanel();
		inner.add(panel_13, "6, 12, fill, fill");
		panel_13.setLayout(new BorderLayout(0, 0));
		
		//font size text field
		this.fontSize = new JTextField();
		panel_13.add(this.fontSize, BorderLayout.WEST);
		this.fontSize.setColumns(10);
		this.fontSize.getDocument().addDocumentListener(this);
		
		JPanel panel_8 = new JPanel();
		inner.add(panel_8, "2, 14, fill, fill");
		panel_8.setLayout(new BorderLayout(0, 0));
		
		JLabel label_4 = new JLabel(ALIGNMENT_LABEL_TEXT);
		panel_8.add(label_4, BorderLayout.EAST);
		
		JPanel panel_9 = new JPanel();
		inner.add(panel_9, "6, 14, fill, fill");
		panel_9.setLayout(new BorderLayout(0, 0));
		
		//alignment combo box
		this.alignment = new JComboBox(StyleEditorUtility.LEGEND_ALIGNMENT_STRINGS);
		this.alignment.addActionListener(this);
		panel_9.add(this.alignment, BorderLayout.WEST);

		this.update();
	}
	
	/**
	 * 
	 * @return The color of the text.
	 */
	private Paint getTextPaint()
	{
		Paint p = this.textColor.getRealPaint();
		
		return p;
	}
	
	/**
	 * Sets the color of the text.
	 * 
	 * @param color
	 */
	private void setTextPaint(Paint p)
	{
		this.textColor.setPaint(p);
	}
	
	/**
	 * 
	 * @return The color of the border.
	 */
	private Paint getBorderPaint()
	{
		Paint p = this.borderColor.getRealPaint();
		
		return p;
	}
	
	/**
	 * Sets the border color.
	 * 
	 * @param color
	 */
	private void setBorderPaint(Paint p)
	{
		this.borderColor.setPaint(p);
	}
	
	/**
	 * 
	 * @return The background color.
	 */
	private Paint getBackgroundPaint()
	{
		Paint p = this.backgroundColor.getRealPaint();
		
		return p;
	}
	
	/**
	 * Sets the background color.
	 * 
	 * @param color
	 */
	private void setBackgroundPaint(Paint p)
	{
		this.backgroundColor.setPaint(p);
	}
	
	/**
	 * 
	 * @return The string of the font type.
	 */
	private String getFontFamily()
	{
		Object temp;
		String result;
		
		temp = this.fontFamily.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Font Family is not a String");
		}
		
		return result;
	}
	
	/**
	 * Sets the font family.
	 * 
	 * @param s
	 */
	private void setFontFamily(String s)
	{
		if(s != null)
			this.fontFamily.setSelectedItem(s);
	}
	
	/**
	 * 
	 * @return The font style as a string.
	 */
	private String getFontStyle()
	{
		Object temp;
		String result;
		
		temp = this.fontStyle.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Tooltip Font Style is not a String");
		}
		
		return result;
	}
	
	/**
	 * Sets the font style.
	 * 
	 * @param font
	 */
	private void setFontStyle(String font)
	{
		if(font != null)
			this.fontStyle.setSelectedItem(font);
	}
	
	/**
	 * 
	 * @return The font size a string.
	 */
	private String getFontSizeText()
	{
		return this.fontSize.getText();
	}
	
	/**
	 * Sets the text of the font size.
	 * 
	 * @param text
	 */
	private void setFontSizeText(int i)
	{
		this.fontSize.setText(Integer.toString(i));
	}
	
	/**
	 * 
	 * @return The alignment of the legend as a string.
	 */
	private String getAlignment()
	{
		Object temp;
		String result;
		
		temp = this.alignment.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Alignment value is not a String");
		}
		
		return result;
	}
	
	/**
	 * Sets the alignment text field.
	 * 
	 * @param align
	 */
	private void setAlignment(String align)
	{
		if(align != null)
			this.alignment.setSelectedItem(align);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		Color color;
		
		if(e.getActionCommand().equals(LegendStylePanel.BACKGROUND_COLOR))
		{
			color = StyleEditorUtility.showColorPicker(this, this.backgroundColor.getBackground());
			
			if(color != null)
				this.backgroundColor.setPaint(color);
		}
		else if(e.getActionCommand().equals(LegendStylePanel.BORDER_COLOR))
		{
			color = StyleEditorUtility.showColorPicker(this, this.borderColor.getBackground());
			
			if(color != null)
				this.borderColor.setPaint(color);
		}
		else if(e.getActionCommand().equals(LegendStylePanel.TEXT_COLOR))
		{
			color = StyleEditorUtility.showColorPicker(this, this.textColor.getBackground());
			
			if(color != null)
				this.textColor.setPaint(color);
		}
		
		super.actionPerformed(e);
	}

	@Override
	/**
	 * Updates the panel.
	 */
	public void update() 
	{
		updateTextColor();
		updateBorderColor();
		updateBackgroundColor();
		updateFont();
		updateAlignment();
	}
	
	/**
	 * Updates the text color.
	 */
	private void updateTextColor()
	{
		Paint tempPaint = this.legendStyle.getDefaultFontPaint();
		
		setTextPaint(tempPaint);
	}
	
	/**
	 * Updates the border color.
	 */
	private void updateBorderColor()
	{
		Paint tempPaint = this.legendStyle.getOutlinePaint();
		
		setBorderPaint(tempPaint);
	}
	
	/**
	 * Updates the background color.
	 */
	private void updateBackgroundColor()
	{
		Paint tempPaint = this.legendStyle.getBackgroundPaint();
		
		setBackgroundPaint(tempPaint);
	}
	
	/**
	 * Updates the font.
	 */
	private void updateFont()
	{
		Font tempFont = this.legendStyle.getDefaultFont();
		
		if(tempFont != null)
		{
			setFontFamily(tempFont.getFamily());
			
			if(tempFont.isBold() && this.legendStyle.getDefaultFont().isItalic())
			{
				setFontStyle(StyleEditorUtility.BOLD_ITALIC);
			}
			
			else if(tempFont.isBold())
			{
				setFontStyle(StyleEditorUtility.BOLD);
			}
			else if(tempFont.isItalic())
			{
				setFontStyle(StyleEditorUtility.ITALIC);
			}
			else if(tempFont.isPlain())
			{
				setFontStyle(StyleEditorUtility.PLAIN);
			}
			
			setFontSizeText(tempFont.getSize());
		}
	}
	
	/**
	 * Updates the alignment.
	 */
	private void updateAlignment()
	{
		if(StyleEditorUtility.ALIGNMENT_MAP_ALIGN_TO_STRINGS.containsKey(this.legendStyle.getAlignment()))
		{
			setAlignment(StyleEditorUtility.ALIGNMENT_MAP_ALIGN_TO_STRINGS.get(this.legendStyle.getAlignment()));
		}
	}

	@Override
	/**
	 * Applies the style.
	 */
	protected void doApply() 
	{
		applyTextColor();
		applyBorderColor();
		applyBackgroundColor();
		applyFont();
		applyAlignment();
	}
	
	/**
	 * Applies the text color.
	 */
	private void applyTextColor()
	{
		this.legendStyle.setDefaultFontPaint(getTextPaint());
	}
	
	/**
	 * Applies the border color.
	 */
	private void applyBorderColor()
	{
		this.legendStyle.setOutlinePaint(getBorderPaint());
	}
	
	/**
	 * Applies the background color.
	 */
	private void applyBackgroundColor()
	{
		this.legendStyle.setBackgroundPaint(getBackgroundPaint());
	}
	
	/**
	 * Applies the font.
	 */
	private void applyFont()
	{
		int tempFontStyle = 0;
		int fontSize;
		
		//find font style
		if(StyleEditorUtility.BOLD_ITALIC.equals(getFontStyle()))
		{
			tempFontStyle = Font.BOLD | Font.ITALIC;
		}
		else if(StyleEditorUtility.BOLD.equals(getFontStyle()))
		{
			tempFontStyle = Font.BOLD;
		}
		else if(StyleEditorUtility.ITALIC.equals(getFontStyle()))
		{
			tempFontStyle = Font.ITALIC;
		}
		else if(StyleEditorUtility.PLAIN.equals(getFontStyle()))
		{
			tempFontStyle = Font.PLAIN;
		}
		
		//setting the font
		try
		{
			fontSize = Integer.parseInt(getFontSizeText());
			
			if(fontSize <= 0)
			{
				JOptionPane.showMessageDialog(this, "Font Size value must be greater than zero.");
			}			
			else
			{
				this.legendStyle.setDefaultFont(new Font(getFontFamily(), tempFontStyle, fontSize));
			}
			
		}
		catch (NumberFormatException e)
		{
			JOptionPane.showMessageDialog(this, INVALID_FONT_SIZE);
		}
	}
	
	/**
	 * Applies the alignment.
	 */
	private void applyAlignment()
	{
		if(StyleEditorUtility.ALIGNMENT_MAP_STRINGS_TO_ALIGN.containsKey(getAlignment()))
		{
			this.legendStyle.setAlignment(getAlignmentObject());
		}
	}
	
	private LegendAlignment getAlignmentObject()
	{
	    return StyleEditorUtility.ALIGNMENT_MAP_STRINGS_TO_ALIGN.get(getAlignment());
	}

	/**
	 * Returns the legend style.
	 * @return The legend style.
	 */
	public LegendStyle getLegendStyle()
	{
		if(this.legendStyle == null)
			throw new NullPointerException("LegendStyle is null.");
		
		return this.legendStyle;
	}

	@Override
	protected boolean modified()
	{
		boolean modified = false;
		
		modified = modified || !Util.isEqual(getTextPaint(),this.legendStyle.getDefaultFontPaint());
	    modified = modified || !Util.isEqual(getBorderPaint(),this.legendStyle.getOutlinePaint());
	    modified = modified || !Util.isEqual(getBackgroundPaint(),this.legendStyle.getBackgroundPaint());
	    
	    try
	    {
	        modified = modified || !Util.isEqual(StyleEditorUtility.getFont(getFontFamily(), getFontStyle(), getFontSizeText()),
	                this.legendStyle.getDefaultFont());
	    }
	    catch (StyleEditorUtility.ConversionException e)
	    {}

		modified = modified || !Util.isEqual(this.legendStyle.getAlignment(),getAlignmentObject());
	    
		return modified;
	}
}
