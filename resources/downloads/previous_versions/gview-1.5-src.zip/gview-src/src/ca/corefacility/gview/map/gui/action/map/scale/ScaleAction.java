package ca.corefacility.gview.map.gui.action.map.scale;

import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.action.map.MapAction;

/**
 * Scale map action.
 * 
 * @author Eric Marinier
 *
 */
public abstract class ScaleAction extends MapAction 
{
	private final GViewMap gViewMap;
	private final double previous;
	
	/**
	 * 
	 * @param gViewMap The GView map object.
	 * @param previous The previous scale level.
	 */
	public ScaleAction(GViewMap gViewMap, double previous)
	{
		if(gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		if(previous < GUIUtility.SCALE_MIN)
			previous = GUIUtility.SCALE_MIN;
		
		if(previous > GUIUtility.SCALE_MAX)
			previous = GUIUtility.SCALE_MAX;
		
		this.gViewMap = gViewMap;
		this.previous = previous;
	}
	
	@Override
	public void undo() throws CannotUndoException 
	{
		this.gViewMap.zoomNormal(this.previous); 
	}
	
	@Override
	public void redo() throws CannotRedoException
	{
		try
        {
            this.run();
        }
		catch (ActionRunException e)
        {
            throw new CannotRedoException();
        }
	}
}
