package ca.corefacility.gview.map.gui.action.style;

import java.awt.HeadlessException;
import java.io.IOException;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.data.GenomeDataImp;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.GViewMapImp;
import ca.corefacility.gview.map.gui.editor.StyleEditorFrame;
import ca.corefacility.gview.map.gui.editor.StyleEditorTree;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility;
import ca.corefacility.gview.map.gui.open.StyleDataFilter;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.io.StyleIOGSS;

public class ImportStyleAction extends StyleEditorAction
{
	private final StyleEditorFrame styleEditorFrame;
	
	/**
	 * 
	 * @param styleEditorFrame The related style editor frame.
	 */
	public ImportStyleAction(StyleEditorFrame styleEditorFrame)
	{
		if(styleEditorFrame == null)
			throw new IllegalArgumentException("StyleEditorFrame is null.");
		
		this.styleEditorFrame = styleEditorFrame;
	}

	@Override
	public void undo() throws CannotUndoException
	{
		throw new CannotUndoException();
	}

	@Override
	public void redo() throws CannotRedoException 
	{
		throw new CannotRedoException();
	}
	
	@Override
	public boolean canUndo() 
	{
		return false;
	}
	
	@Override
	public boolean canRedo() 
	{
		return false;
	}

	@Override
	public void run()
	{
		StyleIOGSS styleIO = new StyleIOGSS();
		
		JFileChooser styleChooser = new JFileChooser(this.styleEditorFrame.getCurrentDirectory());		
		File styleFile;
		
		StyleEditorTree styleTree;		
		GViewMap gViewMap;
		
		GenomeDataImp genomeData = new GenomeDataImp(this.styleEditorFrame.getGenomeData().getSequence());
		MapStyle mapStyle;
		
		styleChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		styleChooser.setFileFilter(new StyleDataFilter());
		
		try
		{			
			if(styleChooser.showOpenDialog(this.styleEditorFrame) == JFileChooser.APPROVE_OPTION 
				&&  styleChooser.getSelectedFile() != null)
			{
				styleFile = styleChooser.getSelectedFile();
				
				this.styleEditorFrame.setCurrentDirectory(styleChooser.getCurrentDirectory());				
				mapStyle = styleIO.readMapStyle(styleFile);
				
				if(mapStyle != null)
				{
					gViewMap = new GViewMapImp(genomeData, mapStyle, StyleEditorUtility.DEFAULT_LAYOUT);
					
					styleTree = new StyleEditorTree(this.styleEditorFrame, gViewMap, styleFile.toURI());
					styleTree.updateTree();
					
					//Add the style
					this.styleEditorFrame.addStyle(styleTree);
				}
			}
		}
		catch (HeadlessException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
