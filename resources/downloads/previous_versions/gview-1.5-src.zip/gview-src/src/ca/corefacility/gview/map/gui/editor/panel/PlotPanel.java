package ca.corefacility.gview.map.gui.editor.panel;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Paint;

import javax.swing.JLabel;

import ca.corefacility.gview.map.gui.editor.StyleColoredButton;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility.ConversionException;
import ca.corefacility.gview.style.datastyle.PlotBuilderType;
import ca.corefacility.gview.style.datastyle.PlotDrawerType;
import ca.corefacility.gview.style.datastyle.PlotStyle;
import ca.corefacility.gview.style.io.PlotIO;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedPlotDataException;
import ca.corefacility.gview.utils.Util;

import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.factories.FormFactory;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.border.TitledBorder;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Arrays;

import javax.swing.border.LineBorder;

/**
 * The panel for a plot.
 * 
 * @author Eric Marinier
 *
 */
public class PlotPanel extends StylePanel implements ActionListener
{
	private static final long serialVersionUID = 1L;	//requested by java
	private static final int paintArraySize = 2;
	
	private static final String PLOT_COLOR_UPPER = "Upper Plot Color";
	private static final String PLOT_COLOR_LOWER = "Lower Plot Color";
	private static final String GRID_COLOR = "Grid Color";
	
	private static final String INVALID_GRID_LINES = "Invalid number of grid lines.";
	private static final String PLOT_STYLE_NULL = "PlotStyle is null.";
	
	private static final String DATA_LABEL_TEXT = "Data:";
	private static final String TYPE_LABEL_TEXT = "Type:";
	private static final String GRID_LINES_LABEL_TEXT = "Grid Lines:";
	private static final String GRID_COLOR_LABEL_TEXT = "Grid Color:";
	private static final String UPPER_COLOR_LABEL_TEXT = "Upper Color:";
	private static final String LOWER_COLOR_LABEL_TEXT = "Lower Color:";
	private static final String AUTO_SCALE_TEXT = "Auto Scale:";
	
	private static final String BROWSE = "Browse ...";
	private static final String PLOT_STYLE_TEXT = "Plot Style";
	
	private static final String GC_CONTENT = "GC Content";
	private static final String GC_SKEW = "GC Skew";
	private static final String FILE_RANGE = "File (range)";
	private static final String FILE_POINT = "File (point)";
	
	private static final String[] DATA_TYPES = {GC_CONTENT, GC_SKEW, FILE_RANGE, FILE_POINT};
	private static final String DATA = "Data";
	
	private static final String LINE = "line";
	private static final String BAR = "bar";
	private static final String	CENTER	= "center";
	
	private static final String[] PLOT_TYPES = {LINE, BAR, CENTER};
	
	private static final String MALFORMED_PLOT_DATA_EXCEPTION = "Malformed Plot Data Exception";
	private static final String IO_EXCEPTION = "IO Exception";
	
	private final StyleColoredButton plotColorUpper;
	private final StyleColoredButton plotColorLower;
	private final StyleColoredButton gridColor;
	
	private final JButton browseFileButton;
	
	private final JTextField dataFileTextField;
	private final JTextField gridLines;
	
	private final JComboBox dataType;
	private final JComboBox type;
	
	private final JCheckBox autoScale;
	
	private final PlotStyle plotStyle;
	
	private final JFileChooser fileChooser;
	private File currentDirectory = null;
	private File chosenDataFile;

	/**
	 * Create the panel.
	 */
	public PlotPanel(PlotStyle plotStyle) 
	{	
		super();
		
		if(plotStyle == null)
			throw new IllegalArgumentException(PLOT_STYLE_NULL);
		
		this.plotStyle = plotStyle;
		
		//Layout
		setBorder(new EmptyBorder(10, 10, 10, 10));
		FormLayout formLayout = new FormLayout(new ColumnSpec[] {
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("center:default"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("left:min:grow"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,},
			new RowSpec[] {
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("15dlu"),
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,});
		formLayout.setRowGroups(new int[][]{new int[]{2, 4, 6, 8, 10, 12, 14}});
		
		JPanel inner = new JPanel();
		inner.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), PLOT_STYLE_TEXT, TitledBorder.LEADING, TitledBorder.TOP, null, new Color(51, 51, 51)));
		add(inner, BorderLayout.NORTH);
		
		inner.setLayout(formLayout);
		
		JPanel panel_4 = new JPanel();
		inner.add(panel_4, "2, 2, fill, fill");
		panel_4.setLayout(new BorderLayout(0, 0));
		
		JLabel lblThickness = new JLabel(DATA_LABEL_TEXT);
		panel_4.add(lblThickness, BorderLayout.EAST);
		
		//data overall panel
		JPanel panel = new JPanel();
		inner.add(panel, "6, 2, fill, fill");
		panel.setLayout(new BorderLayout(0, 0));
		
		//... data file ...
		
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new BorderLayout());
		panel.add(dataPanel, BorderLayout.WEST);
		
		JPanel dataSubPanel = new JPanel();
		dataSubPanel.setLayout(new BoxLayout(dataSubPanel, BoxLayout.LINE_AXIS));
		dataPanel.add(dataSubPanel, BorderLayout.WEST);
		
		//data combo box
		this.dataType = new JComboBox(DATA_TYPES);
		this.dataType.addActionListener(this);
		this.dataType.setActionCommand(DATA);
		dataSubPanel.add(this.dataType);
		
		//data text field
		this.dataFileTextField = new JTextField();
		this.dataFileTextField.setColumns(15);
		this.dataFileTextField.getDocument().addDocumentListener(this);
		this.dataFileTextField.setVisible(false);
		dataSubPanel.add(this.dataFileTextField);
		
		//browse file button
		this.browseFileButton = new JButton(BROWSE);
		this.browseFileButton.setActionCommand(BROWSE);
		this.browseFileButton.addActionListener(this);
		this.browseFileButton.setVisible(false);
		dataSubPanel.add(this.browseFileButton);
		
		//...
		
		JPanel panel_5 = new JPanel();
		inner.add(panel_5, "2, 4, fill, fill");
		panel_5.setLayout(new BorderLayout(0, 0));
		
		JLabel lblTooltipText = new JLabel(TYPE_LABEL_TEXT);
		panel_5.add(lblTooltipText, BorderLayout.EAST);
		
		JPanel panel_1 = new JPanel();
		inner.add(panel_1, "6, 4, fill, fill");
		panel_1.setLayout(new BorderLayout(0, 0));
		
		//plot type combo box
		this.type = new JComboBox(PLOT_TYPES);
		this.type.addActionListener(this);
		panel_1.add(type, BorderLayout.WEST);		
		
		JPanel panel_6 = new JPanel();
		inner.add(panel_6, "2, 6, fill, fill");
		panel_6.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFeatureShape = new JLabel(GRID_LINES_LABEL_TEXT);
		panel_6.add(lblFeatureShape, BorderLayout.EAST);
		
		JPanel panel_2 = new JPanel();
		inner.add(panel_2, "6, 6, fill, fill");
		panel_2.setLayout(new BorderLayout(0, 0));
		
		//grid lines text field
		this.gridLines = new JTextField();
		this.gridLines.setColumns(10);
		this.gridLines.getDocument().addDocumentListener(this);
		panel_2.add(this.gridLines, BorderLayout.WEST);
		
		JPanel panel_7 = new JPanel();
		inner.add(panel_7, "2, 8, fill, fill");
		panel_7.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFeatureEffect = new JLabel(GRID_COLOR_LABEL_TEXT);
		panel_7.add(lblFeatureEffect, BorderLayout.EAST);
		
		JPanel panel_3 = new JPanel();
		inner.add(panel_3, "6, 8, fill, fill");
		panel_3.setLayout(new BorderLayout(0, 0));
		
		//grid color button
		this.gridColor = new StyleColoredButton();
		this.gridColor.setActionCommand(GRID_COLOR);
		this.gridColor.addActionListener(this);
		panel_3.add(this.gridColor, BorderLayout.WEST);	
		
		JPanel panel_8 = new JPanel();
		inner.add(panel_8, "2, 10, fill, fill");
		panel_8.setLayout(new BorderLayout(0, 0));
		
		JLabel lblColor = new JLabel(UPPER_COLOR_LABEL_TEXT);
		panel_8.add(lblColor, BorderLayout.EAST);
		
		JPanel panel_9 = new JPanel();
		inner.add(panel_9, "6, 10, fill, fill");
		panel_9.setLayout(new BorderLayout(0, 0));
		
		//upper plot color
		this.plotColorUpper = new StyleColoredButton();
		this.plotColorUpper.setActionCommand(PLOT_COLOR_UPPER);
		this.plotColorUpper.addActionListener(this);
		panel_9.add(this.plotColorUpper, BorderLayout.WEST);
		
		JPanel panel_10 = new JPanel();
		inner.add(panel_10, "2, 12, fill, fill");
		panel_10.setLayout(new BorderLayout(0, 0));
		
		JLabel lblColor2 = new JLabel(LOWER_COLOR_LABEL_TEXT);
		panel_10.add(lblColor2, BorderLayout.EAST);
		
		JPanel panel_11 = new JPanel();
		inner.add(panel_11, "6, 12, fill, fill");
		panel_11.setLayout(new BorderLayout(0, 0));
		
		//lower plot color
		this.plotColorLower = new StyleColoredButton();
		this.plotColorLower.setActionCommand(PLOT_COLOR_LOWER);
		this.plotColorLower.addActionListener(this);
		panel_11.add(this.plotColorLower, BorderLayout.WEST);
		
		JPanel panel_12 = new JPanel();
		inner.add(panel_12, "2, 14, fill, fill");
		panel_12.setLayout(new BorderLayout(0, 0));
		
		JLabel lblAutoScale = new JLabel(AUTO_SCALE_TEXT);
		panel_12.add(lblAutoScale, BorderLayout.EAST);
		
		JPanel panel_13 = new JPanel();
		inner.add(panel_13, "6, 14, fill, fill");
		panel_13.setLayout(new BorderLayout(0, 0));
		
		//auto scale
		this.autoScale = new JCheckBox();
		panel_13.add(autoScale, BorderLayout.WEST);
		this.autoScale.setSelected(true);
		
		//file chooser
		this.fileChooser = new JFileChooser(currentDirectory);
		this.fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

		this.update();
	}
	
	/**
	 * 
	 * @return The color of the upper portion of the plot.
	 */
	private Paint getPlotUpperPaint()
	{
		Paint p = this.plotColorUpper.getRealPaint();
		
		return p;
	}
	
	/**
	 * Sets the color of the upper portion of the plot.
	 * 
	 * @param c
	 */
	private void setPlotUpperPaint(Paint p)
	{	
		this.plotColorUpper.setPaint(p);
	}
	
	/**
	 * 
	 * @return The color of the lower portion of the slot.
	 */
	private Paint getPlotLowerPaint()
	{
		Paint p = this.plotColorLower.getRealPaint();
		
		return p;
	}
	
	/**
	 * Sets the color of the lower portion of the plot.
	 * 
	 * @param c
	 */
	private void setPlotLowerPaint(Paint p)
	{
		this.plotColorLower.setPaint(p);
	}
	
	/**
	 * 
	 * @return The color of the grid.
	 */
	private Paint getGridPaint()
	{
		Paint p = this.gridColor.getRealPaint();
		
		return p;
	}
	
	/**
	 * Sets the color of the grid.
	 * 
	 * @param c
	 */
	private void setGridPaint(Paint p)
	{
		this.gridColor.setPaint(p);
	}
	
	/**
	 * Gets the text in the file text field.
	 * 
	 * @return The text in the file text field.
	 */
	private String getFileText()
	{
		return this.dataFileTextField.getText();
	}
	
	/**
	 * Sets the file text field text.
	 * 
	 * @param text
	 */
	private void setFileText(String text)
	{
		this.dataFileTextField.setText(text);
	}
	
	/**
	 * 
	 * @return The text in the number of grid lines field.
	 */
	private String getGridLinesText()
	{
		return this.gridLines.getText();
	}
	
	/**
	 * Sets the text in the grid lines field.
	 * 
	 * @param i The number of grid lines.
	 */
	private void setGridLinesText(int i)
	{
		this.gridLines.setText(Integer.toString(i));
	}
	
	/**
	 * 
	 * @return The text in the plot type combo box.
	 */
	private String getType()
	{
		Object temp;
		String result;
		
		temp = this.type.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Type is not a String");
		}
		
		return result;
	}
	
	/**
	 * Sets the text in the plot type combo box.
	 * 
	 * @param shape The shape to using when drawing the graph.
	 */
	private void setType(String shape)
	{
		this.type.setSelectedItem(shape);
	}
	
	/**
	 * Sets the data type.
	 * 
	 * @param s The data type.
	 */
	private void setDataType(String s)
	{
		this.dataType.setSelectedItem(s);
	}
	
	/**
	 * 
	 * @return The selected data type.
	 */
	private String getDataType()
	{
		Object temp;
		String result;
		
		temp = this.dataType.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Data Type is not a String");
		}
		
		return result;
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		Color c;
		
		if(e.getActionCommand().equals(PLOT_COLOR_UPPER))
		{
			c = StyleEditorUtility.showColorPicker(this, this.plotColorUpper.getBackground());
			
			if(c != null)
				this.plotColorUpper.setPaint(c);
		}
		else if(e.getActionCommand().equals(PLOT_COLOR_LOWER))
		{
			c = StyleEditorUtility.showColorPicker(this, this.plotColorLower.getBackground());
			
			if(c != null)
				this.plotColorLower.setPaint(c);
		}
		else if(e.getActionCommand().equals(GRID_COLOR))
		{
			c = StyleEditorUtility.showColorPicker(this, this.gridColor.getBackground());
			
			if(c != null)
				this.gridColor.setPaint(c);
		}
		else if(e.getActionCommand().equals(DATA))
		{
			if(this.dataType.getSelectedItem().equals(FILE_RANGE) || this.dataType.getSelectedItem().equals(FILE_POINT))
			{
				this.dataFileTextField.setVisible(true);
				this.browseFileButton.setVisible(true);
				this.revalidate();
			}
			else
			{
				this.dataFileTextField.setVisible(false);
				this.browseFileButton.setVisible(false);
			}
		}
		else if(e.getActionCommand().equals(BROWSE))
		{
			this.fileChooser.setCurrentDirectory(this.currentDirectory);
			this.fileChooser.showOpenDialog(this);
			this.currentDirectory = this.fileChooser.getCurrentDirectory();
			
			this.chosenDataFile = fileChooser.getSelectedFile();
			
			if (this.chosenDataFile != null)
			{
				setFileText(this.chosenDataFile.getAbsolutePath());
			}
		}
		
		super.actionPerformed(e);
	}

	@Override
	/**
	 * Updates the panel.
	 */
	public void update() 
	{
		updateData();
		updateType();
		updateGridLines();
		updateGridColor();
		updateUpperColor();
		updateLowerColor();
	}
	
	private PlotBuilderType getPlotBuilderType() throws ConversionException
	{
        String dataType = getDataType();
        PlotBuilderType plotBuilder = null;
        File file;
        
        if(dataType.equals(GC_CONTENT))
        {
            plotBuilder = new PlotBuilderType.GCContent();
        }
        else if(dataType.equals(GC_SKEW))
        {
            plotBuilder = new PlotBuilderType.GCSkew();
        }
        else if(dataType.equals(FILE_POINT))
        {
            file = new File(getFileText());
            
            try
            {
                plotBuilder = PlotIO.readPointFile(file.toURI());
            }
            catch (MalformedPlotDataException e)
            {
                throw new StyleEditorUtility.ConversionException(MALFORMED_PLOT_DATA_EXCEPTION);
            }
            catch (IOException e)
            {
                throw new StyleEditorUtility.ConversionException(IO_EXCEPTION);
            }
        }
        else if(dataType.equals(FILE_RANGE))
        {
            file = new File(getFileText());
            
            try
            {
                plotBuilder = PlotIO.readRangeFile(file.toURI());
            }
            catch (MalformedPlotDataException e)
            {
                throw new StyleEditorUtility.ConversionException(MALFORMED_PLOT_DATA_EXCEPTION);
            }
            catch (IOException e)
            {
                throw new StyleEditorUtility.ConversionException(IO_EXCEPTION);
            }
        }
        
        applyAutoScale(plotBuilder);
        
        return plotBuilder;
	}
	
	/**
	 * Updates the data components.
	 */
	private void updateData()
	{
		PlotBuilderType plotBuilder = plotStyle.getPlotBuilderType();
		
		if(plotBuilder instanceof PlotBuilderType.GCContent)
		{
			this.dataType.setSelectedItem(GC_CONTENT);
		}
		else if (plotBuilder instanceof PlotBuilderType.GCSkew)
		{
			this.dataType.setSelectedItem(GC_SKEW);
		} 
		else if(plotBuilder instanceof PlotBuilderType.Points)
		{
			setDataType(FILE_POINT);
		}
		else if(plotBuilder instanceof PlotBuilderType.Range)
		{
			setDataType(FILE_RANGE);
		}	
		
		URI uri = plotBuilder.getURI();
		
		if(uri != null)
		{
			setFileText(uri.getPath());
		}
	}
	
	/**
	 * Updates the type.
	 */
	private void updateType()
	{
		PlotDrawerType plotDrawer = this.plotStyle.getPlotDrawerType();
		
		if(plotDrawer instanceof PlotDrawerType.Line)
		{
			setType(LINE);
		}
		else if(plotDrawer instanceof PlotDrawerType.Bar)
		{
			setType(BAR);
		}
		else if(plotDrawer instanceof PlotDrawerType.Center)
		{
			setType(CENTER);
		}	
	}
	
	/**
	 * Updates the grid lines.
	 */
	private void updateGridLines()
	{
		setGridLinesText(this.plotStyle.getGridLines());
	}
	
	/**
	 * Updates the grid color.
	 */
	private void updateGridColor()
	{
		Paint tempPaint = this.plotStyle.getGridPaint();
		
		setGridPaint(tempPaint);
	}
	
	/**
	 * Updates the upper grid color.
	 */
	private void updateUpperColor()
	{
		Paint tempPaint = this.plotStyle.getPaint()[0];

		setPlotUpperPaint(tempPaint);		
	}
	
	/**
	 * Updates the lower grid color.
	 */
	private void updateLowerColor()
	{
		Paint tempPaint;
		
		if(this.plotStyle.getPaint().length > 1)
		{
			tempPaint = this.plotStyle.getPaint()[1];
			
			setPlotLowerPaint(tempPaint);
		}
	}

	@Override
	/**
	 * Applies the style.
	 */
	protected void doApply() 
	{
		applyData();
		applyType();
		applyGridLines();
		applyGridColor();
		applyUpperAndLowerColor();
	}
	
	/**
	 * Applies the data components.
	 */
	private void applyData()
	{
	    PlotBuilderType plotBuilder;
        try
        {
            plotBuilder = getPlotBuilderType();
            this.plotStyle.setPlotBuilderType(plotBuilder);
        }
        catch (ConversionException e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
	}
	
	private boolean getAutoScale()
	{
	    return this.autoScale.isSelected();
	}
	
	/**
	 * Applies the auto scale or scales to the plots max and min 
	 * 
	 * @param plotBuilder The plot builder to auto scale or not.
	 */
	private void applyAutoScale(PlotBuilderType plotBuilder)
	{
		if(plotBuilder != null)
		{			
			if(getAutoScale())
			{
				plotBuilder.autoScale(true);
			}
			else
			{
			    plotBuilder.autoScale(false);
			}
		}		
	}
	
	/**
	 * Applies the type.
	 */
	private void applyType()
	{
		try
        {
            this.plotStyle.setPlotDrawerType(getPlotDrawerType());
        }
		catch (ConversionException e)
        {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
	}
	
	private PlotDrawerType getPlotDrawerType() throws ConversionException
	{
       String type = getType();
        
        //type
        if(type.equals(LINE))
        {
            return new PlotDrawerType.Line();
        }
        else if(type.equals(BAR))
        {
            return new PlotDrawerType.Bar();
        }
        else if(type.equals(CENTER))
        {
            return new PlotDrawerType.Center();
        }
        else
        {
            throw new StyleEditorUtility.ConversionException("Invalid Plot type " + type);
        }
	}
	
	/**
	 * Applies the grid lines.
	 */
	private void applyGridLines()
	{
		try
		{
			int gridLines = getGridLines();
			this.plotStyle.setGridLines(gridLines);		
		}
		catch (StyleEditorUtility.ConversionException e)
		{
		    JOptionPane.showMessageDialog(this, e.getMessage());
		}
	}
	
	private int getGridLines() throws StyleEditorUtility.ConversionException
	{
	    int lines = -1;
	    try
	    {
    	    lines = Integer.parseInt(getGridLinesText());
    	    
            if(lines < 0)
            {
                throw new StyleEditorUtility.ConversionException("Grid Lines value must be non-negative.");
            }
	    }
	    catch(NumberFormatException nfe)
        {
            throw new StyleEditorUtility.ConversionException(INVALID_GRID_LINES);
        }
        
        return lines;
	}
	
	/**
	 * Applies the grid color.
	 */
	private void applyGridColor()
	{
		this.plotStyle.setGridPaint(getGridPaint());
	}
	
	/**
	 * Applies the upper and lower grid color.
	 */
	private void applyUpperAndLowerColor()
	{
		Paint[] paints = getUpperAndLowerColors();
		
		this.plotStyle.setPaint(paints);
	}
	
	private Paint[] getUpperAndLowerColors()
	{
        Paint[] paints = new Paint[PlotPanel.paintArraySize];
            
        paints[0] = getPlotUpperPaint();
        paints[1] = getPlotLowerPaint();
        
        return paints;
	}
	
	/**
	 * Returns the associated plot style.
	 * 
	 * @return The associated plot style.
	 */
	public PlotStyle getPlotStyle()
	{
		if(this.plotStyle == null)
			throw new NullPointerException("PlotStyle is null.");
		
		return this.plotStyle;
	}

	@Override
	protected boolean modified()
	{
		boolean modified = false;
		
		try
        {
            modified = modified || !this.plotStyle.getPlotBuilderType().equals(getPlotBuilderType());
        }
		catch (ConversionException e)
        {
        }
		
		try
        {
            modified = modified || !this.plotStyle.getPlotDrawerType().equals(getPlotDrawerType());
        }
		catch (ConversionException e)
        {
        }
		
		try
        {
            modified = modified || !(this.plotStyle.getGridLines() == getGridLines());
        }
		catch (ConversionException e)
        {
        }
		
		modified = modified || !Util.isEqual(this.plotStyle.getGridPaint(),getGridPaint());
		modified = modified || !Arrays.deepEquals(this.plotStyle.getPaint(),getUpperAndLowerColors());
		
		return modified;
	}
}
