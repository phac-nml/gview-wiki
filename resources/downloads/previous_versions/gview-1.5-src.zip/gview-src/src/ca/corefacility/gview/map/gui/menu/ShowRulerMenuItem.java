package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBoxMenuItem;

import ca.corefacility.gview.map.gui.GUIUtility;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.action.map.hide.HideRulerAction;
import ca.corefacility.gview.map.gui.action.map.show.ShowRulerAction;

/**
 * Responsible for creating and managing the "Show Ruler" menu item.
 * 
 * @author Eric Marinier
 *
 */
public class ShowRulerMenuItem extends JCheckBoxMenuItem implements ItemListener
{
	private static final long serialVersionUID = 1L;
	
	private final GViewGUIFrame gViewGUIFrame;
	
	/**
	 * Creates a new ShowRuler menu item within the specified frame.
	 * @param gViewGUIFrame  The frame this menu item belongs to.
	 */
	public ShowRulerMenuItem(GViewGUIFrame gViewGUIFrame)
	{
		super(GUIUtility.SHOW_RULER_TEXT);
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;		
		this.addItemListener(this);
	}

	@Override
	/**
	 * Listens for the menu item.
	 */
	public void itemStateChanged(ItemEvent e)
	{
		if (e.getStateChange() == ItemEvent.SELECTED)
		{
			this.gViewGUIFrame.doAction(new ShowRulerAction(this.gViewGUIFrame.getGViewMap().getElementControl()));
		}
		else if (e.getStateChange() == ItemEvent.DESELECTED)
		{
			this.gViewGUIFrame.doAction(new HideRulerAction(this.gViewGUIFrame.getGViewMap().getElementControl()));
		}
	}
	
	/**
	 * Updates the selected state of the menu item.
	 */
	public void update()
	{
		if(this.gViewGUIFrame.getGViewMap().getElementControl().getRulerDisplayed())
		{
			this.setSelected(true);
		}
		else
		{
			this.setSelected(false);
		}			
	}	
}
