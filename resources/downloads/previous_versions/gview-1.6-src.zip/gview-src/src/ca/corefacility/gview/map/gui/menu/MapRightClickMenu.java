package ca.corefacility.gview.map.gui.menu;

import javax.swing.JPopupMenu;

import ca.corefacility.gview.map.controllers.GUIController;

/**
 * The right click menu for the GUI.
 * Displays when the GView Map is right clicked.
 * 
 * @author Eric Marinier
 *
 */
public class MapRightClickMenu extends JPopupMenu
{
	private static final long serialVersionUID = 1L;
	
	public MapRightClickMenu(GUIController guiController)
	{
		super();
		
		if(guiController == null)
			throw new IllegalArgumentException("GUIController is null.");
		
		this.add(new ViewMenu(guiController));
	}
}
