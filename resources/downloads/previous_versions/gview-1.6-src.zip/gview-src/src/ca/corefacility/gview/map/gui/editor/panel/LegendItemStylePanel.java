package ca.corefacility.gview.map.gui.editor.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import ca.corefacility.gview.map.controllers.LegendItemStyleToken;
import ca.corefacility.gview.map.controllers.LegendStyleController;
import ca.corefacility.gview.map.controllers.LegendStyleToken;
import ca.corefacility.gview.map.gui.HintLabel;
import ca.corefacility.gview.map.gui.editor.StyleColoredButton;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility;

import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.RowSpec;

/**
 * The panel for the legend item style properties.
 * 
 * @author Eric Marinier
 *
 */
public class LegendItemStylePanel extends StylePanel implements ActionListener 
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private static final String SWATCH_COLOR = "Swatch Color";
	private static final String TEXT_COLOR = "Text Color";
	
	private static final String LEGEND_ITEM_STYLE_TEXT = "Legend Text Style";
	
	private static final String LEGEND_STYLE_CONTROLLER_NULL = "LegendStyleController is null.";
	private static final String LEGEND_ITEM_STYLE_TOKEN_NULL = "LegendItemStyleToken is null.";
	private static final String LEGEND_STYLE_TOKEN_NULL = "LegendStyleToken is null.";
	
	private static final String SHOW_SWATCH_LABEL_TEXT = "Show Swatch:";
	private static final String SWATCH_COLOR_LABEL_TEXT = "Swatch Color:";
	private static final String FONT_FAMILY_LABEL_TEXT = "Font Family:";
	private static final String FONT_STYLE_LABEL_TEXT = "Font Style:";
	private static final String FONT_SIZE_LABEL_TEXT = "Font Size:";
	private static final String TEXT_LABEL_TEXT = "Text:";
	private static final String TEXT_COLOR_LABEL_TEXT = "Text Color:";
	
	private static final String FONT_FAMILY_HINT = "The legend text font family.";
	private static final String FONT_STYLE_HINT = "The legend text font style.";
	private static final String FONT_SIZE_HINT = "The legend text font size.";
	private static final String LEGEND_ITEM_TEXT_HINT = "The text of the legend item.";
	private static final String SHOW_SWATCH_HINT = "Whether or not the swatch is visible.";
	private static final String SWATCH_COLOR_HINT = "The color of the swatch, typically used for matching this legend text item to any features of the same color.";
	private static final String TEXT_COLOR_HINT = "The color of the legend text.";
	
	private final StyleColoredButton swatchColor;
	private final StyleColoredButton textColor;
	
	private final JComboBox fontFamily;
	private final JComboBox fontStyle;
	
	private final JTextField fontSize;
	private final JTextField legendText;
	
	private final JCheckBox showSwatch;
	
	private final LegendStyleController controller;
	private final LegendItemStyleToken legendItemStyle;
	private final LegendStyleToken legendStyle;

	/**
	 * Create the panel.
	 */
	public LegendItemStylePanel(LegendStyleController controller, 
			LegendStyleToken legendStyle, LegendItemStyleToken legendItemStyle) 
	{		
		super();
		
		if(controller == null)
		{
			throw new IllegalArgumentException(LEGEND_STYLE_CONTROLLER_NULL);
		}
		
		if(legendItemStyle == null)
		{
			throw new IllegalArgumentException(LEGEND_ITEM_STYLE_TOKEN_NULL);
		}
		
		if(legendStyle == null)
		{
			throw new IllegalArgumentException(LEGEND_STYLE_TOKEN_NULL);
		}
		
		this.controller = controller;
		this.legendItemStyle = legendItemStyle;
		this.legendStyle = legendStyle;
		
		//Layout
		setBorder(new EmptyBorder(10, 10, 10, 10));
		FormLayout formLayout = new FormLayout(new ColumnSpec[] {
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("center:default"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("left:min:grow"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,},
			new RowSpec[] {
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("default:grow"),
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("default:grow"),
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("default:grow"),
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("default:grow"),
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,});
		formLayout.setRowGroups(new int[][]{new int[]{10, 8, 6, 12, 14, 2, 4}});
		
		JPanel inner = new JPanel();
		inner.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), LEGEND_ITEM_STYLE_TEXT, TitledBorder.LEADING, TitledBorder.TOP, null, new Color(51, 51, 51)));
		add(inner, BorderLayout.NORTH);
		
		inner.setLayout(formLayout);
		
		//LEGEND ITEM TEXT
		JPanel panel_14 = new JPanel();
		inner.add(panel_14, "2, 2, fill, fill");
		panel_14.setLayout(new BorderLayout(0, 0));
		
		JLabel lblText = new JLabel(TEXT_LABEL_TEXT);
		panel_14.add(lblText, BorderLayout.EAST);
		
		JPanel panel_15 = new JPanel();
		inner.add(panel_15, "6, 2, fill, fill");
		panel_15.setLayout(new BorderLayout(0, 0));
		
		//Legend Item text
		this.legendText = new JTextField();
		this.legendText.setColumns(20);
		panel_15.add(legendText, BorderLayout.WEST);
		
		//hint
		inner.add(new HintLabel(LEGEND_ITEM_TEXT_HINT), "10, 2");
		
		//SHOW SWATCH
		JPanel panel = new JPanel();
		inner.add(panel, "2, 4, fill, fill");
		panel.setLayout(new BorderLayout(0, 0));
		
		JLabel lblShowSwatch = new JLabel(SHOW_SWATCH_LABEL_TEXT);
		panel.add(lblShowSwatch, BorderLayout.EAST);
		
		JPanel panel_4 = new JPanel();
		inner.add(panel_4, "6, 4, fill, fill");
		panel_4.setLayout(new BorderLayout(0, 0));
		
		//show swatch check box
		this.showSwatch = new JCheckBox("");
		this.showSwatch.addActionListener(this);
		panel_4.add(this.showSwatch, BorderLayout.WEST);
		
		//hint
		inner.add(new HintLabel(SHOW_SWATCH_HINT), "10, 4");
		
		//SWATCH COLOR
		JPanel panel_5 = new JPanel();
		inner.add(panel_5, "2, 6, fill, fill");
		panel_5.setLayout(new BorderLayout(0, 0));
		
		JLabel lblSwatchColor = new JLabel(SWATCH_COLOR_LABEL_TEXT);
		panel_5.add(lblSwatchColor, BorderLayout.EAST);
		
		JPanel panel_1 = new JPanel();
		inner.add(panel_1, "6, 6, fill, fill");
		panel_1.setLayout(new BorderLayout(0, 0));
		
		//swatch color button
		this.swatchColor = new StyleColoredButton();
		this.swatchColor.setActionCommand(LegendItemStylePanel.SWATCH_COLOR);
		panel_1.add(this.swatchColor, BorderLayout.WEST);
		this.swatchColor.addActionListener(this);
		this.swatchColor.setToolTipText(LegendItemStylePanel.SWATCH_COLOR);
		
		//hint
		inner.add(new HintLabel(SWATCH_COLOR_HINT), "10, 6");
		
		//TEXT COLOR
		JPanel panel_6 = new JPanel();
		inner.add(panel_6, "2, 8, fill, fill");
		panel_6.setLayout(new BorderLayout(0, 0));
		
		JLabel label = new JLabel(TEXT_COLOR_LABEL_TEXT);
		panel_6.add(label, BorderLayout.EAST);
		
		JPanel panel_2 = new JPanel();
		inner.add(panel_2, "6, 8, fill, fill");
		panel_2.setLayout(new BorderLayout(0, 0));
		
		//text color button
		this.textColor = new StyleColoredButton();
		this.textColor.setActionCommand(LegendItemStylePanel.TEXT_COLOR);
		panel_2.add(this.textColor, BorderLayout.WEST);
		this.textColor.addActionListener(this);
		this.textColor.setToolTipText(LegendItemStylePanel.TEXT_COLOR);
		
		//hint
		inner.add(new HintLabel(TEXT_COLOR_HINT), "10, 8");
		
		//FONT FAMILY
		JPanel panel_7 = new JPanel();
		inner.add(panel_7, "2, 10, fill, fill");
		panel_7.setLayout(new BorderLayout(0, 0));
		
		JLabel label_3 = new JLabel(FONT_FAMILY_LABEL_TEXT);
		panel_7.add(label_3, BorderLayout.EAST);
		
		JPanel panel_3 = new JPanel();
		inner.add(panel_3, "6, 10, fill, fill");
		panel_3.setLayout(new BorderLayout(0, 0));
		
		//font family combo box
		this.fontFamily = new JComboBox(StyleEditorUtility.FONT_NAMES);
		this.fontFamily.addActionListener(this);
		panel_3.add(this.fontFamily, BorderLayout.WEST);
		
		//hint
		inner.add(new HintLabel(FONT_FAMILY_HINT), "10, 10");
		
		//FONT STYLE
		JPanel panel_10 = new JPanel();
		inner.add(panel_10, "2, 12, fill, fill");
		panel_10.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFontStyle = new JLabel(FONT_STYLE_LABEL_TEXT);
		panel_10.add(lblFontStyle, BorderLayout.EAST);
		
		JPanel panel_12 = new JPanel();
		inner.add(panel_12, "6, 12, fill, fill");
		panel_12.setLayout(new BorderLayout(0, 0));
		
		//font style combo box
		this.fontStyle = new JComboBox(StyleEditorUtility.FONT_STYLES);
		this.fontStyle.addActionListener(this);
		panel_12.add(this.fontStyle, BorderLayout.WEST);
		
		//hint
		inner.add(new HintLabel(FONT_STYLE_HINT), "10, 12");
		
		//FONT SIZE
		JPanel panel_11 = new JPanel();
		inner.add(panel_11, "2, 14, fill, fill");
		panel_11.setLayout(new BorderLayout(0, 0));
		
		JLabel lblFontSize = new JLabel(FONT_SIZE_LABEL_TEXT);
		panel_11.add(lblFontSize, BorderLayout.EAST);
		
		JPanel panel_13 = new JPanel();
		inner.add(panel_13, "6, 14, fill, fill");
		panel_13.setLayout(new BorderLayout(0, 0));
		
		//font size text field
		this.fontSize = new JTextField();
		panel_13.add(this.fontSize, BorderLayout.WEST);
		this.fontSize.setColumns(10);
		
		//hint
		inner.add(new HintLabel(FONT_SIZE_HINT), "10, 14");

		this.update();
	}
	
	/**
	 * 
	 * @return The text color.
	 */
	private Paint getTextPaint()
	{
		return this.textColor.getRealPaint();
	}
	
	/**
	 * Sets the text color.
	 * 
	 * @param color
	 */
	private void setTextPaint(Paint p)
	{
		this.textColor.setPaint(p);
	}
	
	/**
	 * 
	 * @return The swatch color.
	 */
	private Paint getSwatchPaint()
	{
		return this.swatchColor.getRealPaint();
	}
	
	/**
	 * Sets the swatch color.
	 * 
	 * @param color
	 */
	private void setSwatchPaint(Paint p)
	{
		this.swatchColor.setPaint(p);
	}
	
	/**
	 * 
	 * @return The font family as a string.
	 */
	private String getFontFamily()
	{
		Object temp;
		String result;
		
		temp = this.fontFamily.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Font Family is not a String");
		}
		
		return result;
	}
	
	/**
	 * Sets the font family.
	 * 
	 * @param s
	 */
	private void setFontFamily(String s)
	{
		this.fontFamily.setSelectedItem(s);
	}
	
	/**
	 * 
	 * @return The font style as a string.
	 */
	private String getFontStyle()
	{
		Object temp;
		String result;
		
		temp = this.fontStyle.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Font Style is not a String");
		}
		
		return result;
	}
	
	/**
	 * Sets the font style.
	 * 
	 * @param fStyle
	 */
	private void setFontStyle(String fStyle)
	{
		this.fontStyle.setSelectedItem(fStyle);
	}
	
	/**
	 * 
	 * @return The font size as a string.
	 */
	private String getFontSizeText()
	{
		return this.fontSize.getText();
	}
	
	/**
	 * Sets the field of the font size.
	 * 
	 * @param text
	 */
	private void setFontSizeText(int size)
	{
		this.fontSize.setText(size + "");
	}
	
	/**
	 * 
	 * @return The legend text.
	 */
	public String getLegendText()
	{
		return this.legendText.getText();
	}
	
	/**
	 * Sets the legend text.
	 * 
	 * @param s
	 */
	private void setLegendText(String s)
	{
		this.legendText.setText(s);
	}
	
	/**
	 * 
	 * @return A boolean of whether or not the swatch is show.
	 */
	private boolean getShowSwatch()
	{
		return this.showSwatch.isSelected();
	}
	
	/**
	 * Sets whether or now the swatch is show.
	 * 
	 * @param b
	 */
	private void setShowSwatch(boolean b)
	{
		this.showSwatch.setSelected(b);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		Color color;
		
		if(e.getActionCommand().equals(LegendItemStylePanel.SWATCH_COLOR))
		{
			color = StyleEditorUtility.showColorPicker(this, this.swatchColor.getBackground());
			
			if(color != null)
				this.swatchColor.setPaint(color);
		}
		else if(e.getActionCommand().equals(LegendItemStylePanel.TEXT_COLOR))
		{
			color = StyleEditorUtility.showColorPicker(this, this.textColor.getBackground());
			
			if(color != null)
				this.textColor.setPaint(color);
		}
		
		super.actionPerformed(e);
	}

	@Override
	/**
	 * Updates the panel.
	 */
	public void update() 
	{
		updateTextColor();
		updateSwatchColor();
		updateShowSwatch();
		updateFont();
		updateLegendText();		
	}
	
	/**
	 * Updates the text color.
	 */
	private void updateTextColor()
	{
		Paint tempPaint = this.controller.getFontColor(legendItemStyle);
		
		setTextPaint(tempPaint);
	}
	
	/**
	 * Updates the swatch color.
	 */
	private void updateSwatchColor()
	{
		Paint tempPaint = this.controller.getSwatchColor(legendItemStyle);
			
		setSwatchPaint(tempPaint);
	}
	
	/**
	 * Updates the show swatch component.
	 */
	private void updateShowSwatch()
	{
		if(this.controller.getSwatchVisible(legendItemStyle))
		{
			setShowSwatch(true);
		}
		else
		{
			setShowSwatch(false);
		}
	}
	
	/**
	 * Updates the font.
	 */
	private void updateFont()
	{
		Font font = this.controller.getFont(legendItemStyle);
		
		if(font == null)
		{
			font = this.controller.getFont(legendStyle);
		}
		
		if(font != null)
		{
			setFontFamily(font.getFamily());
			
			if(font.isBold() && font.isItalic())
			{
				setFontStyle(StyleEditorUtility.BOLD_ITALIC);
			}
			else if(font.isPlain())
			{
				setFontStyle(StyleEditorUtility.PLAIN);
			}
			else if(font.isBold())
			{
				setFontStyle(StyleEditorUtility.BOLD);
			}
			else if(font.isItalic())
			{
				setFontStyle(StyleEditorUtility.ITALIC);
			}			
			
			setFontSizeText(font.getSize());
		}
	}
	
	/**
	 * Updates the legend text.
	 */
	private void updateLegendText()
	{
		setLegendText(this.controller.getText(legendItemStyle));
	}

	@Override
	/**
	 * Applies the style.
	 */
	protected void doApply() 
	{
		applyTextColor();
		applySwatchColor();
		applyShowSwatch();
		applyFont();
		applyLegendText();				
	}
	
	/**
	 * Applies the text color.
	 */
	private void applyTextColor()
	{
		this.controller.setFontColor(legendItemStyle, getTextPaint());
	}
	
	/**
	 * Applies the swatch color.
	 */
	private void applySwatchColor()
	{
		this.controller.setSwatchColor(legendItemStyle, getSwatchPaint());
	}
	
	/**
	 * Applies the show swatch.
	 */
	private void applyShowSwatch()
	{
		this.controller.setSwatchVisible(legendItemStyle, getShowSwatch());	
	}
	
	/**
	 * Applies the font.
	 */
	private void applyFont()
	{
		try
		{
			Font font = StyleEditorUtility.createFont(getFontFamily(), getFontStyle(), getFontSizeText());
			this.controller.setFont(legendItemStyle, font);
		}
		catch (StyleEditorUtility.ConversionException e)
		{
			JOptionPane.showMessageDialog(this, e.getMessage());
			
			this.fontSize.setText(this.controller.getFont(this.legendItemStyle).getSize() + "");
		}
	}
	
	/**
	 * Applies the legend text.
	 */
	private void applyLegendText()
	{
		this.controller.setText(legendItemStyle, getLegendText());
	}
	
	/**
	 * 
	 * @return The legend item style as a token.
	 */
	public LegendItemStyleToken getLegendItemSyle()
	{
		return this.legendItemStyle;
	}

	/**
	 * 
	 * @return The legend style controller.
	 */
	public LegendStyleController getLegendStyleController()
	{
		return this.controller;
	}
}
