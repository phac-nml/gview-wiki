package ca.corefacility.gview.map.gui.editor.transfer;

import java.awt.Paint;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

import ca.corefacility.gview.map.gui.editor.node.SetNode;

/**
 * The set transferable object.
 * 
 * This class represents a set transfer.
 * 
 * It is intended only to facilitate drag and drop behaviour and not intended to transfer sets
 * between programs or saved data.
 * 
 * @author Eric Marinier
 *
 */
public class SetTransferable implements Transferable
{
	public static final DataFlavor setFlavor = new DataFlavor(SetNode.class, "Set Flavor");	//the set flavor
	
	private final Paint color;
	
	public SetTransferable(Paint color)
	{
		this.color = color;
	}
	
	/**
	 * 
	 * @return The data flavor of the set transferable.
	 */
	public static DataFlavor getSetFlavor()
	{
		return SetTransferable.setFlavor;
	}
	
	@Override
	public DataFlavor[] getTransferDataFlavors()
	{
		return new DataFlavor[]{SetTransferable.setFlavor};
	}

	@Override
	public boolean isDataFlavorSupported(DataFlavor flavor)
	{
		boolean result = false;
		
		if(SetTransferable.setFlavor.equals(flavor))
		{
			result = true;
		}
		
		return result;
	}

	@Override
	/**
	 * Will return an integer of the slot number.
	 */
	public Object getTransferData(DataFlavor flavor)
			throws UnsupportedFlavorException, IOException
	{
		return this.color;
	}
}
