package ca.corefacility.gview.map.gui.editor.panel;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import ca.corefacility.gview.map.gui.editor.StyleEditorUtility;

/**
 * The abstract class for style panels.
 * 
 * @author Eric Marinier
 *
 */
public abstract class StylePanel extends JPanel implements ActionListener
{
	private static final long serialVersionUID = 1L;
	
	private boolean updating; //updating variable is used to stop the action listener from firing on an update.

	/**
	 * Create the panel.
	 */
	public StylePanel() 
	{
		super();
		
		this.updating = true;
		
		setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.SOUTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1, BorderLayout.EAST);
		panel_1.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));		
		
		this.updating = false;
	}
	
	/**
	 * Updates the panel.
	 */
	public void updatePanel()
	{
		//updating variable is used to stop the action listener from firing on an update.
		this.updating = true;
		update();
		this.updating = false;
	}
	
	public abstract void update();
	
	public void save()
	{
		apply();
	}
	
	/**
	 * Applies the panel's properties to the appropriate style.
	 */
	public void apply()
	{
		doApply();
	}
	
	protected abstract void doApply();
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(!this.updating)
		{
			if(e.getActionCommand().equals(StyleEditorUtility.SAVE))
			{
				save();
			}
			else
			{
			}
		}
	}
}
