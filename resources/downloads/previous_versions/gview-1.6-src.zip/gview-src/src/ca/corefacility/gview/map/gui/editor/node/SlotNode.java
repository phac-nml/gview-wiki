package ca.corefacility.gview.map.gui.editor.node;

import java.awt.Paint;
import java.util.Enumeration;

import ca.corefacility.gview.map.controllers.SlotStyleController;
import ca.corefacility.gview.map.controllers.SlotStyleToken;
import ca.corefacility.gview.map.gui.editor.panel.SlotPanel;

/**
 * The node class for the slot styles. Intended to be used within a StyleEditorTree.
 * 
 * @author Eric Marinier
 *
 */
public class SlotNode extends FeatureContainerNode implements Slotable 
{
	private static final long serialVersionUID = 1L;	//requested by java
	private static final String SLOT = "Slot";
	
	private final SlotPanel slotPanel;

	/**
	 * 
	 * @param slotPanel The related panel.
	 */
	public SlotNode(SlotPanel slotPanel) 
	{
		super(slotPanel, SLOT);

		if(slotPanel == null)
		{
			throw new IllegalArgumentException("SlotPanel is null.");
		}
		else
		{
			this.slotPanel = slotPanel;			
			this.updateName();
		}
	}	

	@Override
	public SlotPanel getPanel() 
	{
		if(this.slotPanel == null)
			throw new IllegalArgumentException("SlotPanel is null.");
		
		return this.slotPanel;
	}
	
	/**
	 * Determines whether or not the slot node has a plot node child.
	 * 
	 * @return Whether or not the slot node has a plot node child.
	 */
	public boolean containsPlotNode()
	{
		boolean result = false;
		
		@SuppressWarnings("rawtypes")
		Enumeration nodes = this.children();	
		
		while(nodes.hasMoreElements() && result == false)
		{
			if(nodes.nextElement() instanceof PlotNode)
				result = true;
		}
		
		return result;
	}
	
	/**
	 * Determines whether or not the slot node has a set node child.
	 * 
	 * @return Whether or not the slot node has a set node child.
	 */
	public boolean containsSetNode()
	{
		boolean result = false;
		
		@SuppressWarnings("rawtypes")
		Enumeration nodes = this.children();	
		
		while(nodes.hasMoreElements() && result == false)
		{
			if(nodes.nextElement() instanceof SetNode)
				result = true;
		}
		
		return result;
	}

	@Override
	public void updateName()
	{
		super.rename(SLOT + " " + getSlotNumber());
	}

	@Override
	public int getSlotNumber()
	{
		SlotStyleController controller = this.slotPanel.getSlotStyleController();
		SlotStyleToken style = this.slotPanel.getSlotStyle();
		
		int slotNumber = controller.getSlotNumber(style);
		
		return slotNumber;
	}

	@Override
	public boolean canAddSetNodeAsChild()
	{
		boolean result = true;
		
		if(this.containsPlotNode())
		{
			result = false;
		}
		
		return result;
	}
	
	/**
	 * 
	 * @return The slot style as a token.
	 */
	public SlotStyleToken getSlotStyle()
	{
		return this.slotPanel.getSlotStyle();
	}

	/**
	 * 
	 * This returns the color of the node. This will return the color the node SHOULD be, not necessarily the color node currently is.
	 * 
	 * @return The color of the node.
	 */
	public Paint getNodeColor()
	{
		SlotStyleController slotStyleController = this.slotPanel.getSlotStyleController();
		SlotStyleToken style = this.slotPanel.getSlotStyle();
		
		return slotStyleController.getConsensusColor(style);
	}
}
