package ca.corefacility.gview.map.gui.editor.node;

import java.awt.Paint;

import ca.corefacility.gview.map.controllers.LegendItemStyleToken;
import ca.corefacility.gview.map.controllers.LegendStyleController;
import ca.corefacility.gview.map.gui.editor.panel.LegendItemStylePanel;

/**
 * The node class for the legend item styles. Intended to be used within a StyleEditorTree.
 * 
 * @author Eric Marinier
 *
 */
public class LegendItemStyleNode extends StyleEditorNode 
{
	private static final long serialVersionUID = 1L;	//requested by java
	private static final String LEGEND_ITEM_STYLE = "Legend Item";
	
	private final LegendItemStylePanel legendItemStylePanel;	//the related legend item style panel
	
	/**
	 * 
	 * @param legendItemStylePanel The related panel.
	 */
	public LegendItemStyleNode(LegendItemStylePanel legendItemStylePanel)
	{
		super(legendItemStylePanel, LEGEND_ITEM_STYLE);
		
		if(legendItemStylePanel == null)
			throw new IllegalArgumentException("LegendItemStylePanel is null");
		
		this.legendItemStylePanel = legendItemStylePanel;		
		this.rename(this.legendItemStylePanel.getLegendText());
	}	
	
	@Override
	public LegendItemStylePanel getPanel() 
	{
		if(this.legendItemStylePanel == null)
			throw new IllegalArgumentException("legendItemStylePanel is null");
		
		return this.legendItemStylePanel;
	}
	
	@Override
	public LegendStyleNode getParent()
	{
		LegendStyleNode parent = null;
		
		if(super.getParent() instanceof LegendStyleNode)
		{
			parent = (LegendStyleNode)super.getParent();
		}
		else if(super.getParent() != null)
		{
			throw new ClassCastException("LegendItemStyleNode's parent is not a LegendStyleNode.");
		}
		
		return parent;
	}
	
	public LegendItemStyleToken getLegendItemSyle()
	{
		return this.legendItemStylePanel.getLegendItemSyle();
	}

	public Paint getNodeColor()
	{
		LegendStyleController controller = this.legendItemStylePanel.getLegendStyleController();
		LegendItemStyleToken style = this.legendItemStylePanel.getLegendItemSyle();
		
		return controller.getSwatchColor(style);
	}
	
	@Override
	public void update()
	{
		super.update();
		
		String text = this.legendItemStylePanel.getLegendText();
		
		if(text != null && text.length() > 0)
		{
			this.rename(text);
		}
		else
		{
			this.rename(" ");
		}
	}
}
