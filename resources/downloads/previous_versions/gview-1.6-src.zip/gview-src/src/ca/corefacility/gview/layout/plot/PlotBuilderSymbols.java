package ca.corefacility.gview.layout.plot;

public abstract class PlotBuilderSymbols extends PlotBuilderRange
{	
	public PlotBuilderSymbols()
	{
		this.minValue = -1;
		this.maxValue = 1;
	}
	
	protected PlotBuilderSymbols(PlotBuilderSymbols other)
	{
	    super(other);
	}
}
