package ca.corefacility.gview.map.gui.editor.menu;

import javax.swing.JMenu;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import ca.corefacility.gview.map.controllers.GUIController;
import ca.corefacility.gview.map.gui.menu.LayoutMenu;

public class ViewMenu extends JMenu implements MenuListener
{
	private static final long serialVersionUID = 1L;
	
	private final LayoutMenu layoutMenu;
	
	public ViewMenu(GUIController guiController)
	{
		super("View");
		
		this.layoutMenu = new LayoutMenu(guiController);
		this.add(this.layoutMenu);
		
		this.addMenuListener(this);
	}
	
	@Override
	public void menuSelected(MenuEvent e)
	{
		this.layoutMenu.update();
	}

	@Override
	public void menuDeselected(MenuEvent e)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void menuCanceled(MenuEvent e)
	{
		// TODO Auto-generated method stub
		
	}	
}
