package ca.corefacility.gview.map.gui.action.dialog.show;

import ca.corefacility.gview.map.gui.dialog.MoveDialog;

/**
 * Show move dialog action class.
 * 
 * @author Eric Marinier
 */
public class ShowMoveDialogAction extends ShowDialogAction 
{
	/**
	 * 
	 * @param dialog The move dialog to show.
	 */
	public ShowMoveDialogAction (MoveDialog dialog)
	{
		super(dialog);
	}
}
