package ca.corefacility.gview.map.gui.menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;

import ca.corefacility.gview.map.controllers.GUIController;
import ca.corefacility.gview.map.gui.GViewMapManager;
import ca.corefacility.gview.map.gui.GViewMapManager.Layout;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility;

public class LayoutMenu extends JMenu implements ActionListener
{
	private static final long serialVersionUID = 1L;
	private final GUIController guiController;
	
	private final JCheckBoxMenuItem linear;
	private final JCheckBoxMenuItem circular;
	
	public LayoutMenu(GUIController guiController)
	{
		super(StyleEditorUtility.LAYOUT_TEXT);
		
		this.guiController = guiController;
		
		this.linear = new JCheckBoxMenuItem(StyleEditorUtility.LINEAR_LAYOUT);		
		this.linear.setActionCommand(StyleEditorUtility.LINEAR_LAYOUT);
		this.linear.addActionListener(this);
		
		this.circular = new JCheckBoxMenuItem(StyleEditorUtility.CIRCULAR_LAYOUT);
		this.circular.setActionCommand(StyleEditorUtility.CIRCULAR_LAYOUT);
		this.circular.addActionListener(this);
		
		this.add(this.linear);
		this.add(this.circular);
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		String command = e.getActionCommand();
		
		if(command.equals(StyleEditorUtility.LINEAR_LAYOUT))
		{
			this.guiController.displayProgressWhileRebuilding(new Runnable()
			{
				@Override
				public void run()
				{
					guiController.setCurrentLayout(GViewMapManager.Layout.LINEAR);					
				}				
			});			
		}
		else if(command.equals(StyleEditorUtility.CIRCULAR_LAYOUT))
		{
			this.guiController.displayProgressWhileRebuilding(new Runnable()
			{
				@Override
				public void run()
				{
					guiController.setCurrentLayout(GViewMapManager.Layout.CIRCULAR);					
				}				
			});		
		}
	}
	
	/**
	 * Updates the layout menu.
	 */
	public void update()
	{
		GViewMapManager gViewMapManager = this.guiController.getCurrentStyleMapManager();
		Layout layout = gViewMapManager.getLayout();
		
		this.linear.setSelected(false);
		this.circular.setSelected(false);
		
		switch(layout)
    	{
    		case LINEAR:	this.linear.setSelected(true); break;
    		case CIRCULAR:	this.circular.setSelected(true); break;
    	}
	}
}
