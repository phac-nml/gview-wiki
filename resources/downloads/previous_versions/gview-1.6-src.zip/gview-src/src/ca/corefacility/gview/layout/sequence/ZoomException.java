package ca.corefacility.gview.layout.sequence;

public class ZoomException extends Exception
{
    private static final long serialVersionUID = 1L;

    public ZoomException(String message)
    {
        super(message);
    }
}
