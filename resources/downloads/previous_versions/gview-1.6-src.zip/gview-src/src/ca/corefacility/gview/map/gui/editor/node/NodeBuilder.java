package ca.corefacility.gview.map.gui.editor.node;

import java.util.ArrayList;

import ca.corefacility.gview.map.controllers.FeatureHolderStyleToken;
import ca.corefacility.gview.map.controllers.GenomeDataController;
import ca.corefacility.gview.map.controllers.LabelStyleToken;
import ca.corefacility.gview.map.controllers.LegendItemStyleToken;
import ca.corefacility.gview.map.controllers.LegendStyleController;
import ca.corefacility.gview.map.controllers.LegendStyleToken;
import ca.corefacility.gview.map.controllers.PlotStyleToken;
import ca.corefacility.gview.map.controllers.PropertyMappableToken;
import ca.corefacility.gview.map.controllers.PropertyMapperController;
import ca.corefacility.gview.map.controllers.SetStyleController;
import ca.corefacility.gview.map.controllers.SlotItemStyleToken;
import ca.corefacility.gview.map.controllers.SlotStyleController;
import ca.corefacility.gview.map.controllers.SlotStyleToken;
import ca.corefacility.gview.map.controllers.StyleController;
import ca.corefacility.gview.map.gui.editor.StyleEditorTree;
import ca.corefacility.gview.map.gui.editor.panel.BackbonePanel;
import ca.corefacility.gview.map.gui.editor.panel.GlobalPanel;
import ca.corefacility.gview.map.gui.editor.panel.LabelPanel;
import ca.corefacility.gview.map.gui.editor.panel.LegendItemStylePanel;
import ca.corefacility.gview.map.gui.editor.panel.LegendPanel;
import ca.corefacility.gview.map.gui.editor.panel.LegendStylePanel;
import ca.corefacility.gview.map.gui.editor.panel.PlotPanel;
import ca.corefacility.gview.map.gui.editor.panel.RulerPanel;
import ca.corefacility.gview.map.gui.editor.panel.SetPanel;
import ca.corefacility.gview.map.gui.editor.panel.SlotPanel;
import ca.corefacility.gview.map.gui.editor.panel.SlotsPanel;
import ca.corefacility.gview.map.gui.editor.panel.TooltipPanel;
import ca.corefacility.gview.map.gui.editor.panel.propertyMapper.PropertyMapperPanel;

/**
 * This class is responsible for building nodes for the style editor tree object.
 * 
 * @see StyleEditorTree
 * 
 * @author Eric Marinier
 *
 */
public class NodeBuilder
{	
	/**
	 * Creates a global node.
	 * 
	 * @param root The root node.
	 * @param styleController
	 * @return The created global node.
	 */
	public static GlobalNode createGlobalNode(StyleEditorNode root, StyleController styleController)
	{
		GlobalPanel globalPanel = new GlobalPanel(styleController.getGlobalStyleController());
		GlobalNode globalNode = new GlobalNode(globalPanel);
		
		root.add(globalNode);
		
		return globalNode;
	}
	
	/**
	 * Creates the backbone node.
	 * 
	 * @param globalNode The global node.
	 * @param styleController
	 * @return The created backbone node.
	 */
	public static BackboneNode createBackboneNode(GlobalNode globalNode, StyleController styleController)
	{
		if(globalNode == null)
			throw new IllegalArgumentException("GlobalNode is null.");
		
		BackbonePanel backbonePanel = new BackbonePanel(styleController.getBackboneStyleController());
		BackboneNode backboneNode = new BackboneNode(backbonePanel);	
		
		globalNode.add(backboneNode);
		
		return backboneNode;
	}
	
	/**
	 * Creates the backbone node, when there already exists a backbone panel. 
	 * This method exists because the same backbone node exists in two locations, but functions different.
	 * 
	 * @param globalNode The global node.
	 * @param backbonePanel
	 * @return The created backbone node.
	 */
	public static BackboneNode createBackboneNode(GlobalNode globalNode, BackbonePanel backbonePanel)
	{
		if(globalNode == null)
			throw new IllegalArgumentException("GlobalNode is null.");
		
		BackboneNode backboneNode = new BackboneNode(backbonePanel);		
		globalNode.add(backboneNode);
		
		return backboneNode;
	}
	
	/**
	 * Creates the ruler node.
	 * 
	 * @param globalNode The global node.
	 * @param styleController
	 * @return The created ruler node.
	 */
	public static RulerNode createRulerNode(GlobalNode globalNode, StyleController styleController)
	{
		if(globalNode == null)
			throw new IllegalArgumentException("GlobalNode is null.");
		
		RulerPanel rulerPanel = new RulerPanel(styleController.getRulerStyleController());
		RulerNode rulerNode = new RulerNode(rulerPanel);
		
		globalNode.add(rulerNode);
		
		return rulerNode;
	}
	
	/**
	 * Creates the tool tip node.
	 * 
	 * @param globalNode The global node.
	 * @param styleController
	 * @return The created tool tip node.
	 */
	public static TooltipNode createTooltipNode(GlobalNode globalNode, StyleController styleController)
	{
		if(globalNode == null)
			throw new IllegalArgumentException("GlobalNode is null.");
		
		TooltipPanel tooltipPanel = new TooltipPanel(styleController.getTooltipStyleController());
		TooltipNode tooltipNode = new TooltipNode(tooltipPanel);
		
		globalNode.add(tooltipNode);
		
		return tooltipNode;
	}
	
	/**
	 * Creates the legend node.
	 * 
	 * @param globalNode The global node.
	 * @param styleController
	 * @return The created legend node.
	 */
	public static LegendNode createLegendNode(GlobalNode globalNode, StyleController styleController)
	{	
		if(globalNode == null)
			throw new IllegalArgumentException("GlobalNode is null.");
		
		LegendNode legendNode = new LegendNode(new LegendPanel());
		
		globalNode.add(legendNode);
		
		createLegendStyleNodes(legendNode, styleController);
		
		return legendNode;
	}
	
	/**
	 * Creates the legend style nodes.
	 * 
	 * @param legendNode The legend node.
	 * @param styleController
	 */
	public static void createLegendStyleNodes(LegendNode legendNode, StyleController styleController)
	{
		if(legendNode == null)
			throw new IllegalArgumentException("LegendNode is null.");
		
		LegendStyleController legendStyleController = styleController.getLegendStyleController();
		ArrayList<LegendStyleToken> legendStyles = legendStyleController.getLegends();
		
		for(int i = 0; i < legendStyles.size(); i++)
		{
			createLegendStyleNode(legendNode, legendStyles.get(i), styleController);
		}
	}
	
	/**
	 * Creates a legend style node.
	 * 
	 * @param legendNode The legend node.
	 * @param legendStyle
	 * @param styleController
	 * @return The created legend style node.
	 */
	public static LegendStyleNode createLegendStyleNode(LegendNode legendNode, LegendStyleToken legendStyle, StyleController styleController)
	{
		if(legendNode == null)
			throw new IllegalArgumentException("LegendNode is null.");
		
		LegendStyleController legendStyleController = styleController.getLegendStyleController();
		
		LegendStylePanel legendPanel;
		LegendStyleNode legendStyleNode;
		
		legendPanel = new LegendStylePanel(legendStyleController, legendStyle);
		legendStyleNode = new LegendStyleNode(legendPanel);
		
		//update name
		legendStyleNode.rename(LegendStyleController.LEGEND_STYLE + " " + legendStyleController.giveLegendStyleID());
		
		legendNode.add(legendStyleNode);
		
		createLegendItemStyleNodes(legendStyleNode, legendStyle, styleController);		
		
		return legendStyleNode;
	}
	
	/**
	 * Creates the legend item style nodes.
	 * 
	 * @param legendStyleNode The associated legend style node.
	 * @param legendStyle
	 * @param styleController
	 */
	public static void createLegendItemStyleNodes(LegendStyleNode legendStyleNode, LegendStyleToken legendStyle, StyleController styleController)
	{
		if(legendStyleNode == null)
			throw new IllegalArgumentException("LegendStyleNode is null.");
		
		LegendStyleController legendStyleController = styleController.getLegendStyleController();
		ArrayList<LegendItemStyleToken> legendItemStyles = legendStyleController.getLegendItems(legendStyle);
		
		for(int i = 0; i < legendItemStyles.size(); i++)
		{
			createLegendItemStyleNode(legendStyleNode, legendStyle, legendItemStyles.get(i), styleController);
		}
	}
	
	/**
	 * Creates a legend item style node.
	 * 
	 * @param legendStyleNode The associated legend style node.
	 * @param legendStyle
	 * @param legendItemStyle
	 * @param styleController
	 * @return The created legend item style node.
	 */
	public static LegendItemStyleNode createLegendItemStyleNode(LegendStyleNode legendStyleNode, LegendStyleToken legendStyle, 
			LegendItemStyleToken legendItemStyle, StyleController styleController)
	{
		if(legendStyleNode == null)
			throw new IllegalArgumentException("LegendStyleNode is null.");
		
		LegendItemStylePanel legendItemStylePanel;
		LegendItemStyleNode legendItemStyleNode;
		
		LegendStyleController legendStyleController = styleController.getLegendStyleController();
		
		legendItemStylePanel = new LegendItemStylePanel(legendStyleController, legendStyle, legendItemStyle);	
		legendItemStyleNode = new LegendItemStyleNode(legendItemStylePanel);
		
		legendStyleNode.add(legendItemStyleNode);
		
		return legendItemStyleNode;
	}
	
	/**
	 * Creates the slots node. This is a single node.
	 * 
	 * @param root The root node.
	 * @param styleController
	 * @return The created slots node.
	 */
	public static SlotsNode createSlotNodes(StyleEditorNode root, StyleController styleController)
	{
		SlotNode currentSlotNode;
		SlotsNode slotsNode = new SlotsNode(new SlotsPanel());
		
		SlotStyleController slotStyleController = styleController.getSlotStyleController();
		ArrayList<SlotStyleToken> slotStyles = slotStyleController.getSlots();
		
		BackbonePanel backbonePanel = new BackbonePanel(styleController.getBackboneStyleController());
		
		root.add(slotsNode);
		slotsNode.add(new BackboneSlotNode(backbonePanel));
		
		for(int i = 0; i < slotStyles.size(); i++)
		{
			currentSlotNode = createSlotNode(slotStyles.get(i), styleController);			
			slotsNode.add(currentSlotNode);			
			
			createRecursiveSetNodes(currentSlotNode, slotStyleController.getSlotItems(slotStyles.get(i)), styleController);		
		}
		
		return slotsNode;
	}
	
	/**
	 * Creates a single slot node under the slots node.
	 * 
	 * @param slotStyle
	 * @param styleController
	 * @return The created slot node.
	 */
	public static SlotNode createSlotNode(SlotStyleToken slotStyle, StyleController styleController)
	{
		if(slotStyle == null)
			throw new IllegalArgumentException("SlotStyleToken is null.");		
		
		SlotStyleController slotStyleController = styleController.getSlotStyleController();
		
		SlotPanel slotPanel = new SlotPanel(styleController.getSlotStyleController(), slotStyle);
		SlotNode slotNode = new SlotNode(slotPanel);
		
		if(slotStyleController.hasPropertyMapper(slotStyle))
		{
			createPropertyMapperNode(slotNode, slotStyle, styleController);	
		}
		
		slotNode.update();
		
		return slotNode;		
	}
	
	/**
	 * Creates a property mapper node.
	 * 
	 * @param node The associated parent node.
	 * @param token
	 * @param styleController
	 * @return The created property mapper node.
	 */
	public static PropertyMapperNode createPropertyMapperNode(FeatureContainerNode node, FeatureHolderStyleToken token, StyleController styleController)
	{
		PropertyMapperController propertyMapperController = styleController.getPropertyMapperController();
		PropertyMappableToken propertyMappable = propertyMapperController.getPropertyMappable(token);		
		
		return createPropertyMapperNode(node, propertyMappable, styleController);
	}
	
	/**
	 * Creates a property mapper node.
	 * 
	 * @param node The associated parent node.
	 * @param token
	 * @param styleController
	 * @return The created property mapper node.
	 */
	public static PropertyMapperNode createPropertyMapperNode(FeatureContainerNode node, SlotStyleToken token, StyleController styleController)
	{
		PropertyMapperController propertyMapperController = styleController.getPropertyMapperController();
		PropertyMappableToken propertyMappable = propertyMapperController.getPropertyMappable(token);		
		
		return createPropertyMapperNode(node, propertyMappable, styleController);
	}	

	/**
	 * Creates a property mapper node.
	 * 
	 * @param node The associated parent node.
	 * @param propertyMappable
	 * @param styleController
	 * @return The created property mapper node.
	 */
	public static PropertyMapperNode createPropertyMapperNode(FeatureContainerNode node, PropertyMappableToken propertyMappable, StyleController styleController)
	{
		if(node == null)
		{
			throw new IllegalArgumentException("FeatureContainerNode is null.");
		}
		
		PropertyMapperPanel propertyMapperPanel;
		PropertyMapperNode propertyMapperNode = null;	//TODO something safer
		PropertyMapperController propertyMapperController = styleController.getPropertyMapperController(); 
		
		if(!node.containsPropertyMapper())
		{			
			propertyMapperPanel = new PropertyMapperPanel(propertyMapperController, propertyMappable);
			propertyMapperNode = new PropertyMapperNode(propertyMapperPanel);			
			
			node.add(propertyMapperNode);
		}
		else
		{
			throw new IllegalArgumentException("The provided node should not already contain a property mapper.");
		}
		
		return propertyMapperNode;
	}
	
	/**
	 * Recursively creates all set nodes for the passed list of sets and their children. They are added to the passed parent node.
	 * 
	 * @param topNode The associated parent.
	 * @param set
	 * @param styleController
	 */
	public static void createRecursiveSetNodes(StyleEditorNode topNode, ArrayList<SlotItemStyleToken> set, StyleController styleController)
	{
		if(topNode == null)
			throw new IllegalArgumentException("StyleEditorNode topNode is null.");
		
		SlotStyleController slotStyleController = styleController.getSlotStyleController();
				
		PlotNode plotNode;		
		SetNode setNode;
		
		SlotItemStyleToken current;
		PlotStyleToken plotStyle;
		FeatureHolderStyleToken featureHolderStyle;
		
		for(int i = 0; i < set.size(); i++)
		{
			current = set.get(i);
			
			//Plot Style
			if(current instanceof PlotStyleToken)
			{
				plotStyle = (PlotStyleToken)current;
				plotNode = createPlotNode(plotStyle, styleController);
				
				topNode.add(plotNode);
			}
			//Feature Holder Style
			else if(current instanceof FeatureHolderStyleToken)
			{	
				featureHolderStyle = (FeatureHolderStyleToken)current;
				setNode = createSetNode(featureHolderStyle, styleController);
				
				topNode.add(setNode);				
				
				//sub nodes		
				createRecursiveSetNodes(setNode, slotStyleController.getSlotItems(featureHolderStyle), styleController);
			}
		}
	}
	
	/**
	 * Creates a plot node. 
	 * 
	 * @param plotStyle
	 * @param styleController
	 * @return The created plot node.
	 */
	public static PlotNode createPlotNode(PlotStyleToken plotStyle, StyleController styleController)
	{
		if(plotStyle == null)
			throw new IllegalArgumentException("PlotStyleToken is null.");
		
		PlotPanel plotPanel = new PlotPanel(styleController.getPlotStyleController(), plotStyle);
		PlotNode plotNode = new PlotNode(plotPanel);
		
		return plotNode;
	}
	
	/**
	 * Creates a set node.
	 * 
	 * @param featureHolderStyle
	 * @param styleController
	 * @return The created set node.
	 */
	public static SetNode createSetNode(FeatureHolderStyleToken featureHolderStyle, StyleController styleController)
	{
		if(featureHolderStyle == null)
			throw new IllegalArgumentException("FeatureHolderStyleToken is null.");
		
		SetStyleController setStyleController = styleController.getSetStyleController();
		GenomeDataController genomeDataController = styleController.getGenomeDataController();
		
		SetPanel setPanel = new SetPanel(setStyleController, genomeDataController, featureHolderStyle);
		SetNode setNode = new SetNode(setPanel);
		setNode.update();
		
		LabelStyleToken labelStyle = styleController.getLabelStyleController().getLabelStyleToken(featureHolderStyle);
		createLabelStyleNode(setNode, labelStyle, styleController);
		
		if(setStyleController.hasPropertyMapper(featureHolderStyle))
		{
			createPropertyMapperNode(setNode, featureHolderStyle, styleController);
		}
		
		return setNode;
	}

	/**
	 * Creates a label style node.
	 * 
	 * @param parentNode The associated parent node.
	 * @param labelStyle
	 * @param styleController
	 */
	public static void createLabelStyleNode(FeatureContainerNode parentNode, LabelStyleToken labelStyle, StyleController styleController)
	{
		if(parentNode == null)
			throw new IllegalArgumentException("FeatureContainerNode is null.");
		
		if(!parentNode.containsLabelStyleNode())
		//if it doesn't contain a label style node already
		{
			LabelPanel labelPanel = new LabelPanel(styleController.getLabelStyleController(), styleController.getGenomeDataController(), labelStyle);
			LabelNode labelNode = new LabelNode(labelPanel);		
			
			parentNode.add(labelNode);
			labelNode.update();
		}
	}
}
