package ca.corefacility.gview.layout;

public class NoAnnotationException extends Exception
{
    private static final long serialVersionUID = 1L;

    public NoAnnotationException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public NoAnnotationException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoAnnotationException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoAnnotationException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
