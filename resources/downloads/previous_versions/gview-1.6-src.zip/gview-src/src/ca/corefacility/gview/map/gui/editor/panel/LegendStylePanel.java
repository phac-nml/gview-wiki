package ca.corefacility.gview.map.gui.editor.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Paint;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import ca.corefacility.gview.map.controllers.LegendStyleController;
import ca.corefacility.gview.map.controllers.LegendStyleToken;
import ca.corefacility.gview.map.gui.HintLabel;
import ca.corefacility.gview.map.gui.editor.StyleColoredButton;
import ca.corefacility.gview.map.gui.editor.StyleEditorUtility;
import ca.corefacility.gview.style.items.LegendAlignment;

import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.RowSpec;

/**
 * The legend style panel.
 * 
 * @author Eric Marinier
 *
 */
public class LegendStylePanel extends StylePanel implements ActionListener 
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private static final String BACKGROUND_COLOR = "Background Color";
	private static final String BORDER_COLOR = "Border Color";
	
	private static final String LEGEND_STYLE_TEXT = "Legend Box Style";
	
	private static final String LEGEND_STYLE_CONTROLLER_NULL = "LegendStyleController is null.";
	private static final String LEGEND_STYLE_TOKEN_NULL = "LegendStyleToken is null.";
	
	private static final String ALIGNMENT_LABEL_TEXT = "Alignment:";
	private static final String BACKGROUND_COLOR_LABEL_TEXT = "Background Color:";
	private static final String BORDER_COLOR_LABEL_TEXT = "Border Color:";
	
	private static final String BACKGROUND_COLOR_HINT = "The background color of the legend.";
	private static final String BORDER_COLOR_HINT = "The color of the legend's border.";
	private static final String ALIGNMENT_HINT = "The alignment of the legend.";
	
	private final StyleColoredButton backgroundColor;
	private final StyleColoredButton borderColor;
	
	private final JComboBox alignment;
	
	private final LegendStyleController controller;
	private final LegendStyleToken legendStyle;

	/**
	 * Create the panel.
	 */
	public LegendStylePanel(LegendStyleController controller, LegendStyleToken legendStyle) 
	{
		super();
		
		if(controller == null)
		{
			throw new IllegalArgumentException(LEGEND_STYLE_CONTROLLER_NULL);
		}
		
		if(legendStyle == null)
		{
			throw new IllegalArgumentException(LEGEND_STYLE_TOKEN_NULL);
		}
		
		this.controller = controller;
		this.legendStyle = legendStyle;
		
		//Layout
		setBorder(new EmptyBorder(10, 10, 10, 10));
		FormLayout formLayout = new FormLayout(new ColumnSpec[] {
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("center:default"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				ColumnSpec.decode("left:min:grow"),
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,},
			new RowSpec[] {
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("15dlu"),
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				RowSpec.decode("default:grow"),
				FormFactory.RELATED_GAP_ROWSPEC});
		formLayout.setRowGroups(new int[][]{new int[]{6, 4, 2}});
		
		JPanel inner = new JPanel();
		inner.setBorder(new TitledBorder(new LineBorder(new Color(184, 207, 229)), LEGEND_STYLE_TEXT, TitledBorder.LEADING, TitledBorder.TOP, null, new Color(51, 51, 51)));
		add(inner, BorderLayout.NORTH);
		
		inner.setLayout(formLayout);
		
		//BACKGROUND COLOR
		JPanel panel_4 = new JPanel();
		inner.add(panel_4, "2, 2, fill, fill");
		panel_4.setLayout(new BorderLayout(0, 0));
		
		JLabel label_1 = new JLabel(BACKGROUND_COLOR_LABEL_TEXT);
		panel_4.add(label_1, BorderLayout.EAST);
		
		JPanel panel = new JPanel();
		inner.add(panel, "6, 2, fill, fill");
		panel.setLayout(new BorderLayout(0, 0));
		
		//background color button
		this.backgroundColor = new StyleColoredButton();
		this.backgroundColor.setActionCommand(LegendStylePanel.BACKGROUND_COLOR);
		panel.add(this.backgroundColor, BorderLayout.WEST);
		this.backgroundColor.addActionListener(this);
		this.backgroundColor.setToolTipText(LegendStylePanel.BACKGROUND_COLOR);
		
		//hint
		inner.add(new HintLabel(BACKGROUND_COLOR_HINT), "10, 2");
		
		//BORDER COLOR
		JPanel panel_5 = new JPanel();
		inner.add(panel_5, "2, 4, fill, fill");
		panel_5.setLayout(new BorderLayout(0, 0));
		
		JLabel label_2 = new JLabel(BORDER_COLOR_LABEL_TEXT);
		panel_5.add(label_2, BorderLayout.EAST);
		
		JPanel panel_1 = new JPanel();
		inner.add(panel_1, "6, 4, fill, fill");
		panel_1.setLayout(new BorderLayout(0, 0));
		
		//border color button
		this.borderColor = new StyleColoredButton();
		this.borderColor.setActionCommand(LegendStylePanel.BORDER_COLOR);
		panel_1.add(this.borderColor, BorderLayout.WEST);
		this.borderColor.addActionListener(this);
		this.borderColor.setToolTipText(LegendStylePanel.BORDER_COLOR);
		
		//hint
		inner.add(new HintLabel(BORDER_COLOR_HINT), "10, 4");
		
		//ALIGNMENT
		JPanel panel_8 = new JPanel();
		inner.add(panel_8, "2, 6, fill, fill");
		panel_8.setLayout(new BorderLayout(0, 0));
		
		JLabel label_4 = new JLabel(ALIGNMENT_LABEL_TEXT);
		panel_8.add(label_4, BorderLayout.EAST);
		
		JPanel panel_9 = new JPanel();
		inner.add(panel_9, "6, 6, fill, fill");
		panel_9.setLayout(new BorderLayout(0, 0));
		
		//alignment combo box
		this.alignment = new JComboBox(StyleEditorUtility.LEGEND_ALIGNMENT_STRINGS);
		this.alignment.addActionListener(this);
		panel_9.add(this.alignment, BorderLayout.WEST);
		
		//hint
		inner.add(new HintLabel(ALIGNMENT_HINT), "10, 6");

		this.update();
	}
	
	/**
	 * 
	 * @return The color of the border.
	 */
	private Paint getBorderPaint()
	{
		Paint p = this.borderColor.getRealPaint();
		
		return p;
	}
	
	/**
	 * Sets the border color.
	 * 
	 * @param color
	 */
	private void setBorderPaint(Paint p)
	{
		this.borderColor.setPaint(p);
	}
	
	/**
	 * 
	 * @return The background color.
	 */
	private Paint getBackgroundPaint()
	{
		Paint p = this.backgroundColor.getRealPaint();
		
		return p;
	}
	
	/**
	 * Sets the background color.
	 * 
	 * @param color
	 */
	private void setBackgroundPaint(Paint p)
	{
		this.backgroundColor.setPaint(p);
	}
	
	/**
	 * 
	 * @return The alignment of the legend as a string.
	 */
	private String getAlignment()
	{
		Object temp;
		String result;
		
		temp = this.alignment.getSelectedItem();
		
		if (temp instanceof String)
		{
			result = (String)temp;
		}
		else
		{
			throw new IllegalArgumentException("Alignment value is not a String");
		}
		
		return result;
	}
	
	/**
	 * Sets the alignment text field.
	 * 
	 * @param align
	 */
	private void setAlignment(String align)
	{
		if(align != null)
			this.alignment.setSelectedItem(align);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		Color color;
		
		if(e.getActionCommand().equals(LegendStylePanel.BACKGROUND_COLOR))
		{
			color = StyleEditorUtility.showColorPicker(this, this.backgroundColor.getBackground());
			
			if(color != null)
				this.backgroundColor.setPaint(color);
		}
		else if(e.getActionCommand().equals(LegendStylePanel.BORDER_COLOR))
		{
			color = StyleEditorUtility.showColorPicker(this, this.borderColor.getBackground());
			
			if(color != null)
				this.borderColor.setPaint(color);
		}
		
		super.actionPerformed(e);
	}

	@Override
	/**
	 * Updates the panel.
	 */
	public void update() 
	{
		updateBorderColor();
		updateBackgroundColor();
		updateAlignment();
	}
	
	/**
	 * Updates the border color.
	 */
	private void updateBorderColor()
	{
		Paint tempPaint = this.controller.getOutlineColor(this.legendStyle);
		
		setBorderPaint(tempPaint);
	}
	
	/**
	 * Updates the background color.
	 */
	private void updateBackgroundColor()
	{
		Paint tempPaint = this.controller.getBackgroundColor(this.legendStyle);
		
		setBackgroundPaint(tempPaint);
	}
	
	/**
	 * Updates the alignment.
	 */
	private void updateAlignment()
	{
		if(StyleEditorUtility.ALIGNMENT_MAP_ALIGN_TO_STRINGS.containsKey(this.controller.getAlignment(this.legendStyle)))
		{
			setAlignment(StyleEditorUtility.ALIGNMENT_MAP_ALIGN_TO_STRINGS.get(this.controller.getAlignment(this.legendStyle)));
		}
	}

	@Override
	/**
	 * Applies the style.
	 */
	protected void doApply() 
	{
		applyBorderColor();
		applyBackgroundColor();
		applyAlignment();
	}
	
	/**
	 * Applies the border color.
	 */
	private void applyBorderColor()
	{
		this.controller.setOutlineColor(this.legendStyle, getBorderPaint());
	}
	
	/**
	 * Applies the background color.
	 */
	private void applyBackgroundColor()
	{
		this.controller.setBackgroundColor(this.legendStyle, getBackgroundPaint());
	}
	
	/**
	 * Applies the alignment.
	 */
	private void applyAlignment()
	{
		if(StyleEditorUtility.ALIGNMENT_MAP_STRINGS_TO_ALIGN.containsKey(getAlignment()))
		{
			this.controller.setAlignment(this.legendStyle, getAlignmentObject());
		}
		else
		{
			JOptionPane.showMessageDialog(this, "Invalid alignment.");
			
			this.updateAlignment();
		}
	}
	
	/**
	 * 
	 * @return The alignment of the legend.
	 */
	private LegendAlignment getAlignmentObject()
	{
	    return StyleEditorUtility.ALIGNMENT_MAP_STRINGS_TO_ALIGN.get(getAlignment());
	}
	
	/**
	 * 
	 * @return The legend style as a token.
	 */
	public LegendStyleToken getLegendStyle()
	{
		return this.legendStyle;
	}

	/**
	 * 
	 * @return The legend style controller.
	 */
	public LegendStyleController getLegendStyleController()
	{
		return this.controller;
	}
}
