package ca.corefacility.gview.map.gui.action.system;

/**
 * Stystem exit action class.
 * 
 * @author ericm
 *
 */
public class SystemExitAction extends SystemAction 
{
	@Override
	public void run() 
	{
		System.exit(0);
	}
}
