package ca.corefacility.gview.map.gui.action.map;

import ca.corefacility.gview.map.gui.action.Action;

/**
 * The map action class.
 * 
 * @author Eric Marinier
 *
 */
public abstract class MapAction extends Action 
{

}
