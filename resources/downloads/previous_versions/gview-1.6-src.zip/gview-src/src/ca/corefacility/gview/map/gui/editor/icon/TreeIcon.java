package ca.corefacility.gview.map.gui.editor.icon;

import java.awt.Paint;

/**
 * This class is intended to be used as a label icon for a custom JTree renderer.
 * 
 * @author Eric Marinier
 *
 */
public abstract class TreeIcon extends SimpleIcon
{	
	public final int x_offset = 0;
	public final int y_offset = 0;
	
	public final int width = 14;
	public final int height = 14;
	
	public TreeIcon(Paint paint)
	{
		super(paint);
	}
	
	@Override
	public int getIconWidth() 
	{
		return this.width + x_offset + 1;
	}

	@Override
	public int getIconHeight() 
	{
		return this.height + y_offset + 2;
	}
}
