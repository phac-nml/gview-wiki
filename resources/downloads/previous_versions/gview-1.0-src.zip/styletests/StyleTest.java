package styletests;

import gview.data.BlankSymbolList;
import gview.data.GenomeData;
import gview.data.GenomeDataFactory;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.SlotItemStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.items.BackboneStyle;
import gview.style.items.RulerStyle;
import gview.style.items.TooltipStyle;
import gview.textextractor.GeneTextExtractor;

import java.awt.Color;
import java.awt.Font;
import java.util.Iterator;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.seq.impl.SimpleSequenceFactory;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.utils.ChangeVetoException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class StyleTest
{
	private MapStyle mapStyle;
	
	@Before
	public void buildStyle()
	{
		mapStyle = new MapStyle();
		
		// set the style
		GlobalStyle gStyle = mapStyle.getGlobalStyle();
		gStyle.setDefaultHeight(700);
		gStyle.setDefaultWidth(700);
		
		gStyle.setBackgroundPaint(Color.BLACK);
		gStyle.setShowBorder(true);
//		gStyle.setBorderPaint(Color.BLACK);
		gStyle.setTitle("Test1");
		gStyle.setTitlePaint(Color.BLACK);
		gStyle.setTitleFont(new Font("SansSerif", Font.PLAIN, 20));
		
		TooltipStyle tStyle = gStyle.getTooltipStyle();
		tStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tStyle.setBackgroundPaint(new Color(0,0,0,0.7f));
		tStyle.setTextPaint(Color.RED);
		
		BackboneStyle bStyle = gStyle.getBackboneStyle();
		bStyle.setPaint(Color.GRAY);
		bStyle.setThickness(20.0);
		
		RulerStyle rStyle = gStyle.getRulerStyle();
		rStyle.setMajorTickLength(20.0);
		rStyle.setTickThickness(5.0);
		rStyle.setMinorTickPaint(Color.LIGHT_GRAY);
		rStyle.setMajorTickPaint(Color.DARK_GRAY);
	
		buildDataStyle(mapStyle.getDataStyle());
	}
	
	public void buildDataStyle(DataStyle style)
	{
		SlotStyle positive = style.createSlotStyle(1);
		
		positive.setPaint(Color.BLUE);
		positive.setThickness(35);
		positive.setTransparency(1.0f);
		
		FeatureHolderStyle positiveHolder = positive.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positiveHolder.setTransparency(0.7f);
		positiveHolder.setToolTipExtractor(new GeneTextExtractor());
		
		SlotStyle negative = style.createSlotStyle(-1);
		
		negative.setPaint(Color.RED); // this paint may be useless, since paints in featureholders override it
		negative.setThickness(35);
		negative.setTransparency(1.0f);
		
		FeatureHolderStyle negativeHolder = negative.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeHolder.setTransparency(0.7f);
		negativeHolder.setToolTipExtractor(new GeneTextExtractor());
	}
	
	@Test
	public void testDataStyle()
	{
		DataStyle style = mapStyle.getDataStyle();
		Assert.assertNotNull(style);
		
		SlotStyle slot = style.getSlotStyle(1);
		Assert.assertNotNull(slot);
		
		Iterator<SlotItemStyle> styles = slot.styles();
		Assert.assertNotNull(styles);
		Assert.assertTrue(styles.hasNext());
		
		FeatureHolderStyle fhStyle = (FeatureHolderStyle)styles.next();
		Assert.assertNotNull(fhStyle);
		Assert.assertEquals(0, fhStyle.getId());
		Assert.assertEquals(null, fhStyle.getParent());
		
		slot = style.getSlotStyle(-1);
		Assert.assertNotNull(slot);
		
		styles = slot.styles();
		Assert.assertNotNull(styles);
		Assert.assertTrue(styles.hasNext());
		
		fhStyle = (FeatureHolderStyle)styles.next();
		Assert.assertNotNull(fhStyle);
		Assert.assertEquals(1, fhStyle.getId());
		Assert.assertEquals(null, fhStyle.getParent());
	}
}
