package styletests;

import gview.data.BlankSymbolList;
import gview.data.GenomeData;
import gview.data.GenomeDataFactory;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.SlotItemStyle;
import gview.style.datastyle.SlotStyle;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.FeatureHolder;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.seq.impl.SimpleSequenceFactory;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.utils.ChangeVetoException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class FeatureHolderStyleTest
{
	private MapStyle mapStyle;
	private SlotStyle slotStyle;
	
	@Before
	public void setup()
	{
		mapStyle = new MapStyle();
		
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		slotStyle = dataStyle.createSlotStyle(1);
	}
	
	@Test
	public void testContainsFeatureHolderStyle()
	{
		FeatureHolderStyle topHolderStyle;
		topHolderStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.all);
		
		Assert.assertFalse(topHolderStyle.containsFeatureHolderStyle(FeatureFilter.all));
		topHolderStyle.createFeatureHolderStyle(FeatureFilter.all);
		Assert.assertTrue(topHolderStyle.containsFeatureHolderStyle(FeatureFilter.all));
		
		Assert.assertFalse(topHolderStyle.containsFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE)));
		topHolderStyle.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		Assert.assertTrue(topHolderStyle.containsFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE)));
	}
	
	@Test
	public void testGetFeatureHolderStyle()
	{
		FeatureHolderStyle topHolderStyle;
		FeatureHolderStyle currHolderStyle;
		
		topHolderStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.all);
		
		Assert.assertNull(topHolderStyle.getFeatureHolderStyle(FeatureFilter.all));
		currHolderStyle = topHolderStyle.createFeatureHolderStyle(FeatureFilter.all);
		Assert.assertEquals(currHolderStyle, topHolderStyle.getFeatureHolderStyle(FeatureFilter.all));
		
		Assert.assertNull(topHolderStyle.getFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE)));
		currHolderStyle = topHolderStyle.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		Assert.assertEquals(currHolderStyle, topHolderStyle.getFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE)));
	}
	
	@Test
	public void testStyles()
	{
		FeatureHolderStyle holderStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.all);
		FeatureHolderStyle holderStyle2;
		
		// make sure equals works for same objects
		Assert.assertEquals(holderStyle, holderStyle);
		Assert.assertFalse(holderStyle.equals(null));
		
		// make sure the clone method works
		FeatureHolderStyle holderStyleClone = (FeatureHolderStyle)holderStyle.clone();
		Assert.assertEquals(holderStyle, holderStyleClone);
		Assert.assertNull(holderStyleClone.getParent());
		
		Assert.assertNull(holderStyle.getParent());
		Assert.assertEquals(FeatureFilter.all, holderStyle.getFilter());
		
		holderStyle2 = holderStyle.createFeatureHolderStyle(FeatureFilter.none);
		Assert.assertTrue(holderStyle2.getParent() == holderStyle); // make sure parent is same object as holderStyle
		
		Assert.assertEquals(0, holderStyle.getId());
		Assert.assertEquals(1, holderStyle2.getId());
		
		FeatureHolderStyle holderStyle2Clone = (FeatureHolderStyle)holderStyle2.clone();
		Assert.assertEquals(holderStyle2, holderStyle2Clone);
		Assert.assertTrue(holderStyle2.getParent() == holderStyle2Clone.getParent());	
	}
}
