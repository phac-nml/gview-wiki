package gview.style.items;

import java.awt.Font;

/**
 * A style defining how this legend item is printed out.  NOT USED
 */
public class LegendStyle
{
	private Font font;
	
	public Font getFont()
	{
		return font;
	}
	
	public void setFont(Font font)
	{
		this.font = font;
	}
}
