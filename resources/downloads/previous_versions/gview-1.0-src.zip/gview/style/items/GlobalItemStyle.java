package gview.style.items;

/**
 * Stores the style associated with particular global items on the map.
 * 
 * @author Aaron Petkau
 *
 */
public interface GlobalItemStyle
{
	
}
