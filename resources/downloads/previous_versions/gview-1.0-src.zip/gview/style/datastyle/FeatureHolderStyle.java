package gview.style.datastyle;

import gview.layout.feature.FeatureShapeRealizer;
import gview.map.effects.ShapeEffectRenderer;
import gview.textextractor.FeatureTextExtractor;
import gview.textextractor.GeneTextExtractor;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.biojava.bio.seq.FeatureFilter;

/**
 * Stores the style information for a particular set of features. The set of features this applies
 * to is filtered out by the passed filter.
 * 
 * @author Aaron Petkau
 * 
 */
public class FeatureHolderStyle extends SlotItemStyle implements StyleHolder
{
	private int id = 0;

	private FeatureHolderStyle parent = null; // this is used so that we can traverse up the tree to
	// generate the correct holder
	private FeatureHolderStyleFactory factory; // used so that when we create a new
	// FeatureHolderStyle, we can pass this off to the
	// factory (to handle ids).

	private ShapeEffectRenderer shapeEffectRenderer = ShapeEffectRenderer.BASIC_RENDERER;

	private LabelStyle labelStyle; // defines the style of labels associated with this holder.

	/**
	 * This controls how the shape will be drawn. Different implementations draw different shapes.
	 */
	private FeatureShapeRealizer shapeRealizer = FeatureShapeRealizer.NO_ARROW;
	private FeatureTextExtractor toolTipExtractor = new GeneTextExtractor(); // defines how tooltip
	// text will be
	// extracted

	private FeatureFilter filter;

	private Set<SlotItemStyle> styles;

	/**
	 * Constructs a FeatureHolderStyle with the passed information.
	 * 
	 * @param factory
	 * @param parent
	 * @param filter
	 * @param id
	 */
	protected FeatureHolderStyle(FeatureHolderStyleFactory factory, FeatureHolderStyle parent, FeatureFilter filter, int id)
	{
		super();

		assert filter != null;
		assert factory != null;

		this.filter = filter;

		this.id = id;
		this.parent = parent;
		this.factory = factory;

		if (parent != null)
		{
			this.labelStyle = parent.getLabelStyle();
		}
		else
		{
			this.labelStyle = new LabelStyle();
		}

		this.styles = new HashSet<SlotItemStyle>();
	}

	protected FeatureHolderStyle(FeatureHolderStyle holderStyle)
	{
		super(holderStyle);

		this.id = holderStyle.id;
		this.parent = holderStyle.parent;
		this.factory = holderStyle.factory;
		this.filter = holderStyle.filter;
		this.shapeEffectRenderer = holderStyle.shapeEffectRenderer;
		this.shapeRealizer = holderStyle.shapeRealizer;
		this.toolTipExtractor = holderStyle.toolTipExtractor;
		this.labelStyle = holderStyle.labelStyle == null ? null : (LabelStyle)holderStyle.labelStyle.clone();
		this.styles = holderStyle.styles == null ? null : (Set<SlotItemStyle>)((HashSet<SlotItemStyle>)holderStyle.styles).clone();
	}

	/**
	 * @return The parent FeatureHolderStyle of this object, or null if no parent.
	 */
	public FeatureHolderStyle getParent()
	{
		return this.parent;
	}

	/**
	 * @return An id which is used by GenomeData to "cache" filtered out features so we don't always
	 *         have to re-run the filter on all features.
	 */
	public int getId()
	{
		return this.id;
	}

	/**
	 * @return The text extractor used for the tool tips on any features in this style.
	 */
	public FeatureTextExtractor getToolTipExtractor()
	{
		return this.toolTipExtractor;
	}

	/**
	 * Determines if this holder style is using the passed FeatureFilter.
	 * @param filter  The FeatureFilter to check against.
	 * @return  True if this holder style is using the passed FeatureFilter, false otherwise.
	 */
	public boolean hasFeatureFilter(FeatureFilter filter)
	{
		return this.filter.equals(filter);
	}

	/**
	 * Sets the text extractor for the tool tip text.
	 * 
	 * @param toolTipExtractor
	 */
	public void setToolTipExtractor(FeatureTextExtractor toolTipExtractor)
	{
		if (toolTipExtractor == null)
			throw new NullPointerException("toolTipExtractor is null");

		this.toolTipExtractor = toolTipExtractor;
	}

	/**
	 * @return The FeatureFilter used to filter out features this style applies to.
	 */
	public FeatureFilter getFilter()
	{
		return this.filter;
	}

	/**
	 * @return The FeatureShapeRealizer used to construct the shapes for features in this style.
	 */
	public FeatureShapeRealizer getFeatureShapeRealizer()
	{
		return this.shapeRealizer;
	}

	/**
	 * Sets the FeatureShapeRealizer used to construct shapes for features.
	 * 
	 * @param shapeRealizer
	 */
	public void setFeatureShapeRealizer(FeatureShapeRealizer shapeRealizer)
	{
		if (shapeRealizer == null)
			throw new NullPointerException("shapeRealizer is null");

		this.shapeRealizer = shapeRealizer;
	}

	/**
	 * @return The ShapeEffectRenderer used to define how to draw/color the shape of this feature.
	 */
	public ShapeEffectRenderer getShapeEffectRenderer()
	{
		return this.shapeEffectRenderer;
	}

	/**
	 * Sets the ShapeEffectRenderer used to draw/color this feature.
	 * 
	 * @param shapeEffectRenderer
	 */
	public void setShapeEffectRenderer(ShapeEffectRenderer shapeEffectRenderer)
	{
		if (shapeEffectRenderer != null)
		{
			this.shapeEffectRenderer = shapeEffectRenderer;
		}
		else
			throw new NullPointerException("shapeEffectRenderer is null");
	}

	public FeatureHolderStyle createFeatureHolderStyle(FeatureFilter filter)
	{
		FeatureHolderStyle style = null;

		assert filter != null;

		style = this.factory.createFeatureHolderStyle(filter, this);

		// sets newly created default styles
		style.setFeatureShapeRealizer(this.shapeRealizer);
		style.setPaint(this.paint);
		style.setThickness(this.thickness);
		style.setToolTipExtractor(this.toolTipExtractor);
		style.setTransparency(this.transparency);
		style.setShapeEffectRenderer(this.shapeEffectRenderer);
		style.setLabelStyle((LabelStyle)this.labelStyle.clone());

		this.styles.add(style);

		return style;
	}

	/**
	 * Searches for a sub-FeatureHolderStyle with the passed FeatureFilter
	 * 
	 * @param filter
	 *            The filter to search for the substyle.
	 * 
	 * @return The FeatureHolderStyle using the passed filter, or null if not found.
	 */
	public FeatureHolderStyle getFeatureHolderStyle(FeatureFilter filter)
	{
		FeatureHolderStyle style = null;

		if (filter == null)
			throw new NullPointerException("filter is null");

		Iterator<SlotItemStyle> styles = styles();
		while (styles.hasNext() && style == null)
		{
			SlotItemStyle currStyle = styles.next();

			if (currStyle instanceof FeatureHolderStyle)
			{
				FeatureHolderStyle currFeatureHolderStyle = (FeatureHolderStyle)currStyle;

				if (currFeatureHolderStyle.hasFeatureFilter(filter))
				{
					style = currFeatureHolderStyle;
				}
			}
		}

		return style;
	}

	@Override
	public boolean containsFeatureHolderStyle(FeatureFilter filter)
	{
		Iterator<SlotItemStyle> styles = styles();

		while(styles.hasNext())
		{
			SlotItemStyle style = styles.next();

			if (style instanceof FeatureHolderStyle)
			{
				FeatureHolderStyle holderStyle = (FeatureHolderStyle)style;

				if (holderStyle.hasFeatureFilter(filter))
					return true;

			}
		}

		return false;
	}

	@Override
	public Object clone()
	{
		return new FeatureHolderStyle(this);
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (this.factory == null ? 0 : this.factory.hashCode());
		result = prime * result + (this.filter == null ? 0 : this.filter.hashCode());
		result = prime * result + this.id;
		result = prime * result
		+ (this.labelStyle == null ? 0 : this.labelStyle.hashCode());
		result = prime
		* result
		+ (this.shapeEffectRenderer == null ? 0 : this.shapeEffectRenderer
				.hashCode());
		result = prime * result
		+ (this.shapeRealizer == null ? 0 : this.shapeRealizer.hashCode());
		result = prime * result + (this.styles == null ? 0 : this.styles.hashCode());
		result = prime
		* result
		+ (this.toolTipExtractor == null ? 0 : this.toolTipExtractor.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		FeatureHolderStyle other = (FeatureHolderStyle) obj;
		if (this.factory == null)
		{
			if (other.factory != null)
				return false;
		}
		else if (!this.factory.equals(other.factory))
			return false;
		if (this.filter == null)
		{
			if (other.filter != null)
				return false;
		}
		else if (!this.filter.equals(other.filter))
			return false;
		if (this.id != other.id)
			return false;
		if (this.labelStyle == null)
		{
			if (other.labelStyle != null)
				return false;
		}
		else if (!this.labelStyle.equals(other.labelStyle))
			return false;
		if (this.shapeEffectRenderer == null)
		{
			if (other.shapeEffectRenderer != null)
				return false;
		}
		else if (!this.shapeEffectRenderer.equals(other.shapeEffectRenderer))
			return false;
		if (this.shapeRealizer == null)
		{
			if (other.shapeRealizer != null)
				return false;
		}
		else if (!this.shapeRealizer.equals(other.shapeRealizer))
			return false;
		if (this.styles == null)
		{
			if (other.styles != null)
				return false;
		}
		else if (!this.styles.equals(other.styles))
			return false;
		if (this.toolTipExtractor == null)
		{
			if (other.toolTipExtractor != null)
				return false;
		}
		else if (!this.toolTipExtractor.equals(other.toolTipExtractor))
			return false;
		return true;
	}

	public LabelStyle getLabelStyle()
	{
		return this.labelStyle;
	}

	public void setLabelStyle(LabelStyle labelStyle)
	{
		this.labelStyle = labelStyle;
	}

	@Override
	public Iterator<SlotItemStyle> styles()
	{
		return this.styles.iterator();
	}
}
