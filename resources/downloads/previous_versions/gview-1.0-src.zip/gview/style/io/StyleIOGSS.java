package gview.style.io;

import gview.style.MapStyle;
import gview.style.io.gss.GeneralStyleConverter;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

public class StyleIOGSS extends StyleIO
{
	private GeneralStyleConverter gssConverter;
	
	public StyleIOGSS()
	{
		gssConverter = new GeneralStyleConverter();
	}

	@Override
	public MapStyle readMapStyle(Reader styleReader, String uri)
	{
		return gssConverter.decode(styleReader, uri);
	}
	
	public void readMapStyle(MapStyle mapStyle, Reader styleReader, String uri)
	{
		gssConverter.decode(mapStyle, styleReader, uri);
	}

	@Override
	public void writeMapStyle(MapStyle mapStyle, Writer styleWriter) throws IOException
	{
		gssConverter.encode(mapStyle, styleWriter);
	}
}
