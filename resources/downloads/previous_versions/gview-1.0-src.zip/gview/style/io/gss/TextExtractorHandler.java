package gview.style.io.gss;

import gview.textextractor.AnnotationExtractor;
import gview.textextractor.FeatureTextExtractor;
import gview.textextractor.GeneTextExtractor;
import gview.textextractor.LocationExtractor;
import gview.textextractor.SymbolsExtractor;

import org.w3c.css.sac.LexicalUnit;

public class TextExtractorHandler
{
	private static final String TEXT_EXTRACTOR_FUNCTION = "text-extractor";

	private static final String ANNOTATION_NAME = "annotation";
	private static final String GENE_NAME = "gene";
	private static final String LOCATION_NAME = "location";
	private static final String SYMBOLS_NAME = "symbols";

	public static String encode(FeatureTextExtractor textExtractor)
	{
		return TEXT_EXTRACTOR_FUNCTION + "(" + encodeTextExtractor(textExtractor) + ")";
	}

	private static String encodeTextExtractor(FeatureTextExtractor textExtractor)
	{
		String extractorString = null;

		if (textExtractor == null)
		{
			extractorString = "\"null\"";
		}
		else if (textExtractor.getClass().equals(AnnotationExtractor.class))
		{
			AnnotationExtractor annExt = (AnnotationExtractor)textExtractor;
			String annotation = annExt.getAnnotation();

			extractorString = ANNOTATION_NAME + "(\"" + annotation + "\")";
		}
		else if (textExtractor.getClass().equals(LocationExtractor.class))
		{
			extractorString = "\"" + LOCATION_NAME + "\"";
		}
		else if (textExtractor.getClass().equals(GeneTextExtractor.class))
		{
			extractorString = "\"" + GENE_NAME + "\"";
		}
		else if (textExtractor.getClass().equals(SymbolsExtractor.class))
		{
			extractorString = "\"" + SYMBOLS_NAME + "\"";
		}

		return extractorString;
	}

	public static FeatureTextExtractor decode(LexicalUnit textExtractor)
	{
		if (textExtractor == null)
			throw new NullPointerException("textExtractor is null");

		FeatureTextExtractor textExtractorObj = null;

		if (TEXT_EXTRACTOR_FUNCTION.equals(textExtractor.getFunctionName()))
		{
			LexicalUnit parameters = textExtractor.getParameters();

			if (parameters != null)
			{
				if (parameters.getLexicalUnitType() == LexicalUnit.SAC_STRING_VALUE)
				{
					if (LOCATION_NAME.equals(parameters.getStringValue()))
					{
						textExtractorObj = new LocationExtractor();
					}
					else if (GENE_NAME.equals(parameters.getStringValue()))
					{
						textExtractorObj = new GeneTextExtractor();
					}
					else if (SYMBOLS_NAME.equals(parameters.getStringValue()))
					{
						textExtractorObj = new SymbolsExtractor();
					}
				}
				else if (parameters.getLexicalUnitType() == LexicalUnit.SAC_FUNCTION) // sub-function below top function
				{
					LexicalUnit function = parameters;
					parameters = function.getParameters();

					if (parameters != null)
					{
						// annotation extractor
						if (ANNOTATION_NAME.equals(function.getFunctionName()))
						{
							if (parameters.getLexicalUnitType() == LexicalUnit.SAC_STRING_VALUE)
							{
								String parameter = parameters.getStringValue();

								textExtractorObj = new AnnotationExtractor(parameter);
							}
						}
					}
				}
			}
		}

		return textExtractorObj;
	}
}
