package gview.style.io.gss.exceptions;

public class MalformedPlotDataException extends ParseException
{

	public MalformedPlotDataException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public MalformedPlotDataException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MalformedPlotDataException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MalformedPlotDataException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
