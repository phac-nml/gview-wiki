package gview.style.io.gss.coders;

import gview.style.MapStyle;
import gview.style.io.FeatureSetMap;
import gview.style.io.gss.PaintHandler;
import gview.style.io.gss.exceptions.MalformedDeclarationException;
import gview.style.io.gss.exceptions.MalformedSelectorException;
import gview.style.io.gss.exceptions.NoStyleExistsException;
import gview.style.io.gss.exceptions.NoSuchFilterException;
import gview.style.io.gss.exceptions.ParseException;

import java.awt.Color;
import java.awt.Paint;
import java.io.IOException;

import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Selector;

public abstract class GSSCoder
{	
	public abstract void startSelector(Selector selector, FeatureSetMap filtersMap, MapStyle mapStyle) throws ParseException;
	
	public void encodeSelector(MapStyle style, FeatureSetMap setMap, GSSWriter writer)
	{
		if (style == null)
		{
			throw new NullPointerException("style is null");
		}
		
		if (writer == null)
		{
			throw new NullPointerException("writer is null");
		}
		
		encodeProperties(style, setMap, writer);
	}
	
	public void decodeProperty(Selector selector, MapStyle mapStyle, FeatureSetMap filtersMap, String name, LexicalUnit value, String sourceURI) throws ParseException, IOException
	{
		if (mapStyle == null)
		{
			throw new NullPointerException("mapStyle is null");
		}
		
		if (name == null)
		{
			throw new NullPointerException("name is null");
		}
		
		if (value == null)
		{
			throw new NullPointerException("value is null");
		}
		
		if (selector == null)
		{
			throw new NullPointerException("selector is null");
		}
		
		// note: filtersMap can be null, since not every coder uses filtersMap
		
		performDecodeProperty(selector, mapStyle, filtersMap, name, value, sourceURI);
	}
	
	protected abstract void performDecodeProperty(Selector selector, MapStyle mapStyle,
			FeatureSetMap filtersMap, String name, LexicalUnit value, String sourceURI) throws IOException, ParseException;

	/**
	 * Performs the actual encoding of the properties of the selector.
	 * @param style
	 * @param writer
	 */
	protected abstract void encodeProperties(MapStyle style, FeatureSetMap setMap, GSSWriter writer);
	
	/**
	 * @return  The name of the ElementSelector that this instance of GSSCoder can encode/decode.
	 */
	public abstract String getSelectorName();
}
