package gview.style.io.gss;

import gview.style.MapStyle;
import gview.style.io.FeatureSetMap;
import gview.style.io.gss.coders.FilterCoder;
import gview.style.io.gss.coders.GSSWriter;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.RangeLocation;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.Parser;

import com.steadystate.css.parser.SACParserCSS2;

public class GeneralStyleConverter
{
	private StyleConverter globalConverter = new StyleConverter();
	private FilterCoder filterCoder = new FilterCoder();
	
	public GeneralStyleConverter()
	{
	}
	
	/**
	 * Encodes the passed style and writes to the passed writer.
	 * @param style  The MapStyle to encode.
	 * @param writer  The writer to encode into.
	 * @throws IOException
	 */
	public void encode(MapStyle style, Writer writer) throws IOException
	{
		GSSWriter gssWriter = new GSSWriter(writer);
		
		// extracts/encodes FeatureSetMap
		FeatureSetMap featureSetMap = filterCoder.getFeatureFilters(style);
		filterCoder.encodeProperties(featureSetMap, gssWriter);
		
		// encodes other properties
		globalConverter.encodeSelector(style, featureSetMap, gssWriter);
		writer.flush();
	}
	
	public void encode(MapStyle style, String filename) throws IOException
	{
		encode(style, new FileWriter(filename));
	}
	
	/**
	 * Decodes the style information read from the passed reader into a new MapStyle.
	 * @param reader
	 * @return  The new MapStyle.
	 */
	public MapStyle decode(Reader reader, String uri)
	{
		MapStyle mapStyle = new MapStyle();
		
		decode(mapStyle, reader, uri);
		
		return mapStyle;
	}
	
	public void decode(MapStyle mapStyle, Reader reader)
	{
		decode(mapStyle, reader, null);
	}
	
	/**
	 * Decodes the style information read from the passed reader into the passed MapStyle.
	 * 
	 * @param mapStyle  The MapStyle to modify based upon what was passed in the reader.
	 * @param reader  The reader to read the style information from.
	 * @param uri  The uri where we are reading from (null if no such value)
	 */
	public void decode(MapStyle mapStyle, Reader reader, String uri)
	{
		Parser parser = new SACParserCSS2();
		StyleHandler styleHandler = new StyleHandler(globalConverter, mapStyle, uri);
		
		try
		{			
			parser.setDocumentHandler(styleHandler);
			parser.parseStyleSheet(new InputSource(reader));
		}
		catch (CSSException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
}
