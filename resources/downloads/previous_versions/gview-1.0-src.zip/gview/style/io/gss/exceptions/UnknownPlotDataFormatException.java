package gview.style.io.gss.exceptions;

public class UnknownPlotDataFormatException extends ParseException
{
	public UnknownPlotDataFormatException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public UnknownPlotDataFormatException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UnknownPlotDataFormatException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UnknownPlotDataFormatException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
