package gview.style.io.gss.featureFilterCoder;

import java.util.Stack;

import org.biojava.bio.seq.FeatureFilter;
import org.w3c.css.sac.LexicalUnit;

public class AndCoder extends FeatureFilterCoder
{
	private static final String AND_FUNCTION = "and";
	
	@Override
	public FeatureFilter decode(LexicalUnit value)
	{
		FeatureFilter filter = null;
		Stack<LexicalUnit> andUnits; // store on a stack so we can support multiple parameters in and
		
		if (AND_FUNCTION.equals(value.getFunctionName()))
		{
			LexicalUnit parameters = value.getParameters();
			
			if (parameters != null)
			{
				andUnits = new Stack<LexicalUnit>();
				
				while (parameters != null && (parameters.getLexicalUnitType() == LexicalUnit.SAC_FUNCTION ||
						parameters.getLexicalUnitType() == LexicalUnit.SAC_STRING_VALUE))
				{
					andUnits.push(parameters); // push current and unit
					
					parameters = parameters.getNextLexicalUnit();
					
					if (parameters != null)
					{
						if (parameters.getLexicalUnitType() == LexicalUnit.SAC_OPERATOR_COMMA) // if comma, skip
						{
							parameters = parameters.getNextLexicalUnit();
						}
						else // TODO, throw exception
						{
							System.err.println("Missing \",\" in " + value);
							return null;
						}
					}
				}
				
				// pull off last two feature filters
				if (!andUnits.isEmpty())
				{
					LexicalUnit currUnit = andUnits.pop();
					FeatureFilter currFilter1 = coderMap.decode(currUnit);
					
					if (!andUnits.isEmpty())
					{
						currUnit = andUnits.pop();
						FeatureFilter currFilter2 = coderMap.decode(currUnit);
						
						filter = new FeatureFilter.And(currFilter1, currFilter2);
						
						// extract out rest of parameters
						while (!andUnits.isEmpty())
						{
							currUnit = andUnits.pop();
							currFilter1 = coderMap.decode(currUnit);
							
							filter = new FeatureFilter.And(currFilter1, filter);
						}
					}
				}
			}
		}
		
		return filter;
	}

	@Override
	public String encode(FeatureFilter filter)
	{
		String encoding = AND_FUNCTION + "(";
		
		if (canCode(filter))
		{
			FeatureFilter.And andFilter = (FeatureFilter.And)filter;
			
			FeatureFilter filter1 = andFilter.getChild1();
			FeatureFilter filter2 = andFilter.getChild2();
			
			encoding += coderMap.encode(filter1);
			encoding += ",";
			encoding += coderMap.encode(filter2);
			
			encoding += ")";
		}
		else
		{
			throw new IllegalArgumentException("cannot encode filter of type " + filter.getClass());
		}
		
		return encoding;
	}
	
	@Override
	public boolean canCode(FeatureFilter filter)
	{
		if (filter == null)
			return false;
		return FeatureFilter.And.class.equals(filter.getClass());
	}

	@Override
	public String functionName()
	{
		return AND_FUNCTION;
	}
}
