package gview.style.io.gss.exceptions;

public class ParseException extends Exception
{

	public ParseException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public ParseException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ParseException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ParseException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
