package gview.style.io.gss;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.io.gss.exceptions.MalformedDeclarationException;
import gview.style.io.gss.exceptions.MalformedSelectorException;
import gview.style.io.gss.exceptions.NoStyleExistsException;
import gview.style.io.gss.exceptions.NoSuchFilterException;
import gview.style.io.gss.exceptions.ParseException;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.ConditionalSelector;
import org.w3c.css.sac.ElementSelector;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.SACMediaList;
import org.w3c.css.sac.Selector;
import org.w3c.css.sac.SelectorList;

public class StyleHandler implements org.w3c.css.sac.DocumentHandler, com.steadystate.css.sac.DocumentHandlerExt
{
	private MapStyle currentStyle;
	
	private StyleConverter styleConverter;
	private FilterConverter filterConverter;
	
	private SelectorList currentSelectors = null;

	private String sourceURI;
	
	public StyleHandler(StyleConverter styleConverter, MapStyle mapStyle)
	{
		this(styleConverter, mapStyle, null);
	}

	public StyleHandler(StyleConverter styleConverter, MapStyle mapStyle,
			String uri)
	{
		this.styleConverter = styleConverter;
		this.currentStyle = mapStyle;
		this.sourceURI = uri;
		
		filterConverter = new FilterConverter();
	}

	@Override
	public void comment(String text) throws CSSException
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void endDocument(InputSource source) throws CSSException
	{
	}

	@Override
	public void endFontFace() throws CSSException
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void endMedia(SACMediaList media) throws CSSException
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void endPage(String name, String pseudoPage) throws CSSException
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void endSelector(SelectorList selectors) throws CSSException
	{
		this.currentSelectors = null;
		
		// if this is the end of the "filter" selector
		if (filterConverter.canProcessSelectors(selectors))
		{
			styleConverter.setFilterMap(filterConverter.getFeatureSetMap());
		}
	}

	@Override
	public void ignorableAtRule(String atRule) throws CSSException
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void importStyle(String uri, SACMediaList media,
			String defaultNamespaceURI) throws CSSException
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void namespaceDeclaration(String prefix, String uri)
			throws CSSException
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void property(String name, LexicalUnit value, boolean important)
			throws CSSException
	{
		for (int i = 0; i < currentSelectors.getLength(); i++)
		{
			Selector selector = currentSelectors.item(i);
			
			if (styleConverter.canProcessSelector(selector))
			{
				try
				{
					styleConverter.decode(currentStyle, selector, name, value, sourceURI);
				}
				catch (ParseException e)
				{
					throw new CSSException(e);
				}
				catch (IOException e)
				{
					throw new CSSException(e);
				}
			}
			else if (filterConverter.canProcessSelector(selector))
			{
				filterConverter.decode(currentStyle, selector, name, value, important);
			}
		}
	}

	@Override
	public void startDocument(InputSource source) throws CSSException
	{
		System.out.println(source.getURI());
	}

	@Override
	public void startFontFace() throws CSSException
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startMedia(SACMediaList media) throws CSSException
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startPage(String name, String pseudoPage) throws CSSException
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void startSelector(SelectorList selectors) throws CSSException
	{
		this.currentSelectors = selectors;
		
		if (styleConverter.canProcessSelectors(selectors))
		{
			try
			{
				styleConverter.startSelector(selectors, currentStyle);
			}
			catch (ParseException e)
			{
				throw new CSSException(e);
			}
		}
		
		if (filterConverter.canProcessSelectors(selectors))
		{
			filterConverter.startSelector(selectors, currentStyle);
		}
	}

	@Override
	public void charset(String arg0) throws CSSException
	{
		// TODO Auto-generated method stub
		
	}
}
