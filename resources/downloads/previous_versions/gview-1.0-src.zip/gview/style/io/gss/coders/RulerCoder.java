package gview.style.io.gss.coders;

import gview.map.effects.ShapeEffectRenderer;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.io.FeatureSetMap;
import gview.style.io.gss.FontHandler;
import gview.style.io.gss.PaintHandler;
import gview.style.io.gss.ShapeEffectHandler;
import gview.style.io.gss.FontHandler.MalformedFontStringException;
import gview.style.items.RulerStyle;

import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;

import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Selector;

public class RulerCoder extends GSSCoder
{
	private static final String MAJOR_TICK_COLOR_NAME = "major-tick-color";
	private static final String MINOR_TICK_COLOR_NAME = "minor-tick-color";
	private static final String LABEL_COLOR_NAME = "label-color";
	private static final String LABEL_BACKGROUND_COLOR_NAME = "label-background-color";
	private static final String MAJOR_TICK_LENGTH_NAME = "major-tick-length";
	private static final String MINOR_TICK_LENGTH_NAME = "minor-tick-length";
	private static final String TICK_DENSITY_NAME = "tick-density";
	private static final String TICK_THICKNESS_NAME = "tick-thickness";
	private static final String TICK_PADDING_NAME = "tick-padding";
	private static final String TICK_EFFECT_NAME = "tick-effect";
	private static final String LABEL_FONT_NAME = "label-font";

	
	protected void encodeProperties(MapStyle style, FeatureSetMap setMap, GSSWriter writer)
	{
		RulerStyle rulerStyle = style.getGlobalStyle().getRulerStyle();
		
		Paint paint = null;
		
		writer.startSelector(getSelectorName());
		
		paint = rulerStyle.getMajorTickPaint();
		writer.writePropertyPaint(MAJOR_TICK_COLOR_NAME, paint);
	
		paint = rulerStyle.getMinorTickPaint();
		writer.writePropertyPaint(MINOR_TICK_COLOR_NAME, paint);
	
		paint = rulerStyle.getTextPaint();
		writer.writePropertyPaint(LABEL_COLOR_NAME, paint);
		
		paint = rulerStyle.getTextBackgroundPaint();
		writer.writePropertyPaint(LABEL_BACKGROUND_COLOR_NAME, paint);
		
		// encode other properties
		writer.writeProperty(MAJOR_TICK_LENGTH_NAME, Double.toString(rulerStyle.getMajorTickLength()));
		writer.writeProperty(MINOR_TICK_LENGTH_NAME, Double.toString(rulerStyle.getMinorTickLength()));
		writer.writeProperty(TICK_DENSITY_NAME, Float.toString(rulerStyle.getTickDensity()));
		writer.writeProperty(TICK_THICKNESS_NAME, Double.toString(rulerStyle.getTickThickness()));
		writer.writeProperty(TICK_PADDING_NAME, Double.toString(rulerStyle.getPadding()));
		writer.writeProperty(LABEL_FONT_NAME, FontHandler.encode(rulerStyle.getFont()));
		
		writer.endSelector();
	}
	
	
	
	@Override
	public void startSelector(Selector selector, FeatureSetMap filtersMap, MapStyle mapStyle)
	{
		// TODO Auto-generated method stub
		
	}



	@Override
	protected void performDecodeProperty(Selector selector, MapStyle mapStyle,
			FeatureSetMap filtersMap, String name, LexicalUnit value, String sourceURI)
	{
		RulerStyle rStyle = mapStyle.getGlobalStyle().getRulerStyle();
		
		if (name.equals(MAJOR_TICK_COLOR_NAME))
		{
			try
			{
				Paint paint = PaintHandler.decode(value);
				rStyle.setMajorTickPaint(paint);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		else if (name.equals(MINOR_TICK_COLOR_NAME))
		{
			try
			{
				Paint paint = PaintHandler.decode(value);
				rStyle.setMinorTickPaint(paint);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		else if (name.equals(LABEL_COLOR_NAME))
		{
			try
			{
				Paint paint = PaintHandler.decode(value);
				rStyle.setTextPaint(paint);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		else if (name.equals(LABEL_BACKGROUND_COLOR_NAME))
		{
			try
			{
				Paint paint = PaintHandler.decode(value);
				rStyle.setTextBackgroundPaint(paint);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		else if (name.equals(MAJOR_TICK_LENGTH_NAME))
		{
			if (value.getLexicalUnitType() == LexicalUnit.SAC_REAL || value.getLexicalUnitType() == LexicalUnit.SAC_INTEGER)
			{
				float number = value.getFloatValue();
				
				rStyle.setMajorTickLength(number);
			}
		}
		else if (name.equals(MINOR_TICK_LENGTH_NAME))
		{
			if (value.getLexicalUnitType() == LexicalUnit.SAC_REAL || value.getLexicalUnitType() == LexicalUnit.SAC_INTEGER)
			{
				float number = value.getFloatValue();
				
				rStyle.setMinorTickLength(number);
			}
		}
		else if (name.equals(TICK_DENSITY_NAME))
		{
			if (value.getLexicalUnitType() == LexicalUnit.SAC_REAL || value.getLexicalUnitType() == LexicalUnit.SAC_INTEGER)
			{
				float number = value.getFloatValue();
				
				rStyle.setTickDensity(number);
			}
		}
		else if (name.equals(TICK_THICKNESS_NAME))
		{
			if (value.getLexicalUnitType() == LexicalUnit.SAC_REAL || value.getLexicalUnitType() == LexicalUnit.SAC_INTEGER)
			{
				float number = value.getFloatValue();
				
				rStyle.setTickThickness(number);
			}
		}
		else if (name.equals(TICK_THICKNESS_NAME))
		{
			if (value.getLexicalUnitType() == LexicalUnit.SAC_REAL || value.getLexicalUnitType() == LexicalUnit.SAC_INTEGER)
			{
				float number = value.getFloatValue();
				
				rStyle.setTickThickness(number);
			}
		}
		else if (name.equals(TICK_EFFECT_NAME))
		{
			ShapeEffectRenderer shapeEffect = ShapeEffectHandler.decodeShapeEffect(value);
			if (shapeEffect != null)
			{
				rStyle.setShapeEffectRenderer(shapeEffect);
			}
		}
		else if (name.equals(LABEL_FONT_NAME))
		{
			Font labelFont;
			try
			{
				labelFont = FontHandler.decode(value);

				if (labelFont != null)
				{
					rStyle.setFont(labelFont);
				}
			}
			catch (MalformedFontStringException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (name.equals(TICK_PADDING_NAME))
		{
			if (value.getLexicalUnitType() == LexicalUnit.SAC_REAL || value.getLexicalUnitType() == LexicalUnit.SAC_INTEGER)
			{
				float number = value.getFloatValue();
				
				rStyle.setPadding(number);
			}
		}
	}

	public String getSelectorName()
	{
		return selectorName();
	}
	
	public static String selectorName()
	{
		return "ruler";
	}
}
