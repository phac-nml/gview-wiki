package gview.style.io.gss.exceptions;

public class UnknownPlotTypeException extends MalformedDeclarationException
{
	public UnknownPlotTypeException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public UnknownPlotTypeException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UnknownPlotTypeException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UnknownPlotTypeException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
