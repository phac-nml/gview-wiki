package gview.style.io.gss.coders;

import gview.layout.PlotBuilder;
import gview.layout.PlotDrawer;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.PlotStyle;
import gview.style.io.gss.PaintHandler;
import gview.style.io.gss.PlotFileHandler;
import gview.style.io.gss.PlotTypeHandler;
import gview.style.io.gss.exceptions.MalformedDeclarationException;
import gview.style.io.gss.exceptions.ParseException;
import gview.style.io.gss.exceptions.UnknownPlotTypeException;

import java.awt.Paint;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.w3c.css.sac.DescendantSelector;
import org.w3c.css.sac.LexicalUnit;

public class PlotCoder
{
	private static final String PAINT = "color";

	private static final String DATA = "data";

	private static final String TYPE = "type";

	private static final String GRID_LINES = "grid-lines";

	private static final String GRID_COLOR = "grid-color";


	public String getSelectorName()
	{
		return selectorName();
	}

	/**
	 * Decodes the passed name, value into the passed PlotStyle.
	 * @param plotStyle
	 * @param name
	 * @param value
	 * @param sourceURI
	 * @throws IOException
	 * @throws UnknownPlotTypeException
	 */
	public void decodeProperty(PlotStyle plotStyle,
			String name, LexicalUnit value, String sourceURI) throws ParseException, IOException
			{
		if (plotStyle != null)
		{
			if (PAINT.equals(name))
			{
				try
				{
					Paint paint = PaintHandler.decode(value);
					plotStyle.addPaint( paint );
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
			else if (DATA.equals(name))
			{
				try
				{
					File currentDirectory;

					if (sourceURI == null)
					{
						currentDirectory = new File(".");
					}
					else
					{
						File uriFile = new File(new URI(sourceURI));
						currentDirectory = uriFile.getParentFile();
					}

					PlotBuilder plotBuilder = PlotFileHandler.decode(currentDirectory, value);

					plotStyle.setPlotBuilder(plotBuilder);
				}
				catch (URISyntaxException e)
				{
					throw new IOException(e);
				}
			}
			else if (TYPE.equals(name))
			{
				PlotDrawer plotDrawer = PlotTypeHandler.decode(value);

				plotStyle.setPlotDrawer(plotDrawer);
			}
			else if (GRID_LINES.equals(name))
			{
				if (value.getLexicalUnitType() == LexicalUnit.SAC_INTEGER)
				{
					int lines = value.getIntegerValue();

					if (lines < 0)
						throw new MalformedDeclarationException(GRID_LINES + " value must be non-negative");
					else
					{
						plotStyle.setGridLines(lines);
					}
				}
				else
					throw new MalformedDeclarationException(GRID_LINES + " value must be an integer");
			}
			else if (name.equals(GRID_COLOR))
			{
				try
				{
					Paint paint = PaintHandler.decode(value);
					plotStyle.setGridPaint(paint);
				}
				catch (Exception e)
				{
					throw new MalformedDeclarationException(e);
				}
			}
			else
			{
				System.err.println("[warning] unknown declaration name " + name);
			}
		}
		else
			throw new NullPointerException("plotStyle is null");
			}

	public static String selectorName()
	{
		return "plot";
	}

	/**
	 * Encodes the passed style into the passed writer
	 * @param plotStyle
	 * @param selectorBase
	 * @param writer
	 */
	public void encodeStyle(PlotStyle plotStyle,
			String selectorBase, GSSWriter writer)
	{
		if (plotStyle == null)
			throw new NullPointerException("plotStyle is null");

		String labelSelectorName = writer.getDescendantName(selectorBase, getSelectorName());

		writer.startSelector(labelSelectorName);

		writer.writePropertyPaint(PAINT, plotStyle.getPaint()[0]);

		writer.endSelector();
	}

	public void startSelector(DescendantSelector selector, DataStyle dataStyle)
	{
		// TODO Auto-generated method stub

	}
}
