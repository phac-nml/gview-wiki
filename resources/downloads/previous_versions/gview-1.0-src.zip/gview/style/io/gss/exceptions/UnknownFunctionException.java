package gview.style.io.gss.exceptions;

public class UnknownFunctionException extends MalformedDeclarationException
{
	public UnknownFunctionException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public UnknownFunctionException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UnknownFunctionException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UnknownFunctionException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
