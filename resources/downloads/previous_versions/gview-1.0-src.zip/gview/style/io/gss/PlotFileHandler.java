package gview.style.io.gss;

import gview.layout.PlotBuilder;
import gview.layout.PlotBuilderAnnotation;
import gview.layout.PlotBuilderGC;
import gview.layout.PlotBuilderPoints;
import gview.layout.PlotBuilderRange;
import gview.style.io.gss.exceptions.MalformedDeclarationException;
import gview.style.io.gss.exceptions.MalformedPlotDataException;
import gview.style.io.gss.exceptions.ParseException;
import gview.style.io.gss.exceptions.UnknownPlotDataFormatException;
import gview.utils.Util;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.w3c.css.sac.LexicalUnit;

import au.com.bytecode.opencsv.CSVReader;

public class PlotFileHandler
{
	private static final String DATA_FILE_FUNCTION = "plot-file";

	private static final String DATE_TYPE_POINT = "point";
	private static final String DATA_TYPE_RANGE = "range";
	private static final String DATA_TYPE_ANNOTATION = "annotation";

	private static final String EXTENSION = "csv";

	private static final String	GC_SKEW_FUNCTION	= "gcskew";
	private static final String	GC_CONTENT_FUNCTION	= "gccontent";


	private static PlotBuilder readPointFile(File file) throws IOException, MalformedPlotDataException
	{
		final int BASE_INDEX = 0;
		final int VALUE_INDEX = 1;
		final int NUMBER_ELEMENTS = 2;

		PlotBuilderPoints plotBuilder = new PlotBuilderPoints();

		FileReader fileReader = new FileReader(file);
		CSVReader reader = new CSVReader(fileReader);
		String[] currLine = null;

		try
		{
			while ((currLine = reader.readNext()) != null)
			{
				if (currLine.length == NUMBER_ELEMENTS)
				{
					plotBuilder.addPoint(Integer.parseInt(currLine[BASE_INDEX]),
							Double.parseDouble(currLine[VALUE_INDEX]));
				}
				else
					throw new MalformedPlotDataException("incorrect number of columns per line in " + file);
			}
		}
		catch (NumberFormatException e)
		{
			throw new MalformedPlotDataException("in file " + file, e);
		}

		return plotBuilder;
	}

	private static PlotBuilder readRangeFile(File file) throws IOException, MalformedPlotDataException
	{
		final int BASE_START_INDEX = 0;
		final int BASE_END_INDEX = 1;
		final int VALUE_INDEX = 2;
		final int NUMBER_ELEMENTS = 3;

		FileReader fileReader = new FileReader(file);
		CSVReader reader = new CSVReader(fileReader);
		String[] currLine = null;

		PlotBuilderRange plotBuilder = new PlotBuilderRange();

		try
		{
			while ((currLine = reader.readNext()) != null)
			{
				if (currLine.length == NUMBER_ELEMENTS)
				{
					plotBuilder.addRange(Integer.parseInt(currLine[BASE_START_INDEX]),
							Integer.parseInt(currLine[BASE_END_INDEX]),
							Double.parseDouble(currLine[VALUE_INDEX]));
				}
				else
					throw new MalformedPlotDataException("incorrect number of columns per line in " + file);
			}
		}
		catch (NumberFormatException e)
		{
			throw new MalformedPlotDataException("in file " + file, e);
		}

		return plotBuilder;
	}

	private static PlotBuilder readAnnotationFile(File file) throws IOException, MalformedPlotDataException
	{
		final int ANNOTATION_TYPE_INDEX = 0;
		final int ANNOTATION_VALUE_INDEX = 1;
		final int VALUE_INDEX = 2;
		final int NUMBER_ELEMENTS = 3;

		FileReader fileReader = new FileReader(file);
		CSVReader reader = new CSVReader(fileReader);
		String[] currLine = null;

		PlotBuilderAnnotation plotBuilder = new PlotBuilderAnnotation();

		try
		{
			while ((currLine = reader.readNext()) != null)
			{
				if (currLine.length == NUMBER_ELEMENTS)
				{
					plotBuilder.addAnnotationValue(currLine[ANNOTATION_TYPE_INDEX],
							currLine[ANNOTATION_VALUE_INDEX], Double.valueOf(currLine[VALUE_INDEX]));
				}
				else
					throw new MalformedPlotDataException("incorrect number of columns per line in " + file);
			}
		}
		catch (NumberFormatException e)
		{
			throw new MalformedPlotDataException("in file " + file, e);
		}

		return plotBuilder;
	}

	/**
	 * Decodes the passed LexicalUnit into a plot builder.
	 * @param parentDirectory  The directory to look for the file if the name in the LexicalUnit lists a relative file name.
	 * @param value  The LexicalUnit to decode.
	 * @return  A PlotBuilder defining the actual data points to plot out.
	 * @throws MalformedDeclarationException
	 * @throws MalformedPlotDataException
	 */
	public static PlotBuilder decode(File parentDirectory, LexicalUnit value) throws IOException, ParseException
	{
		PlotBuilder plotBuilder = null;

		if (value == null)
			throw new NullPointerException("value is null");
		if (parentDirectory == null)
			throw new NullPointerException("parentDirectory is null");

		if( GC_SKEW_FUNCTION.equalsIgnoreCase( value.getFunctionName() ) )
			return new PlotBuilderGC( false );
		else if( GC_CONTENT_FUNCTION.equalsIgnoreCase( value.getFunctionName() ) )
			return new PlotBuilderGC( true );
		else if (DATA_FILE_FUNCTION.equalsIgnoreCase( value.getFunctionName() ) )
		{
			LexicalUnit parameters = value.getParameters();

			if (parameters != null)
			{
				if (parameters.getLexicalUnitType() == LexicalUnit.SAC_STRING_VALUE)
				{
					String dataType = parameters.getStringValue();

					parameters = parameters.getNextLexicalUnit();

					if (parameters.getLexicalUnitType() != LexicalUnit.SAC_OPERATOR_COMMA)
						throw new MalformedDeclarationException("missing \',\' in line " + value);
					else
					{
						parameters = parameters.getNextLexicalUnit();

						if (parameters.getLexicalUnitType() != LexicalUnit.SAC_STRING_VALUE)
							throw new MalformedDeclarationException("[" + parameters.getStringValue() + "] not of type SAC_STRING_VALUE");
						else
						{
							String filename = parameters.getStringValue();
							String extension = Util.extractExtension(filename);

							// read in file
							if (EXTENSION.equals(extension))
							{
								File fileToRead = new File(filename);

								// if not absolute filename, then filename is a relative file name
								if (!fileToRead.isAbsolute())
								{
									fileToRead = new File(parentDirectory, filename);
								}

								if (DATE_TYPE_POINT.equals(dataType))
								{
									plotBuilder = readPointFile(fileToRead);
								}
								else if (DATA_TYPE_RANGE.equals(dataType))
								{
									plotBuilder = readRangeFile(fileToRead);
								}
								else if (DATA_TYPE_ANNOTATION.equals(dataType))
								{
									plotBuilder = readAnnotationFile(fileToRead);
								}
								else
									throw new UnknownPlotDataFormatException("unknown data format " + dataType);

								plotBuilder.autoScale(); // sets autoscaling of points
							}
						}
					}
				}
			}
		}

		return plotBuilder;
	}

}
