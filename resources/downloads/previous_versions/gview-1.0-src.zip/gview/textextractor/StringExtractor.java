package gview.textextractor;

import org.biojava.bio.seq.Feature;

/**
 * Doesn't extract text from a feature, but instead displays whatever string it is constructed with.
 * 
 * @author Aaron Petkau
 *
 */
public class StringExtractor implements FeatureTextExtractor
{
	private String displayText;
	
	private FeatureTextExtractor textExtractor = null;
	
	public StringExtractor(String displayText)
	{
		this.displayText = displayText;
	}
	
	/**
	 * This constructor can be used to "decorate" a feature text extractor.
	 * @param displayText  The text to display before the text from the passed FeatureTextExtractor.
	 * @param textExtractor  The FeatureTextExtractor with text to display.
	 */
	public StringExtractor(String displayText, FeatureTextExtractor textExtractor)
	{
		this.textExtractor = textExtractor;
		
		if (displayText != null)
		{
			this.displayText = displayText;
		}
		else
		{
			this.displayText = "unknown";
		}
	}

	public String extractText(Feature feature)
	{
		if (textExtractor != null)
		{
			return displayText + textExtractor.extractText(feature);
		}
		else
		{
			return displayText;
		}
	}
	
	public Object clone()
	{
		return new StringExtractor(displayText, textExtractor);
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((displayText == null) ? 0 : displayText.hashCode());
		result = prime * result
				+ ((textExtractor == null) ? 0 : textExtractor.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StringExtractor other = (StringExtractor) obj;
		if (displayText == null)
		{
			if (other.displayText != null)
				return false;
		}
		else if (!displayText.equals(other.displayText))
			return false;
		if (textExtractor == null)
		{
			if (other.textExtractor != null)
				return false;
		}
		else if (!textExtractor.equals(other.textExtractor))
			return false;
		return true;
	}
}
