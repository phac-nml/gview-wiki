package gview.textextractor;

import org.biojava.bio.seq.Feature;

public class LocationExtractor implements FeatureTextExtractor
{	
	public LocationExtractor()
	{
	}
	
	public String extractText(Feature feature)
	{
		return feature.getLocation().toString();
	}
	
	public Object clone()
	{
		return new LocationExtractor();
	}
	
	public boolean equals(Object o)
	{
		if (this == o)
			return true;
		else if (o == null)
			return false;
		else if (this.getClass() != o.getClass())
			return false;
		return true;
	}
}
