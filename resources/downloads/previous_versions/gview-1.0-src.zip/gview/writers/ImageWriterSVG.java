package gview.writers;

import gview.map.GViewMap;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

import org.apache.batik.dom.GenericDOMImplementation;
import org.apache.batik.svggen.SVGGeneratorContext;
import org.apache.batik.svggen.SVGGraphics2D;
import org.apache.batik.svggen.SVGGraphics2DIOException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;

public class ImageWriterSVG extends ImageWriter
{
	private static final String[] acceptedFormats = {"svg"};
	
	public ImageWriterSVG()
	{
	}
	
	public void writeToImage(GViewMap gviewMap, File file)
		throws IOException
	{
        if (file == null)
        {
        	throw new NullPointerException("file is null");
        }
        
        if (gviewMap == null)
        {
        	throw new NullPointerException("gview map is null");
        }
		
	      // Get a DOMImplementation.
        DOMImplementation domImpl =
            GenericDOMImplementation.getDOMImplementation();

        // Create an instance of org.w3c.dom.Document.
        String svgNS = "http://www.w3.org/2000/svg";
        Document document = domImpl.createDocument(svgNS, "svg", null);
        SVGGeneratorContext context = SVGGeneratorContext.createDefault(document);
        boolean textAsShapes = false;

        // Create an instance of the SVG Generator.
        SVGGraphics2D svgGenerator = new SVGGraphics2D(context, textAsShapes);

        gviewMap.draw(svgGenerator);

        // Finally, stream out SVG to the standard output using
        // UTF-8 encoding.
        boolean useCSS = true; // we want to use CSS style attributes
        Writer out;
		try
		{
	        System.out.print("Writing image to " + file.getName() + " ... ");
	        
			out = new OutputStreamWriter(new FileOutputStream(file), "UTF-8");
		    svgGenerator.stream(out, useCSS);
		    out.close();
		    
	        System.out.println("done");
		} catch (UnsupportedEncodingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SVGGraphics2DIOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void writeToImage(GViewMap gviewMap, String filename)
			throws IOException
	{
        if (filename == null)
        {
        	throw new NullPointerException("filename is null");
        }
        
        if (gviewMap == null)
        {
        	throw new NullPointerException("gview map is null");
        }
		
        writeToImage(gviewMap, new File(filename));
	}

	@Override
	public String[] getAcceptedImageFormats()
	{
		return acceptedFormats;
	}
}
