package gview.writers;

import gview.map.GViewMap;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ImageWriterJPG extends ImageWriter
{
	private static final String[] acceptedFormats = {"jpg", "jpeg"};
	
	public ImageWriterJPG()
	{
	}
	
	public void writeToImage(GViewMap gviewMap, String filename)
		throws IOException
	{
        if (filename == null)
        {
        	throw new NullPointerException("filename is null");
        }
        
        if (gviewMap == null)
        {
        	throw new NullPointerException("gview map is null");
        }
        
        writeToImage(gviewMap, new File(filename));
	}

	public void writeToImage(GViewMap gviewMap, File file) throws IOException
	{
        if (file == null)
        {
        	throw new NullPointerException("file is null");
        }
        
        if (gviewMap == null)
        {
        	throw new NullPointerException("gview map is null");
        }
		
        System.out.print("Writing image to " + file.getName() + " ... ");
        
        BufferedImage buffImage = gviewMap.getImage();

        ImageIO.write(buffImage, "jpg", file);
        System.out.println("done");
	}

	@Override
	public String[] getAcceptedImageFormats()
	{
		return acceptedFormats;
	}
}
