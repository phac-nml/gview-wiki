package gview.main;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.data.readers.GViewDataParseException;
import gview.data.readers.GViewFileData;
import gview.data.readers.GViewFileReader;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.LocationConverter;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.BirdsEyeView;
import gview.map.BirdsEyeViewImp;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.MapStyle;
import gview.style.StyleFactory;
import gview.style.io.StyleIO;
import gview.style.io.StyleIOGSS;
import gview.writers.ImageWriter;
import gview.writers.ImageWriterFactory;
import jargs.gnu.CmdLineParser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;

import javax.swing.JComponent;
import javax.swing.JDialog;

import org.biojava.bio.BioException;
import org.biojava.bio.SimpleAnnotation;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava3.genome.parsers.gff.Feature;
import org.biojava3.genome.parsers.gff.FeatureI;
import org.biojava3.genome.parsers.gff.FeatureList;
import org.biojava3.genome.parsers.gff.GFF3;
import org.biojavax.bio.seq.RichLocation;
import org.biojavax.bio.seq.SimplePosition;
import org.biojavax.bio.seq.SimpleRichLocation;

public class GViewMain
{
	private static final String	DEFAULT_FORMAT	= "png";
	private static final String[] OUTPUT_FORMATS = { "png", "jpg", "svg" };
	private static GenomeData genomeData = null;
	private static MapStyle mapStyle = null;
	private static LayoutFactory layoutFactory = null;

	private static StyleIO styleIO = new StyleIOGSS();

	private static void printUsage()
	{
		System.err.println("usage: java -jar gview.jar [OPTION]...");
		System.err.println("-h, --help Print the usage.");
		System.err.println("-H, --height <integer> Specifies the height in pixels for the image.");
		System.err.println("-c, --centerBase <integer> Specifies the base to center on.");
		System.err.println("-i, --inputFile <file> The input file to parse.");
		System.err.println("-l, --layout <layout> The layout of the input, circular or linear.");
		System.err.println("-f, --imageFormat <format> The format of the output: " + Arrays.toString(OUTPUT_FORMATS) + " (default:" + DEFAULT_FORMAT + ")" ); //SVG, or SVGZ.
		System.err.println("-o, --outputFile <file> The image file to create.");
		System.err.println("-v, --viewer Loads up the input file in the viewer.");
		System.err.println("-s, --style <file> The file from which to read the style information from.");
		System.err.println("-b, --birdsEyeView Displays a birds eye view of the map.  This is ignored if -v is not used.");
		System.err.println("-g, --gffFile Specifies a .gff file with additional annotations to include");
		System.err.println("-W, --width <integer> Specifies the width in pixels for the image.");
		System.err.println("-z, --zoomAmount <real> The factor to zoom in by.");
		System.err.println("Example:  java -jar gview.jar -i testfiles/NC_006677.gbk -s styles/basicStyle.gss -l linear -W 1200 -H 900 -f png -o image.png");
		System.err.println("Example:  java -jar gview.jar -i testfiles/NC_006677.gbk -s styles/basicStyle.gss -l circular -v -b");
	}

	private static void createMapStyleData(String inputFile, String styleFile)
	{
		if (inputFile == null)
			return;

		GViewFileData gviewFileData;
		try
		{
			File file = new File( inputFile );

			if( !file.canRead() )
			{
				String tempFile = createTempFileFromClassLoaderResource( inputFile );
				if( tempFile != null )
				{
					inputFile = tempFile;
				}
			}

			gviewFileData = GViewFileReader.read(inputFile);

			if (gviewFileData == null)
				return;

			// handle data/style
			// TODO account for passed style file
			genomeData = gviewFileData.getGenomeData();

			if (gviewFileData.getMapStyle() != null)
			{
				mapStyle = gviewFileData.getMapStyle();
			}
			else if (styleFile != null)
			{
				file = new File( styleFile );
				if( !file.canRead() )
				{
					String tempFile = createTempFileFromClassLoaderResource( styleFile );
					if( tempFile != null )
					{
						styleFile = tempFile;
					}
				}

				mapStyle = styleIO.readMapStyle(styleFile);
			}

			// if style was not already created
			if (mapStyle == null)
			{
				System.err.println("[warning] no style set, using default style");
				mapStyle = StyleFactory.createPosterStyle();
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (GViewDataParseException e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Obtains the region manager factory from the passed layout string.
	 * @param layout  The layout to use (circular or linear).
	 * @return  The correct region manager factory, defaults to linear if layout is invalid.
	 */
	private static LayoutFactory createLayoutFactory(String layout)
	{
		LayoutFactory layoutFactory;

		if (layout == null)
		{
			layoutFactory = new LayoutFactoryLinear();
		}
		else if (layout.equalsIgnoreCase("circular") || layout.equalsIgnoreCase("c"))
		{
			layoutFactory = new LayoutFactoryCircular();
		}
		else if (layout.equalsIgnoreCase("linear") || layout.equalsIgnoreCase("l"))
		{
			layoutFactory = new LayoutFactoryLinear();
		}
		else
		{
			System.err.println("[warning] " + layout + " invalid layout.  Defaulting to linear.");
			layoutFactory = new LayoutFactoryLinear();
		}

		return layoutFactory;
	}

	private static void createViewer(GViewMap map, Boolean birdsEyeView, String title)
	{
		if (map == null)
			return;

		new PFrame(title, false, (PCanvas)map);

		// creates birds eye view if necessary
		if (birdsEyeView != null && birdsEyeView)
		{
			BirdsEyeView bev = new BirdsEyeViewImp();
			bev.connect(map);

			// displays the birds eye view component in a JDialog
			JDialog bevDialog = new JDialog();
			bevDialog.getContentPane().add((JComponent)bev);
			bevDialog.pack();
			bevDialog.setSize(150, 150);
			bevDialog.setVisible(true);
		}

	}

	private static void handleCenterBase(GViewMap gviewMap, LocationConverter locationConverter, Integer centerBase)
	{
		if (gviewMap == null || genomeData == null)
			return;

		if (centerBase != null)
		{
			if (genomeData.baseOnSequence(centerBase.intValue()))
			{
				gviewMap.setCenter(centerBase.intValue());
			}
			else
			{
				System.err.println("[warning] base=" + centerBase + " outside of range of 0 to " + genomeData.getSequenceLength());
				System.err.println("Using default center base = 0");
				gviewMap.setCenter(0);
			}
		}
	}

	private static void handleWriteToFile(GViewMap gviewMap, String format, String outputFile)
	{
		if (gviewMap == null)
			throw new IllegalArgumentException("gviewMap cannot be null");

		if (format == null && outputFile == null)
		{
			System.err.println("[error] no output file format or output file location given. If you don't want to create an output file, use -v to create a viewer window.");
			return;
		}

		// either format or outputFile is non-null
		if (format != null)
		{
			if (outputFile != null)
			{
				ImageWriter writer = ImageWriterFactory.createImageWriter(format);
				if (writer == null)
				{
					System.err.println("[error] output file format '" + format + "' not recognized.");
				}
				else
				{
					try
					{
						writer.writeToImage(gviewMap, outputFile);
					}
					catch (IOException e)
					{
						System.err.println(e);
					}
				}
			}
			else
			{
				System.err.println("[error] no output filename specified.");
			}
		}
		else
		{
			System.err.println("[error] no output file format given.");
		}
	}

	private static void handleZoom(GViewMap gviewMap, double zoomFactor)
	{
		if (gviewMap == null)
			return;

		final double MAX_ZOOM = 10000; // TODO where should I define max zoom factor overall?  In GViewMap?

		if (zoomFactor > 0 && zoomFactor <= MAX_ZOOM)
		{
			gviewMap.setZoomFactor(zoomFactor);
		}
		else
		{
			System.err.println("[warning]  zoom factor=" + zoomFactor + " is not within (0," + MAX_ZOOM + "]");
		}
	}

	public static void main(String[] args)
	{
		GViewMap gviewMap;

		CmdLineParser parser = new CmdLineParser();

		// set up command line arguments
		CmdLineParser.Option birdsEyeView = parser.addBooleanOption('b', "birdsEyeView");
		CmdLineParser.Option centerBase = parser.addIntegerOption('c', "centerBase");
		CmdLineParser.Option format = parser.addStringOption('f', "imageFormat");
		CmdLineParser.Option input = parser.addStringOption('i', "inputFile");
		CmdLineParser.Option layout = parser.addStringOption('l', "layout");
		CmdLineParser.Option output = parser.addStringOption('o', "outputFile");
		CmdLineParser.Option style = parser.addStringOption('s', "style");
		CmdLineParser.Option gff = parser.addStringOption( 'g', "gffFile" );
		CmdLineParser.Option viewer = parser.addBooleanOption('v', "viewer");
		CmdLineParser.Option zoom = parser.addDoubleOption('z', "zoomAmount");
		CmdLineParser.Option help = parser.addBooleanOption('h', "help");
		CmdLineParser.Option height = parser.addIntegerOption('H', "height");
		CmdLineParser.Option width = parser.addIntegerOption('W', "width");

		// attempts to parse the command line
		try
		{
			parser.parse(args);
		}
		catch (CmdLineParser.OptionException e)
		{
			System.err.println(e.getMessage());
			printUsage();
			System.exit(1);
		}

		Boolean birdsEyeViewValue = (Boolean)parser.getOptionValue(birdsEyeView, Boolean.FALSE);
		Integer centerBaseValue = (Integer)parser.getOptionValue(centerBase);
		String formatValue = (String)parser.getOptionValue(format);
		String inputValue = (String)parser.getOptionValue(input);
		String layoutValue = (String)parser.getOptionValue(layout);
		String outputValue = (String)parser.getOptionValue(output);
		String styleValue = (String)parser.getOptionValue(style);
		String gffValue = (String)parser.getOptionValue( gff );
		Boolean viewerValue = (Boolean)parser.getOptionValue(viewer, Boolean.FALSE);
		Double zoomValue = (Double)parser.getOptionValue(zoom);
		Boolean helpValue = (Boolean)parser.getOptionValue(help, Boolean.FALSE);
		Integer heightValue = (Integer)parser.getOptionValue(height, 800);
		Integer widthValue = (Integer)parser.getOptionValue(width, 600);

		if (helpValue != null && helpValue)
		{
			printUsage();
			System.exit(0);
		}
		else if (inputValue == null)
		{
			printUsage();
			System.err.println("\n[error] Please specify an input file name.");
			System.exit(1);
		}
		else if( !viewerValue && outputValue == null )
		{
			printUsage();
			System.err.println( "\n[error] Please either use the interactive viewer (-v) or specify an output file (-o)" );
			System.exit( 1 );
		}
		else
		{
			if( !viewerValue && formatValue == null )
			{
				System.err.println( "[warning] No output format set, using default of " + DEFAULT_FORMAT );
				formatValue = DEFAULT_FORMAT;
			}

			if( !viewerValue && !outputValue.endsWith( "." + formatValue ) )
			{
				System.err.println( "[warning] Appending output format to end of output filename" );
				outputValue += "." + formatValue;
			}

			createMapStyleData(inputValue, styleValue); // TODO handle files defining style as well

			// handle GFF if a gffValue was specified
			if( gffValue != null )
			{
				injectGFFFeatures( genomeData, gffValue );
			}

			// handle layout
			layoutFactory = createLayoutFactory(layoutValue);

			gviewMap = GViewMapFactory.createMap(genomeData, mapStyle, layoutFactory);

			// handles zoom
			if (zoomValue != null)
			{
				handleZoom(gviewMap, zoomValue.doubleValue());
			}

			// resize map to match width/height
			gviewMap.setViewSize(widthValue, heightValue);

			// handles center base
			if (centerBaseValue != null)
			{
				handleCenterBase(gviewMap, new LocationConverter(genomeData), centerBaseValue);
			}
			else
			{
				gviewMap.centerMap(); // centre at middle of sequence backbone
			}

			// creates viewer/birds eye view
			if ( viewerValue )
			{
				createViewer(gviewMap, birdsEyeViewValue, inputValue);
			}
			else
			{
				handleWriteToFile(gviewMap, formatValue, outputValue);
			}
		}
	}

	private static void injectGFFFeatures( GenomeData genomeData2, String gffValue )
	{
		try
		{
			FeatureList list = null;
			File file = new File( gffValue );
			if( !file.exists() )
			{
				String tempFile = createTempFileFromClassLoaderResource( gffValue );
				if( tempFile != null )
				{
					gffValue = tempFile;
				}
			}

			list = GFF3.read( gffValue );
			for( FeatureI f : list )
			{
				Feature fi = (Feature)f;
				StrandedFeature.Template ft = new StrandedFeature.Template();

				if( fi.location().isNegative() )
				{
					ft.location = new SimpleRichLocation( new SimplePosition( -fi.location().getBegin() ), new SimplePosition( -fi.location().getEnd() ), 0, RichLocation.Strand.NEGATIVE_STRAND );
				}
				else
				{
					ft.location = new SimpleRichLocation( new SimplePosition( fi.location().getBegin() ), new SimplePosition( fi.location().getEnd() ), 0, RichLocation.Strand.POSITIVE_STRAND );

				}

				ft.type = fi.type();
				ft.source = "gff";
				ft.annotation = new SimpleAnnotation();

				String attributes = fi.attributes();
				for( String attribute : attributes.split( ";" ) )
				{
					String[] properties = attribute.split( "=" );
					ft.annotation.setProperty( properties[0], properties[1]) ;
				}


				genomeData2.getSequence().createFeature( ft );
			}
		}
		catch ( FileNotFoundException e )
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch ( BioException e )
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch ( IOException e )
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * This method will attempt to find the given resource by using the classloader.
	 * This will enable resources embedded in the jar file being executed to be located and used.
	 * Best used to load default files
	 * @param resource
	 * @return
	 * @throws IOException
	 */
	private static String createTempFileFromClassLoaderResource( String resource ) throws IOException
	{
		InputStream stream = GViewMain.class.getClassLoader().getResourceAsStream( resource );
		if( stream != null )
		{
			String end = resource.substring( resource.lastIndexOf( "." ) );
			File tempfile = File.createTempFile( "gviewtemp", end );
			tempfile.deleteOnExit();

			InputStreamReader reader = new InputStreamReader( stream );
			FileWriter writer = new FileWriter( tempfile );

			int read = reader.read();
			while( read != -1 )
			{
				writer.write( read );
				read = reader.read();
			}

			reader.close();
			writer.close();
			return tempfile.getAbsolutePath();
		}
		return null;
	}
}
