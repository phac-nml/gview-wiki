package gview.examples;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Examples extends JFrame
{
	private static final long serialVersionUID = -2847230740627420471L;

	public Examples()
	{
		getContentPane().setLayout(new FlowLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton genbankFile = new JButton("Genbank File Example");
		genbankFile.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String command1 = "java -jar /media/disk/gview/gview/build/dist/gview.jar -i /media/disk/gview/gview/build/dist/testfiles/NC_006677.gbk -l circular -v -b";
				String command2 = "java -jar /media/disk/gview/gview/build/dist/gview.jar -i /media/disk/gview/gview/build/dist/testfiles/NC_006677.gbk -l linear -v -b";
				
				if (e.getActionCommand().equals("Genbank File Example"))
				{
					try
					{
						System.out.println(command1);
						System.out.println(command2);
						Runtime.getRuntime().exec(command1);
						Runtime.getRuntime().exec(command2);
					}
					catch (IOException ioe)
					{
						// TODO Auto-generated catch block
						ioe.printStackTrace();
					}
				}
			}
		});
		getContentPane().add(genbankFile);
		
		JButton cgviewFile = new JButton("CGview Input Example");
		cgviewFile.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String command1 = "java -jar /media/disk/gview/gview/build/dist/gview.jar -i /media/disk/gview/gview/build/dist/testfiles/cybercell.xml -l circular -v";
				
				if (e.getActionCommand().equals("CGview Input Example"))
				{
					try
					{
						System.out.println(command1);
						Runtime.getRuntime().exec(command1);
					}
					catch (IOException ioe)
					{
						// TODO Auto-generated catch block
						ioe.printStackTrace();
					}
				}
			}
		});
		getContentPane().add(cgviewFile);
		
		setSize(300,100);
		setVisible(true);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		new Examples();
	}

}
