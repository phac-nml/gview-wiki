package gview.examples;

import java.io.File;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.data.readers.GViewFileData;
import gview.data.readers.GViewFileReader;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.MapStyle;

public class ExampleCGViewFile extends PFrame
{
	private static final long serialVersionUID = 3216300435741784341L;

	public ExampleCGViewFile(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	public static void main(String[] args)
	{
		
		try
		{
			GViewFileData gviewFileData = GViewFileReader.read("testfiles" + File.separator + "cybercell.xml");
			
			GenomeData data = gviewFileData.getGenomeData();
			MapStyle style = gviewFileData.getMapStyle();
			
			LayoutFactory lFactory = new LayoutFactoryCircular();
			
			GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
			gViewMap.setVisible(true); // isn't necessary, defaults to visible
			
			new ExampleCGViewFile("cgviewExample", (PCanvas)gViewMap);
			
		}
		catch (Exception e)
		{
			System.err.println(e);
			e.printStackTrace();
		}
	}
}
