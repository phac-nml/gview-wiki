package gview.examples;

import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.util.NoSuchElementException;

import javax.swing.JDialog;

import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.Location;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.data.Slot;
import gview.data.readers.GViewFileData;
import gview.data.readers.GViewFileReader;
import gview.layout.feature.FeatureShapeRealizer;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.BirdsEyeView;
import gview.map.BirdsEyeViewImp;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.map.effects.HighlightEffect;
import gview.map.effects.ShapeEffectRenderer;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.LabelStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.items.BackboneStyle;
import gview.style.items.RulerStyle;
import gview.style.items.TooltipStyle;
import gview.textextractor.FeatureTextExtractor;
import gview.textextractor.LocationExtractor;

public class ExampleCircularLinear extends PFrame
{
	private static final long serialVersionUID = -8092281851583424179L;

	public ExampleCircularLinear(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	private static MapStyle buildStyle()
	{
		/**Global Style**/
		
		MapStyle mapStyle = new MapStyle();
		
		// extract associated GlobalStyle from newly created MapStyle object
		GlobalStyle global = mapStyle.getGlobalStyle();
		
		// set initial height/width of the map
		global.setDefaultHeight(700);
		global.setDefaultWidth(700);
		
		global.setBackgroundPaint(Color.BLACK);
		
		// extract tooltip style from global style
		TooltipStyle tooltip = global.getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(0,0,1.0f,0.5f));
		tooltip.setTextPaint(Color.WHITE);
		
		// extract style information dealing with the backbone
		BackboneStyle backbone = global.getBackboneStyle();
		backbone.setPaint(Color.GRAY.darker());
		backbone.setThickness(5.0);
		
		// extract information dealing with the ruler style
		RulerStyle ruler = global.getRulerStyle();
		ruler.setMajorTickLength(20.0);
		ruler.setTickThickness(3.0);
		ruler.setMinorTickPaint(Color.LIGHT_GRAY);
		ruler.setMajorTickPaint(Color.DARK_GRAY);
		ruler.setFont(new Font("SansSerif", Font.PLAIN, 12));
		ruler.setTextPaint(Color.WHITE);
		
		/**Slots**/
		
		// assumes mapStyle created as above
		
		// extract data style from map style
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// creates the first two slots
		SlotStyle positiveSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		positiveSlot.setThickness(30);
		positiveSlot.setShapeEffectRenderer(ShapeEffectRenderer.STANDARD_RENDERER);
		SlotStyle negativeSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER);
		negativeSlot.setThickness(30);
		negativeSlot.setShapeEffectRenderer(new HighlightEffect());
		
		/**FeatureHolderStyle**/
		
		FeatureTextExtractor textExtractor = new LocationExtractor();
		
		// creates a feature holder style in the first upper slot containing all the features
		FeatureHolderStyle positive = positiveSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positive.setTransparency(0.7f);
		positive.setToolTipExtractor(textExtractor);
		positive.setPaint(Color.BLUE);
		positive.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW);
		
		// creates a holder containing all negative features in the first lower slot
		FeatureHolderStyle negativeFeatures = negativeSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeFeatures.setTransparency(0.7f);
		negativeFeatures.setToolTipExtractor(textExtractor);
		negativeFeatures.setPaint(Color.RED);
		negativeFeatures.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);
		
		return mapStyle;
	}
	
	private static MapStyle buildStyle2()
	{
		/**Global Style**/
		
		MapStyle mapStyle = new MapStyle();
		
		// extract associated GlobalStyle from newly created MapStyle object
		GlobalStyle global = mapStyle.getGlobalStyle();
		
		// set initial height/width of the map
		global.setDefaultHeight(700);
		global.setDefaultWidth(700);
		
		global.setBackgroundPaint(Color.BLACK);
		
		// extract tooltip style from global style
		TooltipStyle tooltip = global.getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(0,0,1.0f,0.5f));
		tooltip.setTextPaint(Color.WHITE);
		
		// extract style information dealing with the backbone
		BackboneStyle backbone = global.getBackboneStyle();
		backbone.setPaint(Color.GRAY.darker());
		backbone.setThickness(5.0);
		
		// extract information dealing with the ruler style
		RulerStyle ruler = global.getRulerStyle();
		ruler.setMajorTickLength(20.0);
		ruler.setTickThickness(3.0);
		ruler.setMinorTickPaint(Color.LIGHT_GRAY);
		ruler.setMajorTickPaint(Color.DARK_GRAY);
		ruler.setFont(new Font("SansSerif", Font.PLAIN, 12));
		ruler.setTextPaint(Color.WHITE);
		
		/**Slots**/
		
		// assumes mapStyle created as above
		
		// extract data style from map style
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// creates the first two slots
		SlotStyle positiveSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		positiveSlot.setThickness(30);
		positiveSlot.setShapeEffectRenderer(ShapeEffectRenderer.STANDARD_RENDERER);
		SlotStyle negativeSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER);
		negativeSlot.setThickness(30);
		negativeSlot.setShapeEffectRenderer(new HighlightEffect());
		
		/**FeatureHolderStyle**/
		
		FeatureTextExtractor textExtractor = new LocationExtractor();
		
		// creates a feature holder style in the first upper slot containing all the features
		FeatureHolderStyle positive = positiveSlot.createFeatureHolderStyle(new FeatureFilter.And(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE),
				new FeatureFilter.ByType("CDS")));
		positive.setTransparency(0.7f);
		positive.setToolTipExtractor(textExtractor);
		positive.setPaint(Color.BLUE);
		positive.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW2);
		
		LabelStyle posLabels = positive.getLabelStyle();
		posLabels.setLabelExtractor(textExtractor);
		posLabels.setShowLabels(true);
		posLabels.setInitialLineLength(50);
		posLabels.setFont(new Font("SansSerif", Font.PLAIN, 10));
		posLabels.setBackgroundPaint(new Color(0.5f, 0.5f, 0.5f, 0.5f));
		
		// creates a holder containing all negative features in the first lower slot
		FeatureHolderStyle negativeFeatures = negativeSlot.createFeatureHolderStyle(new FeatureFilter.And(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE),
				new FeatureFilter.ByType("CDS")));
		negativeFeatures.setTransparency(0.7f);
		negativeFeatures.setToolTipExtractor(textExtractor);
		negativeFeatures.setPaint(Color.RED);
		negativeFeatures.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW2);
		
		LabelStyle negLabels = negativeFeatures.getLabelStyle();
		negLabels.setLabelExtractor(textExtractor);
		negLabels.setShowLabels(true);
		negLabels.setInitialLineLength(50);
		negLabels.setFont(new Font("SansSerif", Font.PLAIN, 10));
		negLabels.setBackgroundPaint(new Color(0.5f, 0.5f, 0.5f, 0.5f));
		
		return mapStyle;
	}
	
	public static void main(String[] args)
	{
		
		try
		{
			GViewFileData gviewFileData = GViewFileReader.read("testfiles" + File.separator + "NC_006677.gbk");
			
			GenomeData data = gviewFileData.getGenomeData();
			MapStyle style = buildStyle();
			style.getClass();//removes the java warning...
			
			LayoutFactory lFactory = new LayoutFactoryLinear();
			
			GViewMap gViewMapCirc = GViewMapFactory.createMap(data, buildStyle2(), lFactory);
			gViewMapCirc.setVisible(true); // isn't necessary, defaults to visible
			
			new ExampleCircularLinear("layoutExample", (PCanvas)gViewMapCirc);
			
			
			BirdsEyeView bev = new BirdsEyeViewImp();
			bev.connect(gViewMapCirc);
			JDialog bird = new JDialog();
			bird.getContentPane().add((PCanvas)bev);
			bird.pack();
			bird.setSize(150, 150);
			bird.setVisible(true);
			
			
//			lFactory = new LayoutFactoryLinear();
//			GViewMap gViewMapLin = GViewMapFactory.createMap(data, style, lFactory);
//			gViewMapCirc.setVisible(true); // isn't necessary, defaults to visible
//			
//			new ExampleCircularLinear("layoutExample", (PCanvas)gViewMapLin);
			
//			BirdsEyeView bev2 = new BirdsEyeViewImp();
//			bev2.connect(gViewMapLin);
//			JDialog bird2 = new JDialog();
//			bird2.getContentPane().add((PCanvas)bev2);
//			bird2.pack();
//			bird2.setSize(150, 150);
//			bird2.setVisible(true);
			
		}
		catch (Exception e)
		{
			System.err.println(e);
			e.printStackTrace();
		}
	}
}
