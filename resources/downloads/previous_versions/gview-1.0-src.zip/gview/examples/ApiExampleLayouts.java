package gview.examples;

import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.NoSuchElementException;

import javax.swing.JComponent;
import javax.swing.JDialog;

import org.biojava.bio.BioException;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.SequenceIterator;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.Location;
import org.biojavax.bio.seq.RichSequence;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.data.GenomeDataFactory;
import gview.data.Slot;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.BirdsEyeView;
import gview.map.BirdsEyeViewImp;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.items.BackboneStyle;
import gview.style.items.RulerStyle;
import gview.style.items.TooltipStyle;
import gview.textextractor.FeatureTextExtractor;
import gview.textextractor.LocationExtractor;

public class ApiExampleLayouts extends PFrame
{
	private static final long serialVersionUID = 7570576560254233243L;


	// creates a new frame and adds the map (a PCanvas) to it
	public ApiExampleLayouts(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	private static MapStyle buildStyle()
	{
		/**Global Style**/
		
		MapStyle mapStyle = new MapStyle();
		
		// extract associated GlobalStyle from newly created MapStyle object
		GlobalStyle global = mapStyle.getGlobalStyle();
		
		// set initial height/width of the map
		global.setDefaultHeight(700);
		global.setDefaultWidth(700);
		
		global.setBackgroundPaint(Color.BLACK);
		
		// extract tooltip style from global style
		TooltipStyle tooltip = global.getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(0,0,1.0f,0.5f));
		tooltip.setTextPaint(Color.WHITE);
		
		// extract style information dealing with the backbone
		BackboneStyle backbone = global.getBackboneStyle();
		backbone.setPaint(Color.GRAY.darker());
		backbone.setThickness(5.0);
		
		// extract information dealing with the ruler style
		RulerStyle ruler = global.getRulerStyle();
		ruler.setMajorTickLength(20.0);
		ruler.setTickThickness(3.0);
		ruler.setMinorTickPaint(Color.LIGHT_GRAY);
		ruler.setMajorTickPaint(Color.DARK_GRAY);
		ruler.setFont(new Font("SansSerif", Font.PLAIN, 12));
		ruler.setTextPaint(Color.WHITE);
		
		/**Slots**/
		
		// assumes mapStyle created as above
		
		// extract data style from map style
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// creates the first two slots
		SlotStyle positveSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		positveSlot.setThickness(30);
		SlotStyle negativeSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER);
		negativeSlot.setThickness(30);
		
		/**FeatureHolderStyle**/
		
		FeatureTextExtractor textExtractor = new LocationExtractor();
		
		// creates a feature holder style in the first upper slot containing all the features
		FeatureHolderStyle positive = positveSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positive.setTransparency(0.7f);
		positive.setToolTipExtractor(textExtractor);
		positive.setPaint(Color.BLUE);
		
		// creates a holder containing all negative features in the first lower slot
		FeatureHolderStyle negativeFeatures = negativeSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeFeatures.setTransparency(0.7f);
		negativeFeatures.setToolTipExtractor(textExtractor);
		negativeFeatures.setPaint(Color.RED);
		
		return mapStyle;
	}
	
	
	public static void main(String[] args)
	{
		BufferedReader br = null;
		
		try
		{
			//create a buffered reader to read the sequence file
			br = new BufferedReader(new FileReader("testfiles/NC_006677.gbk"));
		}
		catch (FileNotFoundException ex) 
		{
	        //can't find the file
	        ex.printStackTrace();
	        System.exit(-1);
		}

        try
        {
    		//read the GenBank File
    		SequenceIterator sequences = RichSequence.IOTools.readGenbankDNA(br, null);
    	   
        	
    		// only obtain one sequence
    		if (sequences.hasNext())
    		{
	        	// extract the sequence
	        	Sequence seq = sequences.nextSequence();     
		  		
	        	// create data, style, and region managers
		  		GenomeData data = GenomeDataFactory.createGenomeData(seq);
		  		MapStyle style = buildStyle(); // creates style, buildStyle() code not shown
		  		LayoutFactory layoutFactory = new LayoutFactoryLinear();
		  		
		  		GViewMap gViewMap = GViewMapFactory.createMap(data, style, layoutFactory);
		  		gViewMap.setVisible(true); // isn't necessary, defaults to visible
		  		
		  		// cast map as a PCanvas, so we can insert it in a PFrame
		  		new ApiExampleLayouts("ApiExampleLayouts", (PCanvas)gViewMap);
		  		
				// creates the birds eye view component, and connects it to the gViewMap
				BirdsEyeView bev = new BirdsEyeViewImp();
				bev.connect(gViewMap);
		  		
				// displays the birds eye view component in a JDialog
				JDialog bird = new JDialog();
				bird.getContentPane().add((JComponent)bev);
				bird.pack();
				bird.setSize(150, 150);
				bird.setVisible(true);
				
				// circular
				layoutFactory = new LayoutFactoryCircular();
		  		
		  		gViewMap = GViewMapFactory.createMap(data, style, layoutFactory);
		  		gViewMap.setVisible(true); // isn't necessary, defaults to visible
		  		
		  		// cast map as a PCanvas, so we can insert it in a PFrame
		  		new ApiExampleLayouts("ApiExampleLayouts", (PCanvas)gViewMap);
		  		
				// creates the birds eye view component, and connects it to the gViewMap
				BirdsEyeView bev2 = new BirdsEyeViewImp();
				bev2.connect(gViewMap);
		  		
				// displays the birds eye view component in a JDialog
				JDialog bird2 = new JDialog();
				bird2.getContentPane().add((JComponent)bev2);
				bird2.pack();
				bird2.setSize(150, 150);
				bird2.setVisible(true);
    		}
	   
        }
		catch (BioException ex)
		{
			//not in GenBank format
			ex.printStackTrace();
		}
		catch (NoSuchElementException ex)
		{
			//request for more sequence when there isn't any
			ex.printStackTrace();
		}
	}
}
