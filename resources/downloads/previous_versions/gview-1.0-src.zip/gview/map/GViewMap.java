package gview.map;

import gview.data.GenomeData;
import gview.layout.prototype.SequencePoint;
import gview.layout.sequence.LayoutFactory;
import gview.map.event.GViewEventListener;
import gview.map.event.GViewEventSubject;
import gview.map.items.FeatureItem;
import gview.style.MapStyle;

import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.util.Collection;

import org.biojava.bio.seq.Feature;

/**
 * gview.main viewing area, handles display of items
 */
public interface GViewMap extends GViewEventSubject, GViewEventListener
{
	// public void setPositioner(SlotRegion positioner);
	public void setMapStyle(MapStyle style);

	public MapStyle getMapStyle();

	public double getZoomFactorForDistance( double deltaBase, double length );

	public double getBackboneLength();

	public SequencePoint translatePoint(Point2D point);


	/**
	 * Used to display/hide this map.
	 * 
	 * @param visible
	 *            True if it is visible, false if hidden.
	 */
	public void setVisible(boolean visible);

	/**
	 * Sets the center point of this map.
	 * 
	 * @param center
	 *            The point that this map will be centered on.
	 */
	public void setCenter(Point2D center);

	// TODO should I allow translate here? Only used so we can properly translate for zooming now.
	public void translate(Point2D delta); // translates map view by the passed amount

	/**
	 * Given a base on the current map, determines the current coordinates.
	 * @param base  A base on the current map.
	 * @return  The coordinates on the map.
	 */
	public Point2D getBaseCoordinate(int base);

	/**
	 * Sets the centre base of this map.
	 * 
	 * @param base
	 *            The base that this map will be centred on.
	 */
	public void setCenter(int base);

	/**
	 * Sets the zoom factor for this map.
	 * 
	 * @param zoomFactor
	 *            A number from 0.0-MAX_ZOOM. //TODO define those
	 */
	public void setZoomFactor(double zoomFactor);

	/**
	 * Sets the current view size to the passed width/height.
	 * @param width  The width (in pixels) to set the view size to.
	 * @param height  The height (in pixels) to set the view size to.
	 */
	public void setViewSize(int width, int height);

	/**
	 * Gets the width of the current view
	 * @return The width (in pixels) of the current view size
	 */
	public double getViewWidth();

	/**
	 * Gets the height of the current view
	 * @return The height ( in pixels ) of the current view size
	 */
	public double getViewHeight();


	public double getSpannedBases( int length );

	/**
	 * Centres the GView map to the very middle of the sequence.
	 */
	public void centerMap();

	/**
	 * Gets the current view as a BufferedImage.
	 * @return A representation of the current view of this map as a BufferedImage.
	 */
	public BufferedImage getImage();

	/**
	 * Draws out this map onto the passed graphics context.
	 * 
	 * @param g
	 *            The graphics context to draw onto.
	 */
	public void draw(Graphics2D g);

	/**
	 * Sets the layout of this map using the passed factory.
	 * 
	 * @param layoutFactory
	 *            The factory to use create an object to layout the map.
	 */
	public void setLayout(LayoutFactory layoutFactory);

	/**
	 * Updates the passed collection of features to be selected.
	 * 
	 * @param selectedFeatures
	 *            The features that are selected.
	 */
	public void updateSelected(Collection<Feature> selectedFeatures);

	/**
	 * Searches for and returns the FeatureItem on the map representing the passed feature.
	 * (should probably return a list here of all FeatureItem's mapped to the passed feature).
	 * 
	 * @param feature  The feature to search for.
	 * 
	 * @return FeatureItem  The FeatureItem mapped to the passed feature.
	 */
	public FeatureItem getFeatureItem(Feature feature);

	/**
	 * Sets the data to be rendered by this map (causes a re-render). Note: not working properly,
	 * probably just easier to do GViewMapFactory.createMap if needed.
	 * 
	 * @param genomeData
	 *            The data to be rendered.
	 */
	public void setData(GenomeData genomeData);

	/**
	 * Sets the view to view all information on the screen.
	 */
	public void viewAll();

	/**
	 * Builds up all the items on the map. TODO should this be public?
	 */
	// public void buildMap();
	// don't need to declare these here, since they are in GViewEventSubject
	// public void addEventListener(GViewEventListener listener);
	//
	// public void removeEventListener(GViewEventListener listener);
	//
	// public void fireEvent(GViewEvent event);
}
