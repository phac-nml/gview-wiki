package gview.map.items;

import gview.layout.prototype.SequencePoint;
import gview.layout.sequence.Backbone;

public class BackboneTextItemImp extends AbstractBackboneTextItem
{
	private static final long serialVersionUID = -3812388795311013307L;

	public BackboneTextItemImp(Backbone backbone, SequencePoint pinnedPoint)
	{
		super(backbone, pinnedPoint);
	}
}
