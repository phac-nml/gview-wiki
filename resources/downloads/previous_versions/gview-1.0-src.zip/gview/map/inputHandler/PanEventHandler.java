package gview.map.inputHandler;

import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.event.PInputEvent;
import edu.umd.cs.piccolo.event.PPanEventHandler;
import gview.map.event.DisplayUpdated;
import gview.map.event.GViewEventListener;
import gview.map.event.GViewEventSubject;
import gview.map.event.GViewEventSubjectImp;

/**
 * Handles pan events on the GView map.
 * @author aaron
 *
 */
public class PanEventHandler extends PPanEventHandler implements
		GViewEventSubject
{
	private GViewEventSubjectImp eventSubject;
	
	/**
	 * Creates a new PanEventHandler.
	 */
	public PanEventHandler()
	{
		setAutopan(false);
		
		eventSubject = new GViewEventSubjectImp();
	}
	
	@Override
	protected void pan(PInputEvent e)
	{
		PCamera camera = e.getCamera();
		
		// fire display updated event
		eventSubject.fireEvent(new DisplayUpdated(this, camera.getViewBounds()));
		
		super.pan(e);
	}
	
	public void addEventListener(GViewEventListener listener)
	{
		eventSubject.addEventListener(listener);
	}

	public void removeAllEventListeners()
	{
		eventSubject.removeAllEventListeners();
	}

	public void removeEventListener(GViewEventListener listener)
	{
		eventSubject.removeEventListener(listener);
	}
}
