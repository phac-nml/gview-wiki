package gview.map.inputHandler;

import gview.map.GViewMap;
import gview.writers.ImageWriter;
import gview.writers.ImageWriterFactory;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * A class used to export the current view of the map to an image.
 * @author aaron
 *
 */
public class ExportImage
{
	private JFileChooser saveDialog;
	
	private JTextField filenameField;
	private JButton browseButton;
	private String browseActionCommand = "browse";
	
	private JPanel filenamePanel;
	private JPanel savePanel;
	
	private String activeDirectory = "Choose file...";
	private File currentSelectedFile = null;
	
	public ExportImage()
	{
		buildComponents();
	}
	
	private Container createExportPropertiesComponent()
	{
		Container exportProperties = new Container();
		
		
		
		return exportProperties;
	}
	
	/**
	 * Performs the export to an image file.  Displays the export dialog allowing the user to save to a file.
	 */
//	private void performExport()
//	{
//		int chooserState;
//		boolean continueToShow = true;
//		
//		int width;
//		int height;
//
//		while (continueToShow)
//		{
//			continueToShow = false;
//
//			chooserState = this.exportDialog.showDialog();
//
//			if (chooserState == JFileChooser.APPROVE_OPTION)
//			{
//				File saveFile = this.exportDialog.getSelectedFile();
//				width = exportDialog.getImageWidth();
//				height = exportDialog.getImageHeight();
//
//				// if file to save to already exists
//				if (saveFile.exists())
//				{
//					int choice = JOptionPane.showConfirmDialog(null,
//							"File " + saveFile.getName() + " already exists.  Are you sure you wish to overwrite it?",
//							"File already exists", JOptionPane.YES_NO_OPTION);
//
//					if (choice == JOptionPane.YES_OPTION)
//					{
//						continueToShow = false;
//						doSave(saveFile, width, height);
//					}
//					else
//					{
//						continueToShow = true;
//					}
//				}
//				else
//				{
//					doSave(saveFile, width, height);
//				}
//			}
//		}
//	}
	
	public void exportView(GViewMap gviewMap)
	{
		int width;
		int height;
		
		createExport();
	}
	
	/**
	 * Performs the actual saving to an image file.
	 * @param saveFile  The File to save the current view to.
	 */
//	private void doSave(File saveFile, int width, int height)
//	{
//		ImageWriter writer;
//		try
//		{
//			gviewMap.setViewSize(width, height);
//			
//			if (ImageWriterFactory.acceptsFile(saveFile))
//			{
//				writer = ImageWriterFactory.createImageWriter(saveFile);
//				writer.writeToImage(this.gviewMap, saveFile);
//			}
//			else
//			{
//				System.out.println("Unsupported file type " + ImageWriterFactory.extractExtension(saveFile.getName()));
//				System.out.print("Extension should be one of ");
//
//				String[] acceptedExtensions = ImageWriterFactory.getAcceptedExtensions();
//
//				for (int i = 0; i < acceptedExtensions.length; i++)
//				{
//					System.out.print(acceptedExtensions[i] + ",");
//				}
//				System.out.println("\nDefaulting to png format");
//
//				writer = ImageWriterFactory.createImageWriter("png");
//				writer.writeToImage(this.gviewMap, saveFile.getAbsolutePath() + ".png");
//			}
//		}
//		catch (IOException e)
//		{
//			e.printStackTrace();
//		}
//	}
	
	private void buildComponents()
	{
		filenamePanel = new JPanel();
		
		saveDialog = new JFileChooser();
		
		browseButton = createBrowseButton();
		activeDirectory = System.getProperty("user.dir");
		filenameField = new JTextField(20);
		filenameField.setText(activeDirectory);
		
		filenamePanel.add(filenameField);
		filenamePanel.add(browseButton);
		
		savePanel = new JPanel();
	}
	
	private JFrame createExport()
	{
		JFrame mainFrame = new JFrame();
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		mainFrame.getContentPane().add(filenamePanel);
		
		mainFrame.pack();
		mainFrame.setVisible(true);
		
		return mainFrame;
	}
	
	private JButton createBrowseButton()
	{
		JButton button = new JButton("Browse...");
		
		button.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				if (browseActionCommand.equals(e.getActionCommand()))
				{
					int chooserState = saveDialog.showDialog(null, "Export to");
					
					if (chooserState == JFileChooser.APPROVE_OPTION)
					{
						currentSelectedFile = saveDialog.getSelectedFile();
						filenameField.setText(currentSelectedFile.getAbsolutePath());
					}
				}
			}
		});
		button.setActionCommand(browseActionCommand);
		
		return button;
	}
	
	public static void main(String[] args)
	{
		ExportImage export = new ExportImage();
		export.exportView(null);
	}
}
