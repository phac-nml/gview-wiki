package gview.map.effects;

import gview.map.items.MapItemState;

import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.util.LinkedList;
import java.util.List;

public class CompositeEffect implements ShapeEffectRenderer
{
	private List<ShapeEffectRenderer> effects = new LinkedList<ShapeEffectRenderer>();

	public void addEffect(ShapeEffectRenderer effect)
	{
		if (effect != null)
		{
			effects.add(effect);
		}
	}
	
	@Override
	public void paint(Shape shape, Graphics2D g, Paint paint, MapItemState state)
	{
		for (ShapeEffectRenderer effectRenderer : effects)
		{
			effectRenderer.paint(shape, g, paint, state);
		}
	}

	@Override
	public boolean paintChanged(MapItemState previousState,
			MapItemState nextState)
	{
		boolean changed = false;
		
		for (ShapeEffectRenderer effectRenderer : effects)
		{
			changed |= effectRenderer.paintChanged(previousState, nextState);
		}
		
		return changed;
	}
}
