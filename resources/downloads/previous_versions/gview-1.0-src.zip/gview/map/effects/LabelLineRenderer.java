package gview.map.effects;

import gview.map.items.MapItemState;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;

public class LabelLineRenderer implements ShapeEffectRenderer
{
	private Stroke stroke = new BasicStroke();

	public void paint(Shape shape, Graphics2D g, Paint paint, MapItemState state)
	{
		Shape line = stroke.createStrokedShape(shape);
		
		g.setPaint(paint);
		g.fill(line);
	}

	public boolean paintChanged(MapItemState previousState,
			MapItemState nextState)
	{
		// TODO Auto-generated method stub
		return false;
	}
}
