package gview.map.effects;

import gview.map.items.MapItemState;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;

public class StandardEffectSelect implements ShapeEffectRenderer
{
	public void paint(Shape shape, Graphics2D g, Paint paint, MapItemState state)
	{
		if (state.isSelected())
		{
			g.setPaint(paint);
			g.fill(shape);
			
			g.setPaint(Color.YELLOW);
			g.draw(shape);
		}
		else
		{
			g.setPaint(paint);
			g.fill(shape);
		}
	}

	public boolean paintChanged(MapItemState previousState,
			MapItemState nextState)
	{
		return (previousState.isSelected() && !nextState.isSelected()) || (!previousState.isSelected() && nextState.isSelected());
	}
}
