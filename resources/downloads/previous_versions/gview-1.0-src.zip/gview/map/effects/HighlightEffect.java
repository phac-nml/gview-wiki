package gview.map.effects;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;

public class HighlightEffect extends AbstractAllEffectRenderer
{
	private final static Paint HIGHLIGHT_PAINT = new Color(1.0f,1.0f,1.0f,0.5f);
	
	protected void paintNormal(Shape shape, Graphics2D g, Paint paint)
	{
		g.setPaint(paint);
		g.fill(shape);
		
		g.setPaint(HIGHLIGHT_PAINT);
		g.draw(shape);
	}

	protected void paintSelected(Shape shape, Graphics2D g, Paint paint)
	{
		g.setPaint(Color.YELLOW);
		g.fill(shape);
		
		g.setPaint(HIGHLIGHT_PAINT);
		g.draw(shape);
	}
	
	protected void paintMouseOver(Shape shape, Graphics2D g, Paint paint)
	{
		g.setPaint(Color.GREEN);
		g.fill(shape);
		
		g.setPaint(HIGHLIGHT_PAINT);
		g.draw(shape);
	}
	
	protected void paintMouseOverSelected(Shape shape, Graphics2D g, Paint paint)
	{
		g.setPaint(Color.GREEN);
		g.fill(shape);
		
		g.setPaint(HIGHLIGHT_PAINT);
		g.draw(shape);
	}
}
