package gview.map.event;

import java.awt.geom.Rectangle2D;

public class DisplayUpdated extends GViewEvent
{
	private static final long serialVersionUID = 1107720499369373959L;
	private Rectangle2D display;
	
	public DisplayUpdated(Object source, Rectangle2D display)
	{
		super(source);
		this.display = display;
	}
	
	public Rectangle2D getDisplay()
	{
		return display;
	}
}
