package gview.utils;

/**
 */
public class Util
{
	// used soley to compare two doubles properly (taking into account rounding errors).
	public static boolean isEqual(double d1, double d2)
	{
		return Math.abs(d1 - d2) < 0.000000001;
	}
	
	public static boolean isEqual(float f1, float f2)
	{
		return isEqual((double)f1, (double)f2); // is this proper?
	}
	
	/**
	 * Extracts the extension from the file name.
	 * @param filename  The name of the file to extract the extension from.
	 * @return  The extracted extension, or null if no extension.
	 */
	public static String extractExtension(String filename)
	{
		String extension = null;
		
		if (filename != null)
		{
			int periodIndex = filename.lastIndexOf('.');
			
			// if period is found, and it is not the last character
			if ((periodIndex != -1) && (periodIndex + 1) < filename.length())
			{
				extension = filename.substring(periodIndex + 1);
			}
		}
		
		return extension;
	}
}
