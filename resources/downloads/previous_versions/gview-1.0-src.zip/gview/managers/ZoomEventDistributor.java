package gview.managers;

import gview.map.event.BackboneZoomEvent;
import gview.map.event.GViewEvent;
import gview.map.event.GViewEventListener;
import gview.map.event.GViewEventSubject;
import gview.map.event.GViewEventSubjectImp;
import gview.map.event.ResolutionSwitchEvent;

/**
 * This class receives zoom events from the backbone, determines if they would result in a context switch or not
 * 	and distributes the appropriate events to any listeners.
 * @author Aaron Petkau
 *
 */
public class ZoomEventDistributor implements GViewEventSubject, GViewEventListener
{
	private GViewEventSubjectImp eventSubject;
	private ResolutionManager resolutionManager;
	
	public ZoomEventDistributor(ResolutionManager resolutionManager)
	{
		eventSubject = new GViewEventSubjectImp();
		this.resolutionManager = resolutionManager;
	}

	public void addEventListener(GViewEventListener listener)
	{
		eventSubject.addEventListener(listener);
	}

	public void removeAllEventListeners()
	{
		eventSubject.removeAllEventListeners();
	}

	public void removeEventListener(GViewEventListener listener)
	{
		eventSubject.removeEventListener(listener);
	}
	
	public void eventOccured(GViewEvent event)
	{
		if (event instanceof BackboneZoomEvent)
		{
			BackboneZoomEvent zoomEvent = (BackboneZoomEvent)event;
			
			if (resolutionManager.isNewResolutionLevel(zoomEvent.getBackbone().getScale()))
			{
				resolutionManager.performSwitch(zoomEvent.getBackbone().getScale());
				ResolutionManager.Direction direction = resolutionManager.direction();
				eventSubject.fireEvent(new ResolutionSwitchEvent(zoomEvent.getBackbone(), direction, resolutionManager.getCurrentResolutionLevel()));
			}
			
			eventSubject.fireEvent(event);
		}
	}
}
