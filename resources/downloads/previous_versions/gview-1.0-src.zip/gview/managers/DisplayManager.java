package gview.managers;

import gview.data.GenomeData;
import gview.layout.sequence.Backbone;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.LocationConverter;
import gview.managers.labels.LabelsManager;
import gview.managers.labels.LabelsManagerSingle;
import gview.managers.labels.LabelsManagerSlots;
import gview.managers.ruler.RulerManager;
import gview.map.event.DisplayChangeListener;
import gview.map.event.DisplayUpdated;
import gview.map.event.GViewEvent;
import gview.map.event.GViewEventListener;
import gview.map.inputHandler.ToolTipHandler;
import gview.map.inputHandler.ZoomSubject;
import gview.map.items.FeatureItem;
import gview.map.items.MapComponent;
import gview.style.MapStyle;

import java.util.List;

import org.biojava.bio.seq.Feature;

public class DisplayManager implements GViewEventListener
{
	private FeaturesManager featuresManager;
	private RulerManager rulerManager;
	private LabelsManager labelsManager;
	private PlotsManager plotsManager;
	
	private SectionManager sectionManager;
	
	private GenomeData genomeData;
	private MapStyle mapStyle;
	private LayoutFactory layoutFactory;
	
	private LayoutManager layoutManager; // should I have this here?  But I need to somehow make featuresManager listener
	//	for BackboneZoomEvents
	
	private LocationConverter locationConverter;
	
	// place tooltip handler here since it depends on tool tip style, which is stored here
	private ToolTipHandler toolTipHandler;
	private ZoomSubject zoomSubject;
	private DisplayChangeListener displayChangeListener;
	
	/**
	 * Creates a new manager which handles the display/layout of items on the map.
	 * @param genomeData  The genome data to render.
	 * @param mapStyle  The style to render the data as.
	 * @param layoutFactory  A factory defining how to construct the layout.
	 * @param zoomSubject  Used to listen into zoom events on map.
	 */
	public DisplayManager(GenomeData genomeData, MapStyle mapStyle, LayoutFactory layoutFactory, ZoomSubject zoomSubject, DisplayChangeListener displayChangeListener, ToolTipHandler toolTipHandler)
	{
		this.zoomSubject = zoomSubject;
		this.displayChangeListener = displayChangeListener;
		this.toolTipHandler = toolTipHandler;
		
		rebuild(mapStyle, layoutFactory, genomeData);
		
		// build features here?  We need to make sure featuresManager got the event of SlotRegionChangedEvent from layoutManager (to get Backbone).
//		featuresManager.buildFeatures();
		
//		styleEventManager = new StyleEventManager();
//		this.mapStyle.addEventListener(styleEventManager);
		
		// this line right here should trigger actual building of items, by passing BackboneChangeEvent to any listeners
		//  need to make sure style/data setup in the respective managers ahead of time
//		layoutManager.createLayout(layoutFactory, mapStyle, zoomSubject);

	}
	
	/**
	 * Changes the genome data to be displayed.  Causes a re-render of everything.
	 * @param genomeData  The new genome data to be displayed.
	 */
	public void setData(GenomeData genomeData)
	{
		if (genomeData == null)
		{
			throw new NullPointerException("genomeData is null");
		}
		else
		{	
			rebuild(mapStyle, layoutFactory, genomeData);
		}
	}
	
	private void rebuild(MapStyle mapStyle, LayoutFactory layoutFactory, GenomeData genomeData)
	{
		this.genomeData = genomeData;
		this.mapStyle = mapStyle;
		this.layoutFactory = layoutFactory;
		
		locationConverter = new LocationConverter(genomeData);
		
		System.out.print("Creating layout...");
		layoutManager = new LayoutManager(locationConverter, layoutFactory, mapStyle, zoomSubject); // need to create first, since building of actual items requires this to be created
		System.out.println("done");
		
		createManagers(genomeData, mapStyle, layoutManager, displayChangeListener);
	}
	
	private void createManagers(GenomeData data, MapStyle mapStyle, LayoutManager layoutManager, DisplayChangeListener displayChangeListener)
	{
		labelsManager = layoutFactory.createLabelsManager();
		
		featuresManager = new FeaturesManager(data, mapStyle, labelsManager); // need to pass labelsManager here
		rulerManager = new RulerManager(mapStyle.getGlobalStyle().getRulerStyle(), locationConverter);
		sectionManager = new SectionManager(locationConverter.getSequenceLength());
		
		plotsManager = new PlotsManager(mapStyle.getDataStyle(), genomeData);
		
		layoutManager.addEventListener(featuresManager);
		layoutManager.addEventListener(rulerManager);
		layoutManager.addEventListener(labelsManager);
		layoutManager.addEventListener(plotsManager);//
		
		sectionManager.addEventListener(rulerManager);
		
		// remove later, when event listeners are all tied together
		layoutManager.addEventListener(sectionManager);
		//sectionManager.eventOccured(new ResolutionSwitchEvent(layoutManager.getBackbone(), ResolutionSwitchEvent.Direction.INCREASE));
		
		// need access to PanEventHandler hear to make sectionManager listen for events from it
		
		displayChangeListener.addEventListener(sectionManager);
		sectionManager.eventOccured(new DisplayUpdated(this, null));
	}
	
	public MapComponent getFeaturesLayer()
	{
		return featuresManager.getFeaturesLayer();
	}
	
	/**
	 * Searches for the FeatureItems associated with the passed feature.
	 * @param feature  The feature to search for it's associated FeatureItem.
	 * @return  The FeatureItems in a List if found, or null if not found.
	 */
	public List<FeatureItem> findFeatureItems(Feature feature)
	{
		return featuresManager.findFeatureItems(feature);
	}
	
	public MapComponent getRulerLayer()
	{
		return rulerManager.getRulerLayer();
	}
	
	public MapComponent getLabelsLayer()
	{
		return labelsManager.getLabelsLayer();
	}
	
	public MapComponent getToolTipItem()
	{
		return toolTipHandler.getToolTipItem();
	}
	
	public MapComponent getPlotsLayer()
	{
		return plotsManager.getPlotsLayer();
	}
	
	public void changeLayout(LayoutFactory layoutFactory, ZoomSubject zoomSubject)
	{
		this.layoutFactory = layoutFactory;
		layoutManager.createLayout(layoutFactory, mapStyle, zoomSubject);
	}
	
	public MapStyle getMapStyle()
	{
		return mapStyle;
	}
	
	/**
	 * Sets the MapStyle for this map and rebuilds.
	 * 
	 * @param mapStyle  The map style to set.
	 */
	public void setMapStyle(MapStyle mapStyle)
	{
		if (mapStyle == null)
		{
			throw new NullPointerException("mapStyle is null");
		}
		else
		{
			rebuild(mapStyle, layoutFactory, genomeData);
		}
	}
	
	/**
	 * @return  The backbone object.
	 */
	public Backbone getBackbone()
	{
		return layoutManager.getBackbone();
	}

	// TODO this was only placed so we can send events by keyboard to re-calculate zoom
	// there must be a better way
	public void eventOccured(GViewEvent event)
	{
		labelsManager.eventOccured(event);
	}
}
