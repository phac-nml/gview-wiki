package gview.managers;

import gview.data.GenomeData;
import gview.layout.Direction;
import gview.layout.PlotBuilder;
import gview.layout.sequence.SlotPath;
import gview.layout.sequence.SlotRegion;
import gview.map.event.BackboneZoomEvent;
import gview.map.event.GViewEvent;
import gview.map.event.GViewEventListener;
import gview.map.event.LayoutChangedEvent;
import gview.map.items.BasicItem;
import gview.map.items.Layer;
import gview.map.items.MapComponent;
import gview.map.items.MapItem;
import gview.map.items.PlotItem;
import gview.map.items.ShapeItem;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.PlotStyle;
import gview.style.datastyle.SlotItemStyle;
import gview.style.datastyle.SlotStyle;

import java.awt.BasicStroke;
import java.awt.Shape;
import java.util.Iterator;

import org.biojava.bio.symbol.RangeLocation;

public class PlotsManager implements GViewEventListener
{
	private MapComponent plotsLayer;

	private DataStyle dataStyle;
	private GenomeData genomeData;

	public PlotsManager(DataStyle dataStyle, GenomeData genomeData)
	{
		this.plotsLayer = new Layer();

		this.dataStyle = dataStyle;
		this.genomeData = genomeData;
	}

	public MapComponent getPlotsLayer()
	{
		return this.plotsLayer;
	}

	private void buildPlots(MapComponent layer, SlotRegion slotRegion)
	{
		Iterator<SlotStyle> slots = this.dataStyle.slots();
		while (slots.hasNext())
		{
			SlotStyle currentSlot = slots.next();

			MapComponent slot = createSlot(currentSlot, slotRegion);

			if (slot != null)
			{
				this.plotsLayer.add(slot);
			}
		}
	}

	private MapComponent createSlot(SlotStyle currentSlot, SlotRegion slotRegion)
	{
		MapComponent layer = null;

		Iterator<SlotItemStyle> items = currentSlot.styles();

		while (items.hasNext())
		{
			SlotItemStyle currItemStyle = items.next();

			if (currItemStyle.getClass().equals(PlotStyle.class))
			{
				PlotStyle currPlot = (PlotStyle) currItemStyle;

				if (layer == null)
				{
					layer = new Layer();
				}

				if (currPlot.getPlotBuilder() != null)
				{
					PlotBuilder plotBuilder = currPlot.getPlotBuilder();
					SlotPath slotPath = slotRegion.getSlotPath(currentSlot.getSlot());

					Shape[][] shapeGroups = plotBuilder.createPlot(this.genomeData, slotPath, currPlot.getPlotDrawer());
					boolean grid = false;
					for( int i = 0; i < shapeGroups.length; i++ )
					{
						Shape[] shapes = shapeGroups[i];
						for( Shape s : shapes )
						{
							PlotItem plot = new PlotItem(currPlot, new RangeLocation(0, this.genomeData.getSequenceLength()));
							plot.setPaint( currPlot.getPaint()[i] );
							plot.setShape(s);

							// if there are grid lines to display
							if( !grid )
							{
								if ( currPlot.getGridLines() > 0 && currPlot.getGridPaint() != null )
								{
									BasicItem gridItem = new BasicItem();
									gridItem.setShape(buildGrid(slotRegion, currentSlot.getSlot(), this.genomeData.getSequenceLength(),
											currPlot.getGridLineThickness(), currPlot.getGridLines()));
									gridItem.setPaint(currPlot.getGridPaint());

									layer.add(gridItem);
									grid = true;
								}
							}

							layer.add(plot);
						}
					}
				}
			}
		}

		return layer;
	}

	/**
	 * Builds a grid for the plot
	 * @param slotRegion
	 * @param slot  The slot the grid should go in.
	 * @param backboneParallelLines  The number of lines parallel to the backbone
	 * 
	 * @return
	 */
	private Shape buildGrid(SlotRegion slotRegion, int slot, int sequenceLength, float thickness, int backboneParallelLines)
	{
		SlotPath slotPath = slotRegion.getSlotPath(slot);

		if  (backboneParallelLines == 1) // if one line, draw only center line
		{
			slotPath.moveTo(0, 0);
			slotPath.lineTo(sequenceLength, Direction.INCREASING);
		}
		else // draw top, bottom, divide rest of lines among internal
		{
			float regionThickness = 2.0f;

			// draw top
			slotPath.moveTo(0, 1.0f);
			slotPath.lineTo(sequenceLength, Direction.INCREASING);

			// draw bottom
			slotPath.moveTo(0, -1.0f);
			slotPath.lineTo(sequenceLength, Direction.INCREASING);

			if (backboneParallelLines > 2)
			{
				// divide into a number of regions equal to number of lines -1
				float gridLineSpacing = regionThickness/(backboneParallelLines-1);

				// draw other lines
				for (float currLineHeight = -1.0f + gridLineSpacing; currLineHeight < 1.0f; currLineHeight += gridLineSpacing)
				{
					slotPath.moveTo(0, currLineHeight);
					slotPath.lineTo(sequenceLength, Direction.INCREASING);
				}
			}
		}

		return slotPath.createStrokedShape(new BasicStroke(thickness));
	}

	@Override
	public void eventOccured(GViewEvent event)
	{
		if (event instanceof BackboneZoomEvent)
		{
			// zoom all features in layer, don't add each feature as a listener to Backbone
			Iterator<MapItem> items = this.plotsLayer.itemsIterator();

			while (items.hasNext())
			{
				MapItem currItem = items.next();

				if (currItem instanceof ShapeItem)
				{
					ShapeItem shapeItem = (ShapeItem) currItem;

					shapeItem.eventOccured(event);
				}
			}
		}
		else if (event instanceof LayoutChangedEvent)
		{
			SlotRegion slotRegion = ((LayoutChangedEvent) event).getSlotRegion();

			// reconstruct features
			this.plotsLayer.clear();
			buildPlots(this.plotsLayer, slotRegion);
			slotRegion.addEventListener(this); // make sure we listen for events from new backbone
		}
	}
}
