package gview.layout.sequence;

import gview.layout.Direction;
import gview.layout.prototype.BackboneShape;

import java.awt.Shape;
import java.awt.Stroke;

/**
 * Builds a general path by transforming the sequence-specific coords,
 *   to coords on the screen in an appropriate slot.
 */
public interface SlotPath extends Cloneable
{
	// TODO add in other lineTo/moveTo methods.  Determine if I should even have these.

	/**
	 * Adds a point at the passed location.
	 * 
	 * @param base  The base on the sequence.
	 * @param heightInSlot  The height in the slot (0 = center) (-1 to 1)
	 * 
	 * TODO define which parameters I need better
	 */
	public void moveTo(double base, double heightInSlot);

	public Backbone getBackbone();

	/**
	 * Move to the location defined by (base, heightInSlot) + offset = (lengthFromBase, height)
	 * @param base  The base pair value to move to.
	 * @param heightInSlot  The height in the slot to move to.
	 * @param lengthFromBase  The length from the base pair (in sequence coordinates) to move to.
	 */
	public void moveTo(double base, double heightInSlot, double lengthFromBase);

	/**
	 * Draws a line from the current coordinates to the new coordinates.  The line will be straight in
	 * 	sequence coordinates, but may be curved in actual coordinates.
	 * 
	 * @param base  The base on the sequence.
	 * @param heightInSlot  The height in the slot (0 = center) (-1 to 1)
	 * @param direction  The direction to draw the line along the sequence.
	 * 
	 * TODO define which parameters I need better
	 * There is also a problem with this method, since sometimes we want "curves", other times we want
	 *  actual lines.
	 */
	public void lineTo(double base, double heightInSlot, Direction direction);

	/**
	 * Defines a true line to the point defined by (base,heightInSlot) + an offset (in terms of lengthFromBase, height).
	 * @param base  The base pair value to draw to.
	 * @param heightInSlot  The height in the slot to draw to.
	 * @param lengthFromBase  The length from the base pair (in sequence coordinates) to draw to.
	 */
	public void realLineTo(double base, double heightInSlot, double lengthFromBase);

	/**
	 * Defines a line (in terms of sequence coordinates) to the point defined by (base,heightInSlot) + an offset (in terms of lengthFromBase, height).
	 * @param base  The base pair value to draw to.
	 * @param heightInSlot  The height in the slot to draw to.
	 * @param lengthFromBase  The length from the base pair (in sequence coordinates) to draw to.
	 * @param direction  The direction to draw the line along the sequence.
	 */
	public void lineTo(double base, double heightInSlot, double lengthFromBase, Direction direction);

	/**
	 * Draws a line from the current coordinates to the new coordinates using the previous heightInSlot
	 * 	(or 0 if no previous heightInSlot).
	 * 
	 * @param base  The base on the sequence.
	 * @param direction  The direction to draw the line along the sequence.
	 * 
	 * TODO define which parameters I need better
	 * There is also a problem with this method, since sometimes we want "curves", other times we want
	 *  actual lines.
	 */
	public void lineTo(double base, Direction direction);

	/**
	 * Closes the path, draws line back to coords of last moveTo.
	 */
	public void closePath();

	/**
	 * @return  The shape described by this SlotPath.
	 */
	public BackboneShape getShape();

	/**
	 * Clears SlotPath
	 */
	public void clear();

	/**
	 * Creates a shape by stroking the path defined with the passed stroke.
	 * 
	 * @param stroke  The stroke defining how to create the shape.
	 * 
	 * @return  A shape stroked by the passed parameter.
	 */
	public Shape createStrokedShape(Stroke stroke);

	//	/**
	//	 * Creates an arc which fills the whole slot.  Used for drawing backbone.  Maybe change this later?
	//	 * @param slot  The slot to create the full arc in.
	//	 *
	//	 * @return  A shape which fills  this whole slot.
	//	 */
	//public Shape createFullArc(int slot);
}
