package gview.layout.sequence.linear;

import gview.layout.sequence.AbstractSlotRegion;
import gview.layout.sequence.Backbone;
import gview.layout.sequence.SequencePath;
import gview.layout.sequence.SlotTranslator;
import gview.managers.ResolutionManager;

public class SlotRegionLinear extends AbstractSlotRegion
{
	public SlotRegionLinear(Backbone backbone, SlotTranslator slots)
	{
		super(backbone, slots);
		
		sequencePath = new SequencePathLinear(backbone);
	}
	
	public SequencePath getSequencePath()
	{
		return new SequencePathLinear(backbone);
	}
}
