package gview.layout.sequence.linear;

import gview.layout.sequence.Backbone;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.LocationConverter;
import gview.layout.sequence.SlotRegion;
import gview.layout.sequence.SlotTranslator;
import gview.layout.sequence.SlotTranslatorImp;
import gview.managers.labels.LabelsManager;
import gview.managers.labels.LabelsManagerSlots;
import gview.style.MapStyle;

public class LayoutFactoryLinear extends LayoutFactory
{

	@Override
	public SlotRegion createSlotRegion(MapStyle mapStyle, LocationConverter locationConverter, double initialBackboneLength)
	{
		if (initialBackboneLength <= 0)
		{
			throw new IllegalArgumentException("initialBackboneLength must be positive");
		}
		
		SlotTranslator slots = new SlotTranslatorImp(mapStyle);
		
		Backbone backbone = new BackboneLinear(locationConverter, initialBackboneLength);
		
		return new SlotRegionLinear(backbone, slots);
	}

	@Override
	public LabelsManager createLabelsManager()
	{
		return new LabelsManagerSlots();
	}
}
