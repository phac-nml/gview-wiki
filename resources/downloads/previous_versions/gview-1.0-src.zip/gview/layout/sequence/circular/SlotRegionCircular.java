package gview.layout.sequence.circular;

import gview.layout.sequence.AbstractSlotRegion;
import gview.layout.sequence.Backbone;
import gview.layout.sequence.SequencePath;
import gview.layout.sequence.SlotTranslator;
import gview.managers.ResolutionManager;

public class SlotRegionCircular extends AbstractSlotRegion
{		
	public SlotRegionCircular(Backbone backbone, SlotTranslator slots)
	{
		super(backbone, slots);
		
		sequencePath = new SequencePathCircular(backbone);
	}
	
	public SequencePath getSequencePath()
	{
		return new SequencePathCircular(backbone);
	}
}
