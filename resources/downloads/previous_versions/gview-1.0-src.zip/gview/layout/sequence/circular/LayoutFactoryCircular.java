package gview.layout.sequence.circular;

import gview.layout.sequence.Backbone;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.LocationConverter;
import gview.layout.sequence.SlotRegion;
import gview.layout.sequence.SlotTranslator;
import gview.layout.sequence.SlotTranslatorImp;
import gview.managers.labels.LabelsManager;
import gview.managers.labels.LabelsManagerSingle;
import gview.style.MapStyle;

public class LayoutFactoryCircular extends LayoutFactory
{

	@Override
	public SlotRegion createSlotRegion(MapStyle mapStyle, LocationConverter locationConverter, double initialBackboneLength)
	{
		if (initialBackboneLength <= 0)
		{
			throw new IllegalArgumentException("initialBackboneLength must be positive");
		}
		
		SlotTranslator slotTranslator = new SlotTranslatorImp(mapStyle);
		
		double initialRadius = initialBackboneLength/(2*Math.PI);
		
		Backbone backbone = new BackboneCircular(locationConverter, initialRadius, slotTranslator.getBottomMostHeight());

		return new SlotRegionCircular(backbone, slotTranslator);
	}

	@Override
	public LabelsManager createLabelsManager()
	{
		return new LabelsManagerSingle();
	}
}
