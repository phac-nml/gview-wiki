package gview.layout.prototype.segments;

import gview.layout.sequence.Backbone;

import java.awt.geom.Path2D;

public class CloseSegment extends StretchableSegment
{
	/**
	 * Creates a new CloseSegment type.
	 */
	public CloseSegment()
	{
		
	}

	@Override
	protected void performAppend(Path2D path, Backbone backbone)
	{
		path.closePath();
	}
}
