package gview.layout;

import gview.data.GenomeData;
import gview.layout.sequence.SlotPath;

import java.awt.Shape;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.biojava.bio.symbol.RangeLocation;

public class PlotBuilderRange extends PlotBuilder
{
	SortedMap<RangeLocation, Double> ranges;

	private final static int NO_BASE = -1;

	private static final double bottomHeight = -1;
	private static final double topHeight = 1;
	private static double centerHeight;

	private static final int	MIN	= 0;
	private static final int	MAX	= 1;

	public PlotBuilderRange()
	{
		this.ranges = new TreeMap<RangeLocation, Double>(new RangeLocationComparator());
		this.centerHeight = 0;
		this.minValue = -1;
		this.maxValue = 1;
	}

	public void setCenterHeight( double height )
	{
		this.centerHeight = height;
	}

	/**
	 * Adds a range to this plot.
	 * @param startBase
	 * @param endBase
	 * @param height
	 */
	public void addRange(int startBase, int endBase, double height)
	{
		this.ranges.put(new RangeLocation(startBase, endBase), height);
	}

	/**
	 * Automatically sets scaling of points so that max point is at top of slot, min is at bottom of slot.
	 */
	@Override
	public void autoScale()
	{
		double minValue = Double.MAX_VALUE;
		double maxValue = -Double.MAX_VALUE;
		double currValue;

		for (RangeLocation range : this.ranges.keySet())
		{
			currValue = this.ranges.get(range);

			if (currValue < minValue)
			{
				minValue = currValue;
			}

			if (currValue > maxValue)
			{
				maxValue = currValue;
			}
		}

		scale(minValue, maxValue);
	}

	@Override
	public Shape[][] createPlot(GenomeData genomeData, SlotPath path, PlotDrawer plotDrawer)
	{
		RangeLocation currLocation;
		double currHeight;

		Set<RangeLocation> rangeSet = this.ranges.keySet();
		Iterator<RangeLocation> rangeIterator = rangeSet.iterator();

		while (rangeIterator.hasNext())
		{
			currLocation = rangeIterator.next();
			currHeight = getScaledHeight(this.ranges.get(currLocation));

			plotDrawer.drawRange(currLocation.getMin(), currLocation.getMax(), currHeight, path);
		}

		return plotDrawer.finishPlotRange(path);
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (this.ranges == null ? 0 : this.ranges.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlotBuilderRange other = (PlotBuilderRange) obj;
		if (this.ranges == null)
		{
			if (other.ranges != null)
				return false;
		}
		else if (!this.ranges.equals(other.ranges))
			return false;
		return true;
	}

	@Override
	public int getNumPoints()
	{
		return this.ranges.size();
	}

	@Override
	public void autoScaleCenter()
	{
		double[] minMax = getMaxMinValues();

		double distance = minMax[MAX] - minMax[MIN];

		double low = centerHeight - minMax[MIN];
		double high = minMax[MAX] - centerHeight;

		if( high >= low )
		{
			scale( minMax[MAX] - high * 2, minMax[MAX] );
		}
		else
		{
			scale( minMax[MIN], minMax[MIN] + low * 2 );
		}
	}


	/**
	 * @author matthew
	 * @return Minimum and Maximum values in the plot.  Minimum value is in the returned array index 0.  Maximum value is in the returned array index 1.
	 */
	@Override
	public double[] getMaxMinValues()
	{
		double[] maxMin = new double[2];
		maxMin[MIN] = Double.MAX_VALUE;
		maxMin[MAX] = -Double.MAX_VALUE;
		double currValue;

		for (RangeLocation range : this.ranges.keySet())
		{
			currValue = this.ranges.get(range);

			if (currValue < maxMin[MIN])
			{
				maxMin[MIN] = currValue;
			}

			if (currValue > maxMin[MAX])
			{
				maxMin[MAX] = currValue;
			}
		}

		return maxMin;
	}
}
