package gview.layout.feature;

import gview.layout.Direction;
import gview.layout.prototype.BackboneShape;
import gview.layout.prototype.CompositeShape;
import gview.layout.sequence.SlotPath;

import java.awt.Shape;
import java.util.Iterator;

import org.biojava.bio.symbol.Location;

/**
 * FeatureShapeRealizer used to draw an arrow which looks like
 * 
 * <===
 * 
 * @author Aaron Petkau
 *
 */
public class ReverseArrowShapeRealizer extends AbstractArrowShapeRealizer
{
	/**
	 * Constructs a ReverseArrowShapeRealizer to draw arrow shapes with the passed arrow length.
	 * @param arrowLength  The length of the arrow part to use.
	 */
	public ReverseArrowShapeRealizer(double arrowLength)
	{
		super(arrowLength);
	}
	
	/**
	 * Constructs a ReverseArrowShapeRealizer to draw arrow shapes with the default arrow lenth.
	 */
	public ReverseArrowShapeRealizer()
	{
		super();
	}
	
	@SuppressWarnings("unchecked")
	protected Shape realizeFeatureShape(SlotPath path, Location location,
			double top, double bottom)
	{
		BackboneShape shape;
		
		Iterator blocks = location.blockIterator();
		while (blocks.hasNext())
		{
			Location block = (Location)blocks.next();
			int start = block.getMin();
			int stop = block.getMax();
			
			// if we are at the last block
			if (!blocks.hasNext())
			{
				this.createArrowBlock(path, start, stop, top, bottom);
			}
			else
			{
				createStandardBlock(path, start, stop, top, bottom);
			}
		}
		
		shape = path.getShape();
		
		path.clear();
		createArrowHead(path, location.getMin(), location.getMax(), top, bottom);
		shape = new CompositeShape(path.getShape(), shape, path.getBackbone().findZoomForLength(location.getMax()-location.getMin(),
				ARROW_LENGTH), path.getBackbone().getScale());
		
		return shape;
	}
	
	protected BackboneShape createArrowBlock(SlotPath path, int start, int stop, double top, double bottom)
	{
		double center = ((double)top + bottom)/2;
		
		path.moveTo(start, center);
		path.realLineTo(start, top, ARROW_LENGTH); // (lineTo(pinned point, lengthFromPin, heightInSlot))
		path.lineTo(stop, Direction.INCREASING);
		path.lineTo(stop, bottom, Direction.NONE);
		path.lineTo(start, bottom, ARROW_LENGTH, Direction.DECREASING);
		path.realLineTo(start, center, 0);
		path.closePath();
		
		return path.getShape();
	}
	
	protected BackboneShape createArrowHead(SlotPath path, int start, int stop, double top, double bottom)
	{
		double centerBase = ((double)start + stop)/2;
		
		double centerHeight = ((double)top + bottom)/2;
		
		path.moveTo(centerBase, centerHeight, -ARROW_LENGTH/2);
		path.realLineTo(centerBase, top, ARROW_LENGTH/2);
		path.realLineTo(centerBase, bottom, ARROW_LENGTH/2);
		path.realLineTo(centerBase, centerHeight, -ARROW_LENGTH/2);
		path.closePath();
		
		return path.getShape();
	}
}
