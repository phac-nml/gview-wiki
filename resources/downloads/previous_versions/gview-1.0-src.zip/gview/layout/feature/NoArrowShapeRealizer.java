package gview.layout.feature;

import gview.layout.sequence.SlotPath;

import java.awt.Shape;
import java.util.Iterator;

import org.biojava.bio.symbol.Location;

/**
 * Draws a feature with no arrow head.  So draws a feature that looks like
 * 
 * ===
 * 
 * @author Aaron Petkau
 *
 */
public class NoArrowShapeRealizer extends FeatureShapeRealizer
{
	@SuppressWarnings("unchecked")
	@Override
	protected Shape realizeFeatureShape(SlotPath path, Location location, double top, double bottom)
	{
		Iterator blocks = location.blockIterator();
		while (blocks.hasNext())
		{
			Location block = (Location)blocks.next();
			int start = block.getMin();
			int stop = block.getMax();
					
			createStandardBlock(path, start, stop, top, bottom);
		}
		
		return path.getShape();
	}
}
