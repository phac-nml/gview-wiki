package gview.layout.feature;

import gview.layout.Direction;
import gview.layout.prototype.BackboneShape;
import gview.layout.sequence.SlotPath;

/**
 * FeatureShapeRealizer used to draw an arrow which looks like
 * 
 * ===>
 * 
 * @author Aaron Petkau
 *
 */
public class ForwardArrowShapeRealizer extends AbstractArrowShapeRealizer
{	
	/**
	 * Constructs a ForwardArrowShapeRealizer to draw arrow shapes with the passed arrow length.
	 * @param arrowLength  The length of the arrow part to use.
	 */
	public ForwardArrowShapeRealizer(double arrowLength)
	{
		super(arrowLength);
	}
	
	/**
	 * Constructs a ForwardArrowShapeRealizer to draw arrow shapes with the default arrow lenth.
	 */
	public ForwardArrowShapeRealizer()
	{
		super();
	}
	
	protected BackboneShape createArrowBlock(SlotPath path, int start, int stop, double top, double bottom)
	{
		double center = ((double)top + bottom)/2;
		
		// draws out the arrow block on the sequence
		path.moveTo(start, top);
		path.lineTo(stop, top, -ARROW_LENGTH, Direction.INCREASING); // (lineTo(pinned point, lengthFromPin, heightInSlot))
		path.realLineTo(stop, center, 0);
		path.realLineTo(stop, bottom, -ARROW_LENGTH);
		path.lineTo(start, Direction.DECREASING);
		path.closePath();
		
		return path.getShape();
	}
	
	protected BackboneShape createArrowHead(SlotPath path, int start, int stop, double top, double bottom)
	{
		double centerBase = ((double)start + stop)/2;
		
		double centerHeight = ((double)top + bottom)/2;
		
		path.moveTo(centerBase, top, -ARROW_LENGTH/2);
		path.realLineTo(centerBase, centerHeight, ARROW_LENGTH/2);
		path.realLineTo(centerBase, bottom, -ARROW_LENGTH/2);
		path.realLineTo(centerBase, top, -ARROW_LENGTH/2);
		path.closePath();
		
		return path.getShape();
	}
}
