package gview.layout.feature;

import gview.layout.Direction;
import gview.layout.prototype.BackboneShape;
import gview.layout.prototype.CompositeShape;
import gview.layout.sequence.SlotPath;

import java.awt.Shape;
import java.util.Iterator;

import org.biojava.bio.symbol.Location;

/**
 * An abstract class containing common code for making arrow shapes.
 * @author Aaron Petkau
 *
 */
public abstract class AbstractArrowShapeRealizer extends FeatureShapeRealizer
{
	protected final double ARROW_LENGTH;
	
	/**
	 * Constructs an arrow shape realizer with the arrow head taking up the passed length.
	 * @param arrowLength  The length of the arrow head.
	 */
	public AbstractArrowShapeRealizer(double arrowLength)
	{
		ARROW_LENGTH = arrowLength;
	}
	
	/**
	 * Constructs an arrow shape realizer with the default arrow lenth.
	 */
	public AbstractArrowShapeRealizer()
	{
		this(10);
	}
	
	@SuppressWarnings("unchecked")
	protected Shape realizeFeatureShape(SlotPath path, Location trueLocation,
			double top, double bottom)
	{
		BackboneShape shape = null;
		
		// iterate over all blocks on this location
		Iterator blocks = trueLocation.blockIterator();
		while (blocks.hasNext())
		{
			Location block = (Location)blocks.next();
			int start = block.getMin();
			int stop = block.getMax();
			
			// if we are at the last block
			if (!blocks.hasNext())
			{
				createArrowBlock(path, start, stop, top, bottom);
			}
			else
			{
				createStandardBlock(path, start, stop, top, bottom, 1.0);
			}
		}
		
		shape = path.getShape();
		
		path.clear();
		createArrowHead(path, trueLocation.getMin(), trueLocation.getMax(), top, bottom);
		shape = new CompositeShape(path.getShape(), shape, path.getBackbone().findZoomForLength(trueLocation.getMax()-trueLocation.getMin(),
				ARROW_LENGTH), path.getBackbone().getScale());
		
		return shape;
	}
	
	/**
	 * Method to override to create the arrow block part of the shape.  (Arrow block is the part of the feature which has the arrow head attached).
	 * @param path  The slot path to draw onto.
	 * @param start  The start base for this arrow block.
	 * @param stop  The stop base for this block.
	 * @param top  The top height for this block, (in range -1.0, to 1.0 defining bottom/top in slot).
	 * @param bottom  The bottom height for this block, (in range -1.0, to 1.0 defining bottom/top in slot).
	 * @return  A BackboneShape representing the arrow block.
	 */
	protected abstract BackboneShape createArrowBlock(SlotPath path, int start, int stop, double top, double bottom);
	
	/**
	 * Method to override to create the arrow head part of the shape.  (Arrow head is the part of the feature that is only the arrow head (displayed at low resolutions)).
	 * @param path  The slot path to draw onto.
	 * @param start  The start base for this arrow head.
	 * @param stop  The stop base for this head.
	 * @param top  The top height for this head, (in range -1.0, to 1.0 defining bottom/top in slot).
	 * @param bottom  The bottom height for this head, (in range -1.0, to 1.0 defining bottom/top in slot).
	 * @return  A BackboneShape representing the arrow head.
	 */
	protected abstract BackboneShape createArrowHead(SlotPath path, int start, int stop, double top, double bottom);
	
	/**
	 * A convience method used to create a standard (no arrow heads etc) block.
	 * @param path  The slot path to draw onto.
	 * @param start  The start based.
	 * @param stop  The stop base.
	 * @param top  The top height, (in range -1.0, to 1.0 defining bottom/top in slot).
	 * @param bottom  The bottom height, (in range -1.0, to 1.0 defining bottom/top in slot).
	 */
	protected void createStandardBlock(SlotPath path, int start, int stop, double top, double bottom, double heightDecrease)
	{
		path.moveTo(start, top*heightDecrease);
		path.lineTo(stop, Direction.INCREASING);
		path.lineTo(stop, bottom, Direction.NONE);
		path.lineTo(start*heightDecrease, Direction.DECREASING);
		path.closePath();
	}
}
