package otherTests;

import gview.managers.ResolutionManager;
import gview.style.io.gss.FontHandler.MalformedFontStringException;

import org.junit.*;

public class ResolutionSwitcherTest
{	
	@Test(expected=IllegalArgumentException.class)
	public void switchScaleZero()
	{
		ResolutionManager switcher = new ResolutionManager(1.0, 2.0, 0.5);
		switcher.isNewResolutionLevel(0.0);
	}
	
	// should throw illegalArgumentexception if minZoom >= initialZoom
	@Test(expected=IllegalArgumentException.class)
	public void initialScaleMinZoom()
	{
		ResolutionManager switcher = new ResolutionManager(1.0, 2.0, 1.0);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void initialScaleNonPos()
	{
		ResolutionManager switcher = new ResolutionManager(0.0, 2.0, 1.0);
	}
	
	// scaleSwitch should be >= 1
	// represents the mult factor (2x, 3x, etc) where we should switch resolutions
	@Test(expected=IllegalArgumentException.class)
	public void zoomSwitchTest()
	{
		ResolutionManager switcher = new ResolutionManager(1.0, 0.9, 0.5);
	}
	
	@Test
	public void switchScaleTest()
	{	
		ResolutionManager switcher;
		double minZoom = 0.5;
		double switchScale = 2.0;
		double initialScale = 1.0;
		
		// first set of tests
		switcher = new ResolutionManager(initialScale, switchScale, minZoom);
		
		// resolution levels should be setup such that
		// level 0 is from (0,0.5)
		// level 1 from [0.5,1.0)
		// level 2 from [1.0, 2.0)
		// and so on
		// we start at level 2 (corresponding to z=1.0)
		
		Assert.assertFalse(switcher.isMinResolutionLevel(0.5)); // 0.5 should be 1 above min res level
		Assert.assertTrue(switcher.isMinResolutionLevel(0.1)); // 0.1 (or anything below 0.5) should be in min res level
		
		Assert.assertFalse(switcher.isNewResolutionLevel(1.0));
		Assert.assertFalse(switcher.isNewResolutionLevel(1.5));
		
		Assert.assertTrue(switcher.isNewResolutionLevel(0.75));
		Assert.assertTrue(switcher.isNewResolutionLevel(0.5));
		Assert.assertTrue(switcher.isNewResolutionLevel(0.4));
		
		Assert.assertTrue(switcher.isNewResolutionLevel(2.1));
		Assert.assertTrue(switcher.isNewResolutionLevel(4.1));
		
		switcher.performSwitch(2.1);
		
		Assert.assertFalse(switcher.isNewResolutionLevel(2.0));
		Assert.assertFalse(switcher.isNewResolutionLevel(3.0));
		
		Assert.assertTrue(switcher.isNewResolutionLevel(1.9));
		Assert.assertTrue(switcher.isNewResolutionLevel(1.0));
		Assert.assertTrue(switcher.isNewResolutionLevel(0.5));
		Assert.assertTrue(switcher.isNewResolutionLevel(4.1));
		Assert.assertTrue(switcher.isNewResolutionLevel(8.1));
		
		Assert.assertEquals(1, switcher.getResolutionLevel(0.7)); // 0.7 should be at level 1
		Assert.assertEquals(1, switcher.getResolutionLevel(0.5));
		Assert.assertEquals(0, switcher.getResolutionLevel(0.1)); // below minResolutionLevel we should be at level 0
		Assert.assertEquals(2, switcher.getResolutionLevel(1.0)); // at res level 2 in this case
		Assert.assertEquals(2, switcher.getResolutionLevel(1.1));
		
		// second set of tests
		minZoom = 0.25;
		switchScale = 2.0;
		initialScale = 1.0;
		switcher = new ResolutionManager(initialScale, switchScale, minZoom);
		
		// resolution levels should be setup such that
		// level 0 is from (0,0.25)
		// level 1 from [0.25,0.5)
		// level 2 from [0.5, 1.0)
		// level 3 from [1.0, 2.0)
		// and so on
		// we start at level 3 (corresponding to z=1.0)
		
		Assert.assertFalse(switcher.isMinResolutionLevel(0.3));
		Assert.assertFalse(switcher.isMinResolutionLevel(0.25));
		Assert.assertTrue(switcher.isMinResolutionLevel(0.1));
		
		Assert.assertFalse(switcher.isNewResolutionLevel(1.0));
		Assert.assertFalse(switcher.isNewResolutionLevel(1.5));
		
		Assert.assertTrue(switcher.isNewResolutionLevel(0.75));
		Assert.assertTrue(switcher.isNewResolutionLevel(0.5));
		Assert.assertTrue(switcher.isNewResolutionLevel(0.4));
		
		Assert.assertTrue(switcher.isNewResolutionLevel(2.1));
		Assert.assertTrue(switcher.isNewResolutionLevel(4.1));
		
		switcher.performSwitch(0.4);
		
		Assert.assertTrue(switcher.isNewResolutionLevel(0.5));
		Assert.assertFalse(switcher.isNewResolutionLevel(0.4));
		Assert.assertTrue(switcher.isNewResolutionLevel(0.2));
		Assert.assertFalse(switcher.isNewResolutionLevel(0.25)); // should be at very min of switch over
		
		Assert.assertTrue(switcher.isNewResolutionLevel(1.1));
		
		Assert.assertEquals(1, switcher.getResolutionLevel(0.3)); // 0.3 should 1 above min level
		Assert.assertEquals(0, switcher.getResolutionLevel(0.1)); // below minResolutionLevel we should be at level 0
		Assert.assertEquals(1, switcher.getResolutionLevel(0.4));
		Assert.assertEquals(2, switcher.getResolutionLevel(0.5)); // at 0.5, should be at res level 2 now
		Assert.assertEquals(2, switcher.getResolutionLevel(0.6));
		Assert.assertEquals(3, switcher.getResolutionLevel(1.0)); // at res level 1.0 in this case, should be at level 3 now
		Assert.assertEquals(3, switcher.getResolutionLevel(1.1));
	}
}
