package profile;

import java.awt.Color;
import java.awt.Font;
import java.awt.geom.Point2D;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.data.Slot;
import gview.data.readers.GViewFileData;
import gview.data.readers.GViewFileReader;
import gview.layout.feature.FeatureShapeRealizer;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.items.BackboneStyle;
import gview.style.items.RulerStyle;
import gview.style.items.TooltipStyle;
import gview.textextractor.GeneTextExtractor;

public class ProfilePaintZoom extends PFrame
{
	private static final long serialVersionUID = 3529302897500122944L;

	public ProfilePaintZoom(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	private static MapStyle createDefaultStyle()
	{
		MapStyle style = new MapStyle();
		
		// set the style
		GlobalStyle gStyle = style.getGlobalStyle();
		gStyle.setDefaultHeight(700);
		gStyle.setDefaultWidth(700);
		
		gStyle.setBackgroundPaint(Color.BLACK);
		gStyle.setShowBorder(true);
//		gStyle.setBorderPaint(Color.BLACK);
		gStyle.setTitle("Test1");
		gStyle.setTitlePaint(Color.BLACK);
		gStyle.setTitleFont(new Font("SansSerif", Font.PLAIN, 20));
		gStyle.setSlotSpacing(10.0);
		
		TooltipStyle tStyle = gStyle.getTooltipStyle();
		tStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tStyle.setBackgroundPaint(new Color(0,0,0,0.7f));
		tStyle.setTextPaint(Color.RED);
		
		BackboneStyle bStyle = gStyle.getBackboneStyle();
		bStyle.setPaint(Color.GRAY);
		bStyle.setThickness(5.0);
		
		RulerStyle rStyle = gStyle.getRulerStyle();
		rStyle.setMajorTickLength(15.0);
		rStyle.setTickThickness(2.0);
		rStyle.setMinorTickPaint(Color.LIGHT_GRAY);
		rStyle.setMajorTickPaint(Color.DARK_GRAY);
		rStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		rStyle.setTextPaint(Color.WHITE);
		
		DataStyle dataStyle = style.getDataStyle();
		
		SlotStyle positive = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		
		positive.setPaint(Color.BLUE);
		positive.setThickness(35);
		positive.setTransparency(1.0f);
		
		FeatureHolderStyle positiveHolder = positive.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positiveHolder.setTransparency(0.7f);
		positiveHolder.setToolTipExtractor(new GeneTextExtractor());
		positiveHolder.setFeatureShapeRealizer(FeatureShapeRealizer.NO_ARROW); // Note:  this part doesn't work for now and isn't really needed
		
		SlotStyle negative = dataStyle.createSlotStyle(Slot.FIRST_LOWER);
		
		negative.setPaint(Color.RED); // this paint may be useless, since paints in featureholders override it
		negative.setThickness(35);
		negative.setTransparency(1.0f);
		
		FeatureHolderStyle negativeHolder = negative.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeHolder.setTransparency(0.7f);
		negativeHolder.setToolTipExtractor(new GeneTextExtractor());
		negativeHolder.setFeatureShapeRealizer(FeatureShapeRealizer.NO_ARROW);

		return style;
	}
	
	public static void main(String[] args)
	{
		int max = 20;
		
		try
		{
			GViewFileData gviewFileData = GViewFileReader.read("testfiles/R_denitrificans.gbk");
			
			GenomeData data = gviewFileData.getGenomeData();
			MapStyle style = createDefaultStyle();
			
			LayoutFactory lFactory = new LayoutFactoryCircular();
			
			
			GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
			System.out.println("Done creating map");
			
			gViewMap.setCenter(new Point2D.Double(0,0));
			for (int i = 0; i < max; i++)
			{
				gViewMap.setZoomFactor((double)(i+1)/max);
				gViewMap.getImage();
			}
			
			System.out.println("Done");
		}
		catch (Exception e)
		{
			System.err.println(e);
			e.printStackTrace();
		}
	}
}
