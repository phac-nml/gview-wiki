package translatetests;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.PathIterator;

import org.junit.Assert;

public class TestUtils
{
	// asserts that the path defined by the two shapes are equal
	public static void assertShapeEqual(Shape expected, Shape actual, double delta)
	{
		final AffineTransform IDENTITY = new AffineTransform();
		
		if (expected == null || actual == null)
		{
			Assert.assertNull(expected);
			Assert.assertNull(actual);
		}
		else
		{
			PathIterator expectedPath = expected.getPathIterator(IDENTITY);
			PathIterator actualPath = actual.getPathIterator(IDENTITY);
			
			double[] expectedCoords = new double[6];
			double[] actualCoords = new double[6];
			
			int actualType;
			int expectedType;
			
			while (!expectedPath.isDone())
			{
				// reset to 0
				for (int i = 0; i < expectedCoords.length; i++)
				{
					expectedCoords[i] = 0;
					actualCoords[i] = 0;
				}
				
				Assert.assertFalse(actualPath.isDone());
				
				actualType = actualPath.currentSegment(actualCoords);
				expectedType = expectedPath.currentSegment(expectedCoords);
				
				// assert that the current segments are equal
				Assert.assertEquals(expectedType, actualType);
				for (int i = 0; i < expectedCoords.length; i++)
				{
					Assert.assertEquals(expectedCoords[i], actualCoords[i], delta);
				}
				
				actualPath.next();
				expectedPath.next();
			}
		}
	}
	
	public static Shape createCircle(double radius, double startAngleDeg, double extentAngleDeg)
	{
		Arc2D arc = null;
		
		double height = radius*2;
		
		double width = height;
		
		double boundsX = -radius;
		double boundsY = -radius;
		
		// defines the arc to draw
		arc = new Arc2D.Double(boundsX, boundsY, width, height, startAngleDeg,
					extentAngleDeg, Arc2D.OPEN);
		
		return arc;
	}
}
