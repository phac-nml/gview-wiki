package translatetests;

import gview.data.GenomeDataFactory;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.items.BackboneStyle;

import java.awt.geom.Arc2D;
import java.awt.geom.Path2D;

import org.junit.Before;
import org.junit.Test;

public class SlotPathCirularTest
{
	// private SlotTranslator slotTrans;
	@SuppressWarnings("unused")
	private double radius;

	private int sequenceLength;
	private int height;
	private int width;

	private double backboneThickness;

	// private double tickThickness;

	// private double delta = 0.00000000001;

	// private Backbone backbone;

	@Before
	@SuppressWarnings("unused")
	public void setup()
	{

		sequenceLength = 100;
		height = 700;
		width = 700;
		backboneThickness = 10.0;

		GenomeDataFactory.createBlankGenomeData(sequenceLength);

		// SlotTranslator slots = new SlotTranslatorImp(style);
		// slotTrans = new SlotTranslatorImp(btrans, slots);

		// TODO set radius better so I don't have to copy code here
		double minDimension = Math.min(height, width);
		radius = minDimension / 2;

		// Backbone backbone = new BackboneCircular(new LocationConverter(data), radius, 0.00001);
	}

	private MapStyle setUpStyle()
	{
		MapStyle style = new MapStyle();

		GlobalStyle gStyle = style.getGlobalStyle();
		gStyle.setDefaultHeight(height);
		gStyle.setDefaultWidth(width);

		BackboneStyle bStyle = gStyle.getBackboneStyle();
		bStyle.setThickness(backboneThickness);

		return style;
	}

	@Test
	public void testMoveTo()
	{
		// SequencePath seqPath = new SequencePathCircular(backbone);
		// SlotPath sPath = new SlotPathImp(seqPath, backbone, slotTrans, 0); // test backbone path
		//		
		// Point2D point;
		//		
		// // test point on zero base on backbone
		// sPath.moveTo(0, 0);
		// point = sPath.createPath2D().getCurrentPoint();
		// Assert.assertEquals(0, point.getX(), delta);
		// Assert.assertEquals(radius, point.getY(), delta);
		//		
		// // test point on sequenceLength base
		// sPath.moveTo(sequenceLength, 0);
		// point = sPath.createPath2D().getCurrentPoint();
		// Assert.assertEquals(0, point.getX(), delta);
		// Assert.assertEquals(radius, point.getY(), delta);
		//		
		// // test half base point
		// sPath.moveTo(sequenceLength/2, 0); // make sure sLengh is evenly divisible
		// point = sPath.createPath2D().getCurrentPoint();
		// Assert.assertEquals(0, point.getX(), delta);
		// Assert.assertEquals(-radius, point.getY(), delta);
		//		
		// // test quarter points
		// sPath.moveTo(sequenceLength/4, 0); // make sure sLengh is evenly divisible
		// point = sPath.createPath2D().getCurrentPoint();
		// Assert.assertEquals(radius, point.getX(), delta);
		// Assert.assertEquals(0, point.getY(), delta);
		//		
		// sPath.moveTo(3*(sequenceLength/4), 0); // make sure sLengh is evenly divisible
		// point = sPath.createPath2D().getCurrentPoint();
		// Assert.assertEquals(-radius, point.getX(), delta);
		// Assert.assertEquals(0, point.getY(), delta);
	}

	@Test
	public void testLineTo()
	{
		// SlotPath sPath = new SlotPathCircular(slotTrans, 0); // test backbone path

		// Rectangle2D expectedFrame = new Rectangle2D.Double(-(double)width/2, -(double)height/2,
		// width, height);
		Path2D expectedArc = new Path2D.Double();

		// test full arc
		// sPath.moveTo(Location.INITIAL_BASE,0);
		// sPath.lineTo(Location.FINAL_BASE);

		expectedArc.moveTo(0, 0);
		expectedArc.append(new Arc2D.Double(-(double) width / 2, -(double) height / 2, width, height, 0, 360, Arc2D.OPEN), true);
		// Rectangle2D trueFrame = sPath.createPath2D().getBounds2D();

		// Assert.assertEquals(expectedFrame, trueFrame);
		// Assert.assertEquals(expectedArc, sPath.createPath2D());
	}

	// this is a test for a normally private method
	/*
	 * @Test public void testGetAngularExtentDegree() { SlotPathCircular sPath = new
	 * SlotPathCircular(slotTrans, 0); // test backbone path
	 * 
	 * double startAngle; double endAngle;
	 * 
	 * startAngle = 0; endAngle = 90; Assert.assertEquals(270,
	 * sPath.getAngularExtentDegree(startAngle, endAngle), delta);
	 * 
	 * startAngle = 0; endAngle = 180; Assert.assertEquals(180,
	 * sPath.getAngularExtentDegree(startAngle, endAngle), delta);
	 * 
	 * startAngle = 0; endAngle = 270; Assert.assertEquals(90,
	 * sPath.getAngularExtentDegree(startAngle, endAngle), delta);
	 * 
	 * startAngle = 90; endAngle = 270; Assert.assertEquals(180,
	 * sPath.getAngularExtentDegree(startAngle, endAngle), delta);
	 * 
	 * startAngle = 180; endAngle = 0; Assert.assertEquals(180,
	 * sPath.getAngularExtentDegree(startAngle, endAngle), delta);
	 * 
	 * startAngle = 180; endAngle = 90; Assert.assertEquals(90,
	 * sPath.getAngularExtentDegree(startAngle, endAngle), delta);
	 * 
	 * startAngle = 270; endAngle = 90; Assert.assertEquals(180,
	 * sPath.getAngularExtentDegree(startAngle, endAngle), delta);
	 * 
	 * startAngle = 315; endAngle = 45; Assert.assertEquals(270,
	 * sPath.getAngularExtentDegree(startAngle, endAngle), delta); }
	 */
}
