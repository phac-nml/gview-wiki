package translatetests;
import gview.data.Slot;
import gview.layout.sequence.SlotTranslator;
import gview.layout.sequence.SlotTranslatorImp;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.items.BackboneStyle;
import gview.style.items.RulerStyle;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class SlotTranslatorTest
{
	private MapStyle style;
	private SlotTranslator slots;
	
	private double delta = 0.00000000001;
	
	@Before
	public void setup()
	{
		style = new MapStyle();
		
		// set the style
		GlobalStyle gStyle = style.getGlobalStyle();
		gStyle.setSlotSpacing(0.0);
		
		BackboneStyle bStyle = gStyle.getBackboneStyle();
		bStyle.setThickness(10.0);
		
		RulerStyle rStyle = gStyle.getRulerStyle();
		rStyle.setMajorTickLength(20.0);
		
		// set data style
		DataStyle dataStyle = style.getDataStyle();
		
		SlotStyle positive = dataStyle.createSlotStyle(1);
		positive.setThickness(30);
		
		SlotStyle negative = dataStyle.createSlotStyle(-1);
		negative.setThickness(30);
		
		slots = new SlotTranslatorImp(style);
	}
	
	private void testGetTopMostHeight(double spacing)
	{
		double height;
		
		height = slots.getTopMostHeight();
		Assert.assertEquals(55 + 2*spacing, height, delta);
	}
	
	private void testGetBottomMostHeight(double spacing)
	{
		double height;
		
		height = slots.getBottomMostHeight();
		Assert.assertEquals(-55 - 2*spacing, height, delta);
	}
	
	private void testGetHeightFromBackbone(double spacing)
	{
		double height;
		
		// test on backbone
		height = slots.getHeightFromBackbone(Slot.BACKBONE, SlotTranslator.CENTER);
		Assert.assertEquals(0, height, delta);
		
		height = slots.getHeightFromBackbone(Slot.BACKBONE, SlotTranslator.TOP);
		Assert.assertEquals(5, height, delta);
		
		height = slots.getHeightFromBackbone(Slot.BACKBONE, SlotTranslator.BOTTOM);
		Assert.assertEquals(-5, height, delta);
		
		// test on positive slot
		height = slots.getHeightFromBackbone(1, SlotTranslator.CENTER);
		Assert.assertEquals(20 + spacing, height, delta);
		
		height = slots.getHeightFromBackbone(1, SlotTranslator.TOP);
		Assert.assertEquals(35 + spacing, height, delta);
		
		height = slots.getHeightFromBackbone(1, SlotTranslator.BOTTOM);
		Assert.assertEquals(5 + spacing, height, delta);
		
		// test negative slot
		height = slots.getHeightFromBackbone(-1, SlotTranslator.CENTER);
		Assert.assertEquals(-20 - spacing, height, delta);
		
		height = slots.getHeightFromBackbone(-1, SlotTranslator.TOP);
		Assert.assertEquals(-5 - spacing, height, delta);
		
		height = slots.getHeightFromBackbone(-1, SlotTranslator.BOTTOM);
		Assert.assertEquals(-35 - spacing, height, delta);
		
		// test on positive ruler
		height = slots.getHeightFromBackbone(Slot.UPPER_RULER, SlotTranslator.CENTER);
		Assert.assertEquals(45 + 2*spacing, height, delta);
		
		height = slots.getHeightFromBackbone(Slot.UPPER_RULER, SlotTranslator.TOP);
		Assert.assertEquals(55 + 2*spacing, height, delta);
		
		height = slots.getHeightFromBackbone(Slot.UPPER_RULER, SlotTranslator.BOTTOM);
		Assert.assertEquals(35 + 2*spacing, height, delta);
		
		// test on negative ruler
		height = slots.getHeightFromBackbone(Slot.LOWER_RULER, SlotTranslator.CENTER);
		Assert.assertEquals(-45 - 2*spacing, height, delta);
		
		height = slots.getHeightFromBackbone(Slot.LOWER_RULER, SlotTranslator.TOP);
		Assert.assertEquals(-35 - 2*spacing, height, delta);
		
		height = slots.getHeightFromBackbone(Slot.LOWER_RULER, SlotTranslator.BOTTOM);
		Assert.assertEquals(-55 - 2*spacing, height, delta);
	}
	
	@Test
	public void testHeightFromBackboneSpacing()
	{
		
		for (double spacing = 0.0; spacing < 10; spacing +=0.5)
		{
			style.getGlobalStyle().setSlotSpacing(spacing);
			slots = new SlotTranslatorImp(style); // TODO eventually, I shouldn't have to create a new object when changing style
			
			testGetHeightFromBackbone(spacing);
			testGetTopMostHeight(spacing);
			testGetBottomMostHeight(spacing);
		}
	}
}
