package ioTests.styles;

import gview.style.io.FeatureSetMap;
import gview.style.io.gss.coders.FilterCoder;
import gview.style.io.gss.coders.GSSWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.RangeLocation;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

public class FilterCoderTest
{
	private FilterCoder coder;
	
	@Before
	public void setup()
	{
		coder = new FilterCoder();
	}
	
	@Test
	public void testEncodeProperties()
	{
		FeatureSetMap setMap;
		
		String expectedEncoding;
		
		StringWriter expectedStringWriter;
		GSSWriter expectedGssWriter;
		
		StringWriter actualStringWriter;
		GSSWriter actualEncodingGSS;
		
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup FeatureSetMap
		setMap = new FeatureSetMap();
		setMap.put("all", FeatureFilter.all);
		
		// setup expected encoding
		expectedGssWriter.startSelector("FeatureFilter");
		expectedGssWriter.writeProperty("all", "feature-filter(\"all\")");
		expectedGssWriter.endSelector();
		expectedEncoding = expectedStringWriter.toString();
		
		coder.encodeProperties(setMap, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
		
		// new test
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup FeatureSetMap
		setMap = new FeatureSetMap();
		setMap.put("strand", new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		
		// setup expected encoding
		expectedGssWriter.startSelector("FeatureFilter");
		expectedGssWriter.writeProperty("strand", "feature-filter(strand(\"positive\"))");
		expectedGssWriter.endSelector();
		expectedEncoding = expectedStringWriter.toString();
		
		coder.encodeProperties(setMap, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
		
		// new test
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup FeatureSetMap
		setMap = new FeatureSetMap();
		setMap.put("and", new FeatureFilter.And(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE), new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE)));
		
		// setup expected encoding
		expectedGssWriter.startSelector("FeatureFilter");
		expectedGssWriter.writeProperty("and", "feature-filter(and(strand(\"positive\"),strand(\"negative\")))");
		expectedGssWriter.endSelector();
		expectedEncoding = expectedStringWriter.toString();
		
		coder.encodeProperties(setMap, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
		
		/*// setup FeatureSetMap
		setMap = new FeatureSetMap();
		setMap.put("and", new FeatureFilter.And(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE),
				new FeatureFilter.And(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE), new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE))));
		
		// setup expected encoding
		expectedGssWriter.startSelector("FeatureFilter");
		expectedGssWriter.writeProperty("and", "feature-filter(and(strand(\"positive\"),strand(\"negative\"),strand(\"negative\")))");
		expectedGssWriter.endSelector();
		expectedEncoding = expectedStringWriter.toString();
		
		coder.encodeProperties(setMap, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());*/
		
		
		
		// new test
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup FeatureSetMap
		setMap = new FeatureSetMap();
		setMap.put("annEquals", new FeatureFilter.ByAnnotation("locus_tag", "loc1"));
		
		// setup expected encoding
		expectedGssWriter.startSelector("FeatureFilter");
		expectedGssWriter.writeProperty("annEquals", "feature-filter(annotationValueEquals(\"locus_tag\",\"loc1\"))");
		expectedGssWriter.endSelector();
		expectedEncoding = expectedStringWriter.toString();
		
		coder.encodeProperties(setMap, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
		
		
		
		// new test
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup FeatureSetMap
		setMap = new FeatureSetMap();
		setMap.put("all-and", new FeatureFilter.And(FeatureFilter.all, new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE)));
		
		// setup expected encoding
		expectedGssWriter.startSelector("FeatureFilter");
		expectedGssWriter.writeProperty("all-and", "feature-filter(and(\"all\",strand(\"negative\")))");
		expectedGssWriter.endSelector();
		expectedEncoding = expectedStringWriter.toString();
		
		coder.encodeProperties(setMap, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
		
		// test encode empty feature set map
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup FeatureSetMap
		setMap = new FeatureSetMap();
		
		// setup expected encoding
		expectedGssWriter.startSelector("FeatureFilter");
		expectedGssWriter.endSelector();
		expectedEncoding = expectedStringWriter.toString();
		
		coder.encodeProperties(setMap, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
	}
	
	@Test
	public void testOrDecode() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		FeatureSetMap setMap = new FeatureSetMap();
		FeatureFilter expectedFilter;
		
		// create expected FeatureFilter
		expectedFilter = new FeatureFilter.Or(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE), 
				new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(or(strand(\"positive\"),strand(\"negative\")))")));
		
		// make sure expectedFilter not in setMap before
		Assert.assertFalse(setMap.containsFilter(expectedFilter));
		
		// decode into set map
		coder.decodeProperty(setMap, "or", currUnit);
				
		// check that expectedFilter is now in setMap
		Assert.assertEquals(expectedFilter, setMap.get("or"));
		
		
		
		
		// create expected FeatureFilter
		expectedFilter = new FeatureFilter.Or(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE), 
				new FeatureFilter.Or(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE), FeatureFilter.all));
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(or(strand(\"positive\"),strand(\"negative\"),\"all\"))")));
		
		// make sure expectedFilter not in setMap before
		Assert.assertFalse(setMap.containsFilter(expectedFilter));
		
		// decode into set map
		coder.decodeProperty(setMap, "or3", currUnit);
				
		// check that expectedFilter is now in setMap
		Assert.assertEquals(expectedFilter, setMap.get("or3"));

		
		
		// create expected FeatureFilter
		expectedFilter = new FeatureFilter.Or(new FeatureFilter.OverlapsLocation(new RangeLocation(0, 100)), 
				new FeatureFilter.Or(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE), 
				new FeatureFilter.Or(FeatureFilter.all, new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE))));
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(or(overlaps(0, 100),strand(\"negative\"),\"all\", strand(\"positive\")))")));
		
		// make sure expectedFilter not in setMap before
		Assert.assertFalse(setMap.containsFilter(expectedFilter));
		
		// decode into set map
		coder.decodeProperty(setMap, "or4", currUnit);
				
		// check that expectedFilter is now in setMap
		Assert.assertEquals(expectedFilter, setMap.get("or4"));
		
		
		
		// create expected FeatureFilter
		expectedFilter = new FeatureFilter.Or(FeatureFilter.all, 
				new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(or(\"all\",strand(\"negative\")))")));
		
		// make sure expectedFilter not in setMap before
		Assert.assertFalse(setMap.containsFilter(expectedFilter));
		
		// decode into set map
		coder.decodeProperty(setMap, "all-or", currUnit);
				
		// check that expectedFilter is now in setMap
		Assert.assertEquals(expectedFilter, setMap.get("all-or"));
	}
	
	@Test
	public void testDecode() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		FeatureSetMap setMap = new FeatureSetMap();
		FeatureFilter expectedFilter;
				
		// create expected FeatureFilter
		expectedFilter = FeatureFilter.all;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(\"all\")")));
		
		// make sure expectedFilter not in setMap before
		Assert.assertFalse(setMap.containsFilter(expectedFilter));
		
		// decode into set map
		coder.decodeProperty(setMap, "all", currUnit);
				
		// check that expectedFilter is now in setMap
		Assert.assertEquals(expectedFilter, setMap.get("all"));
		
		
		
		// create expected FeatureFilter
		expectedFilter = new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(strand(\"positive\"))")));
		
		// make sure expectedFilter not in setMap before
		Assert.assertFalse(setMap.containsFilter(expectedFilter));
		
		// decode into set map
		coder.decodeProperty(setMap, "positive", currUnit);
				
		// check that expectedFilter is now in setMap
		Assert.assertEquals(expectedFilter, setMap.get("positive"));
		
		
		
		// create expected FeatureFilter
		expectedFilter = new FeatureFilter.And(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE), 
				new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(and(strand(\"positive\"),strand(\"negative\")))")));
		
		// make sure expectedFilter not in setMap before
		Assert.assertFalse(setMap.containsFilter(expectedFilter));
		
		// decode into set map
		coder.decodeProperty(setMap, "and", currUnit);
				
		// check that expectedFilter is now in setMap
		Assert.assertEquals(expectedFilter, setMap.get("and"));
		
		
		
		
		// create expected FeatureFilter
		expectedFilter = new FeatureFilter.And(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE), 
				new FeatureFilter.And(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE), FeatureFilter.all));
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(and(strand(\"positive\"),strand(\"negative\"),\"all\"))")));
		
		// make sure expectedFilter not in setMap before
		Assert.assertFalse(setMap.containsFilter(expectedFilter));
		
		// decode into set map
		coder.decodeProperty(setMap, "and3", currUnit);
				
		// check that expectedFilter is now in setMap
		Assert.assertEquals(expectedFilter, setMap.get("and3"));

		
		
		// create expected FeatureFilter
		expectedFilter = new FeatureFilter.And(new FeatureFilter.OverlapsLocation(new RangeLocation(0, 100)), 
				new FeatureFilter.And(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE), 
				new FeatureFilter.And(FeatureFilter.all, new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE))));
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(and(overlaps(0, 100),strand(\"negative\"),\"all\", strand(\"positive\")))")));
		
		// make sure expectedFilter not in setMap before
		Assert.assertFalse(setMap.containsFilter(expectedFilter));
		
		// decode into set map
		coder.decodeProperty(setMap, "and4", currUnit);
				
		// check that expectedFilter is now in setMap
		Assert.assertEquals(expectedFilter, setMap.get("and4"));
		
		
		
		// create expected FeatureFilter
		expectedFilter = new FeatureFilter.And(FeatureFilter.all, 
				new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(and(\"all\",strand(\"negative\")))")));
		
		// make sure expectedFilter not in setMap before
		Assert.assertFalse(setMap.containsFilter(expectedFilter));
		
		// decode into set map
		coder.decodeProperty(setMap, "all-and", currUnit);
				
		// check that expectedFilter is now in setMap
		Assert.assertEquals(expectedFilter, setMap.get("all-and"));
		
		
// bioJava FeatureFilter.ByAnnotation.equals() doesn't work properly
		// compares the internal type by reference (using ==) instead of using type.equals
		// so can't properly execute this test
		// create expected FeatureFilter
		FeatureFilter.ByAnnotation byAnnExpected;
		byAnnExpected = new FeatureFilter.ByAnnotation("locus_tag", "loc1");
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(annotationValueEquals(\"locus_tag\", \"loc1\"))")));
		
		// make sure expectedFilter not in setMap before
		Assert.assertFalse(setMap.containsFilter(byAnnExpected));
		
		// decode into set map
		coder.decodeProperty(setMap, "annEquals", currUnit);
		
		Assert.assertEquals(byAnnExpected.getClass(), setMap.get("annEquals").getClass());
		FeatureFilter.ByAnnotation byAnnActual = (FeatureFilter.ByAnnotation)setMap.get("annEquals");

		// check that expectedFilter is now in setMap
		Assert.assertEquals(byAnnExpected.getKey(), byAnnActual.getKey());
		Assert.assertEquals(byAnnExpected.getValue(), byAnnActual.getValue());
	}
}
