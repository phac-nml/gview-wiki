package ioTests.styles;

import gview.layout.feature.FeatureShapeRealizer;
import gview.map.effects.OutlineEffect;
import gview.map.effects.OutsideEffect;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.io.FeatureSetMap;
import gview.style.io.gss.coders.FeatureSetCoder;
import gview.style.io.gss.coders.GSSWriter;
import gview.style.io.gss.coders.LabelCoder;
import gview.style.io.gss.coders.SlotCoder;
import gview.style.io.gss.exceptions.NoStyleExistsException;
import gview.style.io.gss.exceptions.NoSuchFilterException;
import gview.textextractor.AnnotationExtractor;
import gview.textextractor.LocationExtractor;

import java.awt.Color;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.DescendantSelector;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;
import org.w3c.css.sac.Selector;
import org.w3c.css.sac.SimpleSelector;

import com.steadystate.css.parser.selectors.ConditionalSelectorImpl;
import com.steadystate.css.parser.selectors.DescendantSelectorImpl;
import com.steadystate.css.parser.selectors.ElementSelectorImpl;
import com.steadystate.css.parser.selectors.IdConditionImpl;

public class FeatureSetCoderTest
{
	private FeatureSetCoder coder;
	private FeatureSetMap filtersMap;
	private MapStyle mapStyle;
	
	@Before
	public void setup()
	{
		coder = new FeatureSetCoder();
		filtersMap = new FeatureSetMap();
		
		filtersMap.put("positive", new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		filtersMap.put("all", FeatureFilter.all);
		
		mapStyle = new MapStyle();
	}
	
	private SimpleSelector buildFeatureSelector(String setName)
	{
		SimpleSelector featureSelector = new ConditionalSelectorImpl(new ElementSelectorImpl("FeatureSet"), new IdConditionImpl(setName));
		
		return featureSelector;
	}
	
	private DescendantSelector buildDescendantSelector(Selector base, SimpleSelector descendant)
	{
		DescendantSelector descSel = new DescendantSelectorImpl(base, descendant);
		
		return descSel;
	}
	
	private Selector buildSlotSelector(String slotNumber)
	{
		Selector slotSelector = new ConditionalSelectorImpl(new ElementSelectorImpl("slot"), new IdConditionImpl(slotNumber));
		
		return slotSelector;
	}
	
	@Test
	public void testDecode() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		FeatureHolderStyle workingStyle;
		LexicalUnit currUnit;
		
		SlotStyle currentSlot;
		FeatureHolderStyle expectedStyle;
		
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// create initial feature holder style
		currentSlot = dataStyle.createSlotStyle(1);
		workingStyle = currentSlot.createFeatureHolderStyle(filtersMap.get("positive"));
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setPaint(Color.red);
		
		coder.decodeProperty(workingStyle, "color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("0.75")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setThickness(0.75);
		
		coder.decodeProperty(workingStyle, "thickness-proportion", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("shape-effect(\"outline\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setShapeEffectRenderer(new OutlineEffect());
		
		coder.decodeProperty(workingStyle, "feature-effect", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("shape(\"counterclockwise-arrow\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);
		
		coder.decodeProperty(workingStyle, "feature-shape", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("text-extractor(\"location\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setToolTipExtractor(new LocationExtractor());
		
		coder.decodeProperty(workingStyle, "tooltip-text", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testEncode()
	{
		SlotStyle slotStyle = mapStyle.getDataStyle().createSlotStyle(1);
		LabelCoder labelCoder = new LabelCoder();
		
		FeatureHolderStyle holderStyle = slotStyle.createFeatureHolderStyle(filtersMap.get("positive"));
		String expectedEncoding, actualEncoding;
		
		StringWriter expectedStringWriter;
		GSSWriter expectedGssWriter;
		
		StringWriter actualStringWriter;
		GSSWriter actualEncodingGSS;
		
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup feature set 
		expectedGssWriter.startSelector("slot#1 FeatureSet#positive");
		expectedGssWriter.writeProperty("color", "color(\"blue\")");
		expectedGssWriter.writeProperty("thickness-proportion", "0.5");
		expectedGssWriter.writeProperty("feature-effect", "shape-effect(\"outline\")");
		expectedGssWriter.writeProperty("feature-shape", "shape(\"clockwise-arrow\")");
		expectedGssWriter.writeProperty("tooltip-text", "text-extractor(annotation(\"product\"))");
		expectedGssWriter.endSelector();
		labelCoder.encodeStyle(holderStyle.getLabelStyle(), "slot#1 FeatureSet#positive", expectedGssWriter);
		expectedEncoding = expectedStringWriter.toString();
		
		// setup map
		holderStyle.setPaint(Color.blue);
		holderStyle.setThickness(0.5);
		holderStyle.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW);
		holderStyle.setShapeEffectRenderer(new OutlineEffect());
		holderStyle.setToolTipExtractor(new AnnotationExtractor("product"));
		
		coder.encodeStyle(holderStyle, "slot#1", filtersMap, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
	}
	
	@Test
	public void testEncodeLayered()
	{
		SlotStyle slotStyle = mapStyle.getDataStyle().createSlotStyle(-1);
		LabelCoder labelCoder = new LabelCoder();
		
		FeatureHolderStyle tmpHolderStyle = slotStyle.createFeatureHolderStyle(filtersMap.get("all"));
		FeatureHolderStyle holderStyle = tmpHolderStyle.createFeatureHolderStyle(filtersMap.get("positive"));
		String expectedEncoding;
		
		StringWriter expectedStringWriter;
		GSSWriter expectedGssWriter;
		
		StringWriter actualStringWriter;
		GSSWriter actualEncodingGSS;
		
//		Selector selector;
//		selector = buildSelector("1", "positive");
		
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup feature set 
		expectedGssWriter.startSelector("slot#-1 FeatureSet#all FeatureSet#positive");
		expectedGssWriter.writeProperty("color", "color(\"blue\")");
		expectedGssWriter.writeProperty("thickness-proportion", "0.5");
		expectedGssWriter.writeProperty("feature-effect", "shape-effect(\"outline\")");
		expectedGssWriter.writeProperty("feature-shape", "shape(\"clockwise-arrow\")");
		expectedGssWriter.writeProperty("tooltip-text", "text-extractor(annotation(\"product\"))");
		expectedGssWriter.endSelector();
		labelCoder.encodeStyle(holderStyle.getLabelStyle(), "slot#-1 FeatureSet#all FeatureSet#positive", expectedGssWriter);
		expectedEncoding = expectedStringWriter.toString();
		
		// setup map
		holderStyle.setPaint(Color.blue);
		holderStyle.setThickness(0.5);
		holderStyle.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW);
		holderStyle.setShapeEffectRenderer(new OutlineEffect());
		holderStyle.setToolTipExtractor(new AnnotationExtractor("product"));
		
		coder.encodeStyle(holderStyle, "slot#-1 FeatureSet#all", filtersMap, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
	}
}
