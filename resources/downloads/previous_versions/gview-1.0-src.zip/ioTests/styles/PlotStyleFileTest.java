package ioTests.styles;

import static org.junit.Assert.assertEquals;
import gview.layout.PlotBuilder;
import gview.layout.PlotBuilderPoints;
import gview.style.MapStyle;
import gview.style.datastyle.PlotStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.io.StyleIO;
import gview.style.io.StyleIOGSS;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.junit.Test;

/**
 * Test reading in a style from a temp file, which defines a plot.
 * @author aaron
 *
 */
public class PlotStyleFileTest
{
	/**
	 * Writes a temporary style to a file, returning the file containing it.
	 * Sets up this temp file to be deleted upon quiting the program.
	 * @param plotDataLocation  The location of the plot data.
	 * 
	 * @return
	 * @throws IOException
	 */
	private File writeTempStyleFile(String plotDataLocation) throws IOException
	{
		File dataFile = File.createTempFile("gview-gss-plot", ".gss");
		dataFile.deleteOnExit();

		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("FeatureFilter");
		writer.println("{}");
		writer.println();
		writer.println("slot");
		writer.println("{");
		writer.println("spacing: 10.0;");
		writer.println("}");
		writer.println("slot#-1");
		writer.println("{}");
		writer.println("slot#-1 plot");
		writer.println("{");
		writer.println("data: plot-file(\"point\",\"" + plotDataLocation + "\");");
		writer.println("}");
		writer.close();

		return dataFile;
	}

	/**
	 * Writes a temporary file containing test plot data.
	 * @return  The temporary file written.
	 * @throws IOException
	 */
	private File writeTempPlotDataFile() throws IOException
	{
		File dataFile = File.createTempFile("plot-data", ".csv");
		dataFile.deleteOnExit();

		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("0,0.5"); // format base,value
		writer.println("1,0.75");
		writer.println("2,1.0");
		writer.println("3,2.0");
		writer.close();

		return dataFile;
	}

	private PlotBuilder getExpectedPlotBuilder()
	{
		PlotBuilderPoints expectedPlotBuilder = new PlotBuilderPoints();
		expectedPlotBuilder.addPoint(0,0.5);
		expectedPlotBuilder.addPoint(1,0.75);
		expectedPlotBuilder.addPoint(2,1.0);
		expectedPlotBuilder.addPoint(3,2.0);
		expectedPlotBuilder.autoScale();

		return expectedPlotBuilder;
	}

	@Test
	public void testReadStyleAbsolutePath() throws IOException
	{
		StyleIO styleReader = new StyleIOGSS();

		File plotDataFile = writeTempPlotDataFile();
		File styleDataFile = writeTempStyleFile(plotDataFile.getAbsolutePath());

		MapStyle mapStyle = styleReader.readMapStyle(styleDataFile.getAbsolutePath());

		SlotStyle sStyle = mapStyle.getDataStyle().getSlotStyle(-1);
		PlotStyle actualPlotStyle = (PlotStyle) sStyle.getPlotStyles().iterator().next();
		PlotBuilder actualPlotBuilder = actualPlotStyle.getPlotBuilder();
		PlotBuilder expectedPlotBuilder = getExpectedPlotBuilder();

		assertEquals(expectedPlotBuilder, actualPlotBuilder);

		plotDataFile.delete();
		styleDataFile.delete();
	}

	@Test
	public void testReadStyleURI() throws IOException
	{
		StyleIO styleReader = new StyleIOGSS();

		File plotDataFile = writeTempPlotDataFile();
		File styleDataFile = writeTempStyleFile(plotDataFile.getAbsolutePath());

		FileReader fileReader = new FileReader(styleDataFile);

		MapStyle mapStyle = styleReader.readMapStyle(fileReader, styleDataFile.toURI().toString());

		SlotStyle sStyle = mapStyle.getDataStyle().getSlotStyle(-1);
		PlotStyle actualPlotStyle = (PlotStyle) sStyle.getPlotStyles().iterator().next();
		PlotBuilder actualPlotBuilder = actualPlotStyle.getPlotBuilder();
		PlotBuilder expectedPlotBuilder = getExpectedPlotBuilder();

		assertEquals(expectedPlotBuilder, actualPlotBuilder);

		plotDataFile.delete();
		styleDataFile.delete();
	}

	// TODO probably eventually want a test here, since I allow a person to pass a URI to read file
	@Test
	public void testReadStyleURIWeb() throws IOException
	{
	}

	@Test
	public void testReadStyleRelativePath() throws IOException
	{
		StyleIO styleReader = new StyleIOGSS();

		File plotDataFile = writeTempPlotDataFile();
		File styleDataFile = writeTempStyleFile(plotDataFile.getName());

		MapStyle mapStyle = styleReader.readMapStyle(styleDataFile.getAbsolutePath());

		SlotStyle sStyle = mapStyle.getDataStyle().getSlotStyle(-1);
		PlotStyle actualPlotStyle = (PlotStyle) sStyle.getPlotStyles().iterator().next();
		PlotBuilder actualPlotBuilder = actualPlotStyle.getPlotBuilder();
		PlotBuilder expectedPlotBuilder = getExpectedPlotBuilder();

		assertEquals(expectedPlotBuilder, actualPlotBuilder);

		plotDataFile.delete();
		styleDataFile.delete();
	}
}
