package ioTests.styles;

import gview.layout.PlotBuilder;
import gview.layout.PlotBuilderAnnotation;
import gview.layout.PlotBuilderPoints;
import gview.layout.PlotBuilderRange;
import gview.layout.PlotDrawerBar;
import gview.layout.PlotDrawerLine;
import gview.style.datastyle.PlotStyle;
import gview.style.io.gss.coders.GSSWriter;
import gview.style.io.gss.coders.PlotCoder;
import gview.style.io.gss.exceptions.MalformedDeclarationException;
import gview.style.io.gss.exceptions.MalformedPlotDataException;
import gview.style.io.gss.exceptions.ParseException;
import gview.style.io.gss.exceptions.UnknownPlotDataFormatException;
import gview.style.io.gss.exceptions.UnknownPlotTypeException;

import java.awt.BasicStroke;
import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

public class PlotCoderTest
{
	private PlotCoder coder;
	
	@Before
	public void setup()
	{
		coder = new PlotCoder();
	}
	
	@Test
	public void testDecode() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		PlotStyle expectedStyle;
		
		LexicalUnit currUnit;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setPaint(Color.red);
		
		coder.decodeProperty(workingStyle, "color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testDecodePlotType() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		PlotStyle expectedStyle;
		
		LexicalUnit currUnit;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("line")));
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setPlotDrawer(new PlotDrawerLine(new BasicStroke(0.5f)));
		
		coder.decodeProperty(workingStyle, "type", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("bar")));
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setPlotDrawer(new PlotDrawerBar());
		
		coder.decodeProperty(workingStyle, "type", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testDecodeGrid() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		PlotStyle expectedStyle;
		
		LexicalUnit currUnit;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("0")));
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setGridLines(0);
		
		coder.decodeProperty(workingStyle, "grid-lines", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("1")));
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setGridLines(1);
		
		coder.decodeProperty(workingStyle, "grid-lines", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setGridPaint(Color.red);
		
		coder.decodeProperty(workingStyle, "grid-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"blue\")")));
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setGridPaint(Color.blue);
		
		coder.decodeProperty(workingStyle, "grid-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test(expected=MalformedDeclarationException.class)
	public void testDecodeGridLinesNegative() throws CloneNotSupportedException, ParseException, CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		
		LexicalUnit currUnit;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("-1")));
		
		coder.decodeProperty(workingStyle, "grid-lines", currUnit, null);
	}
	
	@Test
	public void testDecodeDataFileAbsolute() throws IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		PlotStyle expectedStyle;
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("0,0.5"); // format base,value
		writer.println("1,0.75");
		writer.println("2,1.0");
		writer.println("3,2.0");
		writer.close();
		
		// setup expected plotbuilder
		PlotBuilderPoints expectedPlotBuilder = new PlotBuilderPoints();
		expectedPlotBuilder.addPoint(0,0.5);
		expectedPlotBuilder.addPoint(1,0.75);
		expectedPlotBuilder.addPoint(2,1.0);
		expectedPlotBuilder.addPoint(3,2.0);
		expectedPlotBuilder.autoScale();
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
				dataFile.getAbsolutePath() + "\")")));
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setPlotBuilder(expectedPlotBuilder);
		
		// decode values into workingStyle
		coder.decodeProperty(workingStyle, "data", currUnit, dataFile.toURI().toString());
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test(expected=MalformedPlotDataException.class)
	public void testDecodeDataFileNotRange() throws IOException, CloneNotSupportedException, ParseException
	{
		// tests attempting to interpret a file that's not a range plot type as a range plot type
		
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("0,0.5"); // format base,value
		writer.println("1,0.75");
		writer.println("2,1.0");
		writer.println("3,2.0");
		writer.close();
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"range\",\"" +
				dataFile.getName() + "\")")));
		
		// decode values into workingStyle
		coder.decodeProperty(workingStyle, "data", currUnit, dataFile.toURI().toString());
	}
	
	@Test(expected=UnknownPlotDataFormatException.class)
	public void testDecodeDataUnknownType() throws IOException, CloneNotSupportedException, ParseException
	{
		// tests attempting to decode plot data from an unknown type
		
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("0,10,0.5"); // format base,value
		writer.println("10,20,0.75");
		writer.println("20,30,1.0");
		writer.println("30,40,2.0");
		writer.close();
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"unknown\",\"" +
				dataFile.getName() + "\")")));
		
		// decode values into workingStyle
		coder.decodeProperty(workingStyle, "data", currUnit, dataFile.toURI().toString());
	}
	
	@Test(expected=MalformedPlotDataException.class)
	public void testDecodeDataFileNotPoint() throws IOException, CloneNotSupportedException, ParseException
	{
		// tests attempting to interpret a file that's not a point plot type as a point plot type
		
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("0,10,0.5"); // format base,value
		writer.println("10,20,0.75");
		writer.println("20,30,1.0");
		writer.println("30,40,2.0");
		writer.close();
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
				dataFile.getName() + "\")")));
		
		// decode values into workingStyle
		coder.decodeProperty(workingStyle, "data", currUnit, dataFile.toURI().toString());
	}
	
	@Test
	public void testDecodeDataFileRange() throws IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		PlotStyle expectedStyle;
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("0,10,0.5"); // format base,value
		writer.println("10,20,0.75");
		writer.println("20,30,1.0");
		writer.println("30,40,2.0");
		writer.close();
		
		// setup expected plotbuilder
		PlotBuilderRange expectedPlotBuilder = new PlotBuilderRange();
		expectedPlotBuilder.addRange(0,10,0.5);
		expectedPlotBuilder.addRange(10,20,0.75);
		expectedPlotBuilder.addRange(20,30,1.0);
		expectedPlotBuilder.addRange(30,40,2.0);
		expectedPlotBuilder.autoScale();
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"range\",\"" +
				dataFile.getName() + "\")")));
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setPlotBuilder(expectedPlotBuilder);
		
		// decode values into workingStyle
		coder.decodeProperty(workingStyle, "data", currUnit, dataFile.toURI().toString());
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testDecodeDataFileAnnotation() throws IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		PlotStyle expectedStyle;
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("locus_tag,TAG01,0.5"); // annotation type, annotation value, data value
		writer.println("locus_tag,TAG02,0.6");
		writer.println("locus_tag,TAG03,0.7");
		writer.println("locus_tag,TAG04,0.8");
		writer.close();
		
		// setup expected plotbuilder
		PlotBuilderAnnotation expectedPlotBuilder = new PlotBuilderAnnotation();
		expectedPlotBuilder.addAnnotationValue("locus_tag", "TAG01", 0.5);
		expectedPlotBuilder.addAnnotationValue("locus_tag", "TAG02", 0.6);
		expectedPlotBuilder.addAnnotationValue("locus_tag", "TAG03", 0.7);
		expectedPlotBuilder.addAnnotationValue("locus_tag", "TAG04", 0.8);
		expectedPlotBuilder.autoScale();
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"annotation\",\"" +
				dataFile.getName() + "\")")));
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setPlotBuilder(expectedPlotBuilder);
		
		// decode values into workingStyle
		coder.decodeProperty(workingStyle, "data", currUnit, dataFile.toURI().toString());
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test(expected=MalformedPlotDataException.class)
	public void testDecodeDataFileNotAnnotation() throws IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		PlotStyle expectedStyle;
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("0,0.5"); // format base,value
		writer.println("1,0.75");
		writer.println("2,1.0");
		writer.println("3,2.0");
		writer.close();
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"annotation\",\"" +
				dataFile.getName() + "\")")));
		
		// decode values into workingStyle
		coder.decodeProperty(workingStyle, "data", currUnit, dataFile.toURI().toString());
	}
	
	@Test
	public void testDecodeDataFileRelative() throws IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		PlotStyle expectedStyle;
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("0,0.5"); // format base,value
		writer.println("1,0.75");
		writer.println("2,1.0");
		writer.println("3,2.0");
		writer.close();
		
		// setup expected plotbuilder
		PlotBuilderPoints expectedPlotBuilder = new PlotBuilderPoints();
		expectedPlotBuilder.addPoint(0,0.5);
		expectedPlotBuilder.addPoint(1,0.75);
		expectedPlotBuilder.addPoint(2,1.0);
		expectedPlotBuilder.addPoint(3,2.0);
		expectedPlotBuilder.autoScale();
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
				dataFile.getName() + "\")")));
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setPlotBuilder(expectedPlotBuilder);
		
		// decode values into workingStyle
		coder.decodeProperty(workingStyle, "data", currUnit, dataFile.toURI().toString());
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testDecodeDataFileEmpty() throws IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotStyle workingStyle = new PlotStyle();
		PlotStyle expectedStyle;
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
				dataFile.getAbsolutePath() + "\")")));
		
		PlotBuilderPoints expectedPlotBuilder = new PlotBuilderPoints();
		expectedPlotBuilder.autoScale();
		
		// setup expected style
		expectedStyle = (PlotStyle)workingStyle.clone();
		expectedStyle.setPlotBuilder(expectedPlotBuilder);
		
		// decode values into workingStyle
		coder.decodeProperty(workingStyle, "data", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testEncode()
	{
		PlotCoder plotCoder = new PlotCoder();
		PlotStyle plotStyle = new PlotStyle();
		
		String expectedEncoding;
		
		StringWriter expectedStringWriter;
		GSSWriter expectedGssWriter;
		
		StringWriter actualStringWriter;
		GSSWriter actualEncodingGSS;
		
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		String baseSelector = "slot#1";
		
		// setup feature set 
		expectedGssWriter.startSelector(baseSelector + " " + "plot");
		expectedGssWriter.writeProperty("color", "color(\"blue\")");
		expectedGssWriter.endSelector();
		expectedEncoding = expectedStringWriter.toString();
		
		// setup map
		plotStyle.setPaint(Color.blue);
		
		plotCoder.encodeStyle(plotStyle, baseSelector, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
	}
}
