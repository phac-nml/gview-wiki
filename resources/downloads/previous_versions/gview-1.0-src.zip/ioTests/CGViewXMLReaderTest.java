package ioTests;

import static org.junit.Assert.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;

import junit.framework.Assert;

import gview.data.GenomeData;
import gview.data.readers.CGViewXMLReader;
import gview.data.readers.GViewDataParseException;
import gview.data.readers.GViewFileData;
import gview.data.readers.GViewFileReader;
import gview.layout.feature.FeatureShapeRealizer;
import gview.map.effects.OutsideEffect;
import gview.map.effects.ShapeEffectRenderer;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.LabelStyle;
import gview.style.datastyle.SlotItemStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.items.BackboneStyle;

import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.FeatureHolder;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.symbol.Location;
import org.biojava.bio.symbol.RangeLocation;
import org.junit.Before;
import org.junit.Test;

public class CGViewXMLReaderTest
{
	private static final ShapeEffectRenderer noShading = ShapeEffectRenderer.BASIC_RENDERER;
	private static final ShapeEffectRenderer shading = new OutsideEffect(new Color(0,0,0,128));
	
	private CGViewXMLReader cgviewReader;
	private double delta = 0.0000001;
	
	@Before
	public void setup()
	{
		cgviewReader = new CGViewXMLReader();
	}
	
	// expect an exception for 0 sequence length
	@Test(expected=GViewDataParseException.class)
	public void testCGViewElementZeroLength() throws IOException, GViewDataParseException
	{
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"0\">\n" +
				"</cgview>"
				);
		
		GViewFileReader.read(xmlReader, cgviewReader);
	}
	
	// expect an exception for negative sequence length
	@Test(expected=GViewDataParseException.class)
	public void testCGViewElementNegativeLength() throws IOException, GViewDataParseException
	{
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"0\">\n" +
				"</cgview>"
				);
		
		GViewFileReader.read(xmlReader, cgviewReader);
	}
	
	// expect an exception for no listed sequence length
	@Test(expected=GViewDataParseException.class)
	public void testCGViewElementNoSequenceLength() throws IOException, GViewDataParseException
	{
		StringReader xmlReader = new StringReader(
				"<cgview>\n" +
				"</cgview>"
				);
		
		GViewFileReader.read(xmlReader, cgviewReader);
	}
	
	@Test
	public void testCGViewElementNoProperties() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"1\">\n" +
				"</cgview>"
				);
		
		GViewFileData cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		Assert.assertNotNull(cgviewData);
		
		genomeData = cgviewData.getGenomeData();
		mapStyle = cgviewData.getMapStyle();
		
		Assert.assertNotNull(genomeData);
		Assert.assertNotNull(mapStyle);
		
		Assert.assertEquals(1, genomeData.getSequenceLength());
		
		dataStyle = mapStyle.getDataStyle();
		assertNotNull(dataStyle);
		
		// should be no slots
		assertEquals(0, dataStyle.getLowerSlot());
		assertEquals(0, dataStyle.getUpperSlot());
	}
	
	@Test
	public void testCGViewElementProperties() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		GlobalStyle globalStyle = null;
		BackboneStyle backboneStyle = null;
		
		// test color green
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneColor=\"green\">\n" +
				"</cgview>"
				);
		
		GViewFileData cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		Assert.assertNotNull(cgviewData);
		
		genomeData = cgviewData.getGenomeData();
		mapStyle = cgviewData.getMapStyle();
		
		Assert.assertNotNull(genomeData);
		Assert.assertNotNull(mapStyle);
		
		Assert.assertEquals(10, genomeData.getSequenceLength());
		
		dataStyle = mapStyle.getDataStyle();
		assertNotNull(dataStyle);
		
		// should be no slots
		assertEquals(0, dataStyle.getLowerSlot());
		assertEquals(0, dataStyle.getUpperSlot());
		
		globalStyle = mapStyle.getGlobalStyle();
		assertNotNull(globalStyle);
		
		backboneStyle = globalStyle.getBackboneStyle();
		assertNotNull(backboneStyle);
		
		assertEquals(new Color(0,128,0), backboneStyle.getPaint());
		
		// arrowheadLength
		
		// test backbone color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneColor=\"blue\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.blue, mapStyle.getGlobalStyle().getBackboneStyle().getPaint());
		
		// test backboneRadius
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneRadius=\"10.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(10.0*Math.PI*2, mapStyle.getGlobalStyle().getInitialBackboneLength(), delta); // setting radius should set the "backboneLength" in gview
		
		// test backboneRadius
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneRadius=\"550.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(550.0*Math.PI*2, mapStyle.getGlobalStyle().getInitialBackboneLength(), delta);
		
		// test backbone thickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneThickness=\"15.2\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(15.2, mapStyle.getGlobalStyle().getBackboneStyle().getThickness(), delta);
		
		// test backbone thickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneThickness=\"xx-large\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(8.0, mapStyle.getGlobalStyle().getBackboneStyle().getThickness(), delta);
		
		// test background color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backgroundColor=\"white\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.white, mapStyle.getGlobalStyle().getBackgroundPaint());
		
		// test background color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backgroundColor=\"blue\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.blue, mapStyle.getGlobalStyle().getBackgroundPaint());
		
		// borderColor?
		
		// test featureSlotSpacing
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" featureSlotSpacing=\"15.5\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(15.5, mapStyle.getGlobalStyle().getSlotSpacing(), delta);
		
		// test featureSlotSpacing
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" featureSlotSpacing=\"20.5\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(20.5, mapStyle.getGlobalStyle().getSlotSpacing(), delta);
		
		// featureThickness? (default thickness of slots)
		
		// giveFeaturePositions (add values to label)
		
		// height
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" height=\"100\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(100.0, mapStyle.getGlobalStyle().getDefaultHeight(), delta);
		
		// height
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" height=\"150\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(150.0, mapStyle.getGlobalStyle().getDefaultHeight(), delta);
		
		// isLinear?
		
		// longTickColor
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" longTickColor=\"blue\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.blue, mapStyle.getGlobalStyle().getRulerStyle().getMajorTickPaint());
		
		// longTickColor
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" longTickColor=\"white\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.white, mapStyle.getGlobalStyle().getRulerStyle().getMajorTickPaint());
		
		// minimumFeatureLength
		
		// moveInnerLabelsToOuter?
		
		// origin
		
		// test rulerFont
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" rulerFont=\"SansSerif, plain, 18\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(new Font("SansSerif", Font.PLAIN, 18), mapStyle.getGlobalStyle().getRulerStyle().getFont());
		
		// test rulerFont
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" rulerFont=\"SansSerif, bold, 20\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(new Font("SansSerif", Font.BOLD, 20), mapStyle.getGlobalStyle().getRulerStyle().getFont());
		
		// test ruler font color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" rulerFontColor=\"white\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.white, mapStyle.getGlobalStyle().getRulerStyle().getTextPaint());
		
		// test ruler font color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" rulerFontColor=\"blue\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.blue, mapStyle.getGlobalStyle().getRulerStyle().getTextPaint());
		
		// rulerPadding?
		
		// rulerUnits?
		
		// shortTickColor
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" shortTickColor=\"blue\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.blue, mapStyle.getGlobalStyle().getRulerStyle().getMinorTickPaint());
		
		// shortTickColor
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" shortTickColor=\"white\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.white, mapStyle.getGlobalStyle().getRulerStyle().getMinorTickPaint());
		
		// shortTickThickness
		
		// showBorder?
		
		// showShading
		
		// showWarning?
		
		// tickDensity
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickDensity=\"0.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(0.0, mapStyle.getGlobalStyle().getRulerStyle().getTickDensity(), delta);
		
		// tickDensity
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickDensity=\"0.5\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(0.5, mapStyle.getGlobalStyle().getRulerStyle().getTickDensity(), delta);
		
		// tickDensity
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickDensity=\"1.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(1.0, mapStyle.getGlobalStyle().getRulerStyle().getTickDensity(), delta);
		
		// test tickLength
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickLength=\"10.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(10.0, mapStyle.getGlobalStyle().getRulerStyle().getMajorTickLength(), delta);
		
		// test tickLength
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickLength=\"xxx-large\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(11.0, mapStyle.getGlobalStyle().getRulerStyle().getMajorTickLength(), delta);
		
		// test tickThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickThickness=\"5.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(5.0, mapStyle.getGlobalStyle().getRulerStyle().getTickThickness(), delta);
		
		// test tickThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickThickness=\"x-large\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(3.0, mapStyle.getGlobalStyle().getRulerStyle().getTickThickness(), delta);
		
		// title?
		
		// titleFontColor
		
		// titleFont
		
		// warningFont
		
		// warningFontColor
		
		// width
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" width=\"100\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(100.0, mapStyle.getGlobalStyle().getDefaultWidth(), delta);
		
		// zeroTickColor
	}
	
	/**
	 * Given the passed property in the cgview tag (for a label test), gets the corresponding LabelStyle
	 * @param cgviewProperty  The cgview property string to test out.
	 * @return  The corresponding LabelStyle.
	 * @throws GViewDataParseException 
	 * @throws IOException 
	 */
	private LabelStyle getStyleForLabelTest(String cgviewProperty) throws IOException, GViewDataParseException
	{
		LabelStyle labelStyle = null;
		
		SlotStyle slotStyle = null;
		FeatureHolderStyle featureHolderStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\" " + cgviewProperty + ">" +
		"<featureSlot strand=\"direct\">" +
			"<feature label=\"the_label\">" +
				"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		labelStyle = featureHolderStyle.getLabelStyle();
		
		return labelStyle;
	}
	
	@Test
	public void testCGViewLabels() throws IOException, GViewDataParseException
	{
		LabelStyle labelStyle;
		
		// globalLabel
		labelStyle = getStyleForLabelTest("globalLabel=\"false\"");
		assertEquals(false, labelStyle.showLabels());
		
		// globalLabel
		labelStyle = getStyleForLabelTest("globalLabel=\"true\"");
		assertEquals(true, labelStyle.showLabels());
		
		// globalLabel
		labelStyle = getStyleForLabelTest("globalLabel=\"auto\"");
		assertEquals(true, labelStyle.showLabels());
		
		// globalLabelColor
		labelStyle = getStyleForLabelTest("globalLabelColor=\"white\"");
		assertEquals(Color.white, labelStyle.getTextPaint());
		
		// globalLabelColor
		labelStyle = getStyleForLabelTest("globalLabelColor=\"blue\"");
		assertEquals(Color.blue, labelStyle.getTextPaint());
		
		// labelFont
		labelStyle = getStyleForLabelTest("labelFont=\"SansSerif, plain, 18\"");
		assertEquals(new Font("SansSerif", Font.PLAIN, 18), labelStyle.getFont());
		
		// labelFont
		labelStyle = getStyleForLabelTest("labelFont=\"SansSerif, bold, 11\"");
		assertEquals(new Font("SansSerif", Font.BOLD, 11), labelStyle.getFont());
		
		// labelLineLength
		
		// labelLineThickness
		labelStyle = getStyleForLabelTest("labelLineThickness=\"10\"");
		assertEquals(10, labelStyle.getLineThickness(), delta);
		
		// labelLineThickness
		labelStyle = getStyleForLabelTest("labelLineThickness=\"15.5\"");
		assertEquals(15.5, labelStyle.getLineThickness(), delta);
		
		// labelPlacementQuality?
		
		// labelsToKeep?
		
		// useColoredLabelBackgrounds
		labelStyle = getStyleForLabelTest("useColoredLabelBackgrounds=\"true\" globalLabelColor=\"blue\""); // need to set globalLabelColor for this test
		assertEquals(Color.white, labelStyle.getTextPaint()); // text color should be "white" on a "globalLabelColor" background
		assertEquals(Color.blue, labelStyle.getBackgroundPaint());
		assertFalse(labelStyle.isAutoLabelLinePaint());
		assertEquals(Color.blue, labelStyle.getLabelLinePaint());
		
		// useColoredLabelBackgrounds
		labelStyle = getStyleForLabelTest("useColoredLabelBackgrounds=\"true\" globalLabelColor=\"yellow\""); // need to set globalLabelColor for this test
		assertEquals(Color.white, labelStyle.getTextPaint()); // text color should be "white" on a "globalLabelColor" background
		assertEquals(Color.yellow, labelStyle.getBackgroundPaint());
		assertFalse(labelStyle.isAutoLabelLinePaint());
		assertEquals(Color.yellow, labelStyle.getLabelLinePaint());
		
		// useColoredLabelBackgrounds
		labelStyle = getStyleForLabelTest("useColoredLabelBackgrounds=\"false\" globalLabelColor=\"yellow\""); // need to set globalLabelColor for this test
		assertEquals(Color.yellow, labelStyle.getTextPaint());
		
		// useColoredLabelBackgrounds
		labelStyle = getStyleForLabelTest("useColoredLabelBackgrounds=\"false\" globalLabelColor=\"blue\""); // need to set globalLabelColor for this test
		assertEquals(Color.blue, labelStyle.getTextPaint());
		
		// useInnerLabels
	}
	
	// should have exception, as there is no strand listed
	@Test(expected=GViewDataParseException.class)
	public void testFeatureSlotNoStrand() throws IOException, GViewDataParseException
	{		
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot>\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		GViewFileReader.read(xmlReader, cgviewReader);
	}
	
	@Test
	public void testFeatureSlotOrder() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		SlotStyle slotStyle = null;
		
		// test slot style direct strand
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		GViewFileData cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		Assert.assertNotNull(cgviewData);
		
		genomeData = cgviewData.getGenomeData();
		mapStyle = cgviewData.getMapStyle();
		
		Assert.assertNotNull(genomeData);
		Assert.assertNotNull(mapStyle);
		
		Assert.assertEquals(10, genomeData.getSequenceLength());
		
		dataStyle = mapStyle.getDataStyle();
		assertNotNull(dataStyle);
		
		// should be 1 slot, above backbone
		assertEquals(1, dataStyle.getUpperSlot());
		assertEquals(0, dataStyle.getLowerSlot());
		
		slotStyle = dataStyle.getSlotStyle(1);
		
		assertNotNull(slotStyle);
		
		
		// test slot style reverse strand
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"reverse\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		
		// should be 1 slot, below backbone
		assertEquals(0, dataStyle.getUpperSlot());
		assertEquals(-1, dataStyle.getLowerSlot());
		
		slotStyle = dataStyle.getSlotStyle(-1);
		assertNotNull(slotStyle);
		
		
		// test 1 slot above, 1 below
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
					"<featureSlot strand=\"reverse\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		
		// should be 1 slot, below backbone
		assertEquals(1, dataStyle.getUpperSlot());
		assertEquals(-1, dataStyle.getLowerSlot());
		
		slotStyle = dataStyle.getSlotStyle(-1);
		assertNotNull(slotStyle);
		
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);
		
		
		// test 2 above
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		
		// should be 1 slot, below backbone
		assertEquals(2, dataStyle.getUpperSlot());
		assertEquals(0, dataStyle.getLowerSlot());
		
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);
		
		slotStyle = dataStyle.getSlotStyle(2);
		assertNotNull(slotStyle);
		
		// test 2 below
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"reverse\">\n" +
					"</featureSlot>\n"+
					"<featureSlot strand=\"reverse\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		
		// should be 1 slot, below backbone
		assertEquals(0, dataStyle.getUpperSlot());
		assertEquals(-2, dataStyle.getLowerSlot());
		
		slotStyle = dataStyle.getSlotStyle(-1);
		assertNotNull(slotStyle);
		
		slotStyle = dataStyle.getSlotStyle(-2);
		assertNotNull(slotStyle);
	}
	
	@Test
	public void testFeatureSlotProperties() throws IOException, GViewDataParseException
	{
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		SlotStyle slotStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		
		// test featureThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\" featureThickness=\"10.0\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(10.0, slotStyle.getThickness(), delta);
		
		
		// test featureThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\" featureThickness=\"xxx-small\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(1.0, slotStyle.getThickness(), delta);
		
		
		// test showShading
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\" showShading=\"false\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(noShading, slotStyle.getShapeEffectRenderer());
		
		// test showShading
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\" showShading=\"true\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(shading, slotStyle.getShapeEffectRenderer());
	}
	
	/**
	 * Tests for and returns the single FeatureHolderStyle within the passed slot.  Assumes there exists only 1 FeatureHolderStyle.
	 * @param slotStyle  The SlotStyle to extract the FeatureHolderStyle from.
	 * @return  The first FeatureHolderStyle encountered.
	 */
	private FeatureHolderStyle getAndTestForFeatureHolderStyle(SlotStyle slotStyle)
	{
		FeatureHolderStyle holderStyle = null;
		
		assertNotNull(slotStyle);
		
		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		assertTrue(styleIter.hasNext());
		
		while (styleIter.hasNext() && holderStyle == null)
		{
			SlotItemStyle currItemStyle = styleIter.next();
			assertNotNull(currItemStyle);
			
			if (currItemStyle instanceof FeatureHolderStyle)
			{
				holderStyle = (FeatureHolderStyle)currItemStyle;
			}
		}
		
		assertNotNull(holderStyle);
		
		return holderStyle;
	}
	
	/**
	 * Tests to make sure only a single feature exists in the passed FeatureHolder, and returns this feature.
	 * @param holder  The FeatureHolder to check.
	 * @return  The single feature in this FeatureHolder.
	 */
	private Feature getAndTestForSingleFeatureInFeatureHolder(FeatureHolder holder)
	{
		Feature feature = null;
		
		assertNotNull(holder);
		
		Iterator<Feature> featuresIter = holder.features();
		assertNotNull(featuresIter);
		assertTrue(featuresIter.hasNext());
		
		feature = featuresIter.next();
		
		assertNotNull(feature);
		assertFalse(featuresIter.hasNext());
		
		return feature;
	}
	
	/**
	 * Performs the test read for testFeatureProperties, using the passed property string.
	 * @param featurePropertyString  A string defining the property to test.
	 * @return  The FeatureHolderStyle for the particular feature.
	 * @throws GViewDataParseException 
	 * @throws IOException 
	 */
	private FeatureHolderStyle performTestForFeatureProperties(String featurePropertyString) throws IOException, GViewDataParseException
	{
		SlotStyle slotStyle = null;
		FeatureHolderStyle featureHolderStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\">" +
		"<featureSlot strand=\"direct\">" +
			"<feature " + featurePropertyString + ">" +
				"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		return featureHolderStyle;
	}
	
	/**
	 * Test the case of having multiple features, with different labels.  Make sure label text gets set correctly.
	 * @throws IOException
	 * @throws GViewDataParseException
	 */
	@Test
	public void testFeaturePropertiesLabelMultipleFeatures() throws IOException, GViewDataParseException
	{
		SlotStyle slotStyle = null;
		
		SlotItemStyle currItemStyle;
		
		GViewFileData cgviewData;
		
		String location1 = "start=\"1\" stop=\"2\"";
		String location2 = "start=\"2\" stop=\"4\"";
		Location location1Obj = new RangeLocation(1,2);
		Location location2Obj = new RangeLocation(2,4);
		
		String label1 = "label(1,2)";
		String label2 = "label(2,4)";
		
		boolean finishedFeature1 = false;
		boolean finishedFeature2 = false;
		
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\">" +
		"<featureSlot strand=\"direct\">" +
			"<feature label=\"" + label1 + "\">" +
				"<featureRange " + location1 + ">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
			"<feature label=\"" + label2 + "\">" +
				"<featureRange " + location2 + ">"+
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		
		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		// we cannot predict what order the FeatureHolderStyles (and so the corresponding features) will be selected from the iterator
		// so, we must handle both cases (both features)
		// one of the features
		{
			assertTrue(styleIter.hasNext());
			currItemStyle = styleIter.next();
			assertNotNull(currItemStyle);
			FeatureHolderStyle featureHolderStyle = null;
			
			FeatureFilter filterFromHolder;
			FeatureFilter.ByFeature filterFromHolderByFeature;
			Feature featureFromFeatureHolder;
			
			Location currentLocationObj = null;
			
			assertTrue(currItemStyle instanceof FeatureHolderStyle);
			featureHolderStyle = (FeatureHolderStyle)currItemStyle;
			
			// got featureHolderStyle for this feature, filter out the feature
			filterFromHolder = featureHolderStyle.getFilter();
			assertTrue(filterFromHolder instanceof FeatureFilter.ByFeature); // filter should filter out only a single feature
			filterFromHolderByFeature = (FeatureFilter.ByFeature)filterFromHolder;
			featureFromFeatureHolder = filterFromHolderByFeature.getFeature();
			
			// handle the correct feature
			currentLocationObj = featureFromFeatureHolder.getLocation();
			if (location1Obj.equals(currentLocationObj)) // if this is location 1
			{
				if (finishedFeature1)
				{
					fail("Already handled feature1");
				}
				else
				{
					// make sure label is set properly for FeatureHolderStyle for the feature
					assertEquals(label1, featureHolderStyle.getLabelStyle().getLabelExtractor().extractText(
							featureFromFeatureHolder)); // test that label is set properly
					
					finishedFeature1 = true;
				}
			}
			else if (location2Obj.equals(currentLocationObj))
			{
				if (finishedFeature2)
				{
					fail("Already handled feature2");
				}
				else
				{
					// make sure label is set properly for FeatureHolderStyle for the feature
					assertEquals(label2, featureHolderStyle.getLabelStyle().getLabelExtractor().extractText(
							featureFromFeatureHolder)); // test that label is set properly
					
					finishedFeature2 = true;
				}
			}
			else
			{
				fail("Location=" + currentLocationObj + " not one of the valid options.");
			}
		}
		
		// the other feature
		{
			assertTrue(styleIter.hasNext());
			currItemStyle = styleIter.next();
			assertNotNull(currItemStyle);
			FeatureHolderStyle featureHolderStyle = null;
			
			FeatureFilter filterFromHolder;
			FeatureFilter.ByFeature filterFromHolderByFeature;
			Feature featureFromFeatureHolder;
			
			Location currentLocationObj = null;
			
			assertTrue(currItemStyle instanceof FeatureHolderStyle);
			featureHolderStyle = (FeatureHolderStyle)currItemStyle;
			
			// got featureHolderStyle for this feature, filter out the feature
			filterFromHolder = featureHolderStyle.getFilter();
			assertTrue(filterFromHolder instanceof FeatureFilter.ByFeature); // filter should filter out only a single feature
			filterFromHolderByFeature = (FeatureFilter.ByFeature)filterFromHolder;
			featureFromFeatureHolder = filterFromHolderByFeature.getFeature();
			
			// handle the correct feature
			currentLocationObj = featureFromFeatureHolder.getLocation();
			if (location1Obj.equals(currentLocationObj)) // if this is location 1
			{
				if (finishedFeature1)
				{
					fail("Already handled feature1");
				}
				else
				{
					// make sure label is set properly for FeatureHolderStyle for the feature
					assertEquals(label1, featureHolderStyle.getLabelStyle().getLabelExtractor().extractText(
							featureFromFeatureHolder)); // test that label is set properly
					
					finishedFeature1 = true;
				}
			}
			else if (location2Obj.equals(currentLocationObj))
			{
				if (finishedFeature2)
				{
					fail("Already handled feature2");
				}
				else
				{
					// make sure label is set properly for FeatureHolderStyle for the feature
					assertEquals(label2, featureHolderStyle.getLabelStyle().getLabelExtractor().extractText(
							featureFromFeatureHolder)); // test that label is set properly
					
					finishedFeature2 = true;
				}
			}
			else
			{
				fail("Location=" + currentLocationObj + " not one of the valid options.");
			}
		}
	}
	
	@Test
	public void testFeaturePropertiesLabel() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		FeatureFilter filterFromHolder;
		FeatureFilter.ByFeature filterFromHolderByFeature;
		Feature featureFromFeatureHolder;
		
		// test label text
		featureHolderStyle = performTestForFeatureProperties("label=\"the_label\"");
		filterFromHolder = featureHolderStyle.getFilter();
		assertTrue(filterFromHolder instanceof FeatureFilter.ByFeature); // filter should filter out only a single feature
		filterFromHolderByFeature = (FeatureFilter.ByFeature)filterFromHolder;
		featureFromFeatureHolder = filterFromHolderByFeature.getFeature();
		assertEquals("the_label", featureHolderStyle.getLabelStyle().getLabelExtractor().extractText(
				featureFromFeatureHolder)); // test that label is set properly
		
		// test label font
		featureHolderStyle = performTestForFeatureProperties("font=\"SansSerif, bold, 20\"");
		assertEquals(new Font("SansSerif", Font.BOLD, 20), featureHolderStyle.getLabelStyle().getFont());
		
		// test label font
		featureHolderStyle = performTestForFeatureProperties("font=\"SansSerif, italic, 18\"");
		assertEquals(new Font("SansSerif", Font.ITALIC, 18), featureHolderStyle.getLabelStyle().getFont());
		
		// test showLabel
		featureHolderStyle = performTestForFeatureProperties("label=\"the_label\" showLabel=\"true\""); // need to also set label
		assertEquals(true, featureHolderStyle.getLabelStyle().showLabels());
		
		// test showLabel
		featureHolderStyle = performTestForFeatureProperties("label=\"the_label\" showLabel=\"false\"");
		assertEquals(false, featureHolderStyle.getLabelStyle().showLabels());
	}
	
	@Test
	public void testFeaturePropertiesMouseover() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		FeatureFilter filterFromHolder;
		FeatureFilter.ByFeature filterFromHolderByFeature;
		Feature featureFromFeatureHolder;
		
		// test mouseover text
		featureHolderStyle = performTestForFeatureProperties("mouseover=\"the_mouseover_label\"");
		filterFromHolder = featureHolderStyle.getFilter();
		assertTrue(filterFromHolder instanceof FeatureFilter.ByFeature); // filter should filter out only a single feature
		filterFromHolderByFeature = (FeatureFilter.ByFeature)filterFromHolder;
		featureFromFeatureHolder = filterFromHolderByFeature.getFeature();
		assertEquals("the_mouseover_label", featureHolderStyle.getToolTipExtractor().extractText(
				featureFromFeatureHolder)); // test that label is set properly
	}
	
	@Test
	public void testFeatureProperties() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		// test color
		featureHolderStyle = performTestForFeatureProperties("color=\"white\"");
		assertEquals(Color.white, featureHolderStyle.getPaint());
		
		// test color
		featureHolderStyle = performTestForFeatureProperties("color=\"blue\"");
		assertEquals(Color.blue, featureHolderStyle.getPaint());
		
		// test decoration
		featureHolderStyle = performTestForFeatureProperties("decoration=\"arc\"");
		assertEquals(FeatureShapeRealizer.NO_ARROW, featureHolderStyle.getFeatureShapeRealizer());
		
		// test decoration
		featureHolderStyle = performTestForFeatureProperties("decoration=\"hidden\"");
		assertEquals(FeatureShapeRealizer.HIDDEN, featureHolderStyle.getFeatureShapeRealizer());
		
		// test decoration
		featureHolderStyle = performTestForFeatureProperties("decoration=\"clockwise-arrow\"");
		assertEquals(FeatureShapeRealizer.CLOCKWISE_ARROW, featureHolderStyle.getFeatureShapeRealizer());
		
		// test decoration
		featureHolderStyle = performTestForFeatureProperties("decoration=\"counterclockwise-arrow\"");
		assertEquals(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW, featureHolderStyle.getFeatureShapeRealizer());
		
		// test opacity
		featureHolderStyle = performTestForFeatureProperties("opacity=\"0.0\"");
		assertEquals(0.0, featureHolderStyle.getTransparency(), delta);
		
		// test opacity
		featureHolderStyle = performTestForFeatureProperties("opacity=\"0.5\"");
		assertEquals(0.5, featureHolderStyle.getTransparency(), delta);
		
		// test opacity
		featureHolderStyle = performTestForFeatureProperties("opacity=\"1.0\"");
		assertEquals(1.0, featureHolderStyle.getTransparency(), delta);
		
		// test proportion of thickness
		featureHolderStyle = performTestForFeatureProperties("proportionOfThickness=\"0.0\"");
		assertEquals(0.0, featureHolderStyle.getThickness(), delta);
		
		// test proportion of thickness
		featureHolderStyle = performTestForFeatureProperties("proportionOfThickness=\"0.5\"");
		assertEquals(0.5, featureHolderStyle.getThickness(), delta);
		
		// test proportion of thickness
		featureHolderStyle = performTestForFeatureProperties("proportionOfThickness=\"1.0\"");
		assertEquals(1.0, featureHolderStyle.getThickness(), delta);
		
		// test radiusAdjustment
		featureHolderStyle = performTestForFeatureProperties("radiusAdjustment=\"0.0\"");
		assertEquals(-1.0, featureHolderStyle.getHeightAdjust(), delta); // 0.0 translates to height adjust of -1.0
		
		// test radiusAdjustment
		featureHolderStyle = performTestForFeatureProperties("radiusAdjustment=\"0.5\"");
		assertEquals(0.0, featureHolderStyle.getHeightAdjust(), delta);
		
		// test radiusAdjustment
		featureHolderStyle = performTestForFeatureProperties("radiusAdjustment=\"1.0\"");
		assertEquals(1.0, featureHolderStyle.getHeightAdjust(), delta);
		
		// test showShading
		featureHolderStyle = performTestForFeatureProperties("showShading=\"false\"");
		assertEquals(noShading, featureHolderStyle.getShapeEffectRenderer());
		
		// test showShading
		featureHolderStyle = performTestForFeatureProperties("showShading=\"true\"");
		assertEquals(shading, featureHolderStyle.getShapeEffectRenderer());
	}
	
	/**
	 * Used to check if the feature created in <feature></feature> tags is the same as what would be contained in the created FeatureHolderStyle.
	 * @throws IOException
	 * @throws GViewDataParseException
	 */
	@Test
	public void testFeatureAndFeatureHolderStyle() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		SlotStyle slotStyle = null;
		FeatureHolderStyle featureHolderStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		Sequence sequence;
		FeatureHolder singleFeatureHolder;
		Feature featureFromPredefinedFilter;
		FeatureFilter filterFromHolder;
		FeatureFilter.ByFeature filterFromHolderByFeature;
		Feature featureFromFeatureHolder;
		
		// test feature defined, and style for that feature defined
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a location for a feature
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		genomeData = cgviewData.getGenomeData();
		assertNotNull(genomeData);
		
		sequence = genomeData.getSequence();
		assertNotNull(sequence);
		assertEquals(1, sequence.countFeatures()); // should be 1 feature on this sequence
		
		// get the single feature that was created on this sequence
		singleFeatureHolder = sequence.filter(new FeatureFilter.ContainedByLocation(new RangeLocation(1,2)));
		featureFromPredefinedFilter = getAndTestForSingleFeatureInFeatureHolder(singleFeatureHolder);
		
		assertNotNull(featureFromPredefinedFilter);
		assertEquals(new RangeLocation(1,2), featureFromPredefinedFilter.getLocation());
		
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		filterFromHolder = featureHolderStyle.getFilter();
		assertTrue(filterFromHolder instanceof FeatureFilter.ByFeature); // filter should filter out only a single feature
		
		filterFromHolderByFeature = (FeatureFilter.ByFeature)filterFromHolder;
		featureFromFeatureHolder = filterFromHolderByFeature.getFeature();
		
		// make sure the two features (from the pre-defined filter and from the feature holder style) are the same
		assertEquals(featureFromPredefinedFilter, featureFromFeatureHolder);
		
		
		// test feature defined, and style for that feature defined
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"4\" stop=\"5\">"+ // need featureRange here, otherwise we won't have a location for a feature
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		genomeData = cgviewData.getGenomeData();
		assertNotNull(genomeData);
		
		sequence = genomeData.getSequence();
		assertNotNull(sequence);
		assertEquals(1, sequence.countFeatures()); // should be 1 feature on this sequence
		
		// get the single feature that was created on this sequence
		singleFeatureHolder = sequence.filter(new FeatureFilter.ContainedByLocation(new RangeLocation(4,5)));
		featureFromPredefinedFilter = getAndTestForSingleFeatureInFeatureHolder(singleFeatureHolder);
		
		assertNotNull(featureFromPredefinedFilter);
		assertEquals(new RangeLocation(4,5), featureFromPredefinedFilter.getLocation());
		
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		filterFromHolder = featureHolderStyle.getFilter();
		assertTrue(filterFromHolder instanceof FeatureFilter.ByFeature); // filter should filter out only a single feature
		
		filterFromHolderByFeature = (FeatureFilter.ByFeature)filterFromHolder;
		featureFromFeatureHolder = filterFromHolderByFeature.getFeature();
		
		// make sure the two features (from the pre-defined filter and from the feature holder style) are the same
		assertEquals(featureFromPredefinedFilter, featureFromFeatureHolder);
	}
	
	/**
	 * Checks if the locations defined in <featureRange></featureRange> tags are properly set as the location for the Feature object in biojava
	 * @throws IOException
	 * @throws GViewDataParseException
	 */
	@Test
	public void testFeatureRangeLocations() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		Sequence sequence;
		
		Location expectedLocation;
		FeatureHolder singleFeatureHolder;
		Feature feature;

		// test single feature location
		expectedLocation = new RangeLocation(1,2);
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a location for a feature
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		genomeData = cgviewData.getGenomeData();
		assertNotNull(genomeData);
		
		sequence = genomeData.getSequence();
		assertNotNull(sequence);
		assertEquals(1, sequence.countFeatures()); // should be 1 feature on this sequence
		
		// get the single feature that was created on this sequence
		singleFeatureHolder = sequence.filter(new FeatureFilter.ContainedByLocation(new RangeLocation(1,2)));
		feature = getAndTestForSingleFeatureInFeatureHolder(singleFeatureHolder);
		
		assertNotNull(feature);
		assertEquals(expectedLocation, feature.getLocation());
		
		
		// test single feature location
		expectedLocation = new RangeLocation(5,10);
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"5\" stop=\"10\">"+ // need featureRange here, otherwise we won't have a location for a feature
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		genomeData = cgviewData.getGenomeData();
		assertNotNull(genomeData);
		
		sequence = genomeData.getSequence();
		assertNotNull(sequence);
		assertEquals(1, sequence.countFeatures()); // should be 1 feature on this sequence
		
		// get the single feature that was created on this sequence
		singleFeatureHolder = sequence.filter(new FeatureFilter.ContainedByLocation(new RangeLocation(5,10)));
		feature = getAndTestForSingleFeatureInFeatureHolder(singleFeatureHolder);
		
		assertNotNull(feature);
		assertEquals(expectedLocation, feature.getLocation());
		
		
		
		// test single feature location
		expectedLocation = (new RangeLocation(1,2)).union(new RangeLocation(4,7));
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a location for a feature
							"</featureRange>"+
							"<featureRange start=\"4\" stop=\"7\">"+ // need featureRange here, otherwise we won't have a location for a feature
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		genomeData = cgviewData.getGenomeData();
		assertNotNull(genomeData);
		
		sequence = genomeData.getSequence();
		assertNotNull(sequence);
		assertEquals(1, sequence.countFeatures()); // should be 1 feature on this sequence
		
		// get the single feature that was created on this sequence
		singleFeatureHolder = sequence.filter(new FeatureFilter.ContainedByLocation(new RangeLocation(1,7)));
		feature = getAndTestForSingleFeatureInFeatureHolder(singleFeatureHolder);
		
		assertNotNull(feature);
		assertEquals(expectedLocation, feature.getLocation());
	}
}
