package testapi;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.SimpleAnnotation;
import org.biojava.bio.seq.DNATools;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.RangeLocation;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.data.GenomeDataFactory;
import gview.data.Slot;
import gview.data.readers.GViewDataParseException;
import gview.data.readers.GViewFileData;
import gview.data.readers.GViewFileReader;
import gview.layout.feature.FeatureShapeRealizer;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.map.effects.HighlightEffect;
import gview.map.effects.ShapeEffectRenderer;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.StyleFactory;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.LabelStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.items.BackboneStyle;
import gview.style.items.RulerStyle;
import gview.style.items.TooltipStyle;
import gview.textextractor.AnnotationExtractor;
import gview.textextractor.FeatureTextExtractor;
import gview.textextractor.StringExtractor;

public class TestLabelPositions extends PFrame
{
	private static final long serialVersionUID = 271982459532677044L;

	public TestLabelPositions(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}

	private static MapStyle buildStyle()
	{
		/** Global Style **/

		MapStyle mapStyle = new MapStyle();

		// extract associated GlobalStyle from newly created MapStyle object
		GlobalStyle global = mapStyle.getGlobalStyle();

		// set initial height/width of the map
		global.setDefaultHeight(700);
		global.setDefaultWidth(700);

		global.setBackgroundPaint(Color.BLACK);

		// extract tooltip style from global style
		TooltipStyle tooltip = global.getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(0, 0, 1.0f, 0.5f));
		tooltip.setTextPaint(Color.WHITE);

		// extract style information dealing with the backbone
		BackboneStyle backbone = global.getBackboneStyle();
		backbone.setPaint(Color.GRAY.darker());
		backbone.setThickness(5.0);

		// extract information dealing with the ruler style
		RulerStyle ruler = global.getRulerStyle();
		ruler.setMajorTickLength(20.0);
		ruler.setTickThickness(3.0);
		ruler.setMinorTickPaint(Color.LIGHT_GRAY);
		ruler.setMajorTickPaint(Color.DARK_GRAY);
		ruler.setFont(new Font("SansSerif", Font.PLAIN, 12));
		ruler.setTextPaint(Color.WHITE);
		ruler.setTextBackgroundPaint(new Color(255,255,255,128));

		/** Slots **/

		// assumes mapStyle created as above

		// extract data style from map style
		DataStyle dataStyle = mapStyle.getDataStyle();

		// creates the first two slots
		SlotStyle positiveSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		positiveSlot.setThickness(30);
		positiveSlot.setShapeEffectRenderer(ShapeEffectRenderer.STANDARD_RENDERER);
		SlotStyle negativeSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER);
		negativeSlot.setThickness(30);
		negativeSlot.setShapeEffectRenderer(new HighlightEffect());

		/** FeatureHolderStyle **/

		FeatureTextExtractor textExtractor = new StringExtractor("the text\nthe text2\n", new AnnotationExtractor("product"));

		// creates a feature holder style in the first upper slot containing all the features
		FeatureHolderStyle positive = positiveSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positive.setTransparency(0.7f);
		positive.setToolTipExtractor(textExtractor);
		positive.setPaint(Color.BLUE);
		positive.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW);

		LabelStyle posLabels = positive.getLabelStyle();
		posLabels.setTextPaint(Color.BLUE);
		posLabels.setLabelExtractor(textExtractor);
		posLabels.setShowLabels(true);
		posLabels.setInitialLineLength(50);
		posLabels.setBackgroundPaint(new Color(0.5f, 0.5f, 0.5f, 0.5f));
		posLabels.setFont(new Font("SansSerif", Font.BOLD, 8));
		posLabels.setLabelLinePaint(Color.orange);
		posLabels.setAutoLabelLinePaint(false);

		// creates a holder containing all negative features in the first lower slot
		FeatureHolderStyle negativeFeatures = negativeSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeFeatures.setTransparency(0.7f);
		negativeFeatures.setToolTipExtractor(textExtractor);
		negativeFeatures.setPaint(Color.RED);
		negativeFeatures.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);

		LabelStyle negLabels = negativeFeatures.getLabelStyle();
		negLabels.setLabelExtractor(textExtractor);
		negLabels.setShowLabels(true);
		negLabels.setInitialLineLength(50);
		negLabels.setTextPaint(Color.BLUE);
		negLabels.setBackgroundPaint(new Color(0.5f, 0.5f, 0.5f, 0.5f));
		negLabels.setFont(new Font("SansSerif", Font.BOLD, 8));

		return mapStyle;
	}

	private static GenomeData buildData()
	{
		GenomeData data = null;

		try
		{
			Sequence dna = DNATools
					.createDNASequence(
							"atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatga", "dna_1");

			Annotation ann = new SimpleAnnotation();

			StrandedFeature.Template ft = new StrandedFeature.Template();
			ft.annotation = ann;
			ft.type = "test";
			ft.source = "testsource";
			ft.strand = StrandedFeature.POSITIVE;

			// for (int start = 0; start < dna.length(); start+=10)
			// {
			// ft.location = new RangeLocation(start,(int) (start + 10));
			// ann.setProperty("product", "product +" + start);
			// dna.createFeature(ft);
			// }
			//			
			// ft.strand = StrandedFeature.NEGATIVE;
			//			
			// for (int start = 0; start < dna.length(); start+=10)
			// {
			// ft.location = new RangeLocation(start,(int) (start + 10));
			// ann.setProperty("product", "product -" + start);
			// dna.createFeature(ft);
			// }

			ft.location = new RangeLocation(50, (50 + 10));
			ann.setProperty("product", "product +" + 50);
			dna.createFeature(ft);

			data = GenomeDataFactory.createGenomeData(dna);
			System.out.println(data.getSequenceLength());
		}
		catch (IllegalSymbolException ex)
		{
			ex.printStackTrace();
		}
		catch (BioException be)
		{
			be.printStackTrace();
		}

		return data;
	}

	// a test of creating a map
	public static void main(String[] args)
	{
		// create data, style, and layout
		// these should probably use the respective readers to read in from a file
		GViewFileData fileData;
		try
		{
			fileData = GViewFileReader.read("testfiles/R_denitrificans.gbk");
	
			GenomeData data = fileData.getGenomeData();//buildData();
			// MapStyle style = TestBuilder.buildStyle();
			MapStyle style = buildStyle();
	
			LayoutFactory lFactory = new LayoutFactoryCircular();
			
			
			
			data = fileData.getGenomeData();
	
			GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
			gViewMap.setVisible(true); // isn't necessary, defaults to visible
	
			// ImageWriter writer = new ImageWriterImp("png");
			// writer.writeToImage(gViewMap, "/tmp/globalStyle.png");
			gViewMap.setCenter(0);
	
			// note, this is just a hack to get it to work, change how to add maps to a display layer
			new TestLabelPositions("TestLabelPositions", (PCanvas) gViewMap);
	
			// rFactory = new RegionManagerFactoryCircular();
			// gViewMap = GViewMapFactory.createMap(data, style, rFactory);
			// gViewMap.setVisible(true);
			// gViewMap.setCenter(0);
			//		
			// new Test1("Test1Circular", (PCanvas)gViewMap);
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (GViewDataParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
