package testapi;

import javax.swing.JFrame;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.MapStyle;
import gview.style.StyleFactory;

public class TestZoomForProfiler extends PFrame
{
	private static final long serialVersionUID = -196898808903811959L;

	public TestZoomForProfiler(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	public static void main(String[] args)
	{
		GenomeData data = TestBuilder.buildDataFromTestFile();
		MapStyle style = StyleFactory.createDefaultStyle();
		style.setDataStyle(StyleFactory.createDataStyle());
		
		LayoutFactory lFactory = new LayoutFactoryLinear();
		
		GViewMap map = GViewMapFactory.createMap(data, style, lFactory);
		
		JFrame frame = new TestZoomForProfiler("TestZoomForProfiler", (PCanvas)map);
		
		map.setCenter(10);
		for (int i = 1; i < 1000; i++)
		{
			map.setZoomFactor(i/10.0);
			((PCanvas)map).repaint(((PCanvas)map).getBounds());
			System.out.println(i);
		}
		
		System.out.println("Finished");
		frame.dispose();
	}
}
