package testapi;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.seq.DNATools;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.RangeLocation;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.data.GenomeDataFactory;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.MapStyle;
import gview.style.StyleFactory;
import gview.style.datastyle.DataStyle;

public class TestSingleFeature extends PFrame
{
	private static final long serialVersionUID = 7342413715055612065L;

	public TestSingleFeature(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	private static GenomeData buildData()
	{
		GenomeData data = null;
		
		//GenomeDataFactory factory = new GenomeDataFactory();
		
		try
		{
			Sequence dna = DNATools.createDNASequence("atgctgatattatatatatatatatatatatatatatatatatagct", "dna_1");
			
			StrandedFeature.Template ft = new StrandedFeature.Template();
			ft.annotation = Annotation.EMPTY_ANNOTATION;
			ft.location = new RangeLocation(0,15);
			ft.type = "test";
			ft.source = "testsource";
			ft.strand = StrandedFeature.POSITIVE;
			
			dna.createFeature(ft);
			
			data = GenomeDataFactory.createGenomeData(dna);
		}
		catch (IllegalSymbolException ex)
		{
		    ex.printStackTrace();
		}
		catch (BioException be)
		{
			be.printStackTrace();
		}
		
		return data;
	}
	
	// a test of creating a map
	public static void main(String[] args)
	{
		// create data, style, and layout
		// these should probably use the respective readers to read in from a file
		GenomeData data = buildData();
//		MapStyle style = TestBuilder.buildStyle();
		MapStyle style = StyleFactory.createDefaultStyle();
		DataStyle dataStyle = StyleFactory.createDataStyle();
		style.setDataStyle(dataStyle);
		
//		RegionManagerFactory rFactory = new RegionManagerFactoryCircular();
		LayoutFactory lFactory = new LayoutFactoryCircular();
		
		GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
		gViewMap.setVisible(true); // isn't necessary, defaults to visible
		
//		ImageWriter writer = new ImageWriterImp("png");
//		writer.writeToImage(gViewMap, "/tmp/globalStyle.png");
		gViewMap.setCenter(0);
		
		// note, this is just a hack to get it to work, change how to add maps to a display layer
		new TestSingleFeature("TestSingleFeature", (PCanvas)gViewMap);
		
//		rFactory = new RegionManagerFactoryCircular();
//		gViewMap = GViewMapFactory.createMap(data, style, rFactory);
//		gViewMap.setVisible(true);
//		gViewMap.setCenter(0);
//		
//		new Test1("Test1Circular", (PCanvas)gViewMap);
	}
}
