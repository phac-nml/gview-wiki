package testapi;

import edu.umd.cs.piccolo.PCanvas;
import gview.data.BlankSymbolList;
import gview.data.GenomeData;
import gview.data.GenomeDataFactory;
import gview.data.GenomeDataImp;
import gview.layout.feature.FeatureShapeRealizer;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.map.effects.ShadowEffect;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.items.BackboneStyle;
import gview.style.items.RulerStyle;
import gview.style.items.TooltipStyle;
import gview.textextractor.GeneTextExtractor;

import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.NoSuchElementException;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.SimpleAnnotation;
import org.biojava.bio.seq.DNATools;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.SequenceIterator;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.seq.impl.SimpleSequenceFactory;
import org.biojava.bio.seq.io.SeqIOTools;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.RangeLocation;

// used to build styles/data etc for tests
@SuppressWarnings("deprecation")
public class TestBuilder
{
	public static MapStyle buildStyle()
	{
		MapStyle style = new MapStyle();

		// set the style
		GlobalStyle gStyle = style.getGlobalStyle();
		gStyle.setDefaultHeight(500);
		gStyle.setDefaultWidth(500);

		gStyle.setBackgroundPaint(Color.BLACK);
		gStyle.setShowBorder(true);
		// gStyle.setBorderPaint(Color.BLACK);
		gStyle.setTitle("Test1");
		gStyle.setTitlePaint(Color.BLACK);
		gStyle.setTitleFont(new Font("SansSerif", Font.PLAIN, 20));

		TooltipStyle tStyle = gStyle.getTooltipStyle();
		tStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tStyle.setBackgroundPaint(new Color(0, 0, 0, 0.7f));
		tStyle.setTextPaint(Color.RED);

		BackboneStyle bStyle = gStyle.getBackboneStyle();
		bStyle.setPaint(Color.GRAY);
		bStyle.setThickness(10.0);

		RulerStyle rStyle = gStyle.getRulerStyle();
		rStyle.setMajorTickLength(20.0);
		rStyle.setTickThickness(2.0);
		rStyle.setMinorTickPaint(Color.LIGHT_GRAY);
		rStyle.setMajorTickPaint(Color.DARK_GRAY);
		rStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		rStyle.setTextPaint(Color.WHITE);

		buildDataStyleStrands(style.getDataStyle());

		return style;
	}

	/*
	 * // we use data to extract slots/holders and create matching styles private static void
	 * buildDataStyle(DataStyle dataStyle) { SlotStyle slot1 = dataStyle.createSlotStyle(1);
	 * 
	 * slot1.setPaint(Color.BLUE); slot1.setThickness(30); slot1.setTransparency(1.0f);
	 * 
	 * FeatureHolderStyle all = slot1.createFeatureHolderStyle(FeatureFilter.all);
	 * all.setToolTipExtractor(new GeneTextExtractor());
	 * all.setFeatureShapeRealizer(FeatureShapeRealizer.NO_ARROW); }
	 */

	private static void buildDataStyleStrands(DataStyle dataStyle)
	{
		SlotStyle positive = dataStyle.createSlotStyle(1);

		positive.setPaint(Color.BLUE);
		positive.setThickness(35);
		positive.setTransparency(1.0f);

		FeatureHolderStyle positiveHolder = positive.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positiveHolder.setTransparency(0.7f);
		positiveHolder.setToolTipExtractor(new GeneTextExtractor());
		positiveHolder.setFeatureShapeRealizer(FeatureShapeRealizer.NO_ARROW);
		positiveHolder.setShapeEffectRenderer(new ShadowEffect());

		// LabelStyle posLabels = positiveHolder.getLabelStyle();
		// posLabels.setLabelExtractor(new GeneTextExtractor());
		// posLabels.setShowLabels(true);
		// posLabels.setInitialLineLength(50);

		SlotStyle negative = dataStyle.createSlotStyle(-1);

		negative.setPaint(Color.RED); // this paint may be useless, since paints in featureholders
		// override it
		negative.setThickness(35);
		negative.setTransparency(1.0f);

		FeatureHolderStyle negativeHolder = negative.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeHolder.setTransparency(0.7f);
		negativeHolder.setToolTipExtractor(new GeneTextExtractor());
		negativeHolder.setFeatureShapeRealizer(FeatureShapeRealizer.NO_ARROW);
		negativeHolder.setShapeEffectRenderer(new ShadowEffect());
	}

	public static GenomeData buildData()
	{
		GenomeData data = null;

		// GenomeDataFactory factory = new GenomeDataFactory();

		try
		{
			Sequence dna = DNATools.createDNASequence(
					"atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
							+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct", "dna_1");

			StrandedFeature.Template ft = new StrandedFeature.Template();
			ft.annotation = Annotation.EMPTY_ANNOTATION;
			ft.location = new RangeLocation(2, 50);
			ft.type = "test";
			ft.source = "testsource";
			ft.strand = StrandedFeature.POSITIVE;

			dna.createFeature(ft);

			ft.annotation = Annotation.EMPTY_ANNOTATION;
			ft.location = new RangeLocation(50, 89);
			ft.type = "test";
			ft.source = "testsource";
			ft.strand = StrandedFeature.NEGATIVE;

			dna.createFeature(ft);

			ft.location = (new RangeLocation(20, 75)).union(new RangeLocation(77, 88));
			ft.strand = StrandedFeature.POSITIVE;

			dna.createFeature(ft);

			// creates an annotation
			// Map annotationMap = new HashMap();
			// annotationMap.put("gene", "none");
			Annotation ann = new SimpleAnnotation();
			ann.setProperty("gene", "none");

			// creates annotated features
			Feature.Template ft2 = new Feature.Template();
			ft2.annotation = ann;
			ft2.location = new RangeLocation(4, 17);
			ft2.type = "test";
			ft2.source = "testsource";
			dna.createFeature(ft2);

			ft2.location = new RangeLocation(24, 29);
			dna.createFeature(ft2);

			ft.annotation = ann;
			for (int i = 0; i < 15; i++)
			{
				if (i % 2 == 0)
				{
					ft.strand = StrandedFeature.POSITIVE;
				}
				else
				{
					ft.strand = StrandedFeature.NEGATIVE;
				}

				int start = (int) (5 * i + Math.random() * 20 + 100);
				ft.location = new RangeLocation(start, (int) (start + 10 + Math.random() * 10));
				dna.createFeature(ft);
			}

			data = GenomeDataFactory.createGenomeData(dna);
		}
		catch (IllegalSymbolException ex)
		{
			ex.printStackTrace();
		}
		catch (BioException be)
		{
			be.printStackTrace();
		}

		return data;
	}

	public static GenomeData buildDataFromTestFile()
	{
		GenomeData data = null;
		BufferedReader br = null;

		try
		{

			// create a buffered reader to read the sequence file specified by args[0]
			br = new BufferedReader(new FileReader("testfiles/R_denitrificans.gbk"));

		}
		catch (FileNotFoundException ex)
		{
			// can't find the file specified by args[0]
			ex.printStackTrace();
			throw new RuntimeException("File Not Found!");
		}

		// read the GenBank File
		SequenceIterator sequences = SeqIOTools.readGenbank(br);

		// iterate through the sequences
		if (sequences.hasNext())
		{
			try
			{

				Sequence seq = sequences.nextSequence();

				// GenomeDataFactory factory = new GenomeDataFactory();

				// create data, style, and layout
				// these should probably use the respective readers to read in from a file
				data = GenomeDataFactory.createGenomeData(seq);

			}
			catch (BioException ex)
			{
				// not in GenBank format
				ex.printStackTrace();
			}
			catch (NoSuchElementException ex)
			{
				// request for more sequence when there isn't any
				ex.printStackTrace();
			}
		}

		return data;
	}

	public static GenomeData buildDataBlank()
	{
		GenomeData data = null;

		// GenomeDataFactory factory = new GenomeDataFactory();

		try
		{
			// TODO figure out how to actually create sequences properly
			SimpleSequenceFactory seqFactory = new SimpleSequenceFactory();

			Sequence dna = seqFactory.createSequence(new BlankSymbolList(10), null, null, null);

			Feature.Template ft = new Feature.Template();
			ft.annotation = Annotation.EMPTY_ANNOTATION;
			ft.location = new RangeLocation(2, 5);
			ft.type = "test";
			ft.source = "testsource";

			dna.createFeature(ft);

			data = GenomeDataFactory.createGenomeData(dna);
		}
		catch (IllegalSymbolException ex)
		{
			ex.printStackTrace();
		}
		catch (BioException be)
		{
			be.printStackTrace();
		}

		return data;
	}

	public static PCanvas createMap()
	{
		// create data, style, and layout
		// these should probably use the respective readers to read in from a file
		GenomeData data = TestBuilder.buildData();
		MapStyle style = TestBuilder.buildStyle();

		LayoutFactory lFactory = new LayoutFactoryLinear();
		// GViewMapFactory gViewMapFactory = new GViewMapFactory();

		GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
		gViewMap.setVisible(true); // isn't necessary, defaults to visible

		return (PCanvas) gViewMap;
	}

	public static PCanvas createMapFromSequence(Sequence seq)
	{
		// create data, style, and layout
		// these should probably use the respective readers to read in from a file
		GenomeData data = new GenomeDataImp(seq);
		MapStyle style = TestBuilder.buildStyle();

		LayoutFactory lFactory = new LayoutFactoryLinear();
		// GViewMapFactory gViewMapFactory = new GViewMapFactory();

		GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
		gViewMap.setVisible(true); // isn't necessary, defaults to visible

		return (PCanvas) gViewMap;
	}
}
