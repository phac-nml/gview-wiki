package testapi;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.data.readers.GViewFileData;
import gview.data.readers.GViewFileReader;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.MapStyle;

public class TestReadCGView extends PFrame
{
	private static final long serialVersionUID = 24411268069114413L;

	public TestReadCGView(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	public static void main(String[] args)
	{
		
		try
		{
			GViewFileData gviewFileData = GViewFileReader.read("testfiles/cybercell.xml");
			
			GenomeData data = gviewFileData.getGenomeData();
			MapStyle style = gviewFileData.getMapStyle();
			
			LayoutFactory lFactory = new LayoutFactoryLinear();
			
			
			GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
			gViewMap.setVisible(true); // isn't necessary, defaults to visible
			
			new Test1("Test1Linear", (PCanvas)gViewMap);
			
		}
		catch (Exception e)
		{
			System.err.println(e);
			e.printStackTrace();
		}
	}
}
