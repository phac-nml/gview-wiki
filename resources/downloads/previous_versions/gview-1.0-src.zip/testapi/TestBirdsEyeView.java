package testapi;

import javax.swing.JDialog;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.BirdsEyeView;
import gview.map.BirdsEyeViewImp;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.MapStyle;

public class TestBirdsEyeView extends PFrame
{
	private static final long serialVersionUID = 6265029058925944329L;

	public TestBirdsEyeView(String title, boolean fullScreen, PCanvas canvas)
	{
		super(title, fullScreen, canvas);
	}
	
	// a test of creating a map
	public static void main(String[] args)
	{
		// create data, style, and layout
		// these should probably use the respective readers to read in from a file
		GenomeData data = TestBuilder.buildData();
		MapStyle style = TestBuilder.buildStyle();
		
		LayoutFactory lFactory = new LayoutFactoryLinear();
		
		GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
		gViewMap.setVisible(true); // isn't necessary, defaults to visible
		// note, this is just a hack to get it to work, change how to add maps to a display layer
		new TestBirdsEyeView("Test1Linear", false, (PCanvas)gViewMap);
		
		// this will create the actual BirdsEyeView and put it in a JDialog
		BirdsEyeView bev = new BirdsEyeViewImp();
		bev.connect(gViewMap);
		JDialog bird = new JDialog();
		bird.getContentPane().add((PCanvas)bev);
		bird.pack();
		bird.setSize(150, 150);
		bird.setVisible(true);
	}
}
