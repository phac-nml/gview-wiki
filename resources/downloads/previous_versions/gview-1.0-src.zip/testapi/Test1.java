package testapi;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.MapStyle;
import gview.style.StyleFactory;

public class Test1 extends PFrame
{
	private static final long serialVersionUID = -1121743566194319554L;

	public Test1(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	// a test of creating a map
	public static void main(String[] args)
	{
		// create data, style, and layout
		// these should probably use the respective readers to read in from a file
		GenomeData data = TestBuilder.buildData();
//		MapStyle style = TestBuilder.buildStyle();
		MapStyle style = StyleFactory.createPosterStyle2();
		
		LayoutFactory lFactory = new LayoutFactoryCircular();
		
		GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
		gViewMap.setVisible(true); // isn't necessary, defaults to visible
		
//		ImageWriter writer = new ImageWriterImp("png");
//		writer.writeToImage(gViewMap, "/tmp/globalStyle.png");
//		gViewMap.setCenter(0);
		
		// note, this is just a hack to get it to work, change how to add maps to a display layer
		new Test1("Test1Linear", (PCanvas)gViewMap);

		
//		rFactory = new RegionManagerFactoryCircular();
//		gViewMap = GViewMapFactory.createMap(data, style, rFactory);
//		gViewMap.setVisible(true);
//		gViewMap.setCenter(0);
//		
//		new Test1("Test1Circular", (PCanvas)gViewMap);
	}
}
