package testapi;

import java.awt.Color;
import java.awt.Font;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.SimpleAnnotation;
import org.biojava.bio.seq.DNATools;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.RangeLocation;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.data.GenomeDataFactory;
import gview.data.Slot;
import gview.layout.feature.FeatureShapeRealizer;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.map.effects.StandardEffect;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.items.BackboneStyle;
import gview.style.items.RulerStyle;
import gview.style.items.TooltipStyle;

public class TestBackboneFeature extends PFrame
{
	private static final long serialVersionUID = -7194636543066542558L;

	public TestBackboneFeature(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}

	private static MapStyle buildStyle()
	{
		/** Global Style **/

		MapStyle mapStyle = new MapStyle();

		// extract associated GlobalStyle from newly created MapStyle object
		GlobalStyle global = mapStyle.getGlobalStyle();

		// set initial height/width of the map
		global.setDefaultHeight(700);
		global.setDefaultWidth(700);

		global.setBackgroundPaint(Color.BLACK);

		// extract tooltip style from global style
		TooltipStyle tooltip = global.getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(0, 0, 1.0f, 0.5f));
		tooltip.setTextPaint(Color.WHITE);

		// extract style information dealing with the backbone
		BackboneStyle backbone = global.getBackboneStyle();
		backbone.setPaint(Color.GRAY.darker());
		backbone.setThickness(5.0);
		backbone.setShapeEffectRenderer(new StandardEffect());

		// extract information dealing with the ruler style
		RulerStyle ruler = global.getRulerStyle();
		ruler.setMajorTickLength(20.0);
		ruler.setTickThickness(3.0);
		ruler.setMinorTickPaint(Color.LIGHT_GRAY);
		ruler.setMajorTickPaint(Color.DARK_GRAY);
		ruler.setFont(new Font("SansSerif", Font.PLAIN, 12));
		ruler.setTextPaint(Color.WHITE);

		/** Slots **/

		// assumes mapStyle created as above

		// extract data style from map style
		DataStyle dataStyle = mapStyle.getDataStyle();

		// creates the first two slots
		SlotStyle sStyle = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		sStyle.setThickness(30);
		sStyle.setShapeEffectRenderer(new StandardEffect());
		SlotStyle nStyle = dataStyle.createSlotStyle(Slot.FIRST_UPPER + 1);
		nStyle.setThickness(30);
		nStyle.setShapeEffectRenderer(new StandardEffect());
		SlotStyle pStyle = dataStyle.createSlotStyle(Slot.FIRST_UPPER + 2);
		pStyle.setThickness(30);
		pStyle.setShapeEffectRenderer(new StandardEffect());

		/** FeatureHolderStyle **/

		// creates a feature holder style in the first upper slot containing all the features
		FeatureHolderStyle holder = sStyle.createFeatureHolderStyle(new FeatureFilter.AnnotationContains("id", "1"));
		holder.setTransparency(0.7f);
		holder.setPaint(Color.BLUE);
		holder.setFeatureShapeRealizer(FeatureShapeRealizer.NO_ARROW);

		FeatureHolderStyle holderN = nStyle.createFeatureHolderStyle(new FeatureFilter.AnnotationContains("id", "2"));
		holderN.setTransparency(0.7f);
		holderN.setPaint(Color.RED);
		holderN.setFeatureShapeRealizer(FeatureShapeRealizer.NO_ARROW);

		FeatureHolderStyle holderP = pStyle.createFeatureHolderStyle(new FeatureFilter.AnnotationContains("id", "3"));
		holderP.setTransparency(0.7f);
		holderP.setPaint(Color.ORANGE);
		holderP.setFeatureShapeRealizer(FeatureShapeRealizer.NO_ARROW);

		return mapStyle;
	}

	private static GenomeData buildData()
	{
		GenomeData data = null;

		try
		{
			Sequence dna = DNATools
					.createDNASequence(
							"atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatgaatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
									+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctcatga", "dna_1");

			Annotation ann = new SimpleAnnotation();

			StrandedFeature.Template ft = new StrandedFeature.Template();
			ft.annotation = ann;
			ft.type = "test";
			ft.source = "testsource";
			ft.strand = StrandedFeature.POSITIVE;

			ft.location = new RangeLocation(0, dna.length());
			ann.setProperty("id", "1");
			dna.createFeature(ft);

			// ann.setProperty("id", "3");
			// ft.location = new RangeLocation(0,3*dna.length()/4);
			// dna.createFeature(ft);
			//			
			// ann.setProperty("id", "2");
			// ft.location = new RangeLocation(0,dna.length()/7);
			// dna.createFeature(ft);

			data = GenomeDataFactory.createGenomeData(dna);
			System.out.println(data.getSequenceLength());
		}
		catch (IllegalSymbolException ex)
		{
			ex.printStackTrace();
		}
		catch (BioException be)
		{
			be.printStackTrace();
		}

		return data;
	}

	// a test of creating a map
	public static void main(String[] args)
	{
		// create data, style, and layout
		// these should probably use the respective readers to read in from a file
		GenomeData data = buildData();
		// MapStyle style = TestBuilder.buildStyle();
		MapStyle style = buildStyle();

		LayoutFactory lFactory = new LayoutFactoryCircular();

		GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
		gViewMap.setVisible(true); // isn't necessary, defaults to visible

		// ImageWriter writer = new ImageWriterImp("png");
		// writer.writeToImage(gViewMap, "/tmp/globalStyle.png");
		gViewMap.setCenter(0);

		// note, this is just a hack to get it to work, change how to add maps to a display layer
		new TestBackboneFeature("TestBackboneFeature", (PCanvas) gViewMap);

		// rFactory = new RegionManagerFactoryCircular();
		// gViewMap = GViewMapFactory.createMap(data, style, rFactory);
		// gViewMap.setVisible(true);
		// gViewMap.setCenter(0);
		//		
		// new Test1("Test1Circular", (PCanvas)gViewMap);
	}
}
