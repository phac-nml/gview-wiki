package testapi;

import gview.data.GenomeData;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.MapStyle;
import gview.style.StyleFactory;
import gview.writers.ImageWriter;
import gview.writers.ImageWriterFactory;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TestWriteToImage
{
	// a test of creating a map
	public static void main(String[] args)
	{
		// create data, style, and layout
		// these should probably use the respective readers to read in from a file
		GenomeData data = TestBuilder.buildDataFromTestFile();
		MapStyle style = StyleFactory.createPosterStyle();
		
		LayoutFactory lFactory = new LayoutFactoryCircular();
		
		GViewMap map = GViewMapFactory.createMap(data, style, lFactory);
		map.setVisible(true); // isn't necessary, defaults to visible
		
		ImageWriter writer = ImageWriterFactory.createImageWriter("png");
		
		//map.setZoomFactor(10.0);
		for (int i = 0; i < 1; i++)
		{
		    Calendar cal = Calendar.getInstance();
		    SimpleDateFormat sdf = new SimpleDateFormat("hh.mm.ss");
		    String time = sdf.format(cal.getTime());
			
			//map.setCenter(i*400000);
			try
			{
				map.setZoomFactor(10.0);
				map.setViewSize(5000, 5000);
				map.centerMap();
				//map.viewAll();
				//map.setCenter(10000);

				writer.writeToImage(map, "/tmp/image" + time + ".png");
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//writer2.writeToImage(map, "image" + i + ".png");
		}
	}
}
