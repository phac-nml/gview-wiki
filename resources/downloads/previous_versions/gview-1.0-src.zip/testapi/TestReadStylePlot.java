package testapi;

import edu.umd.cs.piccolo.PCanvas;
import gview.data.GenomeData;
import gview.data.Slot;
import gview.data.readers.GViewDataParseException;
import gview.data.readers.GViewFileData;
import gview.data.readers.GViewFileReader;
import gview.examples.ApiExample1;
import gview.layout.PlotDrawerLine;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.io.StyleIOGSS;
import gview.style.io.gss.GeneralStyleConverter;
import gview.style.items.BackboneStyle;
import gview.style.items.RulerStyle;
import gview.style.items.TooltipStyle;
import gview.textextractor.GeneTextExtractor;
import gview.textextractor.LocationExtractor;

import java.awt.Color;
import java.awt.Font;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringWriter;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;

public class TestReadStylePlot
{
	private static MapStyle buildStyle()
	{
		/**Global Style**/
		
		MapStyle mapStyle = new MapStyle();
		
		// extract associated GlobalStyle from newly created MapStyle object
		GlobalStyle global = mapStyle.getGlobalStyle();
		
		// set initial height/width of the map
		global.setDefaultHeight(700);
		global.setDefaultWidth(700);
		
		global.setBackgroundPaint(Color.BLACK);
		
		// extract tooltip style from global style
		TooltipStyle tooltip = global.getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(0,0,1.0f,0.5f));
		tooltip.setTextPaint(Color.WHITE);
		
		// extract style information dealing with the backbone
		BackboneStyle backbone = global.getBackboneStyle();
		backbone.setPaint(Color.GRAY.darker());
		backbone.setThickness(5.0);
		
		// extract information dealing with the ruler style
		RulerStyle ruler = global.getRulerStyle();
		ruler.setMajorTickLength(20.0);
		ruler.setTickThickness(5.0);
		ruler.setMinorTickPaint(Color.LIGHT_GRAY);
		ruler.setMajorTickPaint(Color.DARK_GRAY);
		ruler.setFont(new Font("SansSerif", Font.PLAIN, 12));
		ruler.setTextPaint(Color.WHITE);
		
		/**Slots**/
		
		// assumes mapStyle created as above
		
		// extract data style from map style
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// creates the first two slots
		SlotStyle positiveSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		positiveSlot.setToolTipExtractor(new GeneTextExtractor());
		SlotStyle negativeSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER);
		negativeSlot.setToolTipExtractor(new GeneTextExtractor());
		
		/**FeatureHolderStyle**/
		
		// creates a feature holder style in the first upper slot containing all the features
		FeatureHolderStyle positive = positiveSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positive.setThickness(0.7);
		positive.setTransparency(0.5f);
		positive.setToolTipExtractor(new LocationExtractor());
		positive.setPaint(Color.BLUE);
		
		// creates a holder containing all negative features in the first lower slot
		FeatureHolderStyle negativeFeatures = negativeSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeFeatures.setPaint(Color.RED);
		
		return mapStyle;
	}
	
	public static void main(String[] args) throws IOException
	{
		GeneralStyleConverter styleConverter = new GeneralStyleConverter();
		
		MapStyle style;
		StyleIOGSS styleIO = new StyleIOGSS();
		
		style = styleIO.readMapStyle("styles/posterstyle.gss");
		
		try
		{
			// read in genome data
			GViewFileData fileData = GViewFileReader.read("testfiles/NC_009497.gbk");
			
			GenomeData data = fileData.getGenomeData();
			
			LayoutFactory layoutFactory = new LayoutFactoryLinear();
	  		
	  		GViewMap gViewMap = GViewMapFactory.createMap(data, style, layoutFactory);
	  		gViewMap.setVisible(true); // isn't necessary, defaults to visible
	  		
	  		// cast map as a PCanvas, so we can insert it in a PFrame
	  		new ApiExample1("TestReadStyle", (PCanvas)gViewMap);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (GViewDataParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
