package testapi;


public class DocCode
{
	public static void randomCode()
	{
		// LayoutFactory layoutFactory;

		// layoutFactory = new LayoutFactoryLinear();
		// or
		// layoutFactory = new LayoutFactoryCircular();
	}
}
