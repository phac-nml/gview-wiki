package testapi;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.awt.Stroke;
import java.io.IOException;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.seq.DNATools;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.RangeLocation;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.data.GenomeDataFactory;
import gview.data.Slot;
import gview.layout.feature.FeatureShapeRealizer;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.map.effects.ShapeEffectRenderer;
import gview.map.effects.StandardEffect;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.items.BackboneStyle;
import gview.style.items.RulerStyle;
import gview.style.items.TooltipStyle;
import gview.textextractor.LocationExtractor;
import gview.writers.ImageWriter;
import gview.writers.ImageWriterJPG;
import gview.writers.ImageWriterPNG;

public class TestHierarchyStyle extends PFrame
{
	private static final long serialVersionUID = -6120711150622297708L;

	public TestHierarchyStyle(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}

	private static GenomeData buildData()
	{
		GenomeData data = null;

		// GenomeDataFactory factory = new GenomeDataFactory();

		try
		{
			Sequence dna = DNATools.createDNASequence(
					"atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
							+ "atgctgatattatatatatatatatatatatatatatatatatagcaaaatatatgacttgacttgacttgacttgacttg", "dna_1");

			StrandedFeature.Template ft = new StrandedFeature.Template();
			ft.annotation = Annotation.EMPTY_ANNOTATION;
			ft.type = "test";
			ft.source = "testsource";
			ft.strand = StrandedFeature.POSITIVE;

			for (int i = 0; i < 22; i++)
			{
				int start = (i * 10 + 2);
				ft.location = new RangeLocation(start, (start + 8));
				dna.createFeature(ft);
			}

			ft.strand = StrandedFeature.NEGATIVE;

			for (int i = 0; i < 22; i++)
			{
				int start = (i * 10 + 2);
				ft.location = new RangeLocation(start, (start + 8));
				dna.createFeature(ft);
			}

			data = GenomeDataFactory.createGenomeData(dna);
			System.out.println(data.getSequenceLength());
		}
		catch (IllegalSymbolException ex)
		{
			ex.printStackTrace();
		}
		catch (BioException be)
		{
			be.printStackTrace();
		}

		return data;
	}

	public static MapStyle createDefaultStyle()
	{
		MapStyle style = new MapStyle();

		// set the style
		final Paint shading = new Color(0.0f, 0.0f, 0.0f, 0.2f);
		final Stroke shadeStroke = new BasicStroke(1.0f);

		// set the style
		GlobalStyle gStyle = style.getGlobalStyle();
		gStyle.setDefaultHeight(700);
		gStyle.setDefaultWidth(700);

		gStyle.setBackgroundPaint(new Color(1.0f, 1.0f, 1.0f, 0.0f));
		gStyle.setShowBorder(true);
		// gStyle.setBorderPaint(Color.BLACK);
		// gStyle.setTitle("Test1");
		gStyle.setTitlePaint(Color.BLACK);
		gStyle.setTitleFont(new Font("SansSerif", Font.PLAIN, 20));
		gStyle.setSlotSpacing(10.0);

		TooltipStyle tStyle = gStyle.getTooltipStyle();
		tStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tStyle.setBackgroundPaint(new Color(0, 0, 0, 0.7f));
		tStyle.setTextPaint(Color.BLACK);
		tStyle.setBackgroundPaint(new Color(134, 134, 255));
		tStyle.setOutlinePaint(new Color(0.0f, 0.0f, 0.0f, 0.5f));

		BackboneStyle bStyle = gStyle.getBackboneStyle();
		bStyle.setPaint(Color.GRAY);
		bStyle.setThickness(5.0);
		bStyle.setShapeEffectRenderer(ShapeEffectRenderer.BASIC_RENDERER);
		bStyle.setShapeEffectRenderer(new StandardEffect(shading, new BasicStroke(1.2f)));

		RulerStyle rStyle = gStyle.getRulerStyle();
		rStyle.setMajorTickLength(15.0);
		rStyle.setTickThickness(2.0);
		rStyle.setMinorTickPaint(Color.GREEN.darker().darker());
		rStyle.setMajorTickPaint(Color.GREEN.darker().darker());
		rStyle.setFont(new Font("SansSerif", Font.BOLD, 16));
		rStyle.setTextPaint(Color.BLACK);
		rStyle.setShapeEffectRenderer(new StandardEffect(shading, new BasicStroke(1.2f)));

		DataStyle dataStyle = style.getDataStyle();

		SlotStyle positive = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		positive.setShapeEffectRenderer(new StandardEffect(shading, shadeStroke));

		positive.setPaint(new Color(0, 0, 255));
		positive.setThickness(35);

		FeatureHolderStyle positiveHolder = positive.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positiveHolder.setToolTipExtractor(new LocationExtractor());
		positiveHolder.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW); // Note: this
																					// part doesn't
																					// work for now
																					// and isn't
																					// really needed

		FeatureHolderStyle category1Pos = positiveHolder.createFeatureHolderStyle(new FeatureFilter.OverlapsLocation(new RangeLocation(0, 100)));
		category1Pos.setPaint(new Color(128, 0, 128));

		FeatureHolderStyle category2Pos = positiveHolder.createFeatureHolderStyle(new FeatureFilter.OverlapsLocation(new RangeLocation(100, 200)));
		category2Pos.setPaint(new Color(0, 255, 255));

		SlotStyle negative = dataStyle.createSlotStyle(Slot.FIRST_LOWER);
		negative.setShapeEffectRenderer(new StandardEffect(shading, shadeStroke));

		negative.setPaint(new Color(255, 0, 0)); // this paint may be useless, since paints in
													// featureholders override it
		negative.setThickness(35);

		FeatureHolderStyle negativeHolder = negative.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeHolder.setToolTipExtractor(new LocationExtractor());
		negativeHolder.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);

		FeatureHolderStyle category1Neg = negativeHolder.createFeatureHolderStyle(new FeatureFilter.OverlapsLocation(new RangeLocation(0, 100)));
		category1Neg.setPaint(new Color(255, 128, 0));

		FeatureHolderStyle category2Neg = negativeHolder.createFeatureHolderStyle(new FeatureFilter.OverlapsLocation(new RangeLocation(100, 200)));
		category2Neg.setPaint(new Color(255, 255, 0));

		return style;
	}

	// a test of creating a map
	public static void main(String[] args)
	{
		// create data, style, and layout
		// these should probably use the respective readers to read in from a file
		GenomeData data = buildData();
		// MapStyle style = TestBuilder.buildStyle();
		MapStyle style = createDefaultStyle();

		// RegionManagerFactory rFactory = new RegionManagerFactoryCircular();
		LayoutFactory lFactory = new LayoutFactoryCircular();

		GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
		gViewMap.setVisible(true); // isn't necessary, defaults to visible

		// ImageWriter writer = new ImageWriterImp("png");
		// writer.writeToImage(gViewMap, "/tmp/globalStyle.png");
		gViewMap.setCenter(0);

		// note, this is just a hack to get it to work, change how to add maps to a display layer
		new TestHierarchyStyle("TestHierarchyStyle", (PCanvas) gViewMap);

		try
		{
			Thread.sleep(5000);
		}
		catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ImageWriter writer = new ImageWriterPNG();

		try
		{
			writer.writeToImage(gViewMap, "hirearcy.png");
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// rFactory = new RegionManagerFactoryCircular();
		// gViewMap = GViewMapFactory.createMap(data, style, rFactory);
		// gViewMap.setVisible(true);
		// gViewMap.setCenter(0);
		//		
		// new Test1("Test1Circular", (PCanvas)gViewMap);
	}
}
