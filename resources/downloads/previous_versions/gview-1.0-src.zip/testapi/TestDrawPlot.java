package testapi;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.data.Slot;
import gview.data.readers.GViewDataParseException;
import gview.data.readers.GViewFileData;
import gview.data.readers.GViewFileReader;
import gview.layout.PlotBuilder;
import gview.layout.PlotBuilderPoints;
import gview.layout.PlotBuilderGC;
import gview.layout.PlotBuilderRange;
import gview.layout.PlotDrawerBar;
import gview.layout.PlotDrawerLine;
import gview.layout.PlotDrawerSolid;
import gview.layout.feature.FeatureShapeRealizer;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.map.effects.HighlightEffect;
import gview.map.effects.OutlineEffect;
import gview.map.effects.RaisedShadedEffect;
import gview.map.effects.ShapeEffectRenderer;
import gview.style.GlobalStyle;
import gview.style.MapStyle;
import gview.style.datastyle.DataStyle;
import gview.style.datastyle.FeatureHolderStyle;
import gview.style.datastyle.PlotStyle;
import gview.style.datastyle.SlotStyle;
import gview.style.items.BackboneStyle;
import gview.style.items.RulerStyle;
import gview.style.items.TooltipStyle;
import gview.textextractor.AnnotationExtractor;
import gview.textextractor.FeatureTextExtractor;
import gview.textextractor.StringExtractor;

public class TestDrawPlot extends PFrame
{
	private static final long serialVersionUID = 271982459532677044L;

	public TestDrawPlot(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}

	private static MapStyle buildStyle()
	{
		/** Global Style **/

		MapStyle mapStyle = new MapStyle();

		// extract associated GlobalStyle from newly created MapStyle object
		GlobalStyle global = mapStyle.getGlobalStyle();

		// set initial height/width of the map
		global.setDefaultHeight(700);
		global.setDefaultWidth(700);

		global.setBackgroundPaint(Color.BLACK);

		// extract tooltip style from global style
		TooltipStyle tooltip = global.getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(0, 0, 1.0f, 0.5f));
		tooltip.setTextPaint(Color.WHITE);

		// extract style information dealing with the backbone
		BackboneStyle backbone = global.getBackboneStyle();
		backbone.setPaint(Color.GRAY.darker());
		backbone.setThickness(5.0);

		// extract information dealing with the ruler style
		RulerStyle ruler = global.getRulerStyle();
		ruler.setMajorTickLength(20.0);
		ruler.setTickThickness(3.0);
		ruler.setMinorTickPaint(Color.LIGHT_GRAY);
		ruler.setMajorTickPaint(Color.DARK_GRAY);
		ruler.setFont(new Font("SansSerif", Font.PLAIN, 12));
		ruler.setTextPaint(Color.WHITE);

		/** Slots **/

		// assumes mapStyle created as above

		// extract data style from map style
		DataStyle dataStyle = mapStyle.getDataStyle();

		// creates the first two slots
		SlotStyle positiveSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		positiveSlot.setThickness(30);
		positiveSlot.setShapeEffectRenderer(ShapeEffectRenderer.STANDARD_RENDERER);
		SlotStyle negativeSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER);
		negativeSlot.setThickness(30);
		negativeSlot.setShapeEffectRenderer(new HighlightEffect());

		/** FeatureHolderStyle **/

		FeatureTextExtractor textExtractor = new StringExtractor("the text\nthe text2\n", new AnnotationExtractor("product"));

		// creates a feature holder style in the first upper slot containing all the features
		FeatureHolderStyle positive = positiveSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positive.setTransparency(0.7f);
		positive.setToolTipExtractor(textExtractor);
		positive.setPaint(Color.BLUE);
		positive.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW);

		PlotStyle plotStyle = new PlotStyle();
		plotStyle.setGridPaint(Color.gray);
		plotStyle.setGridLines(5);
		plotStyle.setGridLineThickness(0.3f);
		
		//PlotBuilder plotBuilder = new PlotBuilderGC(10000);
		//plotBuilder.scale(0.45,0.65);
		
		PlotBuilderRange plotBuilder = new PlotBuilderRange();
		plotStyle.setPlotBuilder(plotBuilder);
		
		for (int base = 20000; base < 4000000; base += 1000)
		{
			plotBuilder.addRange(base, base+1000, Math.random()*100);
		}
		
		plotBuilder.scale(0, 100);
		
		plotStyle.setPlotBuilder(plotBuilder);
		
		plotStyle.setPlotDrawer(new PlotDrawerBar());
		
		negativeSlot.addStyleItem(plotStyle);

		return mapStyle;
	}

	// a test of creating a map
	public static void main(String[] args)
	{
		// create data, style, and layout
		// these should probably use the respective readers to read in from a file
		GViewFileData fileData;
		try
		{
			fileData = GViewFileReader.read("testfiles/R_denitrificans.gbk");
	
			GenomeData data = fileData.getGenomeData();//buildData();
			// MapStyle style = TestBuilder.buildStyle();
			MapStyle style = buildStyle();
	
			LayoutFactory lFactory = new LayoutFactoryCircular();
			
			
			data = fileData.getGenomeData();
	
			GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
			gViewMap.setVisible(true); // isn't necessary, defaults to visible
	
			// ImageWriter writer = new ImageWriterImp("png");
			// writer.writeToImage(gViewMap, "/tmp/globalStyle.png");
			gViewMap.setCenter(0);
	
			// note, this is just a hack to get it to work, change how to add maps to a display layer
			new TestDrawPlot("TestDrawPlot", (PCanvas) gViewMap);
	
			// rFactory = new RegionManagerFactoryCircular();
			// gViewMap = GViewMapFactory.createMap(data, style, rFactory);
			// gViewMap.setVisible(true);
			// gViewMap.setCenter(0);
			//		
			// new Test1("Test1Circular", (PCanvas)gViewMap);
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (GViewDataParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
