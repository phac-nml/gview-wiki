package testapi;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;
import gview.data.GenomeData;
import gview.layout.sequence.LayoutFactory;
import gview.layout.sequence.circular.LayoutFactoryCircular;
import gview.layout.sequence.linear.LayoutFactoryLinear;
import gview.map.GViewMap;
import gview.map.GViewMapFactory;
import gview.style.MapStyle;

public class TestZoomCenter extends PFrame
{	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1137247368780272065L;

	public TestZoomCenter(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	// a test of creating a map
	public static void main(String[] args)
	{
		// create data, style, and layout
		// these should probably use the respective readers to read in from a file
		GenomeData data = TestBuilder.buildData();
		MapStyle style = TestBuilder.buildStyle();
		
		LayoutFactory lFactory = new LayoutFactoryLinear();
		
		GViewMap mapL = GViewMapFactory.createMap(data, style, lFactory);
		mapL.setVisible(true); // isn't necessary, defaults to visible
		
		// note, this is just a hack to get it to work, change how to add maps to a display layer
		new TestZoomCenter("Test1Linear", (PCanvas)mapL);
		
		mapL.setCenter(30);
		
		lFactory = new LayoutFactoryCircular();
		GViewMap mapC = GViewMapFactory.createMap(data, style, lFactory);
		mapC.setVisible(true);
		
		new TestZoomCenter("Test1Circular", (PCanvas)mapC);
		
		mapC.setCenter(30);
		mapC.setZoomFactor(2);
		
//		mapC.setZoomFactor(10.0);
//		mapC.setCenter(new Point2D.Double(100,100));
//		mapL.setZoomFactor(2.0);
	}
}
