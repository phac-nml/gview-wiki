package labelTests;

import org.junit.Before;
import org.junit.Test;

public class LabelPositionerTests
{
	//private LabelsPositioner labelPositioner;
	//private Backbone backbone;
	
	//private final int MAX_LABELS = 5;
	
	@Before
	public void setup()
	{
//		labelPositioner = new LabelsPositionerVector(MAX_LABELS, null);
//		backbone = new BackboneCircular(new LocationConverter(GenomeDataFactory.createBlankGenomeData(100)), 100, 0);
	}
	
	@Test
	public void addLabelsToTest()
	{
//		MapItem currItem;
//		
//		BackboneLabelItem essentialItem = new BackboneLabelItem(backbone, null);
//		Label essentialLabel = new Label(essentialItem, null, null);
//		Label nonEssentialLabel = new Label(new BackboneLabelItem(backbone, null), null, null);
//		Label hiddenLabel = new Label(new BackboneLabelItem(backbone, null), null, null);
//		
//		MapComponent layer = new Layer();
//		Assert.assertFalse(layer.itemsIterator().hasNext());
//		
//		labelPositioner.addLabelsTo(layer, 1.0);
//		Assert.assertFalse(layer.itemsIterator().hasNext());
//		
//		labelPositioner.addLabel(essentialLabel, LabelRank.ESSENTIAL);
//		labelPositioner.addLabelsTo(layer, 1.0);
//		
//		Iterator<MapItem> iterator = layer.itemsIterator();
//		
//		Assert.assertTrue(iterator.hasNext());
//		currItem = iterator.next();
//		Assert.assertTrue(currItem instanceof BackboneLabelItem);
//		Assert.assertEquals(essentialItem, currItem);
//		
//		// make sure it only positions up to MAX_LABELS labels
//		// note: already added one label
//		for (int i = 1; i < MAX_LABELS; i++)
//		{
//			labelPositioner.addLabel(new Label(new BackboneLabelItem(backbone, null), null, null), LabelRank.ESSENTIAL);
//		}
//		
//		// add one more label
//		labelPositioner.addLabel(new Label(new BackboneLabelItem(backbone, null), null, null), LabelRank.ESSENTIAL);
//		
//		labelPositioner.addLabelsTo(layer, 1.0);
//		iterator = layer.itemsIterator();
//		
//		// check if all labels are positioned
//		for (int i = 0; i < MAX_LABELS; i++)
//		{
//			Assert.assertTrue(iterator.hasNext());
//			currItem = iterator.next();
//			Assert.assertTrue(currItem instanceof BackboneLabelItem);
//		}
//		
//		Assert.assertFalse(iterator.hasNext()); // shouldn't have any more labels
	}
}
