package managerTests;

import gview.managers.ruler.TickMark;
import gview.managers.ruler.TickMarkCalculator;

import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TickMarkCalculatorTest
{
	private TickMarkCalculator tickCalculator;
	
	@Before
	public void setup()
	{
		int sequenceLength = 100;
		float tickDensity = 1.0f;
		double desiredLengthPerMark = 10;
		
		tickCalculator = new TickMarkCalculator(sequenceLength, tickDensity, desiredLengthPerMark,
				1.0f, 0.5f);
	}
	
	@Test
	public void testCreateMarks()
	{
		tickCalculator.changeBackboneLength(100);
		
		List<TickMark> marks = tickCalculator.createMarks(0, 100);
		
		Assert.assertNotNull(marks);
		
		int expectedBase = 0;
		int expectedIncrementPerMark = 10;
		
		for (TickMark mark : marks)
		{
			int base = mark.getBase();
			
			Assert.assertEquals(expectedBase, base);
			
			expectedBase += expectedIncrementPerMark;
		}
		
		// above loop should go through all tick marks until we hit 110
		Assert.assertEquals(110, expectedBase);
		
		
		
		marks = tickCalculator.createMarks(23, 78);
		
		Assert.assertNotNull(marks);
		
		expectedBase = 30;
		expectedIncrementPerMark = 10;
		
		for (TickMark mark : marks)
		{
			int base = mark.getBase();
			
			Assert.assertEquals(expectedBase, base);
			
			expectedBase += expectedIncrementPerMark;
		}
		
		// above loop should go through all tick marks until we hit 80
		Assert.assertEquals(80, expectedBase);
		
		
		
		tickCalculator.changeBackboneLength(1000);
		
		marks = tickCalculator.createMarks(0, 100);
		
		Assert.assertNotNull(marks);
		
		expectedBase = 0;
		expectedIncrementPerMark = 1;
		
		for (TickMark mark : marks)
		{
			int base = mark.getBase();
			
			Assert.assertEquals(expectedBase, base);
			
			expectedBase += expectedIncrementPerMark;
		}
		
		// above loop should go through all tick marks until we hit 101
		Assert.assertEquals(101, expectedBase);
	}
}
