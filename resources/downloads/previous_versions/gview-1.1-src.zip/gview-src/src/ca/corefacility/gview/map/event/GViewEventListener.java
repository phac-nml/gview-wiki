package ca.corefacility.gview.map.event;

import java.util.EventListener;

public interface GViewEventListener extends EventListener
{
	public void eventOccured(GViewEvent event);
}
