package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.GViewMap;

public class ScaleOutAction extends ScaleAction 
{
	private final GViewMap gViewMap;
	
	public ScaleOutAction(GViewMap gViewMap)
	{
		super(gViewMap,gViewMap.getZoomNormalFactor());
		
		this.gViewMap = gViewMap;
	}
	
	public void run()
	{
		double scaleFactor;
		
		scaleFactor = gViewMap.getZoomNormalFactor();
		scaleFactor *= 0.9;
		gViewMap.zoomNormal(scaleFactor);
	}
}
