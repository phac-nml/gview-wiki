package ca.corefacility.gview.map.gui.action;

import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.ElementControl;

public class HideLabelsAction extends HideItemAction 
{
	private final ElementControl control;
	
	public HideLabelsAction(ElementControl control)
	{
		this.control = control;
	}
	
	@Override
	public void undo() throws CannotUndoException 
	{
		control.setLabelsDisplayed(true);
	}

	@Override
	public void run() 
	{
		control.setLabelsDisplayed(false);
	}

}
