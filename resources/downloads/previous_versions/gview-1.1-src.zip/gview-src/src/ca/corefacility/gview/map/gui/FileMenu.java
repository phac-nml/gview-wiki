package ca.corefacility.gview.map.gui;

import javax.swing.JMenu;

/**
 * Responsible for creating the File menu.
 * 
 * @author ericm
 *
 */
public class FileMenu extends JMenu
{
	private static final long serialVersionUID = -7654430740976972758L;
	
	//Items in the File menu.
	private final OpenMenuItem openItem;
	private final ExportMenuItem exportItem;
	private final ExitMenuItem exitItem;
	
	/**
	 * Creates a new FileMenu belonging the the specified frame.
	 * 
	 * @param frame  The frame this FileMenu belongs to.
	 */
	public FileMenu(GViewGUIFrame frame)
	{
		super(GUIUtility.FILE_TEXT);
		
		//Open Menu Item
		this.openItem = new OpenMenuItem();
		this.add(this.openItem);
		
		//Export Menu Item
		this.exportItem = new ExportMenuItem(frame);
		this.add(this.exportItem);
		
		this.add(GUIUtility.createSeparator(this));
		
		//Exit Menu Item
		this.exitItem = new ExitMenuItem();
		this.add(this.exitItem);
	}
}
