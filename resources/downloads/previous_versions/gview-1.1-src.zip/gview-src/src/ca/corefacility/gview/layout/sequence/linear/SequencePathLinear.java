package ca.corefacility.gview.layout.sequence.linear;

import java.awt.Shape;

import org.biojava.bio.symbol.Location;

import ca.corefacility.gview.layout.Direction;
import ca.corefacility.gview.layout.prototype.NonFragmentingStretchableShape;
import ca.corefacility.gview.layout.prototype.SequencePoint;
import ca.corefacility.gview.layout.prototype.SequencePointImp;
import ca.corefacility.gview.layout.prototype.StretchableShape;
import ca.corefacility.gview.layout.prototype.segments.CloseSegment;
import ca.corefacility.gview.layout.prototype.segments.LineSegment;
import ca.corefacility.gview.layout.prototype.segments.MoveSegment;
import ca.corefacility.gview.layout.sequence.AbstractSequencePath;
import ca.corefacility.gview.layout.sequence.Backbone;

public class SequencePathLinear extends AbstractSequencePath
{
	/**
	 * Creates a new SequencePathLinear around the passed data.
	 * 
	 * @param backbone  The backbone of the sequence.
	 */
	public SequencePathLinear(Backbone backbone)
	{
		super(backbone);
		
		shape = new NonFragmentingStretchableShape(backbone);
	}

	public void closePath()
	{
		shape.appendSegment(new CloseSegment());
		
		prevSequencePoint = new SequencePointImp();
	}

	public void lineTo(double base, double heightFromBackbone, Direction direction) // ignores direction for now
	{
		performLineTo(base, heightFromBackbone, direction);
	}

	public void lineTo(double base, Direction direction)
	{
		performLineTo(base, prevSequencePoint.getHeightFromBackbone(), direction);
	}
	
	// performs the lineTo, used so that we can call this method with  the previous heightFromBackbone (in prevSequencePoint).
	private void performLineTo(double base, double heightFromBackbone, Direction direction)
	{
		SequencePoint movePoint = new SequencePointImp(base, heightFromBackbone);
		
		shape.appendSegment(new LineSegment(movePoint));
		
		prevSequencePoint = movePoint;
	}
	
	public void lineTo(double base, double heightFromBackbone, double lengthFromBase, Direction direction)
	{
		realLineTo(base, heightFromBackbone, lengthFromBase);
	}
	
	public void clear()
	{
		super.clear();
		shape = new NonFragmentingStretchableShape(backbone);
		
		prevSequencePoint = new SequencePointImp();
	}

	@Override
	public Shape createFullBackboneShape(double topHeight, double bottomHeight, Location trueLocation)
	{
		StretchableShape shape = new NonFragmentingStretchableShape(backbone);
		
		SequencePoint currPoint = new SequencePointImp(0, topHeight);
		shape.appendSegment(new MoveSegment(currPoint));
		currPoint = new SequencePointImp(trueLocation.getMax(), topHeight);
		shape.appendSegment(new LineSegment(currPoint));
		currPoint = new SequencePointImp(trueLocation.getMax(), bottomHeight);
		shape.appendSegment(new LineSegment(currPoint));
		currPoint = new SequencePointImp(0, bottomHeight);
		shape.appendSegment(new LineSegment(currPoint));
		currPoint = new SequencePointImp(0, topHeight);
		shape.appendSegment(new LineSegment(currPoint));
		
		return shape;
	}
}
