package ca.corefacility.gview.layout;


import java.awt.Shape;
import java.util.Iterator;

import org.biojava.bio.seq.DNATools;
import org.biojava.bio.seq.ProteinTools;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.symbol.Symbol;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.layout.sequence.SlotPath;
import ca.corefacility.gview.utils.ProgressHandler;
import ca.corefacility.gview.utils.content.AverageCalculator;
import ca.corefacility.gview.utils.content.ContentCalculator.RangeValue;
import ca.corefacility.gview.utils.content.SkewCalculator;

public class PlotBuilderGC extends PlotBuilderRange
{
	private boolean	doGCContent;
	public PlotBuilderGC( boolean content )
	{
		this.minValue = -1;
		this.maxValue = 1;
		this.doGCContent = content;
	}
	
	@Override
	public Shape[][] createPlot(GenomeData genomeData, SlotPath path, PlotDrawer plotDrawer)
	{
		if (!DNATools.getDNA().equals(genomeData.getSequence().getAlphabet()))
		{
			throw new IllegalArgumentException("alphabet for this sequence data is of type \""
					+ genomeData.getSequence().getAlphabet().getName() + "\" and not of type \"DNA\"");
		}
		
		if (genomeData.getSequenceLength() <= 0)
		{
			throw new IllegalArgumentException("no symbols for sequence data");
		}
		
		if( doGCContent )
		{
			ProgressHandler.setMessage(ProgressHandler.CALCULATING_GC_CONTENT + "...");
			
			AverageCalculator calculator = new AverageCalculator.GC(genomeData);
			
			double averageGC = calculator.getTotalAverageContent();
			setCenterHeight( averageGC );
			
			Iterator<RangeValue> averageIter = calculator.contentIterator();
			
			while (averageIter.hasNext())
			{
				RangeValue rangeValue = averageIter.next();
				
				addRange( rangeValue.location.getMin(), rangeValue.location.getMax(), rangeValue.value);
			}
		}
		else
		{
			ProgressHandler.setMessage(ProgressHandler.CALCULATING_GC_SKEW + "...");
			
			SkewCalculator calculator = new SkewCalculator.GC(genomeData);
			
			double averageGCSkew = calculator.getTotalAverageContent();
			setCenterHeight( averageGCSkew );
			
			Iterator<RangeValue> averageIter = calculator.contentIterator();
			
			while (averageIter.hasNext())
			{
				RangeValue rangeValue = averageIter.next();
				
				addRange( rangeValue.location.getMin(), rangeValue.location.getMax(), rangeValue.value);
			}
		}
		
		autoScaleCenter();
		return super.createPlot( genomeData, path, plotDrawer );
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (doGCContent ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlotBuilderGC other = (PlotBuilderGC) obj;
		if (doGCContent != other.doGCContent)
			return false;
		return true;
	}
}
