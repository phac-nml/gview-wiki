package ca.corefacility.gview.map.gui;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBoxMenuItem;

import ca.corefacility.gview.map.ElementControl;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.HideRulerAction;
import ca.corefacility.gview.map.gui.action.ShowRulerAction;

/**
 * Responsible for creating and managing the "Show Ruler" menu item.
 * 
 * @author ericm
 *
 */
public class ShowRulerMenuItem extends JCheckBoxMenuItem implements ItemListener
{
	private static final long serialVersionUID = 7314647385863425910L;

	private final GViewMap gViewMap;
	
	private final ElementControl control;
	
	/**
	 * Creates a new ShowRuler menu item within the specified frame.
	 * @param frame  The frame this menu item belongs to.
	 */
	public ShowRulerMenuItem(GViewGUIFrame frame)
	{
		super(GUIUtility.SHOW_RULER_TEXT);
		
		this.gViewMap = frame.getGViewMap();
		
		this.addItemListener(this);

		this.control = (this.gViewMap).getElementControl();
		
		this.setSelected(true);
	}

	@Override
	/**
	 * Listens for the menu item.
	 */
	public void itemStateChanged(ItemEvent e)
	{
		Action action;
		
		if (e.getStateChange() == ItemEvent.SELECTED)
		{
			action = new ShowRulerAction(control);
			action.run();
		}
		else if (e.getStateChange() == ItemEvent.DESELECTED)
		{
			action = new HideRulerAction(control);
			action.run();
		}
	}
	
	/**
	 * Updates the selected state of the menu item.
	 */
	public void update()
	{
		if(control.getRulerDisplayed())
		{
			this.setSelected(true);
		}
		else
		{
			this.setSelected(false);
		}			
	}
	
}
