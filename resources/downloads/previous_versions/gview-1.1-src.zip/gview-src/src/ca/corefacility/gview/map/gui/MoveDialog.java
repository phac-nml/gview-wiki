package ca.corefacility.gview.map.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import ca.corefacility.gview.map.GViewMap;

/**
 * The custom move dialog box. Extends the abstract SliderDialog class.
 * 
 * @author ericm
 *
 */
public class MoveDialog extends SliderDialog implements ActionListener
{
	private static final long serialVersionUID = 430544496590268219L;

	/**
	 * 
	 * @param frame The frame the dialog will be attached to.
	 * @param gViewMap The GView map the dialog will be working with.
	 */
	public MoveDialog(JFrame frame, GViewMap gViewMap) 
	{	
		super(0, gViewMap.getMaxSequenceLength(), -1, frame, gViewMap, "Enter a location between 0 bp and " + gViewMap.getMaxSequenceLength() + " bp:");
	}
	
	/**
	 * Shows the dialog.
	 */
	public void showMoveDialog()
	{
		double moveLocation = GVIEW_MAP.getCenterBaseValue();
		
		setVisible(true);		
		
		//Check to see if the move location is valid.
		if( moveLocation >= MIN && moveLocation <= GVIEW_MAP.getMaxSequenceLength())
		{
			SLIDER.setValue((int)moveLocation);
			TEXT_FIELD.setText((int)moveLocation + "");
		}
		else if (moveLocation < MIN)
		{
			SLIDER.setValue(MIN);
			TEXT_FIELD.setText(MIN + "");
		}
		else if (moveLocation > GVIEW_MAP.getMaxSequenceLength())
		{
			SLIDER.setValue(GVIEW_MAP.getMaxSequenceLength());
			TEXT_FIELD.setText(GVIEW_MAP.getMaxSequenceLength() + "");			
		}
	}
	
	@Override
	/**
	 * Listens for the buttons.
	 */
	public void actionPerformed(ActionEvent e) 
	{
		double moveLocation;
		
		//OK button pressed.
		if(OK.equals(e.getActionCommand()))
		{	
			try
			{
				//Try to parse the string to a double.
				moveLocation = Double.parseDouble(TEXT_FIELD.getText());
			}
			catch(NumberFormatException nfe)
			{
				//Set to invalid input.
				moveLocation = INVALID;				
			}
			
			//Check for invalid input.
			if(moveLocation < MIN || moveLocation > GVIEW_MAP.getMaxSequenceLength())
			{
				JOptionPane.showMessageDialog(null, TEXT_FIELD.getText() + " is not within " + MIN + " to " + GVIEW_MAP.getMaxSequenceLength(), "Invalid Number", JOptionPane.WARNING_MESSAGE);
				TEXT_FIELD.setText(SLIDER.getValue() + "");
			}
			//Valid input.
			else
			{
				GVIEW_MAP.setCenter((int)moveLocation);			
				setVisible(false);			
			}
		}
		//Cancel button pressed.
		else if(CANCEL.equals(e.getActionCommand()))
		{
			setVisible(false);
		}
	}
}
