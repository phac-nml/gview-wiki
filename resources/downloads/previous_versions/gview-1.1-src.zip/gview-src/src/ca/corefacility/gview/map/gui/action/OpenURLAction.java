package ca.corefacility.gview.map.gui.action;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class OpenURLAction extends SystemAction 
{
	private final String website;
	
	public OpenURLAction(String website)
	{
		this.website = website;
	}
	
	@Override
	public void run() 
	{
        if(java.awt.Desktop.isDesktopSupported())
        {
        	Desktop desktop = Desktop.getDesktop();
        	if (desktop.isSupported(Desktop.Action.BROWSE))
        	{
        		try
				{
					URI uri = new URI(website);
					desktop.browse(uri);
				}
        		catch (URISyntaxException e1)
				{
					e1.printStackTrace();
				}
        		catch (IOException e1)
				{
					e1.printStackTrace();
				}
        	}
        }
	}

}
