package ca.corefacility.gview.style.io.gss.exceptions;

/**
 * 
 * @author aaron
 *
 */
public class NoSuchFilterException extends ParseException
{

	public NoSuchFilterException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public NoSuchFilterException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoSuchFilterException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoSuchFilterException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
