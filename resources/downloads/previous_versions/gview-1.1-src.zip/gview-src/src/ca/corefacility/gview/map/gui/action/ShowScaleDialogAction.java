package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.gui.ScaleDialog;

public class ShowScaleDialogAction extends ShowDialogAction 
{
	public ShowScaleDialogAction(ScaleDialog dialog)
	{
		super(dialog);
	}
}
