package ca.corefacility.gview.map.gui;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.KeyStroke;

import ca.corefacility.gview.map.ElementControl;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.HideLegendAction;
import ca.corefacility.gview.map.gui.action.ShowLegendAction;

/**
 * Responsible for creating and managing the "Show Legend" menu item.
 * 
 * @author ericm
 *
 */
public class ShowLegendMenuItem extends JCheckBoxMenuItem implements ItemListener
{
	private static final long serialVersionUID = -3524736665349741945L;
	
	private final GViewMap gViewMap;
	
	private final ElementControl control;
	
	/**
	 * Creates a new ShowLegend menu item within the specified frame.
	 * 
	 *  @param frame  The frame this menu item belongs to.
	 */
	public ShowLegendMenuItem(GViewGUIFrame frame)
	{
		super(GUIUtility.SHOW_LEGEND_TEXT);
		
		this.gViewMap = frame.getGViewMap();
		
		this.setAccelerator(KeyStroke.getKeyStroke(GUIUtility.LEGEND_SHORTCUT));
		this.addItemListener(this);	

		this.control = (this.gViewMap).getElementControl();
	}
	
	@Override
	/**
	 * Listens for the menu item.
	 */
	public void itemStateChanged(ItemEvent e)
	{
		Action action;
		
		if (e.getStateChange() == ItemEvent.SELECTED)
		{
			action = new ShowLegendAction(control);
			action.run();
		}
		else if (e.getStateChange() == ItemEvent.DESELECTED)
		{
			action = new HideLegendAction(control);
			action.run();
		}
	}
	
	/**
	 * Updates the selected state of the menu item.
	 */
	public void update()
	{
		if(control.getLegendDisplayed())
		{
			this.setSelected(true);
		}
		else
		{
			this.setSelected(false);
		}			
	}
}
