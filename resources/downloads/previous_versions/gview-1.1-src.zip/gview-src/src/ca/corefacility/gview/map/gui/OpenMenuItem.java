package ca.corefacility.gview.map.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import ca.corefacility.gview.map.gui.action.OpenAction;

/**
 * Responsible for creating the Open menu item.
 * 
 * @author ericm
 *
 */
public class OpenMenuItem extends JMenuItem implements ActionListener
{
	private static final long serialVersionUID = -6641674381979921704L;
	
	public OpenMenuItem()
	{
		super(GUIUtility.OPEN_TEXT);
		
		this.setActionCommand(GUIUtility.OPEN);
		this.setAccelerator(KeyStroke.getKeyStroke(GUIUtility.OPEN_SHORTCUT));
		this.addActionListener(this);
	}

	@Override
	/**
	 * Listens for open dialog events.
	 */
	public void actionPerformed(ActionEvent e) 
	{
		OpenAction action;
		
		if (GUIUtility.OPEN.equals(e.getActionCommand()))
		{
			action = new OpenAction();
			action.run();
		}		
	}
}
