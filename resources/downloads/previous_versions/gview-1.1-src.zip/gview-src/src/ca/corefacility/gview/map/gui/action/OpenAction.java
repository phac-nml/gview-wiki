package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.gui.open.OpenDialog;

public class OpenAction extends SystemAction 
{
	@Override
	public void run() 
	{
		OpenDialog.showOpenDialog();
	}
}
