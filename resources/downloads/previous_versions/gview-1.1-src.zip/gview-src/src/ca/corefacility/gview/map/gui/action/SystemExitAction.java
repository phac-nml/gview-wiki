package ca.corefacility.gview.map.gui.action;

public class SystemExitAction extends SystemAction 
{
	@Override
	public void run() 
	{
		System.exit(0);
	}
}
