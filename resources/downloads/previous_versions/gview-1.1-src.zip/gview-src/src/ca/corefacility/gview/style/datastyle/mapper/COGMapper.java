package ca.corefacility.gview.style.datastyle.mapper;

public class COGMapper extends AnnotationMapper implements DiscretePropertyMapper
{
	public COGMapper(String[] cogCategories)
	{
		super("COG", cogCategories);
	}
}
