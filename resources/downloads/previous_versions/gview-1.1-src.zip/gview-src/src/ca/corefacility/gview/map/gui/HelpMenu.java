package ca.corefacility.gview.map.gui;

import javax.swing.JMenu;

/**
 * Responsible for creating the help menu.
 * 
 * @author ericm
 *
 */
public class HelpMenu extends JMenu
{
	private static final long serialVersionUID = -3342273759522042555L;
	
	//Items in the Help menu.
	private final ViewerUsageMenuItem usageItem;
	private final WebsiteMenuItem websiteItem;
	private final AboutMenuItem aboutItem;
	
	/**
	 * Creates the help menu.
	 */
	public HelpMenu(GViewGUIFrame frame)
	{
		super(GUIUtility.HELP_TEXT);
		
		//Viewer Usage Menu Item
		this.usageItem = new ViewerUsageMenuItem();
		this.add(this.usageItem);
		
		//Website Menu Item
		this.websiteItem = new WebsiteMenuItem();
		this.add(this.websiteItem);
		
		//About Menu item
		this.aboutItem = new AboutMenuItem(frame);
		this.add(aboutItem);
	}
}
