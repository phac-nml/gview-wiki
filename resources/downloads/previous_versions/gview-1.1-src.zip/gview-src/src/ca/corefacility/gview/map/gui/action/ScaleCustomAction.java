package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.GViewMap;

public class ScaleCustomAction extends ScaleAction 
{
	private final GViewMap gViewMap;
	private final double value;
	
	public ScaleCustomAction(GViewMap gViewMap, double value)
	{
		super(gViewMap,gViewMap.getZoomNormalFactor());
		
		this.gViewMap = gViewMap;
		this.value = value;
	}

	@Override
	public void run() 
	{
		gViewMap.zoomNormal(value); 
	}
}
