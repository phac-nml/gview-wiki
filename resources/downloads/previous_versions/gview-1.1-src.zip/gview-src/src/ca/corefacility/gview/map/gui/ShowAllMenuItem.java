package ca.corefacility.gview.map.gui;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBoxMenuItem;

import ca.corefacility.gview.map.ElementControl;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.HideAllAction;
import ca.corefacility.gview.map.gui.action.ShowAllAction;

/**
 * Responsible for creating and managing the "Show All" menu item.
 * 
 * @author ericm
 *
 */
public class ShowAllMenuItem extends JCheckBoxMenuItem implements ItemListener
{
	private static final long serialVersionUID = -7757221658484529616L;
	
	private final GViewMap gViewMap;
	
	private final ElementControl control;
	
	/**
	 * Creates a ShowAllMenuItem within the specified frame.
	 * @param frame  The frame containing the ShowAllMenuItem.
	 */
	public ShowAllMenuItem(GViewGUIFrame frame)
	{
		super(GUIUtility.SHOW_ALL_TEXT);
		
		this.gViewMap = frame.getGViewMap();
		
		this.addItemListener(this);
		
		this.control = (this.gViewMap).getElementControl();
		
		this.setSelected(true);
	}

	@Override
	/**
	 * Listens for the menu item.
	 */
	public void itemStateChanged(ItemEvent e)
	{
		Action action;
		
		if (e.getStateChange() == ItemEvent.SELECTED)
		{
			action = new ShowAllAction(control);
			action.run();
		}
		else if (e.getStateChange() == ItemEvent.DESELECTED)
		{
			if(control.getAllDisplayed())
			{
				action = new HideAllAction(control);
				action.run();
			}
		}
	}
	
	/**
	 * Updates the selected state of the menu item.
	 */
	public void update()
	{
		if(control.getAllDisplayed())
		{
			this.setSelected(true);
		}
		else
		{
			this.setSelected(false);
		}
			
	}
	
}
