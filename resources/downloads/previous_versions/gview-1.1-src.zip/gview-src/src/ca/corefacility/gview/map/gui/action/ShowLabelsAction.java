package ca.corefacility.gview.map.gui.action;

import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.ElementControl;

public class ShowLabelsAction extends ShowItemAction 
{
	private final ElementControl control;
	
	public ShowLabelsAction(ElementControl control)
	{
		this.control = control;
	}
	
	@Override
	public void undo() throws CannotUndoException 
	{
		control.setLabelsDisplayed(false);
	}

	@Override
	public void run() 
	{
		control.setLabelsDisplayed(true);
	}

}
