package ca.corefacility.gview.map.gui;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.KeyStroke;


import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.HideBEVDialogAction;
import ca.corefacility.gview.map.gui.action.ShowBEVDialogAction;

/**
 * Responsible for creating and managing the Bird's Eye View menu item.
 * 
 * @author ericm
 *
 */
public class BEVMenuItem extends JCheckBoxMenuItem implements ItemListener 
{
	private static final long serialVersionUID = 4071322905131591857L;
	
	private final GViewGUIFrame frame;
	
	/**
	 * Creates a new BEV menu item within the specified frame.
	 * @param frame The frame this menu item is to be placed in.
	 */
	public BEVMenuItem(GViewGUIFrame frame)
	{
		super(GUIUtility.BEV_TEXT);
		
		this.frame = frame;		
		this.frame.setBEVDialog(new BEVDialog(frame.getGViewMap(), this));	
		
		this.setAccelerator(KeyStroke.getKeyStroke(GUIUtility.BEV_SHORTCUT));
		this.addItemListener(this);
	}
	
	@Override
	/**
	 * Listens for the BEV Menu item being selected.
	 */
	public void itemStateChanged(ItemEvent e) 
	{
		Action action;
		
		if (e.getStateChange() == ItemEvent.SELECTED)
		{
			action = new ShowBEVDialogAction(frame.getBEVDialog());
			action.run();
		}
		else if (e.getStateChange() == ItemEvent.DESELECTED)
		{
			action = new HideBEVDialogAction(frame.getBEVDialog());
			action.run();
		}		
	}
}
