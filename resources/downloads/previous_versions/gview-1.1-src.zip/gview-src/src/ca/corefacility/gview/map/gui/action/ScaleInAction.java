package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.GViewMap;

public class ScaleInAction extends ScaleAction
{
	private final GViewMap gViewMap;
	
	public ScaleInAction(GViewMap gViewMap)
	{
		super(gViewMap,gViewMap.getZoomNormalFactor());
		
		this.gViewMap = gViewMap;
	}
	
	public void run()
	{
		double scaleFactor;
		
		scaleFactor = gViewMap.getZoomNormalFactor();
		scaleFactor *= 1.1;
		gViewMap.zoomNormal(scaleFactor);
	}
}
