package ca.corefacility.gview.style.items;

public enum LegendTextAlignment
{
	LEFT,
	CENTER,
	RIGHT
}
