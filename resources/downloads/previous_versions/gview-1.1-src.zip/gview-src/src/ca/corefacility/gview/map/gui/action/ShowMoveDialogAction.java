package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.gui.MoveDialog;

public class ShowMoveDialogAction extends ShowDialogAction 
{
	public ShowMoveDialogAction (MoveDialog dialog)
	{
		super(dialog);
	}
}
