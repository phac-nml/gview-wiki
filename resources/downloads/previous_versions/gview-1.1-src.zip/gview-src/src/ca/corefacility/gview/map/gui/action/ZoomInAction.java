package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.GViewMap;

public class ZoomInAction extends ZoomAction
{
	private final GViewMap gViewMap;
	
	public ZoomInAction(GViewMap gViewMap)
	{
		super(gViewMap, gViewMap.getZoomFactor());
		
		this.gViewMap = gViewMap;
	}
	
	public void run()
	{
		double zoomFactor;
		
		zoomFactor = gViewMap.getZoomFactor();
		zoomFactor *= 1.1;
		gViewMap.setZoomFactor(zoomFactor);
	}
}
