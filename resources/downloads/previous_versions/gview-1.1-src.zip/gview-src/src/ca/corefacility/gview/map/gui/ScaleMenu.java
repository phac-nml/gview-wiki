package ca.corefacility.gview.map.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.ScaleCustomAction;
import ca.corefacility.gview.map.gui.action.ScaleInAction;
import ca.corefacility.gview.map.gui.action.ScaleOutAction;
import ca.corefacility.gview.map.gui.action.ShowScaleDialogAction;

/**
 * Responsible for creating the Scale menu.
 * 
 * @author ericm
 *
 */
public class ScaleMenu extends JMenu implements ActionListener
{	
	private static final long serialVersionUID = 1L;
	
	private final JCheckBoxMenuItem[] checkItems; 
	
	private final GViewMap gViewMap;
	private final GViewGUIFrame frame;
	
	/**
	 * Creates a new ScaleMenu within the specified frame. 
	 * @param frame The frame the menu will be sitting on. Required for the custom scale dialog.
	 */
	public ScaleMenu(GViewGUIFrame frame)
	{
		super(GUIUtility.SCALE_TEXT);
		
		this.frame = frame;
		this.gViewMap = frame.getGViewMap();	
		
		this.checkItems = new JCheckBoxMenuItem[GUIUtility.specificScaleItems.length];
		
		addMenuItems();
	}
	
	/**
	 * Adds the individual menu items to the scale menu.
	 */
	private void addMenuItems()
	{
		JMenuItem currMenuItem;		
		
		currMenuItem = new JMenuItem(GUIUtility.SCALE_IN);
		currMenuItem.setActionCommand(GUIUtility.SCALE_IN);
		currMenuItem.addActionListener(this);
		this.add(currMenuItem);
		
		currMenuItem = new JMenuItem(GUIUtility.SCALE_OUT);
		currMenuItem.addActionListener(this);
		this.add(currMenuItem);
		
		this.add(GUIUtility.createSeparator(this));
		
		//Add the items to the menu and checkItems
		for (int i = 0; i < GUIUtility.specificScaleItems.length; i++)
		{
			currMenuItem = new JCheckBoxMenuItem(GUIUtility.specificScaleItems[i]);
			currMenuItem.addActionListener(this);
			this.add(currMenuItem);
			
			if(currMenuItem instanceof JCheckBoxMenuItem)
				checkItems[i] = (JCheckBoxMenuItem)currMenuItem;
		}
		
		this.add(GUIUtility.createSeparator(this));
		
		currMenuItem = new JMenuItem(GUIUtility.CUSTOM_TEXT);
		currMenuItem.setActionCommand(GUIUtility.SCALE_CUSTOM);
		currMenuItem.addActionListener(this);
		this.add(currMenuItem);		
	}
	
	/**
	 * Updates the menu by comparing all of the 'checkable' items against the current scale level and sets the 'check' state appropriately for each.
	 */
	public void updateMenu()
	{
		double currScaleLevel = (this.gViewMap.getZoomNormalFactor());
		
		for (int i = 0; i < GUIUtility.specificScaleLevels.length; i++)
		{	
			if((int)Math.round((currScaleLevel * GUIUtility.SCALE_FACTOR)) != GUIUtility.specificScaleLevels[i])
			{
				checkItems[i].setSelected(false);
			}
			else
			{
				checkItems[i].setSelected(true);
			}
		}	
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		Action action;
		
		if (GUIUtility.SCALE_IN.equals(e.getActionCommand()))
		{
			action = new ScaleInAction(gViewMap);
			action.run();
		}
		else if (GUIUtility.SCALE_OUT.equals(e.getActionCommand()))
		{
			action = new ScaleOutAction(gViewMap);
			action.run();
		}
		else if (GUIUtility.SCALE_10.equals(e.getActionCommand()))
		{
			action = new ScaleCustomAction(gViewMap, 10.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.SCALE_25.equals(e.getActionCommand()))
		{
			action = new ScaleCustomAction(gViewMap, 25.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.SCALE_50.equals(e.getActionCommand()))
		{
			action = new ScaleCustomAction(gViewMap, 50.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.SCALE_100.equals(e.getActionCommand()))
		{
			action = new ScaleCustomAction(gViewMap, 100.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.SCALE_200.equals(e.getActionCommand()))
		{
			action = new ScaleCustomAction(gViewMap, 200.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.SCALE_400.equals(e.getActionCommand()))
		{
			action = new ScaleCustomAction(gViewMap, 400.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.SCALE_800.equals(e.getActionCommand()))
		{
			action = new ScaleCustomAction(gViewMap, 800.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.SCALE_1600.equals(e.getActionCommand()))
		{
			action = new ScaleCustomAction(gViewMap, 1600.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}		
		else if( (GUIUtility.SCALE_CUSTOM).equals(e.getActionCommand()) )
		{	
			action = new ShowScaleDialogAction(frame.getScaleDialog());
			action.run();
		}
		
	}
}
