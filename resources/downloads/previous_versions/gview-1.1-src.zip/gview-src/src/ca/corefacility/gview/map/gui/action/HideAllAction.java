package ca.corefacility.gview.map.gui.action;


import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.ElementControl;

public class HideAllAction extends HideItemAction {

	private final ElementControl control;
	
	public HideAllAction(ElementControl control)
	{
		this.control = control;
	}
	
	@Override
	public void undo() throws CannotUndoException 
	{
		control.setLegendDisplayed(true);
		control.setLabelsDisplayed(true);
		control.setRulerDisplayed(true);
	}

	@Override
	public void run() 
	{
		control.setLegendDisplayed(false);
		control.setLabelsDisplayed(false);
		control.setRulerDisplayed(false);
	}

}
