package ca.corefacility.gview.map.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.SystemExitAction;

/**
 * Creates the Exit menu item.
 * 
 * @author ericm
 *
 */
public class ExitMenuItem extends JMenuItem implements ActionListener
{
	private static final long serialVersionUID = 5875414541172100031L;
	
	public ExitMenuItem()
	{
		super(GUIUtility.EXIT_TEXT);
		
		this.setActionCommand(GUIUtility.EXIT);
		this.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(GUIUtility.EXIT_TEXT.equals(e.getActionCommand()))
		{
			Action action = new SystemExitAction();
			action.run();
		}
	}
}
