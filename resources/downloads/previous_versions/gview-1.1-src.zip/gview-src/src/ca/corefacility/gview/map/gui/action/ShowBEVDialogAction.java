package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.gui.BEVDialog;

public class ShowBEVDialogAction extends ShowDialogAction 
{	
	public ShowBEVDialogAction (BEVDialog dialog)
	{
		super(dialog);
	}
}
