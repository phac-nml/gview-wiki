package ca.corefacility.gview.map.gui.open;

import java.io.File;
import java.net.MalformedURLException;

import javax.swing.filechooser.FileFilter;

import ca.corefacility.gview.data.readers.GViewFileReader;

public class SequenceDataFilter extends FileFilter
{

	@Override
	public boolean accept(File f)
	{
		if (f != null)
		{
			if (f.exists())
			{
				return true;
			}
		}
		
		return false;
	}

	@Override
	public String getDescription()
	{
		return "Genbank, GFF, FASTA, EMBL, CGView XML";
	}
}
