package ca.corefacility.gview.map;

import ca.corefacility.gview.managers.DisplayManager;
import ca.corefacility.gview.map.inputHandler.LegendHandler;

/**
 * Allows for controlling of which elements are to be displayed on the map.
 * @author aaron
 *
 */
public class ElementControl
{
	private LegendHandler legendHandler;
	private DisplayManager displayManager;
	
	public ElementControl(DisplayManager displayManager, LegendHandler legendHandler)
	{
		if (displayManager == null)
		{
			throw new IllegalArgumentException("displayManager is null");
		}
		
		if (legendHandler == null)
		{
			throw new IllegalArgumentException("legendHandler is null");
		}
		
		this.legendHandler = legendHandler;
		this.displayManager = displayManager;
	}
	
	public void setLegendDisplayed(boolean displayed)
	{
		legendHandler.setLegendDisplayed(displayed);		
	}
	
	public void setLabelsDisplayed(boolean displayed)
	{
		displayManager.setLabelsDisplayed(displayed);
	}
	
	public void setRulerDisplayed(boolean displayed)
	{
		displayManager.setRulerDisplayed(displayed);
	}
	
	public void setAllDisplayed(boolean displayed)
	{
		setLegendDisplayed(displayed);
		setLabelsDisplayed(displayed);
		setRulerDisplayed(displayed);
	}
	
	public boolean getAllDisplayed()
	{
		return getLegendDisplayed() && getLabelsDisplayed() &&
			   getRulerDisplayed();
	}
	
	public boolean getRulerDisplayed()
	{
		return displayManager.getRulerDisplayed();
	}
	
	public boolean getLabelsDisplayed()
	{
		return displayManager.getLabelsDisplayed();
	}
	
	public boolean getLegendDisplayed()
	{
		return displayManager.getLegendDisplayed();
	}
}
