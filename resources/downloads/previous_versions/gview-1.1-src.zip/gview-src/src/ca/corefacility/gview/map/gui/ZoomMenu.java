package ca.corefacility.gview.map.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.ShowZoomDialogAction;
import ca.corefacility.gview.map.gui.action.ZoomCustomAction;
import ca.corefacility.gview.map.gui.action.ZoomInAction;
import ca.corefacility.gview.map.gui.action.ZoomOutAction;

/**
 * Responsible for creating and managing the Zoom menu on GView's menu bar.
 * 
 * @author ericm
 *
 */
public class ZoomMenu extends JMenu implements ActionListener 
{
	private static final long serialVersionUID = -1607467395456822473L;	//requested by java

	private final GViewMap gViewMap;
	private final GViewGUIFrame frame;
	
	private final JCheckBoxMenuItem[] checkItems; 

	/**
	 * Creates a new Zoom menu within the specified frame. 
	 * @param frame The frame the menu will be sitting on. Required for the custom scale dialog.
	 */
	public ZoomMenu(GViewGUIFrame frame)
	{
		super(GUIUtility.ZOOM_TEXT);
		
		this.frame = frame;
		this.gViewMap = frame.getGViewMap();
		
		this.checkItems = new JCheckBoxMenuItem[GUIUtility.specificZoomItems.length];
		
		addMenuItems();
	}
	
	/**
	 * Adds the individual menu items to the zoom sub menu.
	 */
	private void addMenuItems()
	{
		JMenuItem currMenuItem;
		
		currMenuItem = new JMenuItem(GUIUtility.ZOOM_IN);
		currMenuItem.addActionListener(this);		
		this.add(currMenuItem);
		
		currMenuItem = new JMenuItem(GUIUtility.ZOOM_OUT);		
		currMenuItem.addActionListener(this);
		this.add(currMenuItem);
		
		this.add(GUIUtility.createSeparator(this));		
		
		//Add the items to the menu and checkItems
		for (int i = 0; i < GUIUtility.specificZoomItems.length; i++)
		{
			currMenuItem = new JCheckBoxMenuItem(GUIUtility.specificZoomItems[i]);
			currMenuItem.addActionListener(this);
			this.add(currMenuItem);
			
			if(currMenuItem instanceof JCheckBoxMenuItem)
				checkItems[i] = (JCheckBoxMenuItem)currMenuItem;
		}
		
		this.add(GUIUtility.createSeparator(this));
		
		currMenuItem = new JMenuItem(GUIUtility.CUSTOM_TEXT);
		currMenuItem.setActionCommand(GUIUtility.ZOOM_CUSTOM);
		currMenuItem.addActionListener(this);
		this.add(currMenuItem);
	}
	
	/**
	 * Updates the menu by comparing all of the 'checkable' items against the current zoom level and sets the 'check' state appropriately for each.
	 */
	public void updateMenu()
	{
		int currZoomLevel = (int)(gViewMap.getZoomFactor() * GUIUtility.SCALE_FACTOR); // to coordinate with %'s, also rounding to ints
		
		for (int i = 0; i < GUIUtility.specificZoomLevels.length; i++)
		{	
			if(currZoomLevel != GUIUtility.specificZoomLevels[i])
			{
				checkItems[i].setSelected(false);
			}
			else
			{
				checkItems[i].setSelected(true);
			}
		}		
	}

	@Override
	/**
	 * Listens for the menu items.
	 */
	public void actionPerformed(ActionEvent e)
	{
		Action action;
		
		if (GUIUtility.ZOOM_IN.equals(e.getActionCommand()))
		{
			action = new ZoomInAction(gViewMap);
			action.run();
		}
		else if (GUIUtility.ZOOM_OUT.equals(e.getActionCommand()))
		{
			action = new ZoomOutAction(gViewMap);
			action.run();
		}
		else if (GUIUtility.ZOOM_100.equals(e.getActionCommand()))
		{
			action = new ZoomCustomAction(gViewMap, 100.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.ZOOM_200.equals(e.getActionCommand()))
		{
			action = new ZoomCustomAction(gViewMap, 200.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.ZOOM_400.equals(e.getActionCommand()))
		{
			action = new ZoomCustomAction(gViewMap, 400.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.ZOOM_800.equals(e.getActionCommand()))
		{
			action = new ZoomCustomAction(gViewMap, 800.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.ZOOM_1600.equals(e.getActionCommand()))
		{
			action = new ZoomCustomAction(gViewMap, 1600.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.ZOOM_3200.equals(e.getActionCommand()))
		{
			action = new ZoomCustomAction(gViewMap, 3200.0/GUIUtility.SCALE_FACTOR);
			action.run();
		}
		else if (GUIUtility.ZOOM_CUSTOM.equals(e.getActionCommand()))
		{
			action = new ShowZoomDialogAction(frame.getZoomDialog());
			action.run();
		}	
	}
}
