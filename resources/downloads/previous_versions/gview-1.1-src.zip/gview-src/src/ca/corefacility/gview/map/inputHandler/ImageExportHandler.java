package ca.corefacility.gview.map.inputHandler;

import java.io.File;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.writers.ImageWriter;
import ca.corefacility.gview.writers.ImageWriterFactory;
import ca.corefacility.gview.writers.ImageWriterFilter;

public class ImageExportHandler
{
	private static ImageExportHandler instance = null;
	
	private JFileChooser exportDialog;

	private ImageExportHandler()
	{
		this.exportDialog = makeExporteDialog();
	}
	

	/**
	 * Builds the dialog used to export to an image file.
	 * @return  A JFileChooser used to export to an image file.
	 */
	private JFileChooser makeExporteDialog()
	{
		JFileChooser saveDialog = new JFileChooser();
		JPanel selectorPanel = new JPanel();
		JRadioButton currentScreenButton = new JRadioButton("Current View");

		selectorPanel.add(currentScreenButton);

		saveDialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
		saveDialog.setFileFilter(new ImageWriterFilter());

		//saveDialog.setAccessory(selectorPanel);

		return saveDialog;
	}
	

	public void performExport(GViewMap gviewMap)
	{
		if (gviewMap == null)
		{
			throw new IllegalArgumentException("gviewMap is null");
		}
		
		int chooserState;
		boolean continueToShow = true;

		while (continueToShow)
		{
			continueToShow = false;

			chooserState = this.exportDialog.showDialog(null, "Export");

			if (chooserState == JFileChooser.APPROVE_OPTION)
			{
				File saveFile = this.exportDialog.getSelectedFile();

				// if file to save to already exists
				if (saveFile.exists())
				{
					int choice = JOptionPane.showConfirmDialog(null,
							"File " + saveFile.getName() + " already exists.  Are you sure you wish to overwrite it?",
							"File already exists", JOptionPane.YES_NO_OPTION);

					if (choice == JOptionPane.YES_OPTION)
					{
						continueToShow = false;
						doSave(saveFile, gviewMap);
					}
					else
					{
						continueToShow = true;
					}
				}
				else
				{
					doSave(saveFile, gviewMap);
				}
			}
		}
	}
	
	/**
	 * Performs the actual saving to an image file.
	 * @param saveFile  The File to save the current view to.
	 */
	private void doSave(File saveFile, GViewMap gviewMap)
	{
		ImageWriter writer;
		try
		{
			if (ImageWriterFactory.acceptsFile(saveFile))
			{
				writer = ImageWriterFactory.createImageWriter(saveFile);
				writer.writeToImage(gviewMap, saveFile);
			}
			else
			{
				System.out.println("Unsupported file type " + ImageWriterFactory.extractExtension(saveFile.getName()));
				System.out.print("Extension should be one of ");

				String[] acceptedExtensions = ImageWriterFactory.getAcceptedExtensions();

				for (int i = 0; i < acceptedExtensions.length; i++)
				{
					System.out.print(acceptedExtensions[i] + ",");
				}
				System.out.println("\nDefaulting to png format");

				writer = ImageWriterFactory.createImageWriter("png");
				writer.writeToImage(gviewMap, saveFile.getAbsolutePath() + ".png");
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public static ImageExportHandler getInstance()
	{
		if (instance == null)
		{
			instance = new ImageExportHandler();
		}
		
		return instance;
	}
}
