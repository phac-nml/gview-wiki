package ca.corefacility.gview.layout.prototype.segments;


import java.awt.geom.Path2D;

import ca.corefacility.gview.layout.sequence.Backbone;

public class CloseSegment extends StretchableSegment
{
	/**
	 * Creates a new CloseSegment type.
	 */
	public CloseSegment()
	{
		
	}

	@Override
	protected void performAppend(Path2D path, Backbone backbone)
	{
		path.closePath();
	}
}
