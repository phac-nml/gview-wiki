package ca.corefacility.gview.map.gui.action;

import javax.swing.JFrame;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

public class FullScreenAction extends MapAction
{
	private final JFrame frame;
	
	public FullScreenAction(JFrame frame)
	{
		this.frame = frame;
	}

	@Override
	public void undo() throws CannotUndoException 
	{
		frame.setExtendedState(JFrame.NORMAL);		
	}

	@Override
	public void redo() throws CannotRedoException 
	{
		run();		
	}

	@Override
	public void run() 
	{
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
	}

}
