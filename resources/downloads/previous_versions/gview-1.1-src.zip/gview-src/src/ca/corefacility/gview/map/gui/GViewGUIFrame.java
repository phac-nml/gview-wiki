package ca.corefacility.gview.map.gui;


import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JMenuBar;
import javax.swing.JPanel;

import ca.corefacility.gview.map.GViewMap;
import edu.umd.cs.piccolox.PFrame;

/**
 * The GUI frame for GView.
 * 
 * @author ericm
 *
 */
public class GViewGUIFrame extends PFrame implements WindowListener
{
	private static final long serialVersionUID = 1L;
	
	private static volatile int guiFrameCount = 0;
	
	private int WIDTH = 800;
	private int HEIGHT = 600;
	
	private GViewMap gviewMap;
	
	//The menu bar for the frame.
	private JMenuBar menuBar;
	
	//The menus on the menu bar.
	private FileMenu fileMenu;
	private ViewMenu viewMenu;
	private HelpMenu helpMenu;
	
	//Dialogs
	private ZoomDialog zoomDialog;
	private MoveDialog moveDialog;
	private ScaleDialog scaleDialog;
	private BEVDialog bevDialog;
	private AboutDialog aboutDialog;
	
	/**
	 * 
	 * @param title The title displayed on the frame.
	 * @param fullScreenMode
	 * @param gviewMap The GView map that the frame will be related to.
	 */
	public GViewGUIFrame(String title, boolean fullScreenMode, GViewMap gviewMap)
	{
		if (gviewMap == null)
		{
			throw new IllegalArgumentException("gviewMap is null");
		}
		
		JPanel windowPanel = new JPanel();
		windowPanel.setLayout(new BorderLayout());
		
		windowPanel.add((Component)gviewMap, BorderLayout.CENTER);
		this.setContentPane(windowPanel);
		
		this.gviewMap = gviewMap;
		
		this.setTitle(title);
		this.setFrameSize(WIDTH, HEIGHT);
		this.gviewMap.scaleMapToScreen();
		
		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		this.addWindowListener(this);
		guiFrameCount++;
		
		//Initialise most dialogs:
		initializeDialogs(gviewMap);
		
		//Create GUI:
		this.menuBar = createMenuBar();
		
		//Create file menu:
		this.fileMenu = new FileMenu(this);
		this.menuBar.add(fileMenu);
		
		//Create the view menu:
		this.viewMenu = new ViewMenu(this);
		this.menuBar.add(viewMenu);
		
		//Create the help menu:
		this.helpMenu = new HelpMenu(this);		
		this.menuBar.add(helpMenu);
		
		this.setJMenuBar(menuBar);
		
		this.gviewMap.setVisible(true);
	}

	/**
	 * Sets the size of the frame and canvas.
	 * 
	 * @param width
	 * @param height
	 */
	public void setFrameSize(int width, int height)
	{
		this.setSize(WIDTH, HEIGHT);
		this.gviewMap.setViewSize(WIDTH, HEIGHT);
	}
	
	public GViewMap getGViewMap()
	{
		return gviewMap;
	}
	
	/**
	 * Returns the number of displayed frames.
	 * 
	 * @return The number of gui frames currently displayed.
	 */
	public static synchronized int getDisplayedFrames()
	{
		return guiFrameCount;
	}
	
	/**
	 * Sets whether or not the bird's eye view dialog box is visible.
	 * 
	 * @param b
	 */
	public void setBirdsEyeView(boolean b) 
	{
		bevDialog.setVisible(b);
	}

	@Override
	/**
	 * no effect
	 */
	public void windowOpened(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	/**
	 * Updates the number of frames that currently open.
	 */
	public void windowClosing(WindowEvent e)
	{
		guiFrameCount--;
				
		if (guiFrameCount <= 0)
		{
			System.exit(0);
		}
		else
		{
			this.dispose();
		}
	}

	@Override
	/**
	 * no effect
	 */
	public void windowClosed(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	/**
	 * no effect
	 */
	public void windowIconified(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	/**
	 * no effect
	 */
	public void windowDeiconified(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	/**
	 * no effect
	 */
	public void windowActivated(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	/**
	 * no effect
	 */
	public void windowDeactivated(WindowEvent e)
	{
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * Creates the menu bar.
	 * 
	 * @return
	 * 	A JMenuBar.
	 */
	private JMenuBar createMenuBar()
	{
		JMenuBar menuBar;
		
		menuBar = new JMenuBar();
		
		return menuBar;
	}
	
	/**
	 * Initializes the dialog boxes used by the frame.
	 * 
	 * @param frame The frame that will be using the dialogs.
	 * @param gViewMap The GView map that the dialogs will be effecting.
	 */
	private void initializeDialogs(GViewMap gViewMap)
	{
		zoomDialog = new ZoomDialog(this, gViewMap);
		scaleDialog = new ScaleDialog(this, gViewMap);
		moveDialog = new MoveDialog(this, gViewMap);
		aboutDialog = new AboutDialog(this);
	}
	
	public void setBEVDialog(BEVDialog dialog)
	{
		this.bevDialog = dialog;
	}
	
	public BEVDialog getBEVDialog()
	{
		return this.bevDialog;
	}
	
	/**
	 * 
	 * @return The scale dialog (tradition scaling).
	 */
	public ScaleDialog getScaleDialog()
	{
		return scaleDialog;
	}
	
	/**
	 * 
	 * @return The move dialog. Allows users to move to a specific base pair.
	 */
	public MoveDialog getMoveDialog()
	{
		return moveDialog;
	}
	
	/**
	 * 
	 * @return The zoom dialog (expanding zoom).
	 */
	public ZoomDialog getZoomDialog()
	{
		return zoomDialog;
	}
	
	/**
	 * 
	 * @return The about dialog, which contains information about the program.
	 */
	public AboutDialog getAboutDialog()
	{
		return aboutDialog;
	}
}















