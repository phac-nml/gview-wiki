package ca.corefacility.gview.map.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.OpenURLAction;

/**
 * Responsible for creating and managing the Website menu item.
 * 
 * @author ericm
 *
 */
public class WebsiteMenuItem extends JMenuItem implements ActionListener
{
	private static final long serialVersionUID = -7123998522800388275L;
	
	/**
	 * Default constructor.
	 */
	public WebsiteMenuItem()
	{
		super(GUIUtility.WEBSITE_TEXT);
		
		this.addActionListener(this);
		this.setActionCommand(GUIUtility.WEBSITE);
	}

	@Override
	/**
	 * Listens for the menu item.
	 */
	public void actionPerformed(ActionEvent e) 
	{
		Action action;
		
		if (GUIUtility.WEBSITE.equals(e.getActionCommand()))
		{
			action = new OpenURLAction(GUIUtility.URL);
			action.run();
		}
	}
}
