package ca.corefacility.gview.map.gui;

import javax.swing.JMenu;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

/**
 * Responsible for creating and managing the View menu on GView's menu bar.
 * 
 * @author ericm
 *
 */
public class ViewMenu extends JMenu implements MenuListener
{
	private static final long serialVersionUID = -3608630446171425857L;	//requested by java
	
	//Items in the View menu.
	private final ShowLegendMenuItem legendItem;
	private final ShowLabelsMenuItem labelsItem;
	private final ShowRulerMenuItem rulerItem;
	private final ShowAllMenuItem allItem;
	
	private final BEVMenuItem BEVItem;
	private final ZoomMenu zoomMenu;
	private final ScaleMenu scaleMenu;
	private final MoveMenu moveMenu;
	private final FitMapToScreenMenuItem fitMapToScreenItem;
	private final FullScreenMenuItem fullScreenItem;
	
	/**
	 * Creates a new ViewMenu within the specified frame. 
	 * @param frame The frame the menu will be sitting on.
	 */
	public ViewMenu(GViewGUIFrame frame)
	{
		super(GUIUtility.VIEW_TEXT);
	
		this.addMenuListener(this);

		//Show Legend Menu Item
		this.legendItem = new ShowLegendMenuItem(frame);
		this.add(this.legendItem);
		
		//Show Labels Menu Item
		this.labelsItem = new ShowLabelsMenuItem(frame);
		this.add(this.labelsItem);
		
		//Show Ruler Menu Item
		this.rulerItem = new ShowRulerMenuItem(frame);
		this.add(this.rulerItem);
		
		//Show All Menu Item
		this.allItem = new ShowAllMenuItem(frame);
		this.add(this.allItem);
		
		//Separator.
		this.add(GUIUtility.createSeparator(this));
		
		//Bird's Eye View Menu Item.
		this.BEVItem = new BEVMenuItem(frame);
		this.add(this.BEVItem);
		
		//Separator.
		this.add(GUIUtility.createSeparator(this));
		
		//Zoom Sub Menu
		this.zoomMenu = new ZoomMenu(frame);
		this.add(this.zoomMenu);
		
		//Scale Sub Menu
		this.scaleMenu = new ScaleMenu(frame);
		this.add(this.scaleMenu);
		
		//Move Sub Menu
		this.moveMenu = new MoveMenu(frame);
		this.add(this.moveMenu);
		
		//Separator.
		this.add(GUIUtility.createSeparator(this));
		
		//Fit Map to Screen Menu Item
		this.fitMapToScreenItem = new FitMapToScreenMenuItem(frame);
		this.add(this.fitMapToScreenItem);
		
		//Full Screen Menu Item
		this.fullScreenItem = new FullScreenMenuItem(frame);
		this.add(this.fullScreenItem);
	}

	@Override
	/**
	 * Listens for the menu being selected and causes sub menus' and sub items' states to be updated.
	 */
	public void menuSelected(MenuEvent e) 
	{
		//This allows for the correct values to be checked off in their respective sub menus.
		zoomMenu.updateMenu();
		scaleMenu.updateMenu();
		fullScreenItem.update();
		
		rulerItem.update();
		labelsItem.update();
		legendItem.update();
		allItem.update();
	}

	@Override
	/**
	 * no effect
	 */
	public void menuDeselected(MenuEvent e) 
	{
		// TODO Auto-generated method stub		
	}

	@Override
	/**
	 * no effect
	 */
	public void menuCanceled(MenuEvent e) 
	{
		// TODO Auto-generated method stub		
	}
}
