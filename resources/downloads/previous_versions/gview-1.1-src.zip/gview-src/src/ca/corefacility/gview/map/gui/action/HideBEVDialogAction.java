package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.gui.BEVDialog;

public class HideBEVDialogAction extends HideDialogAction 
{
	public HideBEVDialogAction(BEVDialog dialog)
	{
		super(dialog);
	}
}
