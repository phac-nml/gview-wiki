package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.GViewMap;

public class ZoomOutAction extends ZoomAction
{
	private final GViewMap gViewMap;
	
	public ZoomOutAction(GViewMap gViewMap)
	{
		super(gViewMap, gViewMap.getZoomFactor());
		
		this.gViewMap = gViewMap;
	}
	
	public void run()
	{
		double zoomFactor;
		
		zoomFactor = gViewMap.getZoomFactor();
		zoomFactor *= 0.9;
		gViewMap.setZoomFactor(zoomFactor);
	}
}
