package ca.corefacility.gview.test.gViewMapTests;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.seq.DNATools;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.RangeLocation;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.sequence.circular.LayoutFactoryCircular;
import ca.corefacility.gview.layout.sequence.linear.LayoutFactoryLinear;
import ca.corefacility.gview.map.GViewMapImp;
import ca.corefacility.gview.map.event.FeatureSelectEvent;
import ca.corefacility.gview.map.event.GViewEvent;
import ca.corefacility.gview.map.event.GViewEventListener;
import ca.corefacility.gview.map.items.FeatureItem;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;

public class GViewMapTest
{
	
	@Test
	public void blankTest()
	{
		
	}
//	private GenomeData data;
//	private MapStyle style;
//	private Feature[] featuresList = null;
//
//	Collection<Feature> featuresSelected = null;
//
//	@Before
//	public void setup()
//	{
//		int numFeatures = 500;
//
//		// GenomeDataFactory factory = new GenomeDataFactory();
//
//		featuresList = new Feature[numFeatures];
//
//		// creates features, and stores in featuresList
//		try
//		{
//			Sequence dna = DNATools.createDNASequence(
//					"atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
//							+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct", "dna_1");
//
//			StrandedFeature.Template ft = new StrandedFeature.Template();
//			ft.annotation = Annotation.EMPTY_ANNOTATION;
//			ft.type = "test";
//			ft.source = "testsource";
//
//			// sets a bunch of locations
//			for (int i = 0; i < numFeatures; i++)
//			{
//				if (i % 2 == 0)
//				{
//					ft.strand = StrandedFeature.POSITIVE;
//				}
//				else
//				{
//					ft.strand = StrandedFeature.NEGATIVE;
//				}
//
//				int start = i * 2;// Math.min((int) (5*i + Math.random()*20 + 100), dna.length());
//				ft.location = new RangeLocation(start, start + 5);// Math.min((int) (start + 10 +
//				// Math.random()*10),dna.length()));
//
//				featuresList[i] = dna.createFeature(ft);
//			}
//
//			data = GenomeDataFactory.createGenomeData(dna);
//			style = createStyle();
//		}
//		catch (IllegalSymbolException ex)
//		{
//			ex.printStackTrace();
//		}
//		catch (BioException be)
//		{
//			be.printStackTrace();
//		}
//	}
//
//	// just need style that displays all features
//	private MapStyle createStyle()
//	{
//		MapStyle style = new MapStyle();
//
//		SlotStyle slot1 = style.getDataStyle().createSlotStyle(1);
//
//		slot1.createFeatureHolderStyle(FeatureFilter.all);
//
//		SlotStyle slot2 = style.getDataStyle().createSlotStyle(2);
//
//		slot2.createFeatureHolderStyle(FeatureFilter.all);
//
//		return style;
//	}
//
//	// @Test
//	// public void testFindFeatureItem() // TODO this method is private in GViewMap, so should we
//	// even test it?
//	// {
//	// GViewMapImp gviewMap = new GViewMapImp(data, style, new LayoutFactoryCircular());
//	//		
//	// Feature extraFeature = getExtraFeature();
//	//        
//	//		
//	// // make sure we can find all features
//	// for (int i = 0; i < featuresList.length; i++)
//	// {
//	// Feature currentFeature = featuresList[i];
//	//			
//	// List<FeatureItem> foundItems = gviewMap.findFeatureItems(currentFeature);
//	// Assert.assertNotNull(foundItems);
//	//			
//	// Iterator<FeatureItem> itemsIterator = foundItems.iterator();
//	//			
//	// while (itemsIterator.hasNext())
//	// {
//	// FeatureItem foundItem = itemsIterator.next();
//	// Assert.assertNotNull(foundItem);
//	//				
//	// Feature foundFeature = foundItem.getFeature();
//	// Assert.assertEquals(currentFeature, foundFeature);
//	// }
//	// }
//	//		
//	// // make sure we don't find features that don't exist
//	// Assert.assertNull(gviewMap.findFeatureItems(extraFeature));
//	//		
//	// Assert.assertNull(gviewMap.findFeatureItems(null));
//	// }
//
//	@Test
//	public void testUpdateSelected()
//	{
//		Random random = new Random();
//		GViewMapImp gviewMap = new GViewMapImp(data, style, new LayoutFactoryCircular());
//		ArrayList<Feature> featuresToSelect;
//
//		gviewMap.addEventListener(new GViewEventListener() {
//			public void eventOccured(GViewEvent event)
//			{
//				if (event instanceof FeatureSelectEvent)
//				{
//					Collection<FeatureItem> selectedItems = ((FeatureSelectEvent) event).getSelectedItems();
//
//					featuresSelected = new ArrayList<Feature>();
//
//					for (FeatureItem item : selectedItems)
//					{
//						featuresSelected.add(item.getFeature());
//					}
//				}
//			}
//		});
//
//		featuresToSelect = new ArrayList<Feature>();
//
//		Assert.assertNull(featuresSelected);
//
//		// initially, no event should be run, so featuresSelected shouldn't be changed
//		gviewMap.updateSelected(featuresToSelect);
//		Assert.assertTrue(collectionsContainSame(featuresToSelect, featuresSelected));
//
//		// test single feature
//		for (int i = 0; i < featuresList.length; i++)
//		{
//			featuresToSelect.clear();
//			featuresToSelect.add(featuresList[i]);
//			gviewMap.updateSelected(featuresToSelect);
//			Assert.assertTrue(collectionsContainSame(featuresToSelect, featuresSelected));
//		}
//
//		// test multiple features
//		featuresToSelect.clear();
//		for (int i = 0; i < featuresList.length / 2; i++)
//		{
//			featuresToSelect.add(featuresList[i]);
//		}
//		gviewMap.updateSelected(featuresToSelect);
//		Assert.assertTrue(collectionsContainSame(featuresToSelect, featuresSelected));
//
//		// test random features
//		featuresToSelect.clear();
//		for (int i = 0; i < 5; i++)
//		{
//			featuresToSelect.clear();
//			for (int j = 0; j < featuresList.length / 2; j++)
//			{
//				featuresToSelect.add(featuresList[random.nextInt(featuresList.length)]);
//			}
//			gviewMap.updateSelected(featuresToSelect);
//			Assert.assertTrue(collectionsContainSame(featuresToSelect, featuresSelected));
//		}
//	}
//
//	private boolean collectionsContainSame(Collection<Feature> c1, Collection<Feature> c2)
//	{
//		boolean result = true;
//
//		if (c1 == null && c2 == null)
//		{
//			return true;
//		}
//		else if (c1 == null || c2 == null)
//		{
//			return false;
//		}
//		else
//		{
//			for (Feature feature : c1)
//			{
//				if (!c2.contains(feature))
//				{
//					result = false;
//				}
//			}
//
//			for (Feature feature : c2)
//			{
//				if (!c1.contains(feature))
//				{
//					result = false;
//				}
//			}
//		}
//
//		return result;
//	}
//
//	/*
//	 * private Feature getExtraFeature() { Feature feature = null;
//	 * 
//	 * try { // create a blank sequence to create other features on SimpleSequenceFactory seqFactory
//	 * = new SimpleSequenceFactory(); SymbolList blankList = new BlankSymbolList(100); Sequence
//	 * otherSequence = seqFactory.createSequence(blankList, null, null, null);
//	 * 
//	 * StrandedFeature.Template ft = new StrandedFeature.Template(); ft.annotation =
//	 * Annotation.EMPTY_ANNOTATION; ft.type = "test"; ft.source = "testsource"; ft.location = new
//	 * RangeLocation(0,10);
//	 * 
//	 * feature = otherSequence.createFeature(ft); } catch (BioException e) { e.printStackTrace(); }
//	 * 
//	 * return feature; }
//	 */
}
