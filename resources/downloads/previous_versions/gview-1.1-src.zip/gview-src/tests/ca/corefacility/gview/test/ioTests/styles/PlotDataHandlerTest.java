package ca.corefacility.gview.test.ioTests.styles;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Assert;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.layout.PlotBuilder;
import ca.corefacility.gview.layout.PlotBuilderGC;
import ca.corefacility.gview.layout.PlotBuilderPoints;
import ca.corefacility.gview.style.io.gss.PlotDataHandler;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.test.util.StringUtils;

public class PlotDataHandlerTest
{
	private ServerThread serverThread;
	
	@Test
	public void testDecodePoint() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("0,0.5"); // format base,value
		writer.println("1,0.75");
		writer.println("2,1.0");
		writer.println("3,2.0");
		writer.close();
		
		// setup expected plotbuilder
		PlotBuilderPoints expectedPlotBuilder = new PlotBuilderPoints();
		expectedPlotBuilder.addPoint(0,0.5);
		expectedPlotBuilder.addPoint(1,0.75);
		expectedPlotBuilder.addPoint(2,1.0);
		expectedPlotBuilder.addPoint(3,2.0);
		expectedPlotBuilder.autoScale();
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
				StringUtils.escapePathSeparator(dataFile.getAbsolutePath()) + "\")")));
		
		PlotBuilder actualPlotBuilder = PlotDataHandler.decode((new File(".")).toURI(), currUnit);
		
		Assert.assertEquals(expectedPlotBuilder, actualPlotBuilder);
	}
	
	private class ServerThread extends Thread
	{
		private int timeSleptMillis = 0;
		private int port;
		private String message;
		private boolean threadRun;
		
		private ServerSocket serverSocket = null;
		
		public ServerThread(int port, String message) throws IOException
		{
			serverSocket = new ServerSocket(port);
			this.port = serverSocket.getLocalPort();
			this.message = message;
		}
		
		public void close()
		{
			threadRun = false;
		}
		
		public int getPort()
		{
			return port;
		}
		
		@Override
		public void run()
		{
			threadRun = true;
			try
			{
				serverSocket.setSoTimeout(5000);
				
				Socket s = serverSocket.accept();
									
				DataOutputStream stream = new DataOutputStream(s.getOutputStream());
				
				stream.writeBytes("HTTP/1.1 200 OK\r\n"+
						"Content-Length: " + message.getBytes().length + "\r\n\r\n");
				stream.writeBytes(message);
				
				// wait until client has picked up all data before closing, or until we timeout
				while (threadRun || timeSleptMillis < 5000)
				{
					sleep(500);
					timeSleptMillis += 500;
				}
				
				stream.close();
				s.close();
				serverSocket.close();
			}
			catch (IOException e)
			{
				Assert.fail(e.toString());
			}
			catch (InterruptedException e)
			{
				Assert.fail(e.toString());
			}
		}
	}
	
	private int setupCSVDataServer(String message) throws IOException
	{		
		int port;
		
		serverThread = new ServerThread(0, message);
		port = serverThread.getPort();
		serverThread.start();
		
		return port;
	}
	
	@Test
	public void testGCContentOld() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		PlotBuilder workingPlotBuilder;
		PlotBuilder expectedPlotBuilder;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("gcContent(\"\")")));
		
		// expected builder
		expectedPlotBuilder = new PlotBuilderGC(true);
		
		// decode values into workingStyle
		workingPlotBuilder = PlotDataHandler.decode(new File(".").toURI(), currUnit);
		
		Assert.assertEquals(expectedPlotBuilder, workingPlotBuilder);
	}
	
	@Test
	public void testGCSkewOld() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		PlotBuilder workingPlotBuilder;
		PlotBuilder expectedPlotBuilder;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("gcSkew(\"\")")));
		
		// expected builder
		expectedPlotBuilder = new PlotBuilderGC(false);
		
		// decode values into workingStyle
		workingPlotBuilder = PlotDataHandler.decode(new File(".").toURI(), currUnit);
		
		Assert.assertEquals(expectedPlotBuilder, workingPlotBuilder);
	}
	
	@Test
	public void testGCContent() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		PlotBuilder workingPlotBuilder;
		PlotBuilder expectedPlotBuilder;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-calculator(\"gcContent\")")));
		
		// expected builder
		expectedPlotBuilder = new PlotBuilderGC(true);
		
		// decode values into workingStyle
		workingPlotBuilder = PlotDataHandler.decode(new File(".").toURI(), currUnit);
		
		Assert.assertEquals(expectedPlotBuilder, workingPlotBuilder);
	}
	
	@Test
	public void testGCSkew() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		PlotBuilder workingPlotBuilder;
		PlotBuilder expectedPlotBuilder;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-calculator(\"gcSkew\")")));
		
		// expected builder
		expectedPlotBuilder = new PlotBuilderGC(false);
		
		// decode values into workingStyle
		workingPlotBuilder = PlotDataHandler.decode(new File(".").toURI(), currUnit);
		
		Assert.assertEquals(expectedPlotBuilder, workingPlotBuilder);
	}
	
	@Test
	public void testAbsoluteRemotePath() throws IOException, ParseException, InterruptedException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		int port = 0;
		
		PlotBuilder actualPlotBuilder;
		PlotBuilderPoints expectedPlotBuilder = new PlotBuilderPoints();
		expectedPlotBuilder.addPoint(0,0.5);
		expectedPlotBuilder.addPoint(1,0.75);
		expectedPlotBuilder.addPoint(2,1.0);
		expectedPlotBuilder.addPoint(3,2.0);
		expectedPlotBuilder.autoScale();
		
		port = setupCSVDataServer("0,0.5\n"+
								  "1,0.75\n"+
								  "2,1.0\n"+
								  "3,2.0\n");
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"http://localhost:"+port+"/file.csv\")")));
		
		actualPlotBuilder = PlotDataHandler.decode((new File(".")).toURI(), currUnit);
		serverThread.close();
		
		Assert.assertEquals(expectedPlotBuilder, actualPlotBuilder);
	}
	
	@Test
	public void testRelativeRemotePath() throws IOException, ParseException, URISyntaxException, InterruptedException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		int port = 0;
		
		PlotBuilder actualPlotBuilder;
		PlotBuilderPoints expectedPlotBuilder = new PlotBuilderPoints();
		expectedPlotBuilder.addPoint(0,0.5);
		expectedPlotBuilder.addPoint(1,0.75);
		expectedPlotBuilder.addPoint(2,1.0);
		expectedPlotBuilder.addPoint(3,2.0);
		expectedPlotBuilder.autoScale();
		
		port = setupCSVDataServer("0,0.5\n"+
								  "1,0.75\n"+
								  "2,1.0\n"+
								  "3,2.0\n");
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"file.csv\")")));
		
		actualPlotBuilder = PlotDataHandler.decode(new URI("http://localhost:" + port + "/style.gss"), currUnit);
		serverThread.close();
		
		Assert.assertEquals(expectedPlotBuilder, actualPlotBuilder);
	}
	
	// should not get an exception thrown
	@Test
	public void testAbolutePath() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
				StringUtils.escapePathSeparator(dataFile.getAbsolutePath()) + "\")")));
		
		PlotDataHandler.decode((new File(".")).toURI(), currUnit);
	}
	
	// should not get an exception thrown
	@Test
	public void testAbolutePathURI() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
				dataFile.toURI() + "\")")));
		
		PlotDataHandler.decode((new File(".")).toURI(), currUnit);
	}
	
	// should get an exception thrown as we are attempting to look for the file in the wrong directory
	@Test(expected=FileNotFoundException.class)
	public void testRelativePathWrongDirectory() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		File workingDirectory = new File(".");
		
		// create temp file for data, in default temp directory (not workingDirectory)
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		File dataFileCurrDirectory = new File(workingDirectory, dataFile.getName());
		
		// only run test if file does not exist in current directory
		if (!dataFileCurrDirectory.isFile())
		{
			// check to make sure if we pass the current working directory as the currentDirectory (not the temp directory), then
			//	we won't find the file
			
			File parentDirectory = dataFile.getParentFile();
			if (parentDirectory != null)
			{
				// want to make sure if we just pass the "name" of the file, it will look for the file in the current directory
				currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
						dataFile.getName() + "\")")));
				
				PlotDataHandler.decode(workingDirectory.toURI(), currUnit);
			}
		}
	}
	
	// should not get an exception thrown
	// test if we list the file as "filename", then it will check for it as a relative path compared to the passed root directory
	@Test
	public void testRelativePath() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		File parentDirectory = dataFile.getParentFile();
		if (parentDirectory != null)
		{
			currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
					dataFile.getName() + "\")")));
			
			PlotDataHandler.decode(parentDirectory.toURI(), currUnit);
		}
	}
}
