package ca.corefacility.gview.test.ioTests.cgviewxml;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;

import org.junit.*;

import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.GViewFileData;
import ca.corefacility.gview.data.readers.GViewFileReader;
import ca.corefacility.gview.data.readers.cgview.CGViewXMLReader;
import ca.corefacility.gview.style.GlobalStyle;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.items.LegendAlignment;
import ca.corefacility.gview.style.items.LegendItemStyle;
import ca.corefacility.gview.style.items.LegendStyle;
import ca.corefacility.gview.style.items.LegendTextAlignment;

import static org.junit.Assert.*;

public class LegendElementTest
{
	private CGViewXMLReader cgviewReader;

	@Before
	public void setup()
	{
		cgviewReader = new CGViewXMLReader();
	}
	
	private StringReader generateLegendPropertiesText(String legendProperties)
	{
		return new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<legend " + legendProperties + ">"+
					"</legend>"+
				"</cgview>"
				);
	}
	
	private LegendStyle getAndTestForSingleLegendStyle(GViewFileData cgviewData)
	{
		MapStyle mapStyle;
		GlobalStyle globalStyle;
		Iterator<LegendStyle> legendStyles;
		LegendStyle legendStyle;
		
		assertNotNull(cgviewData);
		mapStyle = cgviewData.getMapStyle();
		assertNotNull(mapStyle);
		globalStyle = mapStyle.getGlobalStyle();
		assertNotNull(globalStyle);
		legendStyles = globalStyle.legendStyles();
		assertNotNull(legendStyles);
		assertTrue(legendStyles.hasNext());
		legendStyle = legendStyles.next();
		assertFalse(legendStyles.hasNext());
		assertNotNull(legendStyle);
		
		return legendStyle;
	}
	
	@Test
	public void testLegendPropertiesInherited() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		LegendStyle legendStyle;
		
		xmlReader =  new StringReader(
				"<cgview sequenceLength=\"10\" backgroundColor=\"red\">\n" +
				"<legend>"+
				"</legend>"+
			"</cgview>"
			);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(Color.red, legendStyle.getBackgroundPaint());
	}
	
	@Test
	public void testLegendProperties() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		LegendStyle legendStyle;
		
		// test allowLabelClash?
		
		xmlReader = generateLegendPropertiesText("backgroundColor=\"black\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(Color.black, legendStyle.getBackgroundPaint());
		
		xmlReader = generateLegendPropertiesText("backgroundColor=\"white\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(Color.white, legendStyle.getBackgroundPaint());
		
		// test default backgroundOpacity
		xmlReader = generateLegendPropertiesText("backgroundColor=\"red\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(0xFFFF0000, ((Color)legendStyle.getBackgroundPaint()).getRGB());
		assertEquals(255, ((Color)legendStyle.getBackgroundPaint()).getAlpha());
		
		// test backgroundOpacity
		xmlReader = generateLegendPropertiesText("backgroundColor=\"red\" backgroundOpacity=\"1.0\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(0xFFFF0000, ((Color)legendStyle.getBackgroundPaint()).getRGB());
		assertEquals(255, ((Color)legendStyle.getBackgroundPaint()).getAlpha());
		
		// test backgroundOpacity
		xmlReader = generateLegendPropertiesText("backgroundColor=\"red\" backgroundOpacity=\"0.0\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(0x00FF0000, ((Color)legendStyle.getBackgroundPaint()).getRGB());
		assertEquals(0, ((Color)legendStyle.getBackgroundPaint()).getAlpha());
		
		// test drawWhenZoomed?
		
		// test default font
		xmlReader = generateLegendPropertiesText("");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(new Font("SansSerif", Font.PLAIN, 8), legendStyle.getDefaultFont());
		
		xmlReader = generateLegendPropertiesText("font=\"SansSerif,bold,12\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(new Font("SansSerif", Font.BOLD, 12), legendStyle.getDefaultFont());
		
		xmlReader = generateLegendPropertiesText("font=\"SansSerif,italic,10\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(new Font("SansSerif", Font.ITALIC, 10), legendStyle.getDefaultFont());
		
		// test default font color
		xmlReader = generateLegendPropertiesText("");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(Color.black, legendStyle.getDefaultFontPaint());
		
		xmlReader = generateLegendPropertiesText("fontColor=\"white\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(Color.white, legendStyle.getDefaultFontPaint());
		
		xmlReader = generateLegendPropertiesText("fontColor=\"red\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		assertEquals(Color.red, legendStyle.getDefaultFontPaint());
	}
	
	@Test
	public void testLegendTextAlignment() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		
		MapStyle mapStyle;
		GlobalStyle globalStyle;
		Iterator<LegendStyle> legendStyles;
		LegendStyle legendStyle;
		Iterator<LegendItemStyle> legendItems;
		LegendItemStyle legendItemStyle;
		
		// test default text alignment
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backgroundColor=\"red\">\n" +
					"<legend>"+
						"<legendItem text=\"text1\"/>"+
					"</legend>"+
				"</cgview>"
			);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		assertNotNull(cgviewData);
		mapStyle = cgviewData.getMapStyle();
		assertNotNull(mapStyle);
		globalStyle = mapStyle.getGlobalStyle();
		assertNotNull(globalStyle);
		legendStyles = globalStyle.legendStyles();
		assertNotNull(legendStyles);
		assertTrue(legendStyles.hasNext());
		legendStyle = legendStyles.next();
		assertFalse(legendStyles.hasNext());
		assertNotNull(legendStyle);
		
		legendItems = legendStyle.legendItems();
		assertNotNull(legendItems);
		assertTrue(legendItems.hasNext());
		legendItemStyle = legendItems.next();
		assertFalse(legendItems.hasNext());
		assertNotNull(legendItemStyle);
		assertEquals(LegendTextAlignment.LEFT, legendItemStyle.getTextAlignment());
		
		// test text alignment
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backgroundColor=\"red\">\n" +
					"<legend textAlignment=\"left\">"+
						"<legendItem text=\"text1\"/>"+
					"</legend>"+
				"</cgview>"
			);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		assertNotNull(cgviewData);
		mapStyle = cgviewData.getMapStyle();
		assertNotNull(mapStyle);
		globalStyle = mapStyle.getGlobalStyle();
		assertNotNull(globalStyle);
		legendStyles = globalStyle.legendStyles();
		assertNotNull(legendStyles);
		assertTrue(legendStyles.hasNext());
		legendStyle = legendStyles.next();
		assertFalse(legendStyles.hasNext());
		assertNotNull(legendStyle);
		
		legendItems = legendStyle.legendItems();
		assertNotNull(legendItems);
		assertTrue(legendItems.hasNext());
		legendItemStyle = legendItems.next();
		assertFalse(legendItems.hasNext());
		assertNotNull(legendItemStyle);
		assertEquals(LegendTextAlignment.LEFT, legendItemStyle.getTextAlignment());
		
		// test text alignment
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backgroundColor=\"red\">\n" +
					"<legend textAlignment=\"center\">"+
						"<legendItem text=\"text1\"/>"+
					"</legend>"+
				"</cgview>"
			);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		assertNotNull(cgviewData);
		mapStyle = cgviewData.getMapStyle();
		assertNotNull(mapStyle);
		globalStyle = mapStyle.getGlobalStyle();
		assertNotNull(globalStyle);
		legendStyles = globalStyle.legendStyles();
		assertNotNull(legendStyles);
		assertTrue(legendStyles.hasNext());
		legendStyle = legendStyles.next();
		assertFalse(legendStyles.hasNext());
		assertNotNull(legendStyle);
		
		legendItems = legendStyle.legendItems();
		assertNotNull(legendItems);
		assertTrue(legendItems.hasNext());
		legendItemStyle = legendItems.next();
		assertFalse(legendItems.hasNext());
		assertNotNull(legendItemStyle);
		assertEquals(LegendTextAlignment.CENTER, legendItemStyle.getTextAlignment());
		
		// test text alignment
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backgroundColor=\"red\">\n" +
					"<legend textAlignment=\"right\">"+
						"<legendItem text=\"text1\"/>"+
					"</legend>"+
				"</cgview>"
			);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		assertNotNull(cgviewData);
		mapStyle = cgviewData.getMapStyle();
		assertNotNull(mapStyle);
		globalStyle = mapStyle.getGlobalStyle();
		assertNotNull(globalStyle);
		legendStyles = globalStyle.legendStyles();
		assertNotNull(legendStyles);
		assertTrue(legendStyles.hasNext());
		legendStyle = legendStyles.next();
		assertFalse(legendStyles.hasNext());
		assertNotNull(legendStyle);
		
		legendItems = legendStyle.legendItems();
		assertNotNull(legendItems);
		assertTrue(legendItems.hasNext());
		legendItemStyle = legendItems.next();
		assertFalse(legendItems.hasNext());
		assertNotNull(legendItemStyle);
		assertEquals(LegendTextAlignment.RIGHT, legendItemStyle.getTextAlignment());
	}
	
	@Test
	public void testLegendPosition() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		LegendStyle legendStyle;
		LegendAlignment alignment;
		
		// test default legend position
		xmlReader = generateLegendPropertiesText("");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		alignment = legendStyle.getAlignment();
		assertEquals(LegendAlignment.UPPER_RIGHT, alignment);
		
		xmlReader = generateLegendPropertiesText("position=\"upper-left\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		alignment = legendStyle.getAlignment();
		assertEquals(LegendAlignment.UPPER_LEFT, alignment);
		
		xmlReader = generateLegendPropertiesText("position=\"upper-center\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		alignment = legendStyle.getAlignment();
		assertEquals(LegendAlignment.UPPER_CENTER, alignment);
		
		xmlReader = generateLegendPropertiesText("position=\"upper-right\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		alignment = legendStyle.getAlignment();
		assertEquals(LegendAlignment.UPPER_RIGHT, alignment);
		
		xmlReader = generateLegendPropertiesText("position=\"middle-left\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		alignment = legendStyle.getAlignment();
		assertEquals(LegendAlignment.MIDDLE_LEFT, alignment);
		
		xmlReader = generateLegendPropertiesText("position=\"middle-center\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		alignment = legendStyle.getAlignment();
		assertEquals(LegendAlignment.MIDDLE_CENTER, alignment);
		
		xmlReader = generateLegendPropertiesText("position=\"middle-right\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		alignment = legendStyle.getAlignment();
		assertEquals(LegendAlignment.MIDDLE_RIGHT, alignment);
		
		xmlReader = generateLegendPropertiesText("position=\"lower-left\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		alignment = legendStyle.getAlignment();
		assertEquals(LegendAlignment.LOWER_LEFT, alignment);
		
		xmlReader = generateLegendPropertiesText("position=\"lower-center\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		alignment = legendStyle.getAlignment();
		assertEquals(LegendAlignment.LOWER_CENTER, alignment);
		
		xmlReader = generateLegendPropertiesText("position=\"lower-right\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendStyle = getAndTestForSingleLegendStyle(cgviewData);
		alignment = legendStyle.getAlignment();
		assertEquals(LegendAlignment.LOWER_RIGHT, alignment);
	}
}
