package ca.corefacility.gview.test.styletests;

import static org.junit.Assert.assertEquals;

import java.awt.Color;

import org.biojava.bio.BioException;
import org.biojava.bio.SimpleAnnotation;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.impl.SimpleSequenceFactory;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.bio.symbol.SymbolList;
import org.biojava.utils.ChangeVetoException;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.Slot;
import ca.corefacility.gview.map.items.FeatureItem;
import ca.corefacility.gview.map.items.FeatureItemImp;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.datastyle.mapper.AnnotationMapper;
import ca.corefacility.gview.style.datastyle.mapper.COGMapper;
import ca.corefacility.gview.style.datastyle.mapper.DiscretePaintMapper;
import ca.corefacility.gview.style.datastyle.mapper.DiscreteStyleMapper;
import ca.corefacility.gview.style.datastyle.mapper.OpacityFeatureStyleMapper;
import ca.corefacility.gview.style.datastyle.mapper.PropertyMapperScore;
import ca.corefacility.gview.style.datastyle.mapper.PropertyStyle;
import ca.corefacility.gview.style.datastyle.mapper.PropertyStyleContinuous;
import ca.corefacility.gview.style.datastyle.mapper.PropertyStyleDiscrete;

public class PropertyStyleTest
{
	private final float delta = 0.00001f;
	
	private MapStyle mapStyle;
	private FeatureHolderStyle featureHolderStyle;
	
	@Before
	public void setup()
	{
		mapStyle = new MapStyle();
		DataStyle dataStyle = mapStyle.getDataStyle();
		SlotStyle slotStyle = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		featureHolderStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.all);
	}
	
	private Feature buildFeature(String key, String value) throws ChangeVetoException, BioException
	{
		SymbolList blankList = new BlankSymbolList(100);
		SimpleSequenceFactory seqFactory = new SimpleSequenceFactory();
		Sequence blankSequence = seqFactory.createSequence(blankList, null, null, null);

		
		Feature.Template basic = new Feature.Template();
		basic.location = new RangeLocation(1,9);
		basic.annotation = new SimpleAnnotation();
		basic.annotation.setProperty(key, value);
		
		
		return blankSequence.createFeature(basic);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testDiscreteMapperUnmatchedCategories()
	{
		// missing a Color
		new PropertyStyleDiscrete(new AnnotationMapper("COG", new String[]{"A", "B"}),
				new DiscretePaintMapper(new Color[]{Color.BLUE}));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testDiscreteMapperUnmatchedCategories2()
	{
		// missing a annotation category
		new PropertyStyleDiscrete(new AnnotationMapper("COG", new String[]{"A"}),
				new DiscretePaintMapper(new Color[]{Color.BLUE, Color.RED}));
	}
	
	@Test
	public void testContinuousMapper() throws ChangeVetoException, BioException
	{
		Feature f;
		FeatureItemImp item;
		
		PropertyStyle mapper;
		
		mapper = new PropertyStyleContinuous(new PropertyMapperScore(0.0f,100.0f),
				new OpacityFeatureStyleMapper());
		
		featureHolderStyle.setPaint(Color.RED);
		f = buildFeature("Score", "50");
		item = new FeatureItemImp(featureHolderStyle, f);
		assertEquals(Color.RED, item.getPaint());
		
		mapper.performMappingFor(item);
		
		assertEquals(0.5f, item.getTransparency(), delta);
		
		
		featureHolderStyle.setPaint(Color.RED);
		f = buildFeature("Score", "75");
		item = new FeatureItemImp(featureHolderStyle, f);
		assertEquals(Color.RED, item.getPaint());
		
		mapper.performMappingFor(item);
		
		assertEquals(0.75f, item.getTransparency(), delta);
	}
	
	@Test
	public void testDiscreteMapper() throws ChangeVetoException, BioException
	{
		Feature f;
		FeatureItem item;
		
		PropertyStyle mapper;
		
		mapper = new PropertyStyleDiscrete(new AnnotationMapper("COG", new String[]{"A"}),
				new DiscretePaintMapper(new Color[]{Color.BLUE}));
		
		featureHolderStyle.setPaint(Color.RED);
		f = buildFeature("COG", "A");
		item = new FeatureItemImp(featureHolderStyle, f);
		assertEquals(Color.RED, item.getPaint());
		
		mapper.performMappingFor(item);
		assertEquals(Color.BLUE, item.getPaint());
		
		
		featureHolderStyle.setPaint(Color.RED);
		f = buildFeature("COG", "B");
		item = new FeatureItemImp(featureHolderStyle, f);
		assertEquals(Color.RED, item.getPaint());
		
		mapper.performMappingFor(item);
		assertEquals(Color.RED, item.getPaint()); // no change
		
		
		
		mapper = new PropertyStyleDiscrete(new AnnotationMapper("COG", new String[]{"A", "B"}),
				new DiscretePaintMapper(new Color[]{Color.BLUE, Color.ORANGE}));
		
		featureHolderStyle.setPaint(Color.RED);
		f = buildFeature("COG", "A");
		item = new FeatureItemImp(featureHolderStyle, f);
		assertEquals(Color.RED, item.getPaint());
		
		mapper.performMappingFor(item);
		assertEquals(Color.BLUE, item.getPaint());
		
		f = buildFeature("COG", "B");
		item = new FeatureItemImp(featureHolderStyle, f);
		assertEquals(Color.RED, item.getPaint());
		
		mapper.performMappingFor(item);
		assertEquals(Color.ORANGE, item.getPaint());
		
		
		mapper = new PropertyStyleDiscrete(new COGMapper(new String[]{"A", "B"}),
				new DiscretePaintMapper(new Color[]{Color.BLUE, Color.ORANGE}));
		
		featureHolderStyle.setPaint(Color.RED);
		f = buildFeature("COG", "A");
		item = new FeatureItemImp(featureHolderStyle, f);
		assertEquals(Color.RED, item.getPaint());
		
		mapper.performMappingFor(item);
		assertEquals(Color.BLUE, item.getPaint());
		
		f = buildFeature("COG", "B");
		item = new FeatureItemImp(featureHolderStyle, f);
		assertEquals(Color.RED, item.getPaint());
		
		mapper.performMappingFor(item);
		assertEquals(Color.ORANGE, item.getPaint());
	}
}
