package ca.corefacility.gview.test.ioTests;

import static org.junit.Assert.*;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

import org.junit.*;

import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.StandardSequenceFormatReader;

public class FileFormatDetectTest
{	
	@Test
	public void testDetectGenbank() throws IOException, GViewDataParseException
	{
		StandardSequenceFormatReader standardReader = new StandardSequenceFormatReader();
		String file = 
			"LOCUS       TEST     10000 bp    DNA             PLN       22-JUN-5000\n"+
			"DEFINITION  def\nACCESSION   89999\nVERSION xxx\nKEYWORDS .\nSOURCE source\nFEATURES             Location/Qualifiers\n"+
			"source          1..10000\n";
		
		byte[] fileBytes = file.getBytes();
		ByteArrayInputStream inputStream = new ByteArrayInputStream(fileBytes);
		BufferedInputStream bStream = new BufferedInputStream(inputStream);
		
		assertTrue(standardReader.canRead(bStream));
	}
	
	@Test
	public void testDetectNonReadable() throws IOException, GViewDataParseException
	{
		StandardSequenceFormatReader standardReader = new StandardSequenceFormatReader();

		String file = 
			   "test";
		
		byte[] fileBytes = file.getBytes();
		ByteArrayInputStream inputStream = new ByteArrayInputStream(fileBytes);
		BufferedInputStream bStream = new BufferedInputStream(inputStream);
		
		assertFalse(standardReader.canRead(bStream));
	}
	
	@Test
	public void testDetectFASTA() throws IOException, GViewDataParseException
	{
		StandardSequenceFormatReader standardReader = new StandardSequenceFormatReader();

		String file = 
			   ">Stuff\n"+
			   "AAATTTCCCGGG";
		
		byte[] fileBytes = file.getBytes();
		ByteArrayInputStream inputStream = new ByteArrayInputStream(fileBytes);
		BufferedInputStream bStream = new BufferedInputStream(inputStream);
		
		assertTrue(standardReader.canRead(bStream));
	}
}
