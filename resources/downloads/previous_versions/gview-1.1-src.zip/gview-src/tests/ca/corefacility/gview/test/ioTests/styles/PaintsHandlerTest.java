package ca.corefacility.gview.test.ioTests.styles;

import static org.junit.Assert.*;

import java.awt.Color;
import java.awt.Paint;
import java.io.IOException;
import java.io.StringReader;

import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.io.gss.PaintHandler;
import ca.corefacility.gview.style.io.gss.PaintsHandler;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.style.io.gss.exceptions.UnknownFunctionException;

public class PaintsHandlerTest
{
	@Test
	public void testDecodeSingleColor() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		Paint[] expected;
		Paint[] actual;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("colors(color(\"red\"))")));
		expected = new Paint[]{Color.red};
		
		actual = PaintsHandler.decode(currUnit);
		
		assertArrayEquals(expected, actual);
	}
	
	@Test(expected=CSSException.class)
	public void testNoColor() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		parser.parsePropertyValue(new InputSource(new StringReader("colors()")));
	}
	
	@Test(expected=ParseException.class)
	public void testInvalidColor() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit = parser.parsePropertyValue(new InputSource(new StringReader("colors(paint(3,4,5))")));
		
		PaintsHandler.decode(currUnit);
	}
	
	@Test
	public void testDecodeMultipleColor() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		Paint[] expected;
		Paint[] actual;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("colors(color(\"red\")" +
				",color(\"blue\"), color(\"green\"))")));
		expected = new Paint[]{Color.red, Color.blue, new Color(0, 128, 0)};
		
		actual = PaintsHandler.decode(currUnit);
		
		assertArrayEquals(expected, actual);
		
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("colors(color(\"red\")" +
		",color(1,2,3,4))")));
		expected = new Paint[]{Color.red, new Color(1,2,3,4)};
		
		actual = PaintsHandler.decode(currUnit);
		
		assertArrayEquals(expected, actual);
	}
	
	@Test(expected=UnknownFunctionException.class)
	public void testUnknownString() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit unit = parser.parsePropertyValue(new InputSource(new StringReader("paints(color(\"red\"))")));
		PaintsHandler.decode(unit);
	}
}
