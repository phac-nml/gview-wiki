package ca.corefacility.gview.test.plotTests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.biojava.bio.seq.DNATools;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.bio.symbol.Symbol;
import org.junit.Test;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataImp;
import ca.corefacility.gview.utils.content.AverageCalculator;
import ca.corefacility.gview.utils.content.ContentCalculator;
import ca.corefacility.gview.utils.content.ContentCalculator.RangeValue;
import ca.corefacility.gview.utils.content.SkewCalculator;

public class SkewCalculatorTest
{
	private double delta = 0.0000001;
	
	@Test
	public void alternatingWindow4Step2() throws IllegalSymbolException
	{
		GenomeData genomeData;
		ContentCalculator content;
		Iterator<RangeValue> gAverageIter;

		Sequence dna;
		
		RangeValue currValue;

		dna = DNATools.createDNASequence("ggccggcc", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new SkewCalculator(genomeData, true, DNATools.g(), DNATools.c(),2,4);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-2.0/6.0, currValue.value, delta);
		assertEquals(new RangeLocation(1, 3), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(2.0/6.0, currValue.value, delta);
		assertEquals(new RangeLocation(3, 5), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-2.0/6.0, currValue.value, delta);
		assertEquals(new RangeLocation(5, 7), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(2.0/6.0, currValue.value, delta);
		assertEquals(new RangeLocation(7, 9), currValue.location);
		assertFalse(gAverageIter.hasNext());
		
		
		
		dna = DNATools.createDNASequence("aaggttccaa", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new SkewCalculator(genomeData, true, DNATools.g(), DNATools.c(),2,4);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(1.0, currValue.value, delta);
		assertEquals(new RangeLocation(1, 3), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(1.0, currValue.value, delta);
		assertEquals(new RangeLocation(3, 5), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(0.0, currValue.value, delta);
		assertEquals(new RangeLocation(5, 7), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-1.0, currValue.value, delta);
		assertEquals(new RangeLocation(7, 9), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-1.0, currValue.value, delta);
		assertEquals(new RangeLocation(9, 11), currValue.location);
		assertFalse(gAverageIter.hasNext());
	}
	
	@Test
	public void alternatingWindow4Step2NotCircular() throws IllegalSymbolException
	{
		GenomeData genomeData;
		ContentCalculator content;
		Iterator<RangeValue> gAverageIter;

		Sequence dna;
		
		RangeValue currValue;

		dna = DNATools.createDNASequence("ggccggcc", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new SkewCalculator(genomeData, false, DNATools.g(), DNATools.c(),2,4);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(2.0/6.0, currValue.value, delta);
		assertEquals(new RangeLocation(3, 5), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-2.0/6.0, currValue.value, delta);
		assertEquals(new RangeLocation(5, 7), currValue.location);
		assertFalse(gAverageIter.hasNext());
		
		
		
		dna = DNATools.createDNASequence("aaggttccaa", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new SkewCalculator(genomeData, false, DNATools.g(), DNATools.c(),2,4);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(2.0/2.0, currValue.value, delta);
		assertEquals(new RangeLocation(3, 5), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(0.0, currValue.value, delta);
		assertEquals(new RangeLocation(5, 7), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-2.0/2.0, currValue.value, delta);
		assertEquals(new RangeLocation(7, 9), currValue.location);
		assertFalse(gAverageIter.hasNext());
	}
	
	@Test
	public void alternatingWindow2Step1() throws IllegalSymbolException
	{
		GenomeData genomeData;
		ContentCalculator content;
		Iterator<RangeValue> gAverageIter;

		Sequence dna;
		
		RangeValue currValue;

		dna = DNATools.createDNASequence("gcgcgc", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new SkewCalculator(genomeData, true, DNATools.g(), DNATools.c(),1,2);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-1.0/3.0, currValue.value, delta);
		assertEquals(new RangeLocation(1, 2), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(1.0/3.0, currValue.value, delta);
		assertEquals(new RangeLocation(2,3), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-1.0/3.0, currValue.value, delta);
		assertEquals(new RangeLocation(3,4), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(1.0/3.0, currValue.value, delta);
		assertEquals(new RangeLocation(4,5), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-1.0/3.0, currValue.value, delta);
		assertEquals(new RangeLocation(5,6), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(1.0/3.0, currValue.value, delta);
		assertEquals(new RangeLocation(6,7), currValue.location);
		assertFalse(gAverageIter.hasNext());
	}
	
	@Test
	public void skewDiffSymbolsAlternating() throws IllegalSymbolException
	{
		GenomeData genomeData;
		ContentCalculator content;
		Iterator<RangeValue> gAverageIter;

		Sequence dna;
		
		RangeValue currValue;

		dna = DNATools.createDNASequence("gcgcg", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new SkewCalculator(genomeData, true, DNATools.g(), DNATools.c(),1,0);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(1.0, currValue.value, delta);
		assertEquals(new RangeLocation(1, 2), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-1.0, currValue.value, delta);
		assertEquals(new RangeLocation(2, 3), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(1.0, currValue.value, delta);
		assertEquals(new RangeLocation(3, 4), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-1.0, currValue.value, delta);
		assertEquals(new RangeLocation(4, 5), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(1.0, currValue.value, delta);
		assertEquals(new RangeLocation(5, 6), currValue.location);
		assertFalse(gAverageIter.hasNext());
		
		
		
		dna = DNATools.createDNASequence("atata", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new SkewCalculator(genomeData, true, DNATools.a(), DNATools.t(),1,0);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(1.0, currValue.value, delta);
		assertEquals(new RangeLocation(1, 2), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-1.0, currValue.value, delta);
		assertEquals(new RangeLocation(2, 3), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(1.0, currValue.value, delta);
		assertEquals(new RangeLocation(3, 4), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(-1.0, currValue.value, delta);
		assertEquals(new RangeLocation(4, 5), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(1.0, currValue.value, delta);
		assertEquals(new RangeLocation(5, 6), currValue.location);
		assertFalse(gAverageIter.hasNext());
		
		
		
		dna = DNATools.createDNASequence("atata", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new SkewCalculator(genomeData, true, DNATools.g(), DNATools.c(),1,0);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(0.0, currValue.value, delta);
		assertEquals(new RangeLocation(1, 2), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(0.0, currValue.value, delta);
		assertEquals(new RangeLocation(2, 3), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(0.0, currValue.value, delta);
		assertEquals(new RangeLocation(3, 4), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(0.0, currValue.value, delta);
		assertEquals(new RangeLocation(4, 5), currValue.location);
		assertTrue(gAverageIter.hasNext());
		
		currValue = gAverageIter.next();
		assertEquals(0.0, currValue.value, delta);
		assertEquals(new RangeLocation(5, 6), currValue.location);
		assertFalse(gAverageIter.hasNext());
	}
	
	@Test
	public void totalAverageSymbolsContentTest() throws IllegalSymbolException
	{
		GenomeData genomeData;
		SkewCalculator content;

		Sequence dna;
		
		dna = DNATools.createDNASequence("ggggccccaaaatttt", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new SkewCalculator(genomeData, true, DNATools.g(), DNATools.c(),1,1);
		assertEquals(0.0, content.getTotalAverageContent(), delta);
		
		content = new SkewCalculator(genomeData, true, DNATools.a(), DNATools.t(),1,1);
		assertEquals(0.0, content.getTotalAverageContent(), delta);
		
		
		dna = DNATools.createDNASequence("gccaaatttt", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new SkewCalculator(genomeData, true, DNATools.g(), DNATools.c(),1,1);
		assertEquals(-1.0/3.0, content.getTotalAverageContent(), delta);
		
		content = new SkewCalculator(genomeData, true, DNATools.a(), DNATools.t(),1,1);
		assertEquals(-1.0/7.0, content.getTotalAverageContent(), delta);
	}
}
