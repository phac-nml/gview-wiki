package ca.corefacility.gview.test.ioTests.styles;


import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.io.IOException;
import java.io.StringReader;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.io.gss.FontHandler;
import ca.corefacility.gview.style.io.gss.PaintHandler;
import ca.corefacility.gview.style.io.gss.FontHandler.MalformedFontStringException;
import ca.corefacility.gview.style.io.gss.PaintHandler.UnknownPaintException;
import ca.corefacility.gview.style.io.gss.exceptions.UnknownFunctionException;

public class FontHandlerTest
{
	private Parser parser;
	
	@Before
	public void setup()
	{
		 parser = new com.steadystate.css.parser.SACParserCSS2();
	}
	
	@Test
	public void encodeTests()
	{
		Assert.assertEquals("font(\"SansSerif\",\"plain\",12)", FontHandler.encode(new Font("SansSerif", Font.PLAIN, 12)));
		Assert.assertEquals("font(\"SansSerif\",\"bold\",12)", FontHandler.encode(new Font("SansSerif", Font.BOLD, 12)));
		Assert.assertEquals("font(\"SansSerif\",\"italic\",12)", FontHandler.encode(new Font("SansSerif", Font.ITALIC, 12)));
		Assert.assertEquals("font(\"SansSerif\",\"bold-italic\",12)", FontHandler.encode(new Font("SansSerif", Font.BOLD + Font.ITALIC, 12)));
		
		Assert.assertEquals("font(\"SansSerif\",\"plain\",14)", FontHandler.encode(new Font("SansSerif", Font.PLAIN, 14)));
	}
	
	@Test
	public void decodeTest() throws CSSException, IOException, UnknownFunctionException, MalformedFontStringException
	{
		InputSource currEncodedString;
		LexicalUnit currUnit;
				
		currEncodedString = new InputSource(new StringReader("font(\"SansSerif\", \"plain\", 15)"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(new Font("SansSerif", Font.PLAIN, 15), FontHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("font(\"SansSerif\", \"bold\", 15)"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(new Font("SansSerif", Font.BOLD, 15), FontHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("font(\"SansSerif\", \"italic\", 15)"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(new Font("SansSerif", Font.ITALIC, 15), FontHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("font(\"SansSerif\", \"bold-italic\", 15)"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(new Font("SansSerif", Font.BOLD + Font.ITALIC, 15), FontHandler.decode(currUnit));
	}
	
	@Test(expected=NullPointerException.class)
	public void testNullParameter() throws UnknownFunctionException, MalformedFontStringException
	{
		FontHandler.decode(null);
	}
	
	@Test(expected=MalformedFontStringException.class)
	public void testNoFontParameters() throws UnknownFunctionException, CSSException, IOException, MalformedFontStringException
	{
		LexicalUnit unit = parser.parsePropertyValue(new InputSource(new StringReader("font(\"\")")));
		FontHandler.decode(unit);
	}
	
	@Test(expected=MalformedFontStringException.class)
	public void testUnknownString() throws UnknownFunctionException, CSSException, IOException, MalformedFontStringException
	{
		LexicalUnit unit = parser.parsePropertyValue(new InputSource(new StringReader("fonts(\"SansSerif\",\"plain\",12)")));
		FontHandler.decode(unit);
	}
	
	@Test(expected=MalformedFontStringException.class)
	public void testUnknownString3() throws UnknownFunctionException, CSSException, IOException, MalformedFontStringException
	{
		LexicalUnit unit = parser.parsePropertyValue(new InputSource(new StringReader("font(\"SansSerif\",\"aplain\",12)")));
		FontHandler.decode(unit);
	}
	
	@Test(expected=MalformedFontStringException.class)
	public void testUnknownString4() throws UnknownFunctionException, CSSException, IOException, MalformedFontStringException
	{
		LexicalUnit unit = parser.parsePropertyValue(new InputSource(new StringReader("font(\"SansSerif\",\"plain\",a12)")));
		FontHandler.decode(unit);
	}
}
