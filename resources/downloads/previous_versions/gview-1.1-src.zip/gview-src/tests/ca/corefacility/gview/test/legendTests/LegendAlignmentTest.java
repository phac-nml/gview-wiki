package ca.corefacility.gview.test.legendTests;

import static org.junit.Assert.*;

import java.awt.geom.Rectangle2D;

import org.junit.Test;

import ca.corefacility.gview.map.items.LegendItem;
import ca.corefacility.gview.style.items.LegendAlignment;
import ca.corefacility.gview.style.items.LegendItemStyle;
import ca.corefacility.gview.style.items.LegendStyle;

public class LegendAlignmentTest
{
	private final double delta = 0.000001;
	
	@Test
	public void testAlignLegendOutside()
	{
		LegendStyle ls = new LegendStyle();
		LegendItem l;
		LegendItemStyle lis = new LegendItemStyle("text");
		ls.addLegendItem(lis);
		ls.setOutlinePaint(null);
		
		Rectangle2D initialBounds,finalBounds;
		
		ls.setAlignment(LegendAlignment.UPPER_LEFT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), false); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned outside of rectangle
		assertEquals(-initialBounds.getWidth(), finalBounds.getX(), delta);
		assertEquals(-initialBounds.getHeight(), finalBounds.getY(), delta);
		
		
		ls.setAlignment(LegendAlignment.UPPER_CENTER);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), false); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned outside of rectangle
		assertEquals(50-initialBounds.getWidth()/2, finalBounds.getX(), delta);
		assertEquals(-initialBounds.getHeight(), finalBounds.getY(), delta);
		

		ls.setAlignment(LegendAlignment.UPPER_RIGHT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), false); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned outside of rectangle
		assertEquals(100, finalBounds.getX(), delta);
		assertEquals(-initialBounds.getHeight(), finalBounds.getY(), delta);
		
		
		ls.setAlignment(LegendAlignment.MIDDLE_LEFT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), false); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned outside of rectangle
		assertEquals(-initialBounds.getWidth(), finalBounds.getX(), delta);
		assertEquals(50-initialBounds.getHeight()/2, finalBounds.getY(), delta);
		
		
		ls.setAlignment(LegendAlignment.MIDDLE_CENTER);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), false); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned outside of rectangle
		assertEquals(50-initialBounds.getWidth()/2, finalBounds.getX(), delta);
		assertEquals(50-initialBounds.getHeight()/2, finalBounds.getY(), delta);
		

		ls.setAlignment(LegendAlignment.MIDDLE_RIGHT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), false); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned outside of rectangle
		assertEquals(100, finalBounds.getX(), delta);
		assertEquals(50-initialBounds.getHeight()/2, finalBounds.getY(), delta);
		
		
		ls.setAlignment(LegendAlignment.LOWER_LEFT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), false); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned outside of rectangle
		assertEquals(-initialBounds.getWidth(), finalBounds.getX(), delta);
		assertEquals(100, finalBounds.getY(), delta);
		
		
		ls.setAlignment(LegendAlignment.LOWER_CENTER);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), false); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned outside of rectangle
		assertEquals(50-initialBounds.getWidth()/2, finalBounds.getX(), delta);
		assertEquals(100, finalBounds.getY(), delta);
		

		ls.setAlignment(LegendAlignment.LOWER_RIGHT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), false); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned outside of rectangle
		assertEquals(100, finalBounds.getX(), delta);
		assertEquals(100, finalBounds.getY(), delta);
	}
	
	@Test
	public void testAlignLegendInside()
	{
		LegendStyle ls = new LegendStyle();
		LegendItem l;
		LegendItemStyle lis = new LegendItemStyle("text");
		ls.addLegendItem(lis);
		ls.setOutlinePaint(null);
		
		Rectangle2D initialBounds,finalBounds;
		
		ls.setAlignment(LegendAlignment.UPPER_LEFT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), true); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned inside of rectangle
		assertEquals(0, finalBounds.getX(), delta);
		assertEquals(0, finalBounds.getY(), delta);
		
		
		ls.setAlignment(LegendAlignment.UPPER_CENTER);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), true); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned inside of rectangle
		assertEquals(50-initialBounds.getWidth()/2, finalBounds.getX(), delta);
		assertEquals(0, finalBounds.getY(), delta);
		

		ls.setAlignment(LegendAlignment.UPPER_RIGHT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), true); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned inside of rectangle
		assertEquals(100-initialBounds.getWidth(), finalBounds.getX(), delta);
		assertEquals(0, finalBounds.getY(), delta);
		
		
		
		ls.setAlignment(LegendAlignment.MIDDLE_LEFT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), true); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned inside of rectangle
		assertEquals(0, finalBounds.getX(), delta);
		assertEquals(50-initialBounds.getHeight()/2, finalBounds.getY(), delta);
		
		
		ls.setAlignment(LegendAlignment.MIDDLE_CENTER);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), true); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned inside of rectangle
		assertEquals(50-initialBounds.getWidth()/2, finalBounds.getX(), delta);
		assertEquals(50-initialBounds.getHeight()/2, finalBounds.getY(), delta);
		

		ls.setAlignment(LegendAlignment.MIDDLE_RIGHT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), true); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned inside of rectangle
		assertEquals(100-initialBounds.getWidth(), finalBounds.getX(), delta);
		assertEquals(50-initialBounds.getHeight()/2, finalBounds.getY(), delta);
		
		
		ls.setAlignment(LegendAlignment.LOWER_LEFT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), true); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned inside of rectangle
		assertEquals(0, finalBounds.getX(), delta);
		assertEquals(100-initialBounds.getHeight(), finalBounds.getY(), delta);
		
		
		ls.setAlignment(LegendAlignment.LOWER_CENTER);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), true); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned inside of rectangle
		assertEquals(50-initialBounds.getWidth()/2, finalBounds.getX(), delta);
		assertEquals(100-initialBounds.getHeight(), finalBounds.getY(), delta);
		

		ls.setAlignment(LegendAlignment.LOWER_RIGHT);
		l = LegendItem.buildLegend(ls);
		
		initialBounds = l.getFullBounds();
		l.alignLegend(new Rectangle2D.Float(0,0,100,100), true); // align outside of 100x100 rectangle
		finalBounds = l.getFullBounds();
		
		// make sure legend item is aligned inside of rectangle
		assertEquals(100-initialBounds.getWidth(), finalBounds.getX(), delta);
		assertEquals(100-initialBounds.getHeight(), finalBounds.getY(), delta);
	}
}
