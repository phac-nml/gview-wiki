package ca.corefacility.gview.test.ioTests.styles;

import java.awt.Color;
import java.io.IOException;
import java.io.StringReader;


import org.biojava.bio.seq.FeatureFilter;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.ConditionalSelector;
import org.w3c.css.sac.DescendantSelector;
import org.w3c.css.sac.ElementSelector;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;
import org.w3c.css.sac.Selector;
import org.w3c.css.sac.SimpleSelector;

import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.LabelStyle;
import ca.corefacility.gview.style.datastyle.PlotStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.io.FeatureSetMap;
import ca.corefacility.gview.style.io.gss.PaintHandler.UnknownPaintException;
import ca.corefacility.gview.style.io.gss.coders.DescendentCoder;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedDeclarationException;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedSelectorException;
import ca.corefacility.gview.style.io.gss.exceptions.NoStyleExistsException;
import ca.corefacility.gview.style.io.gss.exceptions.NoSuchFilterException;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;

import com.steadystate.css.parser.selectors.ConditionalSelectorImpl;
import com.steadystate.css.parser.selectors.DescendantSelectorImpl;
import com.steadystate.css.parser.selectors.ElementSelectorImpl;
import com.steadystate.css.parser.selectors.IdConditionImpl;

public class DescendentCoderTest
{
	private DescendentCoder descendentCoder;
	private MapStyle mapStyle;
	private FeatureSetMap setMap;
	private Parser parser;
	
	@Before
	public void setup()
	{
		parser = new com.steadystate.css.parser.SACParserCSS2();
		descendentCoder = new DescendentCoder();
		mapStyle = new MapStyle();
		setMap = new FeatureSetMap();
	}
	
	private DescendantSelector buildDescendantSelector(String slotNumber, SimpleSelector leafSelector)
	{
		DescendantSelectorImpl dec;
		ConditionalSelector slotSel = new ConditionalSelectorImpl(new ElementSelectorImpl("slot"), new IdConditionImpl(slotNumber));
		
		dec = new DescendantSelectorImpl(slotSel, leafSelector);
		
		return dec;
	}
	
	@Test(expected=NoStyleExistsException.class)
	public void testNoSlot() throws CSSException, IOException, ParseException
	{
		LexicalUnit currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		DescendantSelector sel = buildDescendantSelector("1",new ConditionalSelectorImpl(new ElementSelectorImpl("FeatureSet"), new IdConditionImpl("set1")));
		
		setMap.put("set1", FeatureFilter.all);
		descendentCoder.decodeProperty(sel, mapStyle, setMap, "text-color", currUnit, null);
	}
	
	@Test(expected=NoStyleExistsException.class)
	public void testNoHolderStyle() throws CSSException, IOException, ParseException
	{
		LexicalUnit currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		DescendantSelector sel = buildDescendantSelector("1",new ConditionalSelectorImpl(new ElementSelectorImpl("FeatureSet"), new IdConditionImpl("set1")));
		mapStyle.getDataStyle().createSlotStyle(1); // build slotstyle for slot 1
		
		setMap.put("set1", FeatureFilter.all);
		descendentCoder.decodeProperty(sel, mapStyle, setMap, "text-color", currUnit, null);
	}
	
	@Test
	public void testWithHolderStyle() throws CSSException, IOException, ParseException
	{
		LexicalUnit currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		DescendantSelector sel = buildDescendantSelector("1",new ConditionalSelectorImpl(new ElementSelectorImpl("FeatureSet"), new IdConditionImpl("set1")));
		SlotStyle slot1 = mapStyle.getDataStyle().createSlotStyle(1); // build slotstyle for slot 1
		slot1.createFeatureHolderStyle(FeatureFilter.all);
		
		setMap.put("set1", FeatureFilter.all);
		descendentCoder.decodeProperty(sel, mapStyle, setMap, "color", currUnit, null);
	}
	
	@Test(expected=NoStyleExistsException.class)
	public void testWithIncorrectFilter() throws CSSException, IOException, ParseException
	{
		LexicalUnit currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		DescendantSelector sel = buildDescendantSelector("1",new ConditionalSelectorImpl(new ElementSelectorImpl("FeatureSet"), new IdConditionImpl("set1")));
		SlotStyle slot1 = mapStyle.getDataStyle().createSlotStyle(1); // build slotstyle for slot 1
		slot1.createFeatureHolderStyle(FeatureFilter.all);
		
		setMap.put("set1", FeatureFilter.none); // does not match filter of any holder style in slot 1
		descendentCoder.decodeProperty(sel, mapStyle, setMap, "color", currUnit, null);
	}
	
	@Test(expected=NoSuchFilterException.class)
	public void testNoFilter() throws CSSException, IOException, ParseException
	{
		LexicalUnit currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		DescendantSelector sel = buildDescendantSelector("1",new ConditionalSelectorImpl(new ElementSelectorImpl("FeatureSet"), new IdConditionImpl("set1")));
		mapStyle.getDataStyle().createSlotStyle(1); // build slotstyle for slot 1
	
		descendentCoder.decodeProperty(sel, mapStyle, setMap, "text-color", currUnit, null);
	}
	
	@Test
	public void testDecodeToLabelStyle() throws CSSException, IOException // make sure DescendentCoder class decodes properly to a LabelStyle
, ParseException
	{
		FeatureHolderStyle allFeaturesHolderStyle;
		
		// add values to a FeatureSetMap, for passing into decoder
		setMap.put("set1", FeatureFilter.all);
		
		MapStyle mapStyle = new MapStyle();
		SlotStyle slotStyle = mapStyle.getDataStyle().createSlotStyle(1);
		allFeaturesHolderStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.all);
		
		LexicalUnit currUnit;
		
		DescendantSelector labelStyleSelector;
		
		// perform test for LabelStyle under Slot 1
		LabelStyle labelStyle;
		labelStyle = slotStyle.getLabelStyle();
		labelStyle.setTextPaint(Color.blue);
		
		Assert.assertFalse(labelStyle.getTextPaint().equals(Color.red));
		
		labelStyleSelector = buildDescendantSelector("1",new ElementSelectorImpl("labels"));
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		descendentCoder.decodeProperty(labelStyleSelector, mapStyle, null, "text-color", currUnit, null);
		
		Assert.assertEquals(Color.red, labelStyle.getTextPaint()); // make sure that we decoded value properly into label style
		
		// perform test for LabelStyle under allFeaturesHolderStyle
		labelStyle = allFeaturesHolderStyle.getLabelStyle();
		labelStyle.setTextPaint(Color.blue);
		Assert.assertFalse(labelStyle.getTextPaint().equals(Color.red));
		
		// this time we test labelstyle selector under a FeatureHolderStyle, "slot#1 FeatureSet#set1 labels"
		labelStyleSelector = buildDescendantSelector("1", new ConditionalSelectorImpl(new ElementSelectorImpl("FeatureSet"), new IdConditionImpl("set1")) );
		labelStyleSelector = new DescendantSelectorImpl(labelStyleSelector, new ElementSelectorImpl("labels"));
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		descendentCoder.decodeProperty(labelStyleSelector, mapStyle, setMap, "text-color", currUnit, null);
		
		Assert.assertEquals(Color.red, labelStyle.getTextPaint()); // make sure that we decoded value properly into label style
	}
	
	@Ignore
	@Test
	public void testDecodeToPlotStyle() throws ParseException, CSSException, IOException
	{
		SlotStyle slotStyle = mapStyle.getDataStyle().createSlotStyle(1);
		
		LexicalUnit currUnit;
		
		DescendantSelector plotStyleSelector;
		
		PlotStyle plotStyle = new PlotStyle();
		slotStyle.addStyleItem(plotStyle);
		plotStyle.setPaint(Color.blue);
		
		Assert.assertFalse(plotStyle.getPaint().equals(new Color[]{Color.red}));
		
		plotStyleSelector = buildDescendantSelector("1",new ElementSelectorImpl("plot"));
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		descendentCoder.decodeProperty(plotStyleSelector, mapStyle, null, "color", currUnit, null);
		
		Assert.assertArrayEquals(new Color[]{Color.red}, plotStyle.getPaint()); // make sure that we decoded value properly into plot style
	}
	
	@Test(expected=MalformedSelectorException.class)
	public void testDecodePlotUnderFeatureSet() throws CSSException, IOException, ParseException
	{
		SlotStyle slotStyle = mapStyle.getDataStyle().createSlotStyle(1);
		
		LexicalUnit currUnit;
		
		DescendantSelector plotStyleSelector;
		
		PlotStyle plotStyle = new PlotStyle();
		slotStyle.addStyleItem(plotStyle);
		
		// perform another test, this time with a PlotStyle under a FeatureSet, as in
		// "slot#1 FeatureSet#set1 plot"
		
		plotStyleSelector = buildDescendantSelector("1", new ConditionalSelectorImpl(new ElementSelectorImpl("FeatureSet"), new IdConditionImpl("set1")) );
		plotStyleSelector = new DescendantSelectorImpl(plotStyleSelector, new ElementSelectorImpl("plot"));
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		descendentCoder.decodeProperty(plotStyleSelector, mapStyle, null, "color", currUnit, null);
	}
}
