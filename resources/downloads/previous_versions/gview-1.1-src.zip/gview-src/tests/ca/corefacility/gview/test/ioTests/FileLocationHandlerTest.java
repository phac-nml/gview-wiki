package ca.corefacility.gview.test.ioTests;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Test;

import ca.corefacility.gview.utils.FileLocationHandler;

public class FileLocationHandlerTest
{
	@Test
	public void urlSpaceTest() throws IOException
	{
		String location;
		URI actualuri;
		File tmp;
		
		try
		{
			location = "http://localhost/test data.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI("http", "//localhost/test data.gbk", null), actualuri);
			
			location = "http://localhost/t t/test data.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI("http", "//localhost/t t/test data.gbk", null), actualuri);
			
			location = "https://localhost/test data.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI("https", "//localhost/test data.gbk", null), actualuri);
			
			location = "https://localhost/t t/test data.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI("https", "//localhost/t t/test data.gbk", null), actualuri);
			
			location = "ftp://localhost/test data.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI("ftp", "//localhost/test data.gbk", null), actualuri);
			
			location = "ftp://localhost/t t/test data.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI("ftp", "//localhost/t t/test data.gbk", null), actualuri);
			
			location = "file://localhost/test data.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI("file", "//localhost/test data.gbk", null), actualuri);
			
			location = "file://localhost/t t/test data.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI("file", "//localhost/t t/test data.gbk", null), actualuri);
			
			
			// test with space + :
			tmp = File.createTempFile("test: s", null);
			tmp.deleteOnExit();
			actualuri = FileLocationHandler.getURI(tmp.getAbsolutePath());
			assertEquals(tmp.toURI(), actualuri);
			tmp.delete();
			
			tmp = File.createTempFile("url SpaceTest", null);
			tmp.deleteOnExit();
			location = tmp.getAbsolutePath();
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(tmp.toURI(), actualuri);
			tmp.delete();
		}
		catch (URISyntaxException e)
		{
			fail("syntax error: " + e);
		}
	}
	
	@Test
	public void urlSchemes() throws IOException
	{
		String location;
		URI actualuri;
		
		try
		{
			location = "http://localhost/t.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI(location), actualuri);
			
			location = "http://localhost/test/t.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI(location), actualuri);
			
			location = "http://localhost:88/t.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI(location), actualuri);
			
			location = "http://localhost:88/test/t.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI(location), actualuri);
			
			location = "http://localhost/test/t#t";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI("http://localhost/test/t%23t"), actualuri);
			
			location = "https://localhost/t.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI(location), actualuri);
			
			location = "https://localhost/test/t.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI(location), actualuri);
			
			location = "ftp://localhost/t.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI(location), actualuri);
			
			location = "ftp://localhost/test/t.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI(location), actualuri);
			
			location = "file:///localhost/t.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI(location), actualuri);
			
			location = "file:///localhost/test/t.gbk";
			actualuri = FileLocationHandler.getURI(location);
			assertEquals(new URI(location), actualuri);
		}
		catch (URISyntaxException e)
		{
			fail("syntax error: " + e);
		}
	}
}
