package ca.corefacility.gview.test.plotTests;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.biojava.bio.seq.DNATools;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.bio.symbol.Symbol;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataImp;
import ca.corefacility.gview.utils.content.AverageCalculator;
import ca.corefacility.gview.utils.content.ContentCalculator;
import ca.corefacility.gview.utils.content.ContentCalculator.RangeValue;

public class AverageCalculatorTest
{	
	final static int A = 0;
	final static int C = 1;
	final static int G = 2;
	final static int T = 3;
	final static int totalSymbols = 4;
	final static char[] symbols = new char[totalSymbols];
	
	private final double delta = 0.0000001;
	
	static
	{
		symbols[A] = 'a';
		symbols[C] = 'c';
		symbols[G] = 'g';
		symbols[T] = 't';
	}
	
	private Sequence buildSequenceWithSymbols(int[] symbolsCount) throws IllegalSymbolException
	{
		StringBuilder dnaString = new StringBuilder();
		
		for (int i = 0; i < symbolsCount.length; i++)
		{
			for (int j = 0; j < symbolsCount[i]; j++)
			{
				dnaString.append(symbols[i]);
			}
		}
		
		return DNATools.createDNASequence(dnaString.toString(), "name");
	}
	
	private int getTotalSymbols(int[] symbolsCount)
	{
		int total = 0;
		
		for (int i = 0; i < symbolsCount.length; i++)
		{
			total += symbolsCount[i];
		}
		
		return total;
	}
	
	@Test
	public void averageDiffSymbolsAlternating() throws IllegalSymbolException
	{
		GenomeData genomeData;
		ContentCalculator content;
		Iterator<RangeValue> gAverageIter;

		Sequence dna;
		
		RangeValue currAverage;
		
		Set<Symbol> symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.g());

		dna = DNATools.createDNASequence("gcgcg", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new AverageCalculator(genomeData, true, symbolSet,1,0);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(1, currAverage.value, delta);
		assertEquals(new RangeLocation(1, 2), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(0, currAverage.value, delta);
		assertEquals(new RangeLocation(2, 3), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(1, currAverage.value, delta);
		assertEquals(new RangeLocation(3, 4), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(0, currAverage.value, delta);
		assertEquals(new RangeLocation(4, 5), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(1, currAverage.value, delta);
		assertEquals(new RangeLocation(5, 6), currAverage.location);
		assertFalse(gAverageIter.hasNext());
	}
	
	@Test
	public void averageDiffSymbolsStepTwoWindowFour() throws IllegalSymbolException
	{
		GenomeData genomeData;
		ContentCalculator content;
		Iterator<RangeValue> gAverageIter;

		Sequence dna;
		
		RangeValue currAverage;
		Set<Symbol> symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.g());

		dna = DNATools.createDNASequence("ggccggcc", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new AverageCalculator(genomeData, true, symbolSet,2,4);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/6.0, currAverage.value, delta); // avg(ccggcc)
		assertEquals(new RangeLocation(1, 3), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(4.0/6.0, currAverage.value, delta); // avg(ggccgg)
		assertEquals(new RangeLocation(3, 5), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/6.0, currAverage.value, delta); // avg(ccggcc)
		assertEquals(new RangeLocation(5, 7), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(4.0/6.0, currAverage.value, delta); // avg(ggccgg)
		assertEquals(new RangeLocation(7, 9), currAverage.location);
		assertFalse(gAverageIter.hasNext());
		
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.g());
		symbolSet.add(DNATools.c());
		dna = DNATools.createDNASequence("aaggttccaa", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new AverageCalculator(genomeData, true, symbolSet,2,4);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/6.0, currAverage.value, delta); 
		assertEquals(new RangeLocation(1, 3), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/6.0, currAverage.value, delta); 
		assertEquals(new RangeLocation(3, 5), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(4.0/6.0, currAverage.value, delta); 
		assertEquals(new RangeLocation(5, 7), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/6.0, currAverage.value, delta); 
		assertEquals(new RangeLocation(7, 9), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/6.0, currAverage.value, delta);
		assertEquals(new RangeLocation(9, 11), currAverage.location);
		assertFalse(gAverageIter.hasNext());
	}
	
	@Test
	public void averageDiffSymbolsStepTwoWindowFourNotCircular() throws IllegalSymbolException
	{
		GenomeData genomeData;
		ContentCalculator content;
		Iterator<RangeValue> gAverageIter;

		Sequence dna;
		
		RangeValue currAverage;
		Set<Symbol> symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.g());

		dna = DNATools.createDNASequence("ggccggcc", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new AverageCalculator(genomeData, false, symbolSet,2,4);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(4.0/6.0, currAverage.value, delta);
		assertEquals(new RangeLocation(3, 5), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/6.0, currAverage.value, delta);
		assertEquals(new RangeLocation(5, 7), currAverage.location);
		assertFalse(gAverageIter.hasNext());
		
		
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.g());
		symbolSet.add(DNATools.c());

		dna = DNATools.createDNASequence("aaggttccaa", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new AverageCalculator(genomeData, false, symbolSet,2,4);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/6.0, currAverage.value, delta);
		assertEquals(new RangeLocation(3, 5), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(4.0/6.0, currAverage.value, delta);
		assertEquals(new RangeLocation(5, 7), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/6.0, currAverage.value, delta);
		assertEquals(new RangeLocation(7, 9), currAverage.location);
		assertFalse(gAverageIter.hasNext());
	}
	
	@Test
	public void averageDiffSymbolsAlternatingWindowTwo() throws IllegalSymbolException
	{
		GenomeData genomeData;
		ContentCalculator content;
		Iterator<RangeValue> gAverageIter;

		Sequence dna;
		
		RangeValue currAverage;
		Set<Symbol> symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.g());

		dna = DNATools.createDNASequence("gcgcgc", "name");
		genomeData = new GenomeDataImp(dna);
		
		content = new AverageCalculator(genomeData, true, symbolSet,1,2);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(1.0/3.0, currAverage.value, delta); // avg(cgc)
		assertEquals(new RangeLocation(1, 2), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/3.0, currAverage.value, delta); // avg(gcg)
		assertEquals(new RangeLocation(2, 3), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(1.0/3.0, currAverage.value, delta); // avg(cgc)
		assertEquals(new RangeLocation(3, 4), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/3.0, currAverage.value, delta); // avg(gcg)
		assertEquals(new RangeLocation(4, 5), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(1.0/3.0, currAverage.value, delta); // avg(cgc)
		assertEquals(new RangeLocation(5, 6), currAverage.location);
		assertTrue(gAverageIter.hasNext());
		
		currAverage = gAverageIter.next();
		assertEquals(2.0/3.0, currAverage.value, delta); // avg(gcg)
		assertEquals(new RangeLocation(6, 7), currAverage.location);
		assertFalse(gAverageIter.hasNext());
	}
	
	@Test
	public void averageAllSameSymbols() throws IllegalSymbolException
	{
		GenomeData genomeData;
		ContentCalculator content;
		Iterator<RangeValue> gAverageIter;

		Sequence dna;
		Set<Symbol> symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.g());
		
		int stepBase;

		dna = DNATools.createDNASequence("ggggg", "name");
		genomeData = new GenomeDataImp(dna);
		
		// width window size of "1", should give average of 1 each time g
		content = new AverageCalculator(genomeData, true, symbolSet,1,0);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		stepBase=1;
		while (gAverageIter.hasNext())
		{
			RangeValue curr = gAverageIter.next();
			
			assertEquals(1, curr.value, delta);
			assertEquals(new RangeLocation(stepBase, stepBase+1), curr.location);
			
			stepBase++;
		}
		
		assertEquals(6, stepBase);
		
		
		//
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.g());
		content = new AverageCalculator(genomeData, true, symbolSet,1,2);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		stepBase=1;
		while (gAverageIter.hasNext())
		{
			RangeValue curr = gAverageIter.next();
			
			assertEquals(1, curr.value, delta);
			assertEquals(new RangeLocation(stepBase, stepBase+1), curr.location);
			
			stepBase++;
		}
		
		assertEquals(6, stepBase);
		
		// width window size of "1", should give average of 0 each time a
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.a());
		content = new AverageCalculator(genomeData, true, symbolSet,1,0);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		stepBase=1;
		while (gAverageIter.hasNext())
		{
			RangeValue curr = gAverageIter.next();
			
			assertEquals(0, curr.value, delta);
			assertEquals(new RangeLocation(stepBase, stepBase+1), curr.location);
			
			stepBase++;
		}
		
		assertEquals(6, stepBase);
		
		
		
		// width window size of "1", should give average of 0 each time c
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.c());
		content = new AverageCalculator(genomeData, true, symbolSet,1,0);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		stepBase=1;
		while (gAverageIter.hasNext())
		{
			RangeValue curr = gAverageIter.next();
			
			assertEquals(0, curr.value, delta);
			assertEquals(new RangeLocation(stepBase, stepBase+1), curr.location);
			
			stepBase++;
		}
		
		assertEquals(6, stepBase);
		
		
		// width window size of "1", should give average of 0 each time t
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.t());
		content = new AverageCalculator(genomeData, true, symbolSet,1,0);
		gAverageIter = content.contentIterator();
		assertNotNull(gAverageIter);
		assertTrue(gAverageIter.hasNext());
		
		stepBase=1;
		while (gAverageIter.hasNext())
		{
			RangeValue curr = gAverageIter.next();
			
			assertEquals(0, curr.value, delta);
			assertEquals(new RangeLocation(stepBase, stepBase+1), curr.location);
			
			stepBase++;
		}
		
		assertEquals(6, stepBase);
	}
	
	@Test
	public void totalAverageSymbolsContentTest() throws IllegalSymbolException
	{
		GenomeData genomeData;
		AverageCalculator content;

		int[] symbolsCount = new int[totalSymbols];
		double total;
		Sequence dna;
		
		Set<Symbol> symbolSet;
		
		symbolsCount[A] = 50;
		symbolsCount[C] = 51;
		symbolsCount[G] = 52;
		symbolsCount[T] = 53;
		total = getTotalSymbols(symbolsCount);
		dna = buildSequenceWithSymbols(symbolsCount);
		genomeData = new GenomeDataImp(dna);
		
		// test without registering symbols
		symbolSet = new HashSet<Symbol>();
		content = new AverageCalculator(genomeData, true, symbolSet,1,1);
		assertEquals(0.0, content.getTotalAverageContent(), delta);
		
		// test registering each symbol individually
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.a());
		content = new AverageCalculator(genomeData, true, symbolSet,1,1);
		assertEquals(symbolsCount[A]/total, content.getTotalAverageContent(), delta);
		
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.c());
		content = new AverageCalculator(genomeData, true, symbolSet,1,1);
		assertEquals(symbolsCount[C]/total, content.getTotalAverageContent(), delta);
		
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.g());
		content = new AverageCalculator(genomeData, true, symbolSet,1,1);
		assertEquals(symbolsCount[G]/total, content.getTotalAverageContent(), delta);
		
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.t());
		content = new AverageCalculator(genomeData, true, symbolSet,1,1);
		assertEquals(symbolsCount[T]/total, content.getTotalAverageContent(), delta);
		
		// test registering pairs
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.t());
		symbolSet.add(DNATools.c());
		content = new AverageCalculator(genomeData, true, symbolSet,1,1);
		assertEquals((symbolsCount[T]+symbolsCount[C])/total, content.getTotalAverageContent(), delta);
		
		// test registering pairs (not circular)
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.t());
		symbolSet.add(DNATools.c());
		content = new AverageCalculator(genomeData, false, symbolSet,1,1);
		assertEquals((symbolsCount[T]+symbolsCount[C])/total, content.getTotalAverageContent(), delta);
		
		// test registering pairs
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.t());
		symbolSet.add(DNATools.a());
		content = new AverageCalculator(genomeData, true, symbolSet,1,1);
		assertEquals((symbolsCount[T]+symbolsCount[A])/total, content.getTotalAverageContent(), delta);
		
		// test registering all
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.t());
		symbolSet.add(DNATools.a());
		symbolSet.add(DNATools.c());
		symbolSet.add(DNATools.g());
		content = new AverageCalculator(genomeData, true, symbolSet,1,1);
		assertEquals(1.0, content.getTotalAverageContent(), delta);
		
		
		// test with 0 of one symbol
		symbolsCount[A] = 0;
		symbolsCount[C] = 51;
		symbolsCount[G] = 52;
		symbolsCount[T] = 53;
		total = getTotalSymbols(symbolsCount);
		dna = buildSequenceWithSymbols(symbolsCount);
		genomeData = new GenomeDataImp(dna);
		symbolSet = new HashSet<Symbol>();
		symbolSet.add(DNATools.a());
		content = new AverageCalculator(genomeData, true, symbolSet,1,1);
		assertEquals(0.0, content.getTotalAverageContent(), delta);
	}
}
