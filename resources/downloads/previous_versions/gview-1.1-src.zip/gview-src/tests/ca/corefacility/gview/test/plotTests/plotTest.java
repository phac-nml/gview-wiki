package ca.corefacility.gview.test.plotTests;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.SortedMap;


import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.SimpleAnnotation;
import org.biojava.bio.seq.DNATools;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.utils.ChangeVetoException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.NoAnnotationException;
import ca.corefacility.gview.layout.PlotBuilderAnnotation;
import ca.corefacility.gview.layout.PlotBuilderPoints;
import ca.corefacility.gview.managers.ResolutionManager;
import ca.corefacility.gview.style.datastyle.PlotStyle;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;

public class plotTest
{ 
	public static GenomeData buildData()
	{
		GenomeData data = null;

		try
		{
			Sequence dna = DNATools.createDNASequence(
					"atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct"
							+ "atgctgatattatatatatatatatatatatatatatatatatagctatgctgatattatatatatatatatatatatatatatatatatagct", "dna_1");

			Feature.Template ft = new Feature.Template();
			
			ft.annotation = new SimpleAnnotation();
			ft.annotation.setProperty("locus_tag", "TAG01");
			ft.location = new RangeLocation(1, 5);
			dna.createFeature(ft);
			
			ft.annotation = new SimpleAnnotation();
			ft.annotation.setProperty("locus_tag", "TAG02");
			ft.location = new RangeLocation(5, 10);
			dna.createFeature(ft);
			
			ft.annotation = new SimpleAnnotation();
			ft.annotation.setProperty("locus_tag", "TAG03");
			ft.location = new RangeLocation(15, 18);
			dna.createFeature(ft);
			
			ft.annotation = new SimpleAnnotation();
			ft.annotation.setProperty("locus_tag", "TAG04");
			ft.location = new RangeLocation(30, 45);
			dna.createFeature(ft);

			data = GenomeDataFactory.createGenomeData(dna);
		}
		catch (IllegalSymbolException ex)
		{
			ex.printStackTrace();
		}
		catch (ChangeVetoException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (BioException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return data;
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void addNegPointTest()
	{	
		PlotBuilderPoints plotBuilder = new PlotBuilderPoints();
		
		plotBuilder.addPoint(-1, 1.0);
	}
	
	// test creating an annotation plot where the data we pass does not have the specific annotation we added to the plot builder
	@Test(expected=NoAnnotationException.class)
	public void testCreateAnnotationPlotNoAnnotation() throws IOException, CloneNotSupportedException, ParseException, NoAnnotationException
	{	
		GenomeData data = buildData();
		
		// plot builder
		PlotBuilderAnnotation plotBuilder = new PlotBuilderAnnotation();
		plotBuilder.addAnnotationValue("locus_tag", "NOTATAG", 0.5);
		
		// get SortedMap of ranges for the passed data
		SortedMap<RangeLocation, Double> rangeMap = plotBuilder.getRangesFor(data);
	}
	
	// test creating an annotation plot where the data we pass does not have the specific annotation we added to the plot builder
	@Test(expected=NoAnnotationException.class)
	public void testCreateAnnotationPlotNoAnnotation2() throws IOException, CloneNotSupportedException, ParseException, NoAnnotationException
	{	
		GenomeData data = buildData();
		
		// plot builder
		PlotBuilderAnnotation plotBuilder = new PlotBuilderAnnotation();
		plotBuilder.addAnnotationValue("notAAnnotationType", "NOTAVALUE", 0.5);
		
		// get SortedMap of ranges for the passed data
		SortedMap<RangeLocation, Double> rangeMap = plotBuilder.getRangesFor(data);
	}

	@Test
	public void testCreateAnnotationPlot() throws IOException, CloneNotSupportedException, ParseException, NoAnnotationException
	{	
		GenomeData data = buildData();
		
		// plot builder
		PlotBuilderAnnotation plotBuilder = new PlotBuilderAnnotation();
		plotBuilder.addAnnotationValue("locus_tag", "TAG01", 0.5);
		plotBuilder.addAnnotationValue("locus_tag", "TAG02", 0.6);
		plotBuilder.addAnnotationValue("locus_tag", "TAG03", 0.7);
		plotBuilder.addAnnotationValue("locus_tag", "TAG04", 0.8);
		plotBuilder.autoScale();
		
		// get SortedMap of ranges for the passed data
		SortedMap<RangeLocation, Double> rangeMap = plotBuilder.getRangesFor(data);
		
		// make sure values are as expected
		assertEquals(4, rangeMap.size());
		assertEquals(new Double(0.5), rangeMap.get(new RangeLocation(1,5)));
		assertEquals(new Double(0.6), rangeMap.get(new RangeLocation(5,10)));
		assertEquals(new Double(0.7), rangeMap.get(new RangeLocation(15,18)));
		assertEquals(new Double(0.8), rangeMap.get(new RangeLocation(30,45)));
		
		// make sure any other value in map gives null
		assertNull(rangeMap.get(new RangeLocation(45,46)));
	}
}
