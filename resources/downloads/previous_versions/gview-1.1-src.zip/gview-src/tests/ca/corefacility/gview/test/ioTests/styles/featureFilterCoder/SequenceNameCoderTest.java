package ca.corefacility.gview.test.ioTests.styles.featureFilterCoder;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.io.gss.featureFilterCoder.FeatureFilterCoder;
import ca.corefacility.gview.style.io.gss.featureFilterCoder.SequenceNameCoder;
import ca.corefacility.gview.style.io.gss.featureFilterCoder.StrandedCoder;
import ca.corefacility.gview.utils.SequenceNameFilter;

public class SequenceNameCoderTest
{
	@Test
	public void testEncode() throws CSSException, IOException
	{
		String encoded;
		FeatureFilterCoder coder = new SequenceNameCoder();
		SequenceNameFilter filter = new SequenceNameFilter("name");
		
		assertTrue(coder.canCode(filter));
		
		encoded = coder.encode(filter);
		
		assertEquals("sequenceName(\"name\")", encoded);
	}
	
	@Test
	public void testDecode() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		FeatureFilterCoder coder = new SequenceNameCoder();
		LexicalUnit currUnit;
		FeatureFilter filter;
		SequenceNameFilter nameFilter;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("sequenceName(\"name1\")")));
		filter = coder.decode(currUnit);
		assertNotNull(filter);
		assertEquals(SequenceNameFilter.class, filter.getClass());
		nameFilter = (SequenceNameFilter)filter;
		assertEquals("name1", nameFilter.getSequenceName());
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("sequenceName(\"name2\")")));
		filter = coder.decode(currUnit);
		assertNotNull(filter);
		assertEquals(SequenceNameFilter.class, filter.getClass());
		nameFilter = (SequenceNameFilter)filter;
		assertEquals("name2", nameFilter.getSequenceName());
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("sequenceName(\"\")")));
		filter = coder.decode(currUnit);
		assertNotNull(filter);
		assertEquals(SequenceNameFilter.class, filter.getClass());
		nameFilter = (SequenceNameFilter)filter;
		assertEquals("", nameFilter.getSequenceName());
	}
}
