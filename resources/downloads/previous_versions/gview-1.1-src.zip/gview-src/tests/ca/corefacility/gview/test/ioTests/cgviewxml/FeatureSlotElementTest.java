package ca.corefacility.gview.test.ioTests.cgviewxml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.awt.Color;
import java.io.IOException;
import java.io.StringReader;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.GViewFileData;
import ca.corefacility.gview.data.readers.GViewFileReader;
import ca.corefacility.gview.data.readers.cgview.CGViewXMLReader;
import ca.corefacility.gview.map.effects.OutsideEffect;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;

public class FeatureSlotElementTest
{
	private static final ShapeEffectRenderer noShading = ShapeEffectRenderer.NO_SELECT_RENDERER;
	private static final ShapeEffectRenderer shading = new OutsideEffect(new Color(0,0,0,128));
	
	private CGViewXMLReader cgviewReader;
	private double delta = 0.0000001;
	
	@Before
	public void setup()
	{
		cgviewReader = new CGViewXMLReader();
	}
	
	// should have exception, as there is no strand listed
	@Test(expected=GViewDataParseException.class)
	public void testFeatureSlotNoStrand() throws IOException, GViewDataParseException
	{		
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot>\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		GViewFileReader.read(xmlReader, cgviewReader);
	}
	
	@Test
	public void testFeatureSlotOrder() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		SlotStyle slotStyle = null;
		
		// test slot style direct strand
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		GViewFileData cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		Assert.assertNotNull(cgviewData);
		
		genomeData = cgviewData.getGenomeData();
		mapStyle = cgviewData.getMapStyle();
		
		Assert.assertNotNull(genomeData);
		Assert.assertNotNull(mapStyle);
		
		Assert.assertEquals(10, genomeData.getSequenceLength());
		
		dataStyle = mapStyle.getDataStyle();
		assertNotNull(dataStyle);
		
		// should be 1 slot, above backbone
		assertEquals(1, dataStyle.getUpperSlot());
		assertEquals(0, dataStyle.getLowerSlot());
		
		slotStyle = dataStyle.getSlotStyle(1);
		
		assertNotNull(slotStyle);
		
		
		// test slot style reverse strand
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"reverse\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		
		// should be 1 slot, below backbone
		assertEquals(0, dataStyle.getUpperSlot());
		assertEquals(-1, dataStyle.getLowerSlot());
		
		slotStyle = dataStyle.getSlotStyle(-1);
		assertNotNull(slotStyle);
		
		
		// test 1 slot above, 1 below
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
					"<featureSlot strand=\"reverse\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		
		// should be 1 slot, below backbone
		assertEquals(1, dataStyle.getUpperSlot());
		assertEquals(-1, dataStyle.getLowerSlot());
		
		slotStyle = dataStyle.getSlotStyle(-1);
		assertNotNull(slotStyle);
		
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);
		
		
		// test 2 above
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		
		// should be 2 slots, above backbone
		assertEquals(2, dataStyle.getUpperSlot());
		assertEquals(0, dataStyle.getLowerSlot());
		
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);
		
		slotStyle = dataStyle.getSlotStyle(2);
		assertNotNull(slotStyle);
		
		// test 2 below
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"reverse\">\n" +
					"</featureSlot>\n"+
					"<featureSlot strand=\"reverse\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		
		// should be 2 slots , below backbone
		assertEquals(0, dataStyle.getUpperSlot());
		assertEquals(-2, dataStyle.getLowerSlot());
		
		slotStyle = dataStyle.getSlotStyle(-1);
		assertNotNull(slotStyle);
		
		slotStyle = dataStyle.getSlotStyle(-2);
		assertNotNull(slotStyle);
	}
	
	@Test
	public void testFeatureSlotThickness() throws IOException, GViewDataParseException
	{
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		SlotStyle slotStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		
		// test featureThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\" featureThickness=\"10.0\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(10.0, slotStyle.getThickness(), delta);
		
		
		// test featureThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\" featureThickness=\"xxx-small\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(1.0, slotStyle.getThickness(), delta);
	}
	
	@Test
	public void testFeatureSlotThicknessInherited() throws IOException, GViewDataParseException
	{
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		SlotStyle slotStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		
		// test featureThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" featureThickness=\"10.0\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(10.0, slotStyle.getThickness(), delta);
		
		
		// test featureThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" featureThickness=\"xxx-small\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(1.0, slotStyle.getThickness(), delta);
	}
	
	@Test
	public void testShowShading() throws IOException, GViewDataParseException
	{
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		SlotStyle slotStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		
		// test showShading
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\" showShading=\"false\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(noShading, slotStyle.getShapeEffectRenderer());
		
		// test showShading
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\" showShading=\"true\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(shading, slotStyle.getShapeEffectRenderer());
	}
	
	@Test
	public void testShowShadingInherited() throws IOException, GViewDataParseException
	{
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		SlotStyle slotStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		
		// test showShading
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" showShading=\"false\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(noShading, slotStyle.getShapeEffectRenderer());
		
		// test showShading
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" showShading=\"true\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(shading, slotStyle.getShapeEffectRenderer());
	}
}
