package ca.corefacility.gview.test.ioTests.styles;


import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.DescendantSelector;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;
import org.w3c.css.sac.Selector;
import org.w3c.css.sac.SimpleSelector;

import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.map.effects.OutlineEffect;
import ca.corefacility.gview.map.effects.OutsideEffect;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.PlotStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.datastyle.mapper.AnnotationMapper;
import ca.corefacility.gview.style.datastyle.mapper.COGMapper;
import ca.corefacility.gview.style.datastyle.mapper.DiscretePaintMapper;
import ca.corefacility.gview.style.datastyle.mapper.OpacityFeatureStyleMapper;
import ca.corefacility.gview.style.datastyle.mapper.PropertyMapperScore;
import ca.corefacility.gview.style.datastyle.mapper.PropertyStyleContinuous;
import ca.corefacility.gview.style.datastyle.mapper.PropertyStyleDiscrete;
import ca.corefacility.gview.style.io.FeatureSetMap;
import ca.corefacility.gview.style.io.StyleIOGSS;
import ca.corefacility.gview.style.io.gss.FontHandler;
import ca.corefacility.gview.style.io.gss.PaintHandler;
import ca.corefacility.gview.style.io.gss.ShapeEffectHandler;
import ca.corefacility.gview.style.io.gss.ShapeHandler;
import ca.corefacility.gview.style.io.gss.PaintHandler.UnknownPaintException;
import ca.corefacility.gview.style.io.gss.coders.GSSWriter;
import ca.corefacility.gview.style.io.gss.coders.LabelCoder;
import ca.corefacility.gview.style.io.gss.coders.RulerCoder;
import ca.corefacility.gview.style.io.gss.coders.SlotCoder;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedDeclarationException;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedSelectorException;
import ca.corefacility.gview.style.io.gss.exceptions.NoStyleExistsException;
import ca.corefacility.gview.style.io.gss.exceptions.NoSuchFilterException;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.style.items.RulerStyle;
import ca.corefacility.gview.textextractor.AnnotationExtractor;
import ca.corefacility.gview.textextractor.LocationExtractor;

import com.steadystate.css.parser.selectors.*;

public class SlotCoderTest
{
	private SlotCoder coder;
	
	@Before
	public void setup()
	{
		coder = new SlotCoder();
	}
	
	private SimpleSelector buildFeatureSelector(String setName)
	{
		SimpleSelector featureSelector = new ConditionalSelectorImpl(new ElementSelectorImpl("FeatureSet"), new IdConditionImpl(setName));
		
		return featureSelector;
	}
	
	private DescendantSelector buildDescendantSelector(Selector base, SimpleSelector descendant)
	{
		DescendantSelector descSel = new DescendantSelectorImpl(base, descendant);
		
		return descSel;
	}
	
	private Selector buildSlotSelector(String slotNumber)
	{
		Selector slotSelector = new ConditionalSelectorImpl(new ElementSelectorImpl("slot"), new IdConditionImpl(slotNumber));
		
		return slotSelector;
	}
	
	@Test(expected=ParseException.class)
	public void testDecodeInvalid() throws CSSException, IOException, ParseException
	{
		MapStyle mapStyle = new MapStyle();
		FeatureSetMap filtersMap = new FeatureSetMap();
		
		filtersMap.put("positive", new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		filtersMap.put("all", FeatureFilter.all);
		
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		Selector selector;
		
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// create the selector
		selector = buildSlotSelector("-1");
		
		// create initial feature holder style
		dataStyle.createSlotStyle(-1);

		// must run startSelector to (among other things) set the filter map
		coder.startSelector(selector, filtersMap, mapStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		coder.decodeProperty(selector, mapStyle, filtersMap, "invalid", currUnit, null);
	}
	
	// test out automatic slot creation if it doesn't already exist
	@Test
	public void testSlotCreation() throws ParseException
	{
		MapStyle mapStyle = new MapStyle();
		DataStyle dataStyle = mapStyle.getDataStyle();
		Selector selector;
		
		// make sure there is no slot number 1
		Assert.assertFalse(dataStyle.containsSlotStyle(1));
		
		selector = buildSlotSelector("1");
		
		// this should create slot number 1
		coder.startSelector(selector, null, mapStyle);
		
		Assert.assertTrue(dataStyle.containsSlotStyle(1));
		
		// make sure there is no slot number 1
		Assert.assertFalse(dataStyle.containsSlotStyle(-1));
		
		selector = buildSlotSelector("-1");
		
		// this should create slot number 1
		coder.startSelector(selector, null, mapStyle);
		
		Assert.assertTrue(dataStyle.containsSlotStyle(-1));
	}
	
	// test out decoding from a feature set below a slot
	@Test
	public void testDecodeSlotFeatureSet() throws CSSException, IOException, ParseException
	{	
		MapStyle mapStyle = new MapStyle();
		FeatureSetMap filtersMap = new FeatureSetMap();
		
		filtersMap.put("positive", new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		filtersMap.put("all", FeatureFilter.all);
		
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		FeatureHolderStyle topStyle;
		FeatureHolderStyle workingStyle;
		LexicalUnit currUnit;
		
		Selector selector;
		
		SlotStyle currentSlot;
		FeatureHolderStyle expectedStyle;
		
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// create the selector
		selector = buildDescendantSelector(buildDescendantSelector(buildSlotSelector("-1"), buildFeatureSelector("all")),
				buildFeatureSelector("positive"));
		
		// create initial feature holder style
		currentSlot = dataStyle.createSlotStyle(-1);
		topStyle = currentSlot.createFeatureHolderStyle(filtersMap.get("all"));
		workingStyle = topStyle.createFeatureHolderStyle(filtersMap.get("positive"));
		
		// must run startSelector to (among other things) set the filter map
		coder.startSelector(selector, filtersMap, mapStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setPaint(Color.red);
		
		coder.decodeProperty(selector, mapStyle, filtersMap, "color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("shape-effect(\"outline\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setShapeEffectRenderer(new OutlineEffect());
		
		coder.decodeProperty(selector, mapStyle, filtersMap, "feature-effect", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("shape(\"counterclockwise-arrow\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);
		
		coder.decodeProperty(selector, mapStyle, filtersMap, "feature-shape", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("text-extractor(\"location\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setToolTipExtractor(new LocationExtractor());
		
		coder.decodeProperty(selector, mapStyle, filtersMap, "tooltip-text", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("text-extractor(annotation(\"h1\"))")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setHyperlinkExtractor(new AnnotationExtractor("h1"));
		
		coder.decodeProperty(selector, mapStyle, filtersMap, "hyperlink", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("continuous-map(score(0,100.0), opacity)")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setPropertyStyle(new PropertyStyleContinuous(new PropertyMapperScore(0.0f,100.0f), new OpacityFeatureStyleMapper()));
		
		coder.decodeProperty(selector, mapStyle, filtersMap, "property-mapper", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("discrete-map(cog(" +
				"\"A\", \"B\"), colors(color(\"red\"), color(\"blue\")))")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setPropertyStyle(new PropertyStyleDiscrete(new COGMapper(new String[]{"A", "B"}),
				new DiscretePaintMapper(new Color[]{Color.RED, Color.BLUE})));
		
		coder.decodeProperty(selector, mapStyle, filtersMap, "property-mapper", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testDecodeSlotNumber() throws CSSException, IOException, ParseException
	{
		MapStyle map1;
		
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		SlotStyle workingStyle;
		LexicalUnit currUnit;
		
		SlotStyle expectedStyle;

		// setup encoding
		Selector selector;
		
		map1 = new MapStyle();
		DataStyle dataStyle = map1.getDataStyle();
		
		selector = buildSlotSelector("1");
		
		// create initial slot style
		workingStyle = dataStyle.createSlotStyle(1);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		// setup expected style
		expectedStyle = (SlotStyle)workingStyle.clone();
		expectedStyle.setPaint(Color.red);
		
		coder.decodeProperty(selector, map1, null, "color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("5.0")));
		
		// setup expected style
		expectedStyle = (SlotStyle)workingStyle.clone();
		expectedStyle.setThickness(5.0);
		
		coder.decodeProperty(selector, map1, null, "thickness", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("shape-effect(\"shaded\")")));
		
		// setup expected style
		expectedStyle = (SlotStyle)workingStyle.clone();
		expectedStyle.setShapeEffectRenderer(new OutsideEffect(new Color(0,0,0,128)));
		
		coder.decodeProperty(selector, map1, null, "feature-effect", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("shape(\"clockwise-arrow\")")));
		
		// setup expected style
		expectedStyle = (SlotStyle)workingStyle.clone();
		expectedStyle.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW);
		
		coder.decodeProperty(selector, map1, null, "feature-shape", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("text-extractor(annotation(\"gene\"))")));
		
		// setup expected style
		expectedStyle = (SlotStyle)workingStyle.clone();
		expectedStyle.setToolTipExtractor(new AnnotationExtractor("gene"));
		
		coder.decodeProperty(selector, map1, null, "tooltip-text", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("text-extractor(annotation(\"h1\"))")));
		
		// setup expected style
		expectedStyle = (SlotStyle)workingStyle.clone();
		expectedStyle.setHyperlinkExtractor(new AnnotationExtractor("h1"));
		
		coder.decodeProperty(selector, map1, null, "hyperlink", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testEncode()
	{
		MapStyle mapStyle = new MapStyle();
		LabelCoder labelCoder = new LabelCoder();
		
		SlotStyle slotStyle = mapStyle.getDataStyle().createSlotStyle(1);
		String expectedEncoding, actualEncoding;
		
		StringWriter expectedStringWriter;
		GSSWriter expectedGssWriter;
		
		StringWriter actualStringWriter;
		GSSWriter actualEncodingGSS;
		
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup global slot
		expectedGssWriter.startSelector("slot");
		expectedGssWriter.writeProperty("spacing", "10.0");
		expectedGssWriter.endSelector();
		
		// setup slot numbers
		expectedGssWriter.startSelector("slot", "1");
		expectedGssWriter.writeProperty("color", "color(\"blue\")");
		expectedGssWriter.writeProperty("feature-effect", "shape-effect(\"outline\")");
		expectedGssWriter.writeProperty("feature-shape", "shape(\"clockwise-arrow\")");
		expectedGssWriter.writeProperty("hyperlink", "text-extractor(annotation(\"h1\"))");
		expectedGssWriter.writeProperty("thickness", "10.0");
		expectedGssWriter.writeProperty("tooltip-text", "text-extractor(annotation(\"a\"))");
		expectedGssWriter.endSelector();
		labelCoder.encodeStyle(slotStyle.getLabelStyle(), "slot#1", expectedGssWriter);
		expectedEncoding = expectedStringWriter.toString();
		
		// setup map
		mapStyle.getGlobalStyle().setSlotSpacing(10.0); // setup slot spacing
		slotStyle.setPaint(Color.blue);
		slotStyle.setThickness(10.0);
		slotStyle.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW);
		slotStyle.setHyperlinkExtractor(new AnnotationExtractor("h1"));
		slotStyle.setToolTipExtractor(new AnnotationExtractor("a"));
		slotStyle.setShapeEffectRenderer(new OutlineEffect());
		
		coder.encodeSelector(mapStyle, null, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
	}
}
