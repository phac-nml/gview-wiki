import java.awt.Color;
import java.awt.Font;

import org.biojava.bio.BioException;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.seq.impl.SimpleSequenceFactory;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.bio.symbol.SymbolList;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.data.Slot;
import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.layout.sequence.LayoutFactory;
import ca.corefacility.gview.layout.sequence.linear.LayoutFactoryLinear;
import ca.corefacility.gview.main.GUIManager;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.GViewMapFactory;
import ca.corefacility.gview.style.GlobalStyle;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.items.BackboneStyle;
import ca.corefacility.gview.style.items.RulerStyle;
import ca.corefacility.gview.style.items.TooltipStyle;
import ca.corefacility.gview.textextractor.LocationExtractor;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;

public class featureshaperealizerexample extends PFrame
{
	private static final long serialVersionUID = -3094980468302491586L;

	// creates a new frame and adds the map (a PCanvas) to it
	public featureshaperealizerexample(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	/**
	 * @return  The style used to build the GView map.
	 */
	private static MapStyle buildStyle()
	{
		/**Global Style**/
		
		MapStyle mapStyle = new MapStyle();
		
		// extract associated GlobalStyle from newly created MapStyle object
		GlobalStyle global = mapStyle.getGlobalStyle();
		
		// set initial height/width of the map
		global.setDefaultHeight(700);
		global.setDefaultWidth(700);
		
		global.setBackgroundPaint(Color.WHITE);
		
		// set tool tip style.  This is used to display extra information about various items on the map.
		TooltipStyle tooltip = global.getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(134, 134, 255)); // set background paint to (r,g,b)=(134,134,255)
		tooltip.setOutlinePaint(new Color(0.0f, 0.0f, 0.0f, 0.5f)); // set outline paint of tool tip item to (r,g,b) = (0,0,0) and alpha=0.5
		tooltip.setTextPaint(Color.BLACK);  // set the paint of the text for the tool tip item
		
		// set style information dealing with the backbone.  This is the item displayed in the very centre of the slots.
		BackboneStyle backbone = global.getBackboneStyle();
		backbone.setPaint(Color.GRAY.darker());
		backbone.setThickness(5.0);
		
		// set information dealing with the ruler style
		RulerStyle ruler = global.getRulerStyle();
		ruler.setMajorTickLength(10.0);
		ruler.setTickThickness(2.0);
		ruler.setMinorTickPaint(Color.GREEN.darker().darker());
		ruler.setMajorTickPaint(Color.GREEN.darker().darker());
		ruler.setFont(new Font("SansSerif", Font.BOLD, 12));  // font/font paint set information dealing with the text label of the ruler
		ruler.setTextPaint(Color.BLACK);
		
		/**Slots**/
		
		// assumes mapStyle created as above
		
		// extract data style from map style
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// creates the first two slots
		SlotStyle firstUpperSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER); // first slot above backbone
		firstUpperSlot.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW); // sets all features drawn in this slot to be drawn with a forward arrow
		
		SlotStyle firstLowerSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER); // first slot below backbone
		firstLowerSlot.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);
		
		// creates slots right next to the first slots
		SlotStyle secondUpperSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER + 1);
		secondUpperSlot.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW2);
		
		SlotStyle secondLowerSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER - 1);
		secondLowerSlot.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW2);
		
		// sets the default color of any features in these slots
		firstUpperSlot.setPaint(Color.BLACK);
		firstLowerSlot.setPaint(Color.BLACK);
		secondUpperSlot.setPaint(Color.BLACK);
		secondLowerSlot.setPaint(Color.BLACK);
		
		 // sets the thickness of the respective slots
		firstUpperSlot.setThickness(30);
		firstLowerSlot.setThickness(30);
		secondUpperSlot.setThickness(30);
		secondLowerSlot.setThickness(30);
		
		/**FeatureHolderStyle**/
		
		// assumes SlotStyles were created as above
		
		// creates a feature holder style in the first upper slot containing all the positive stranded features
		FeatureHolderStyle positiveFeatures = firstUpperSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positiveFeatures.setThickness(0.7); // sets the thickness of these features as a proportion of the thickness of the slot
		positiveFeatures.setTransparency(0.9f); // sets transparency of all features drawn within this slot
		positiveFeatures.setToolTipExtractor(new LocationExtractor()); 	// sets how to extract text to be displayed for tool tips on these features
		positiveFeatures.setPaint(Color.BLUE); // sets default color of the positive features
		
		// Creates a sub feature holder style below the positiveFeatures feature holder.  This can be used to extract and override style information
		//	for features that would be contained within the positiveFeatures feature holder.
		// In this example, we will override the blue color for positive features that overlap bases [50,95] and color them a darker blue.
		FeatureHolderStyle subPositiveFeatures = positiveFeatures.createFeatureHolderStyle(new FeatureFilter.OverlapsLocation(new RangeLocation(50,95)));
		subPositiveFeatures.setPaint(Color.BLUE.darker().darker().darker().darker()); // overrides the color for these features, making it darker
		subPositiveFeatures.setFeatureShapeRealizer(FeatureShapeRealizer.NO_ARROW); // overrides the FeatureShapeRealizer inherited from the firstUpperSlot
																					//	and sets all features in this holder to be drawn with no arrow
		
		// creates a holder containing all negative features in the first lower slot
		FeatureHolderStyle negativeFeatures = firstLowerSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeFeatures.setThickness(0.7);
		negativeFeatures.setToolTipExtractor(new LocationExtractor());
		negativeFeatures.setPaint(Color.RED);
		
		// creates a holder containing all features in the second upper slot
		FeatureHolderStyle allFeatures = secondUpperSlot.createFeatureHolderStyle(FeatureFilter.all);
		allFeatures.setThickness(0.7);
		allFeatures.setToolTipExtractor(new LocationExtractor());
		allFeatures.setPaint(Color.GREEN);
		
		// creates a holder containing only features overlapping bases [0,50] in the second lower slot
		FeatureHolderStyle locationFeatures = secondLowerSlot.createFeatureHolderStyle(new FeatureFilter.OverlapsLocation(new RangeLocation(0,50)));
		locationFeatures.setThickness(0.7);
		locationFeatures.setToolTipExtractor(new LocationExtractor());
		locationFeatures.setPaint(Color.BLACK);
		
		return mapStyle;
	}
	
	/**
	 * @return  The data that will be displayed on the map.
	 */
	private static GenomeData buildData()
	{
		GenomeData data = null;
		
		// create a blank symbol list with a length of 95
		SymbolList blankList = new BlankSymbolList(95);
		
		try
		{
			// create a factory to build the blank sequence
			SimpleSequenceFactory seqFactory = new SimpleSequenceFactory();
			
			// creates a sequence from the blank symbol list
			Sequence blankSequence = seqFactory.createSequence(blankList, null, null, null);
			
			// creates a basic feature located at the beginning of the sequence
			Feature.Template basic = new Feature.Template();
			basic.location = new RangeLocation(1,9);
			blankSequence.createFeature(basic);
			
			// creates a basic feature located at the end of the sequence
			basic.location = new RangeLocation(91,94);
			blankSequence.createFeature(basic);
			
			// creates a positive stranded feature
			StrandedFeature.Template stranded = new StrandedFeature.Template();
			stranded.strand = StrandedFeature.POSITIVE;
			stranded.location = new RangeLocation(11,19);
			blankSequence.createFeature(stranded);
			
			// creates another positive stranded feature
			stranded.location = new RangeLocation(31,39);
			blankSequence.createFeature(stranded);
			
			// and another positive stranded feature
			stranded.location = new RangeLocation(51,59);
			blankSequence.createFeature(stranded);
			
			// and another positive stranded feature
			stranded.location = new RangeLocation(71,79);
			blankSequence.createFeature(stranded);
			
			// creates a negative stranded feature
			stranded.strand = StrandedFeature.NEGATIVE;
			stranded.location = new RangeLocation(21,29);
			blankSequence.createFeature(stranded);
			
			// creates another negative stranded feature
			stranded.location = new RangeLocation(41,49);
			blankSequence.createFeature(stranded);
			
			// and another negative stranded feature
			stranded.location = new RangeLocation(61,69);
			blankSequence.createFeature(stranded);
			
			// and another negative stranded feature
			stranded.location = new RangeLocation(81,89);
			blankSequence.createFeature(stranded);
			
			// creates a GenomeData object from the Sequence
			data = GenomeDataFactory.createGenomeData(blankSequence);
		}
		catch (IllegalSymbolException ex)
		{
			ex.printStackTrace();
		}
		catch (BioException be)
		{
			be.printStackTrace();
		}
		
		return data;
	}
	
	public static void main(String[] args)
	{
		// creates the 3 components necessary to build the map
		GenomeData data = buildData();
		MapStyle style = buildStyle();
		LayoutFactory layoutFactory;
		
		// change this to change between linear/circular layouts
		layoutFactory = new LayoutFactoryLinear();
//		layoutFactory = new LayoutFactoryCircular();
		
		// builds the map from the data/style/layout information
		GViewMap gViewMap = GViewMapFactory.createMap(data, style, layoutFactory);

		GUIManager.getInstance().buildGUIFrame("FeatureShapeRealizerExample", gViewMap);
	}
}
