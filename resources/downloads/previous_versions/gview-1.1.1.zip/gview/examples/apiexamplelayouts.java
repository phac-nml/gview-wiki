import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.NoSuchElementException;

import javax.swing.JComponent;
import javax.swing.JDialog;

import org.biojava.bio.BioException;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.SequenceIterator;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.Location;
import org.biojavax.bio.seq.RichSequence;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.data.Slot;
import ca.corefacility.gview.layout.sequence.LayoutFactory;
import ca.corefacility.gview.layout.sequence.circular.LayoutFactoryCircular;
import ca.corefacility.gview.layout.sequence.linear.LayoutFactoryLinear;
import ca.corefacility.gview.main.GUIManager;
import ca.corefacility.gview.map.BirdsEyeView;
import ca.corefacility.gview.map.BirdsEyeViewImp;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.GViewMapFactory;
import ca.corefacility.gview.style.GlobalStyle;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.items.BackboneStyle;
import ca.corefacility.gview.style.items.RulerStyle;
import ca.corefacility.gview.style.items.TooltipStyle;
import ca.corefacility.gview.textextractor.FeatureTextExtractor;
import ca.corefacility.gview.textextractor.LocationExtractor;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;

public class apiexamplelayouts extends PFrame
{
	private static final long serialVersionUID = 7570576560254233243L;


	// creates a new frame and adds the map (a PCanvas) to it
	public apiexamplelayouts(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	private static MapStyle buildStyle()
	{
		/**Global Style**/
		
		MapStyle mapStyle = new MapStyle();
		
		// extract associated GlobalStyle from newly created MapStyle object
		GlobalStyle global = mapStyle.getGlobalStyle();
		
		// set initial height/width of the map
		global.setDefaultHeight(700);
		global.setDefaultWidth(700);
		
		global.setBackgroundPaint(Color.WHITE);
		
		// extract tooltip style from global style
		TooltipStyle tooltip = global.getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(0.4f,0.4f,1.0f,1.0f));
		tooltip.setTextPaint(Color.BLACK);
		
		// extract style information dealing with the backbone
		BackboneStyle backbone = global.getBackboneStyle();
		backbone.setPaint(Color.GRAY.darker());
		backbone.setThickness(5.0);
		
		// extract information dealing with the ruler style
		RulerStyle ruler = global.getRulerStyle();
		ruler.setTickDensity(0.5f);
		ruler.setMajorTickLength(5.0);
		ruler.setMinorTickLength(1.5);
		ruler.setTickThickness(2.0);
		ruler.setMinorTickPaint(Color.LIGHT_GRAY);
		ruler.setMajorTickPaint(Color.DARK_GRAY);
		ruler.setFont(new Font("SansSerif", Font.PLAIN, 12));
		ruler.setTextPaint(Color.BLACK);
		
		/**Slots**/
		
		// assumes mapStyle created as above
		
		// extract data style from map style
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// creates the first two slots
		SlotStyle positveSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		positveSlot.setThickness(30);
		SlotStyle negativeSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER);
		negativeSlot.setThickness(30);
		
		/**FeatureHolderStyle**/
		
		FeatureTextExtractor textExtractor = new LocationExtractor();
		
		// creates a feature holder style in the first upper slot containing all cds positive features
		FeatureHolderStyle positive = positveSlot.createFeatureHolderStyle(
				new FeatureFilter.And(new FeatureFilter.ByType("CDS"),
				new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE)));
		positive.setTransparency(0.7f);
		positive.setToolTipExtractor(textExtractor);
		positive.setPaint(Color.BLUE);
		
		// creates a holder containing all negative features in the first lower slot
		FeatureHolderStyle negativeFeatures = negativeSlot.createFeatureHolderStyle(
				new FeatureFilter.And(new FeatureFilter.ByType("CDS"),
				new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE)));
		negativeFeatures.setTransparency(0.7f);
		negativeFeatures.setToolTipExtractor(textExtractor);
		negativeFeatures.setPaint(Color.RED);
		
		return mapStyle;
	}
	
	
	public static void main(String[] args)
	{
		BufferedReader br = null;
		
		try
		{
			//create a buffered reader to read the sequence file
			br = new BufferedReader(new FileReader("example_data/NC_007622.gbk"));
		}
		catch (FileNotFoundException ex) 
		{
	        //can't find the file
	        ex.printStackTrace();
	        System.exit(-1);
		}

        try
        {
    		//read the GenBank File
    		SequenceIterator sequences = RichSequence.IOTools.readGenbankDNA(br, null);
    	   
        	
    		// only obtain one sequence
    		if (sequences.hasNext())
    		{
	        	// extract the sequence
	        	Sequence seq = sequences.nextSequence();     
		  		
	        	// create data, style, and layout managers
		  		GenomeData data = GenomeDataFactory.createGenomeData(seq);
		  		MapStyle style = buildStyle(); // creates style, buildStyle() code not shown
		  		LayoutFactory layoutFactory = new LayoutFactoryLinear();
		  		
		  		GViewMap gViewMap = GViewMapFactory.createMap(data, style, layoutFactory);
		  		
		  		// inserts first gview map into a GViewGUIFrame which includes the menu bar
		  		GUIManager.getInstance().buildGUIFrame("ApiExampleLayoutsGUIFrame", gViewMap);
				
				// circular
				layoutFactory = new LayoutFactoryCircular();
		  		
		  		gViewMap = GViewMapFactory.createMap(data, style, layoutFactory);
		  		
		  		// inserts first gview map into a GViewGUIFrame which includes the menu bar
		  		GUIManager.getInstance().buildGUIFrame("ApiExampleLayoutsGUIFrame", gViewMap);
    		}
	   
        }
		catch (BioException ex)
		{
			//not in GenBank format
			ex.printStackTrace();
		}
		catch (NoSuchElementException ex)
		{
			//request for more sequence when there isn't any
			ex.printStackTrace();
		}
	}
}
