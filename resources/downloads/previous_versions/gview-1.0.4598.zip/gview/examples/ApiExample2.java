import java.awt.Color;
import java.awt.Font;

import javax.swing.JComponent;
import javax.swing.JDialog;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.seq.impl.SimpleSequenceFactory;
import org.biojava.bio.symbol.IllegalSymbolException;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.bio.symbol.SymbolList;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.data.Slot;
import ca.corefacility.gview.layout.sequence.LayoutFactory;
import ca.corefacility.gview.layout.sequence.circular.LayoutFactoryCircular;
import ca.corefacility.gview.map.BirdsEyeView;
import ca.corefacility.gview.map.BirdsEyeViewImp;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.GViewMapFactory;
import ca.corefacility.gview.style.GlobalStyle;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.items.BackboneStyle;
import ca.corefacility.gview.style.items.RulerStyle;
import ca.corefacility.gview.style.items.TooltipStyle;
import ca.corefacility.gview.textextractor.LocationExtractor;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;

public class ApiExample2 extends PFrame
{
	private static final long serialVersionUID = -8025926938125434620L;

	// creates a new frame and adds the map (a PCanvas) to it
	public ApiExample2(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	/**
	 * @return  The data that will be displayed on the map.
	 */
	private static GenomeData buildData()
	{
		GenomeData data = null;
		
		// create a blank symbol list with the given length
		SymbolList blankList = new BlankSymbolList(115);
		
		try
		{
			// create a factory to build the blank sequence
			SimpleSequenceFactory seqFactory = new SimpleSequenceFactory();
			
			// creates a sequence from the blank symbol list
			Sequence blankSequence = seqFactory.createSequence(blankList, null, null, null);
			
			// creates template stranded feature
			StrandedFeature.Template stranded = new StrandedFeature.Template();
			
			// create positive stranded features
			for (int i = 0; i < 6; i++)
			{
				stranded.strand = StrandedFeature.POSITIVE;
				stranded.annotation = Annotation.EMPTY_ANNOTATION;
				stranded.location = new RangeLocation(12*i,15*i + 5);
				stranded.type = "test";
				stranded.source = "testsource";
				blankSequence.createFeature(stranded);
			}
			
			// create negative stranded features
			for (int i = 0; i < 6; i++)
			{
				stranded.strand = StrandedFeature.NEGATIVE;
				stranded.annotation = Annotation.EMPTY_ANNOTATION;
				stranded.location = new RangeLocation(10*i,16*i + 10);
				stranded.type = "test";
				stranded.source = "testsource";
				blankSequence.createFeature(stranded);
			}
			
			// creates a GenomeData object from the Sequence
			data = GenomeDataFactory.createGenomeData(blankSequence);
		}
		catch (IllegalSymbolException ex)
		{
		    ex.printStackTrace();
		}
		catch (BioException be)
		{
			be.printStackTrace();
		}
		
		return data;
	}
	
	private static MapStyle buildStyle()
	{
		/**Global Style**/
		
		MapStyle mapStyle = new MapStyle();
		
		// extract associated GlobalStyle from newly created MapStyle object
		GlobalStyle global = mapStyle.getGlobalStyle();
		
		// set initial height/width of the map
		global.setDefaultHeight(700);
		global.setDefaultWidth(700);
		
		global.setBackgroundPaint(Color.WHITE);
		
		// extract tooltip style from global style
		TooltipStyle tooltip = global.getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(150,150,255,230));
		tooltip.setTextPaint(Color.BLACK);
		
		// extract style information dealing with the backbone
		BackboneStyle backbone = global.getBackboneStyle();
		backbone.setPaint(Color.GRAY.darker());
		backbone.setThickness(5.0);
		
		// extract information dealing with the ruler style
		RulerStyle ruler = global.getRulerStyle();
		ruler.setMajorTickLength(5.0);
		ruler.setMinorTickLength(1.5);
		ruler.setTickThickness(1.0);
		ruler.setMinorTickPaint(Color.LIGHT_GRAY);
		ruler.setMajorTickPaint(Color.DARK_GRAY);
		ruler.setFont(new Font("SansSerif", Font.PLAIN, 12));
		ruler.setTextPaint(Color.BLACK);
		
		/**Slots**/
		
		// assumes mapStyle created as above
		
		// extract data style from map style
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// creates the first two slots
		SlotStyle positveSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		positveSlot.setThickness(20);
		SlotStyle negativeSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER);
		negativeSlot.setThickness(20);
		
		/**FeatureHolderStyle**/
		
		// creates a feature holder style in the first upper slot containing all the features
		FeatureHolderStyle positive = positveSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positive.setThickness(0.7);
		positive.setToolTipExtractor(new LocationExtractor());
		positive.setPaint(new Color(128,0,128)); // purple
		
		// creates a holder containing all negative features in the first lower slot
		FeatureHolderStyle negativeFeatures = negativeSlot.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeFeatures.setPaint((new Color(128,0,128)).darker()); // dark purple
		
		return mapStyle;
	}
	
	public static void main(String[] args)
	{
		// creates the 3 components necessary to build the map
		GenomeData data = buildData();
		MapStyle style = buildStyle();
		LayoutFactory layoutFactory = new LayoutFactoryCircular();
		
		// builds the map from the data/style/layout information
		GViewMap gViewMap = GViewMapFactory.createMap(data, style, layoutFactory);
		
		// creates the gview.main display frame
		new ApiExample2("ApiExample2", (PCanvas)gViewMap);
		
		// creates the birds eye view component, and connects it to the gViewMap
		BirdsEyeView bev = new BirdsEyeViewImp();
		bev.connect(gViewMap);
		
		// displays the birds eye view component in a JDialog
		JDialog bird = new JDialog();
		bird.getContentPane().add((JComponent)bev);
		bird.pack();
		bird.setSize(150, 150);
		bird.setVisible(true);
	}
}
