package ca.corefacility.gview.map.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.ShowAboutDialogAction;

/**
 * Responsible for creating the "About" menu item.
 * 
 * @author ericm
 *
 */
public class AboutMenuItem extends JMenuItem implements ActionListener
{
	private static final long serialVersionUID = -3619586268694907998L;
	
	private final GViewGUIFrame frame;
	
	/**
	 * @param frame The frame object this item is a part of. 
	 */
	public AboutMenuItem(GViewGUIFrame frame)
	{
		super(GUIUtility.ABOUT_TEXT);
		
		this.frame = frame;
		
		this.setActionCommand(GUIUtility.ABOUT);
		this.addActionListener(this);
	}

	@Override
	/**
	 * Listens for "About" menu item actions.
	 */
	public void actionPerformed(ActionEvent e) 
	{
		Action action;
		
		if (GUIUtility.ABOUT.equals(e.getActionCommand()))
		{
			action = new ShowAboutDialogAction(frame.getAboutDialog());
			action.run();
		}		
	}
}
