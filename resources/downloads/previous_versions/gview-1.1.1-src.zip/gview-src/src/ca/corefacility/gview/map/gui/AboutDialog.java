package ca.corefacility.gview.map.gui;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTMLEditorKit;

import javax.swing.BoxLayout;

public class AboutDialog extends JDialog implements HyperlinkListener, ActionListener
{

	private static final long serialVersionUID = 1247417939930528810L;
	
	private final JPanel contentPanel = new JPanel();
	private JTextPane textPane;

	/**
	 * Create the dialog.
	 */
	public AboutDialog(JFrame frame) 
	{
		super(frame, "About GView");
		
		setBounds(100, 100, 450, 450);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.X_AXIS));
		{
			textPane = new JTextPane();
			textPane.addHyperlinkListener(this);
			
			textPane.setEditable(false);
			textPane.setEditorKit(new HTMLEditorKit());
			textPane.setText(GUIUtility.ABOUT_DIALOG_TEXT);
			contentPanel.add(textPane);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(this);
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
		
		pack();
	}

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) 
	{
		if(e.getEventType() == HyperlinkEvent.EventType.ACTIVATED)
        {
			if (java.awt.Desktop.isDesktopSupported())
			{
	        	Desktop desktop = Desktop.getDesktop();
	        	if (desktop.isSupported(Desktop.Action.BROWSE))
	        	{       		
	        		try
					{
						URI usageURI = e.getURL().toURI();
						desktop.browse(usageURI);
					}
	        		catch (URISyntaxException e1)
					{
						e1.printStackTrace();
					}
	        		catch (IOException e1)
					{
						e1.printStackTrace();
					}
	        	}
			}
        }
		else if (e.getEventType() == HyperlinkEvent.EventType.ENTERED)
		{
			textPane.setToolTipText(e.getURL().toString());
		}
		else if (e.getEventType() == HyperlinkEvent.EventType.EXITED)
		{
			textPane.setToolTipText(null);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getActionCommand().equals("OK"))
		{
			this.setVisible(false);
		}
	}
}
