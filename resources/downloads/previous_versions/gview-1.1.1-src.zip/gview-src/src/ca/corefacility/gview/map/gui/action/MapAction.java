package ca.corefacility.gview.map.gui.action;

public abstract class MapAction extends Action {

}
