package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.gui.AboutDialog;

public class ShowAboutDialogAction extends ShowDialogAction 
{
	public ShowAboutDialogAction (AboutDialog dialog)
	{
		super(dialog);
	}
}
