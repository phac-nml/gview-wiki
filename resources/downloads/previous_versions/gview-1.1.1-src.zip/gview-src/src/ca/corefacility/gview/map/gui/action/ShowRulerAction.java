package ca.corefacility.gview.map.gui.action;

import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.ElementControl;

public class ShowRulerAction extends ShowItemAction 
{
	private final ElementControl control;
	
	public ShowRulerAction(ElementControl control)
	{
		this.control = control;
	}

	@Override
	public void undo() throws CannotUndoException 
	{
		control.setRulerDisplayed(false);
	}

	@Override
	public void run() 
	{
		control.setRulerDisplayed(true);
	}

}
