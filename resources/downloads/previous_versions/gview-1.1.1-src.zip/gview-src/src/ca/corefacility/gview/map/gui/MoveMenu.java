package ca.corefacility.gview.map.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.MoveEndAction;
import ca.corefacility.gview.map.gui.action.MoveFirstQuarterAction;
import ca.corefacility.gview.map.gui.action.MoveHalfAction;
import ca.corefacility.gview.map.gui.action.MoveStartAction;
import ca.corefacility.gview.map.gui.action.MoveThirdQuarterAction;
import ca.corefacility.gview.map.gui.action.ShowMoveDialogAction;

/**
 * Responsible for creating the move menu.
 * 
 * @author ericm
 *
 */
public class MoveMenu extends JMenu implements ActionListener
{
	private static final long serialVersionUID = 8067577474636211456L;
	
	private final GViewMap gViewMap;
	private final GViewGUIFrame frame;
	
	/**
	 * Creates a new MoveMenu with the specified frame. 
	 * @param frame The frame the menu will be sitting on. Required for the custom scale dialog.
	 */
	public MoveMenu(GViewGUIFrame frame)
	{
		super(GUIUtility.MOVE_TEXT);
		
		this.frame = frame;
		this.gViewMap = frame.getGViewMap();
		
		addMenuItems();
	}
	
	/**
	 * Adds the individual menu items to the zoom sub menu.
	 */
	private void addMenuItems()
	{
		JMenuItem currMenuItem;
		
		//Start item.
		currMenuItem = new JMenuItem(GUIUtility.START);
		currMenuItem.setActionCommand(GUIUtility.START);
		currMenuItem.setAccelerator(KeyStroke.getKeyStroke(GUIUtility.CENTER_SHORTCUT));
		currMenuItem.addActionListener(this);
		this.add(currMenuItem);
		
		//Other move items.
		for (int i = 1; i < GUIUtility.constantBaseMoves.length; i++)
		{
			currMenuItem = new JMenuItem(GUIUtility.constantBaseMoves[i]);
			currMenuItem.setActionCommand(GUIUtility.constantBaseMoves[i]);
			currMenuItem.addActionListener(this);
			this.add(currMenuItem);
		}
		
		this.add(GUIUtility.createSeparator(this));
		
		//Custom move item.
		currMenuItem = new JMenuItem(GUIUtility.MOVE_BASE_CUSTOM);
		currMenuItem.setActionCommand(GUIUtility.MOVE_BASE_CUSTOM);
		currMenuItem.addActionListener(this);
		this.add(currMenuItem);
	}

	@Override
	/**
	 * Listens for move events.
	 */
	public void actionPerformed(ActionEvent e)
	{
		Action action;
		
		if (GUIUtility.START.equals(e.getActionCommand()))
		{
			action = new MoveStartAction(gViewMap);
			action.run();
		}
		else if (GUIUtility.QUARTER_1.equals(e.getActionCommand()))
		{
			action = new MoveFirstQuarterAction(gViewMap);
			action.run();
		}
		else if (GUIUtility.HALF.equals(e.getActionCommand()))
		{
			action = new MoveHalfAction(gViewMap);
			action.run();
		}
		else if (GUIUtility.QUARTER_3.equals(e.getActionCommand()))
		{
			action = new MoveThirdQuarterAction(gViewMap);
			action.run();
		}
		else if (GUIUtility.END.equals(e.getActionCommand()))
		{
			action = new MoveEndAction(gViewMap);
			action.run();
		}
		else if (GUIUtility.MOVE_BASE_CUSTOM.equals(e.getActionCommand()))
		{
			action = new ShowMoveDialogAction(frame.getMoveDialog());
			action.run();
		}
	}	
}
