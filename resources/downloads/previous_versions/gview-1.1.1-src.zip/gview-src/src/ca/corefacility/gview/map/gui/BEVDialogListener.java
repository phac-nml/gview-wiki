package ca.corefacility.gview.map.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import ca.corefacility.gview.map.BirdsEyeViewImp;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.event.GViewEvent;
import ca.corefacility.gview.map.event.GViewEventListener;
import ca.corefacility.gview.map.event.ZoomNormalEvent;
import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.ScaleInAction;
import ca.corefacility.gview.map.gui.action.ScaleOutAction;

/**
 * A custom listener class for the BEV Dialog.
 * 
 * @author ericm
 *
 */
public class BEVDialogListener implements WindowListener, ComponentListener, ChangeListener, GViewEventListener, ActionListener
{
	private final GViewMap gViewMap;
	private final BirdsEyeViewImp BEV;	//The actual BEV object.
	private final BEVMenuItem BEVItem;	//The corresponding menu item to select and deselect.
	private final JSlider slider;
	private boolean zoomEventFromGView;	//Needed internally to prevent thrashing of the slider and zoom level.
	
	/**
	 * 
	 * @param gViewMap The map the dialog relates to.
	 * @param BEV The BEV map implementation.
	 * @param BEVItem The BEV menu item.
	 * @param slider The slider on the BEV Dialog.
	 */
	public BEVDialogListener(GViewMap gViewMap, BirdsEyeViewImp BEV, BEVMenuItem BEVItem, JSlider slider)
	{
		this.BEV = BEV;
		this.BEVItem = BEVItem;
		this.slider = slider;
		this.gViewMap = gViewMap;
	}
	
	@Override
	/**
	 * Updates the BEV Map.
	 */
	public void componentResized(ComponentEvent e) 
	{
		BEV.updateFromViewed();			
	}

	@Override
	/**
	 * Updates the BEV Map.
	 */
	public void componentMoved(ComponentEvent e) 
	{
		BEV.updateFromViewed();	
	}

	@Override
	/**
	 * Updates the BEV Map.
	 */
	public void componentShown(ComponentEvent e) 
	{
		BEV.updateFromViewed();	
	}

	@Override
	/**
	 * Updates the BEV Map.
	 */
	public void componentHidden(ComponentEvent e) 
	{
		BEV.updateFromViewed();	
	}

	@Override
	/**
	 * Updates the BEV Map.
	 */
	public void windowOpened(WindowEvent e) 
	{
		BEV.updateFromViewed();	
	}

	@Override
	/**
	 * Updates the BEV Map.
	 */
	public void windowClosing(WindowEvent e) 
	{
		BEV.updateFromViewed();
		BEVItem.setSelected(false);	//set the menu item to unchecked
	}

	@Override
	/**
	 * Updates the BEV Map.
	 */
	public void windowClosed(WindowEvent e) 
	{
		BEV.updateFromViewed();	
	}

	@Override
	/**
	 * Updates the BEV Map.
	 */
	public void windowIconified(WindowEvent e) 
	{
		BEV.updateFromViewed();	
	}

	@Override
	/**
	 * Updates the BEV Map.
	 */
	public void windowDeiconified(WindowEvent e) 
	{
		BEV.updateFromViewed();	
	}

	@Override
	/**
	 * Updates the BEV Map.
	 */
	public void windowActivated(WindowEvent e) 
	{
		BEV.updateFromViewed();	
	}

	@Override
	/**
	 * Updates the BEV Map.
	 */
	public void windowDeactivated(WindowEvent e) 
	{
		BEV.updateFromViewed();	
	}

	@Override
	/**
	 * Listens for the slider value being changed.
	 */
	public void stateChanged(ChangeEvent e) 
	{
		//Basically, only update if the zooming event occurred before or after the slider itself sets the zoom level.
		if(!zoomEventFromGView)
			gViewMap.zoomNormal( GUIUtility.convertSliderValueToScale(slider.getValue()) );		
	}

	/**
	 * Sets whether or not the next zoom event occurred from the GViewMap itself or from another component.
	 * 
	 * @param b
	 */
	private void setGViewZoomEventOccured(boolean b) 
	{
		zoomEventFromGView = b;		
	}

	@Override
	/**
	 * Fires when a GViewEvent occurs. Listens for a ZoomNormal event and updates the slider of the BEV Dialog accordingly.
	 */
	public void eventOccured(GViewEvent event) 
	{
		if(event instanceof ZoomNormalEvent)
		{
			//Basically, only update if the zooming event occurred before or after the slider itself sets the zoom level.
			//Prevents thrashing of the zoom level, which is partially caused by the slider having only integer values and 
			//the zoom level accepting double values.
			this.setGViewZoomEventOccured(true);
			this.slider.setValue(GUIUtility.convertScaleToSlider(gViewMap.getZoomNormalFactor()));
			this.setGViewZoomEventOccured(false);
		}		
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		Action action;
		
		if( GUIUtility.SCALE_IN.equals(e.getActionCommand()) )
		{
			action = new ScaleInAction(this.gViewMap);
			action.run();
		}
		else if( GUIUtility.SCALE_OUT.equals(e.getActionCommand()) )
		{
			action = new ScaleOutAction(this.gViewMap);
			action.run();
		}
	}
}
