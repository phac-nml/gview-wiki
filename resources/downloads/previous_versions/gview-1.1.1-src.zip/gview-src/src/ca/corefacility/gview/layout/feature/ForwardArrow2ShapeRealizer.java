package ca.corefacility.gview.layout.feature;

import ca.corefacility.gview.layout.Direction;
import ca.corefacility.gview.layout.prototype.BackboneShape;
import ca.corefacility.gview.layout.sequence.SlotPath;

/**
 * FeatureShapeRealizer used to draw an arrow which looks like
 * 
 * ---->
 * 
 * @author Aaron Petkau
 *
 */
public class ForwardArrow2ShapeRealizer extends AbstractArrowShapeRealizer
{
	private final double HEIGHT_DECREASE;
	
	/**
	 * Constructs a ForwardArrow2ShapeRealizer to draw alternate arrow shapes with the passed arrow length and height decrease.
	 * @param arrowLength  The length of the arrow part to use.
	 * @param heightDecrease  A proportion of thickness of the straight part and arrow head part of the arrow (1.0 is no decrease).
	 * 							So controls difference between
	 * 							this (--->) and
	 * 							this(==>)
	 */
	public ForwardArrow2ShapeRealizer(double arrowLength, double heightDecrease)
	{
		super(arrowLength);
		HEIGHT_DECREASE = heightDecrease;
	}
	
	/**
	 * Constructs a ForwardArrow2ShapeRealizer to draw arrow shapes with the default settings
	 */
	public ForwardArrow2ShapeRealizer()
	{
		this(10, 0.7);
	}

	protected BackboneShape createArrowBlock(SlotPath path, int start, float center,
			int stop, double top, double bottom)
	{	
		double centerHeight = ((double)top + bottom)/2;

		path.moveTo(start, top*HEIGHT_DECREASE);
		path.lineTo(stop, top*HEIGHT_DECREASE, -ARROW_LENGTH, Direction.INCREASING); // (lineTo(pinned point, lengthFromPin, heightInSlot))
		path.realLineTo(stop, top, -ARROW_LENGTH);
		path.realLineTo(stop, centerHeight, 0);
		path.realLineTo(stop, bottom, -ARROW_LENGTH);
		path.realLineTo(stop, bottom*HEIGHT_DECREASE, -ARROW_LENGTH);
		path.lineTo(start, Direction.DECREASING);
		path.closePath();
		
		return path.getShape();
	}
	
	protected BackboneShape createArrowHead(SlotPath path, int start, float center, int stop, double top, double bottom)
	{
		double centerBase = ((double)start + stop)/2;
		
		double centerHeight = ((double)top + bottom)/2;
		
		path.moveTo(centerBase, top, -ARROW_LENGTH/2);
		path.realLineTo(centerBase, centerHeight, ARROW_LENGTH/2);
		path.realLineTo(centerBase, bottom, -ARROW_LENGTH/2);
		path.realLineTo(centerBase, top, -ARROW_LENGTH/2);
		path.closePath();
		
		return path.getShape();
	}
}
