package ca.corefacility.gview.layout;


import java.awt.Shape;

import ca.corefacility.gview.layout.sequence.SlotPath;

public class PlotDrawerSolid extends PlotDrawer
{
	boolean finishedInitialPoint = false;

	private int initialBase;

	private int prevBase;

	private final static double bottomHeight = -1;

	@Override
	public void drawPoint(int base, double heightInSlot, SlotPath slotPath)
	{
		if (!this.finishedInitialPoint)
		{
			slotPath.moveTo(base, heightInSlot);

			this.prevBase = base;
			this.initialBase = base;
			this.finishedInitialPoint = true;
		}
		else
		{
			slotPath.lineTo(base, heightInSlot, Direction.INCREASING);

			this.prevBase = base;
		}
	}

	@Override
	public Shape finishPlotPoint(SlotPath slotPath)
	{
		if (this.finishedInitialPoint)
		{
			slotPath.lineTo(this.prevBase, bottomHeight, Direction.NONE);
			slotPath.lineTo(this.initialBase, Direction.DECREASING);
			slotPath.closePath();
		}

		reset();

		return slotPath.getShape();
	}

	@Override
	public void reset()
	{
		this.finishedInitialPoint = false;
	}

	@Override
	public void drawRange(int startBase, int endBase, double heightInSlot,
			SlotPath slotPath)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public Shape[][] finishPlotRange(SlotPath slotPath)
	{
		// TODO Auto-generated method stub
		return null;
	}
}
