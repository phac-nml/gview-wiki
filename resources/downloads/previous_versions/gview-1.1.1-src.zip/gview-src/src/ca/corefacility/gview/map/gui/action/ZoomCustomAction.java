package ca.corefacility.gview.map.gui.action;

import ca.corefacility.gview.map.GViewMap;

public class ZoomCustomAction extends ZoomAction 
{
	private final GViewMap gViewMap;
	private final double value;
	
	public ZoomCustomAction(GViewMap gViewMap, double value)
	{
		super(gViewMap, gViewMap.getZoomFactor());
		
		this.gViewMap = gViewMap;
		this.value = value;
	}

	@Override
	public void run() 
	{
		gViewMap.setZoomFactor(value); 
	}
}
