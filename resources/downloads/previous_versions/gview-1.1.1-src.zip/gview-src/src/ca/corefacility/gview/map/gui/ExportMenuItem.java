package ca.corefacility.gview.map.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.action.ExportAction;

/**
 * Responsible for creating the Export menu item.
 * 
 * @author ericm
 *
 */
public class ExportMenuItem extends JMenuItem implements ActionListener
{
	private final GViewMap gViewMap;
	
	private static final long serialVersionUID = -4942134741338512388L;

	public ExportMenuItem(GViewGUIFrame frame)
	{
		super(GUIUtility.EXPORT_TEXT);
		
		this.gViewMap = frame.getGViewMap();
		
		this.setActionCommand(GUIUtility.EXPORT);
		this.setAccelerator(KeyStroke.getKeyStroke(GUIUtility.EXPORT_SHORTCUT));
		this.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(GUIUtility.EXPORT.equals(e.getActionCommand()))
		{
			ExportAction action = new ExportAction(gViewMap);
			action.run();
		}
	}
}
