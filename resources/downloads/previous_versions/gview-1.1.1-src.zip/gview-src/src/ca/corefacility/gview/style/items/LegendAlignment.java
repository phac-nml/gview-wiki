package ca.corefacility.gview.style.items;

public enum LegendAlignment
{
	UPPER_LEFT,
	UPPER_CENTER,
	UPPER_RIGHT,
	
	MIDDLE_LEFT,
	MIDDLE_CENTER,
	MIDDLE_RIGHT,
	
	LOWER_LEFT,
	LOWER_CENTER,
	LOWER_RIGHT,
}