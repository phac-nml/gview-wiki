package ca.corefacility.gview.map.gui.action;

import javax.swing.undo.CannotRedoException;

public abstract class ShowItemAction extends MapAction 
{
	@Override
	public void redo() throws CannotRedoException 
	{
		run();
	}
}
