package ca.corefacility.gview.map.inputHandler;

import ca.corefacility.gview.managers.DisplayManager;
import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;

public class LegendHandler
{
	private PCamera mainView;
	private DisplayManager displayManager;
	
	private boolean legendDisplayed = false;
	
	public LegendHandler(PCamera mainView)
	{
		this.mainView = mainView;
	}
	
	public void toggleLegend()
	{
		if (legendDisplayed)
		{
			// turn off legend
			setLegendDisplayed(false);
		}
		else
		{
			// turn on legend
			setLegendDisplayed(true);
		}
	}
	
	public void setLegendDisplayed(boolean display)
	{
		displayManager.setLegendDisplayed(display);
		
		if (display)
		{
			mainView.addChild((PNode)displayManager.getLegendLayer());
//			mainView.addLayer((PLayer)displayManager.getLegendLayer());
		}
		else
		{
			mainView.removeChild((PNode)displayManager.getLegendLayer());
//			mainView.removeLayer((PLayer)displayManager.getLegendLayer());
		}
		
		legendDisplayed = display;
	}

	public void setDisplayManager(DisplayManager displayManager)
	{
		this.displayManager = displayManager;
	}
}
