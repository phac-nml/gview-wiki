package ca.corefacility.gview.layout.feature;


import java.awt.Shape;
import java.util.Iterator;

import org.biojava.bio.symbol.Location;

import ca.corefacility.gview.layout.Direction;
import ca.corefacility.gview.layout.prototype.BackboneShape;
import ca.corefacility.gview.layout.prototype.CompositeShape;
import ca.corefacility.gview.layout.sequence.SlotPath;

/**
 * FeatureShapeRealizer used to draw an arrow which looks like
 * 
 * <===
 * 
 * @author Aaron Petkau
 *
 */
public class ReverseArrowShapeRealizer extends AbstractArrowShapeRealizer
{
	/**
	 * Constructs a ReverseArrowShapeRealizer to draw arrow shapes with the passed arrow length.
	 * @param arrowLength  The length of the arrow part to use.
	 */
	public ReverseArrowShapeRealizer(double arrowLength)
	{
		super(arrowLength);
	}
	
	/**
	 * Constructs a ReverseArrowShapeRealizer to draw arrow shapes with the default arrow lenth.
	 */
	public ReverseArrowShapeRealizer()
	{
		super();
	}
	
	@SuppressWarnings("unchecked")
	protected Shape realizeFeatureShape(SlotPath path, Location location,
			double top, double bottom, int sequenceLength)
	{
		BackboneShape shape;
		boolean pointLocation = false;
		
		if (!location.isContiguous())
		{
			Iterator blocks = location.blockIterator();
			while (blocks.hasNext())
			{
				Location block = (Location)blocks.next();
				int start = extractStart(block);
				int stop = extractStop(block);
				float centerBase = findCenterBase(start, stop, sequenceLength);
				
				if (start != stop)
				{
					// if we are at the last block
					if (!blocks.hasNext())
					{
						this.createArrowBlock(path, start, centerBase, stop, top, bottom);
					}
					else
					{
						createStandardBlock(path, start, stop, top, bottom);
					}
				}
				// TODO: how to draw a single point block?
			}
		}
		else
		{
			int start = extractStart(location);
			int stop = extractStop(location);
			float centerBase = findCenterBase(start, stop, sequenceLength);
			
			if (start != stop)
			{
				createArrowBlock(path, start, centerBase, stop, top, bottom);
			}
			else
			{
				pointLocation = true;
				this.createArrowHead(path, start, centerBase, stop, top, bottom);
			}
		}
		
		shape = path.getShape();
		
		if (!pointLocation)
		{
			path.clear();
			float centerBase = findCenterBase(location.getMin(), location.getMax(), sequenceLength);

			int locationLength = extractMinMaxLength(location,sequenceLength);
			createArrowHead(path, location.getMin(), centerBase, location.getMax(), top, bottom);
			shape = new CompositeShape(path.getShape(), shape, path.getBackbone().findZoomForLength(locationLength,
					ARROW_LENGTH), path.getBackbone().getScale());
		}
		
		return shape;
	}
	
	protected BackboneShape createArrowBlock(SlotPath path, int start, float center, int stop, double top, double bottom)
	{
		double centerHeight = ((double)top + bottom)/2;
		
		path.moveTo(start, centerHeight);
		path.realLineTo(start, top, ARROW_LENGTH); // (lineTo(pinned point, lengthFromPin, heightInSlot))
		path.lineTo(stop, Direction.INCREASING);
		path.lineTo(stop, bottom, Direction.NONE);
		path.lineTo(start, bottom, ARROW_LENGTH, Direction.DECREASING);
		path.realLineTo(start, centerHeight, 0);
		path.closePath();
		
		return path.getShape();
	}
	
	protected BackboneShape createArrowHead(SlotPath path, int start, float center, int stop, double top, double bottom)
	{
		double centerBase = center;
		
		double centerHeight = ((double)top + bottom)/2;
		
		path.moveTo(centerBase, centerHeight, -ARROW_LENGTH/2);
		path.realLineTo(centerBase, top, ARROW_LENGTH/2);
		path.realLineTo(centerBase, bottom, ARROW_LENGTH/2);
		path.realLineTo(centerBase, centerHeight, -ARROW_LENGTH/2);
		path.closePath();
		
		return path.getShape();
	}
}
