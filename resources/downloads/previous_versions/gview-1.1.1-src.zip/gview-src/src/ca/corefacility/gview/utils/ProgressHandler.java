package ca.corefacility.gview.utils;

import ca.corefacility.gview.main.SplashScreen;

/**
 * Responsible for watching the loading progress of the program and displaying the appropriate information.
 * 
 * Each stage is given equal loading bar 'size'.
 * 
 * @author ericm
 *
 */
public class ProgressHandler 
{
	public static final String CREATING_LAYOUT = "Creating Layout";
	public static final String BUILDING_FEATURES = "Building Features";
	public static final String POSITIONING_LABELS = "Positioning Labels";
	public static final String CALCULATING_GC_CONTENT = "Calculating GC Content";
	public static final String CALCULATING_GC_SKEW = "Calculating GC Skew";
	public static final String CREATING_PLOTS = "Creating Plots";
	
	public static final String NONE = "None";	//default stage; used as an intermediate stage
	
	private static final String[] stages = {CREATING_LAYOUT, BUILDING_FEATURES, POSITIONING_LABELS, CREATING_PLOTS};
	
	private static SplashScreen splashScreen = null;
	private static String current = NONE;
	
	/**
	 * Initialize without a splash screen. 
	 */
	public static void initialize()
	{
		splashScreen = null;
		current = NONE;
	}
	
	/**
	 * Initialize with a splash screen. 
	 */
	public static void initialize(SplashScreen splash)
	{
		splashScreen = splash;	
		current = NONE;
	}
	
	/**
	 * Starts the passed stage. Checks to see if it is a valid stage.
	 * 
	 * @param stage The stage to start.
	 * 
	 */
	public static void start(String stage)
	{
		if(stage == null)
			throw new IllegalArgumentException("stage is null");
		
		if(current.equals(NONE))
		{
			//good..
			
			//Check for a valid stage:
			for(int i = 0; i < stages.length; i++)
			{
				if(stage.equals(stages[i]))
				{
					current = stages[i];
					
					if(splashScreen != null)
						splashScreen.setMessage(current);

					System.out.print(stages[i] + "...");
				}
			}
		}
		else
		{
			//bad..
		}
	}
	
	/**
	 * Finishes the passed stage. Checks to see if it is a valid stage.
	 * 
	 * @param stage The stage to start.
	 * 
	 */
	public static void finish(String stage)
	{
		int progress = 0;
		
		if(stage == null)
			throw new IllegalArgumentException("stage is null");
		
		//Finishing the current state?
		if(stage.equals(current))
		{
			//Find stage
			for(int i = 0; i < stages.length; i++)
			{
				if(stage.equals(stages[i]))
				{
					current = NONE;
					
					progress = (int) ((i + 1) * 100/stages.length);
					
					if(splashScreen != null)
						splashScreen.setProgress(progress);
					
					System.out.println(" done");
				}
			}			
		}
	}
	
	/**
	 * Displays the passed message.
	 * 
	 * @param message The message to display.
	 */
	public static void setMessage(String message)
	{
		if(splashScreen != null)
			splashScreen.setMessage(message);

		System.out.print(message);
	}
	
	/**
	 *  
	 * @return The progress handler's current stage.
	 */
	public static String getStage()
	{
		return current;
	}

}
