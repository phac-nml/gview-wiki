package ca.corefacility.gview.map.gui.action;

import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.ElementControl;

public class HideLegendAction extends HideItemAction 
{
	private final ElementControl control;
	
	public HideLegendAction(ElementControl control)
	{
		this.control = control;
	}

	@Override
	public void undo() throws CannotUndoException 
	{
		control.setLegendDisplayed(true);
	}

	@Override
	public void run() 
	{
		control.setLegendDisplayed(false);
	}

}
