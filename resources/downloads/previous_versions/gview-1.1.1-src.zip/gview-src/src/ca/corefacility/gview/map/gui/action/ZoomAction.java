package ca.corefacility.gview.map.gui.action;

import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.GViewMap;

public abstract class ZoomAction extends MapAction 
{
	private final GViewMap gViewMap;
	private final double previous;
	
	public ZoomAction(GViewMap gViewMap, double previous)
	{
		this.gViewMap = gViewMap;
		this.previous = previous;
	}
	
	@Override
	public void undo() throws CannotUndoException 
	{
		gViewMap.setZoomFactor(previous); 
	}
	
	@Override
	public void redo() throws CannotRedoException 
	{
		run();
	}
}
