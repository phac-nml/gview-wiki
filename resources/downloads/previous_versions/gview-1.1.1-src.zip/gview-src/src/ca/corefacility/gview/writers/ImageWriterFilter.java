package ca.corefacility.gview.writers;

import java.io.File;

import javax.swing.filechooser.FileFilter;

public class ImageWriterFilter extends FileFilter
{
	@Override
	public boolean accept(File f)
	{
		if (f.isDirectory())
		{
			return true;
		}
		
		String extension = extractExtension(f);
		if (extension != null)
		{
			if (extension.equals("jpg") ||
					extension.equals("jpeg") ||
					extension.equals("png") ||
					extension.equals("svg") ||
					extension.equals("svgz"))
			{
				return true;
			}
		}
		
		return false;
	}

	@Override
	public String getDescription()
	{
		return "Images (*.jpg, *.png, *.svg, *.svgz)";
	}
	
	public static String extractExtension(File file)
	{
		return extractExtension(file.getName());
	}
	
	public static String extractExtension(String filename)
	{
		String extension = null;

		if (filename != null)
		{
			int periodIndex = filename.lastIndexOf('.');

			// if period is found, and it is not the last character
			if ((periodIndex != -1) && (periodIndex + 1) < filename.length())
			{
				extension = filename.substring(periodIndex + 1);
			}
		}

		return extension;
	}
}
