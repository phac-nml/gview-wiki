package ca.corefacility.gview.map.gui.action;

public abstract class MoveAction extends MapAction {

}
