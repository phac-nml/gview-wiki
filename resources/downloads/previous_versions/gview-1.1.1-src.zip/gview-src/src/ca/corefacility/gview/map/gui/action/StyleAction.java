package ca.corefacility.gview.map.gui.action;

public abstract class StyleAction extends Action {

}
