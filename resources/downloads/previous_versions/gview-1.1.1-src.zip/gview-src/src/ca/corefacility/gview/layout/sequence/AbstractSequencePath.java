package ca.corefacility.gview.layout.sequence;

import java.awt.Stroke;

import ca.corefacility.gview.layout.prototype.BackboneShape;
import ca.corefacility.gview.layout.prototype.SequenceOffset;
import ca.corefacility.gview.layout.prototype.SequencePoint;
import ca.corefacility.gview.layout.prototype.SequencePointImp;
import ca.corefacility.gview.layout.prototype.StretchableShape;
import ca.corefacility.gview.layout.prototype.StrokedBackboneShape;
import ca.corefacility.gview.layout.prototype.segments.LineSegment;
import ca.corefacility.gview.layout.prototype.segments.MoveSegment;


public abstract class AbstractSequencePath implements SequencePath
{
	// should these be protected?
	protected StretchableShape shape;

	protected Backbone backbone;

	protected SequencePoint prevSequencePoint;

	// TODO see if I need this here (maybe only in circular)
	// protected Point2D prevPoint; // stores previous point added

	/**
	 * Creates a new SequencePath around the passed data.
	 * 
	 * @param backbone
	 *            The backbone of the sequence.
	 * 
	 */
	protected AbstractSequencePath(Backbone backbone)
	{
		if (backbone == null)
		{
			throw new IllegalArgumentException("backbone is null");
		}
		else
		{
			this.backbone = backbone;

			prevSequencePoint = new SequencePointImp();
		}
	}

	public BackboneShape getShape()
	{
		return shape;
	}

	public void moveTo(double base, double heightFromBackbone)
	{
		// TODO not sure how to deal with center
		SequencePointImp movePoint = new SequencePointImp(base, heightFromBackbone);

		shape.appendSegment(new MoveSegment(movePoint));

		prevSequencePoint = movePoint;
	}

	public void moveTo(double base, double heightFromBackbone, double lengthFromBase)
	{
		SequencePoint offsetPoint = new SequenceOffset(base, heightFromBackbone, lengthFromBase);

		shape.appendSegment(new MoveSegment(offsetPoint));

		prevSequencePoint = offsetPoint;
	}

	public void realLineTo(double base, double heightFromBackbone, double lengthFromBase)
	{
		SequenceOffset offsetPoint;

		offsetPoint = new SequenceOffset(base, heightFromBackbone, lengthFromBase);

		shape.appendSegment(new LineSegment(offsetPoint));

		prevSequencePoint = offsetPoint;
	}

	public Backbone getBackbone()
	{
		return backbone;
	}

	@Override
	public BackboneShape createStrokedShape(Stroke s)
	{
		return new StrokedBackboneShape(s, shape, backbone);
	}

	public void clear()
	{
		prevSequencePoint = new SequencePointImp();
	}
}
