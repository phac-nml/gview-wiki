package ca.corefacility.gview.map.gui.action;

import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.GViewMap;

public class MoveStartAction extends MoveAction {

	private final GViewMap gViewMap;

	public MoveStartAction(GViewMap gViewMap)
	{
		this.gViewMap = gViewMap;
	}
	
	@Override
	public void undo() throws CannotUndoException {
		// TODO Auto-generated method stub

	}

	@Override
	public void redo() throws CannotRedoException {
		// TODO Auto-generated method stub

	}

	@Override
	public void run() 
	{
		gViewMap.setCenter(0);
	}

}
