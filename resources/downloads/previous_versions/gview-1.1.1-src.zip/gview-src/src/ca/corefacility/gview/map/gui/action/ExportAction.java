package ca.corefacility.gview.map.gui.action;

import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.inputHandler.ImageExportHandler;

public class ExportAction extends MapAction {

	GViewMap gViewMap;
	
	public ExportAction(GViewMap gViewMap)
	{
		this.gViewMap = gViewMap;
	}
	
	@Override
	public void undo() throws CannotUndoException 
	{
		throw new CannotUndoException();
	}

	@Override
	public void redo() throws CannotRedoException 
	{
		throw new CannotRedoException();
	}

	@Override
	public void run() 
	{
		ImageExportHandler.getInstance().performExport(gViewMap);
	}
	
	@Override
	public boolean canUndo() 
	{
		return false;
	}
	
	@Override
	public boolean canRedo() 
	{
		return false;
	}

}
