package ca.corefacility.gview.map.gui.action;

import javax.swing.JDialog;
import javax.swing.undo.CannotRedoException;
import javax.swing.undo.CannotUndoException;

public abstract class ShowDialogAction extends Action 
{
	private JDialog dialog;
	
	ShowDialogAction(JDialog dialog)
	{
		this.dialog = dialog;
	}
	
	@Override
	public void undo() throws CannotUndoException 
	{
		dialog.setVisible(false);
	}

	@Override
	public void redo() throws CannotRedoException 
	{
		dialog.setVisible(true);
	}

	@Override
	public void run() 
	{
		dialog.setVisible(true);
	}
}
