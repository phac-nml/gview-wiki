package ca.corefacility.gview.map.gui;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.KeyStroke;

import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.FullScreenAction;
import ca.corefacility.gview.map.gui.action.ResizeScreenAction;

/**
 * Responsible for creating the "Full Screen" menu item.
 * 
 * @author ericm
 *
 */
public class FullScreenMenuItem extends JCheckBoxMenuItem implements ItemListener
{
	private static final long serialVersionUID = -3338771370336483719L;
	
	private final GViewGUIFrame frame;
	
	/**
	 * Creates a new menu item for Full Screen within the specified frame.
	 * 
	 * @param frame The frame the full screen menu item will send its message to.
	 */
	public FullScreenMenuItem(GViewGUIFrame frame)
	{
		super(GUIUtility.FULL_SCREEN);
		
		this.frame = frame;
		
		this.setActionCommand(GUIUtility.FULL_SCREEN);
		this.setAccelerator(KeyStroke.getKeyStroke(GUIUtility.FULL_SCREEN_SHORTCUT));
		this.addItemListener(this);
	}
	
	/**
	 * Updates the check mark.
	 */
	public void update()
	{
		if(frame.getExtendedState() == JFrame.MAXIMIZED_BOTH)
			this.setSelected(true);
		else
			this.setSelected(false);
	}

	@Override
	/**
	 * Listens for "Full Screen" (checkable) menu item(s).
	 */
	public void itemStateChanged(ItemEvent e)
	{
		Action action;
		
		if (e.getStateChange() == ItemEvent.SELECTED)
		{
			action = new FullScreenAction(frame);
			action.run();
		}
		else if (e.getStateChange() == ItemEvent.DESELECTED)
		{
			action = new ResizeScreenAction(frame);
			action.run();
		}
	}
}
