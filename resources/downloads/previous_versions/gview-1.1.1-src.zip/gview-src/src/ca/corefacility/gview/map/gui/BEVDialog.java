package ca.corefacility.gview.map.gui;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JSlider;
import javax.swing.JToolBar;

import ca.corefacility.gview.map.BirdsEyeViewImp;
import ca.corefacility.gview.map.GViewMap;

/**
 * The bird's eye view dialog box.
 * 
 * @author ericm
 *
 */
public class BEVDialog extends JDialog
{
	private static final long serialVersionUID = 1L;
	
	private final String magnifierPlusPath = "images/icons/magnifier--plus.png";
	private final String magnifierMinusPath = "images/icons/magnifier--minus.png";
	
	private final BirdsEyeViewImp BEV;
	
	private final JSlider slider;
	private final JButton plusButton;
	private final JButton minusButton;
	
	private final BEVDialogListener bevDialogListener;
	
	/**
	 * Creates a new BEVDialog with the passed map/BEVMenuItem.
	 * @param gViewMap The GViewMap it will be working with.
	 * @param BEVItem The Bird's Eye View menu item the dialog relates to. Required for unchecking on dialog close.
	 */
	public BEVDialog(GViewMap gViewMap, BEVMenuItem BEVItem)
	{
		super();
		
		this.setTitle(GUIUtility.BEV_TEXT);
		
		this.BEV = new BirdsEyeViewImp();
		this.BEV.connect(gViewMap);			
		
		this.slider = new JSlider((int)GUIUtility.SCALE_SLIDER_MIN, (int)GUIUtility.SCALE_SLIDER_MAX);
		this.slider.setValue(GUIUtility.convertScaleToSlider(gViewMap.getZoomNormalFactor()));
		
		this.plusButton = new JButton(new ImageIcon(GUIUtility.loadImage(magnifierPlusPath)));		
		this.minusButton = new JButton(new ImageIcon(GUIUtility.loadImage(magnifierMinusPath)));
		
		this.bevDialogListener = new BEVDialogListener(gViewMap, BEV, BEVItem, slider);
		
		this.addWindowListener(this.bevDialogListener);				
		this.addComponentListener(this.bevDialogListener);	
		this.setSize(300, 300);
		
		//The BEVDialogListener must listen to the GViewMap for ZoomEvents to update the slider.
		gViewMap.addEventListener(this.bevDialogListener);		
		
		//Create the content of the dialog.
		create(this.getContentPane());
		
		this.setVisible(false);		
	}
	
	/**
	 * Creates the content of the BEVDialog.
	 * 
	 * @param contentPane the pane the dialog will be created on.
	 */
	private void create(Container contentPane)
	{
		JToolBar toolBar = new JToolBar();
		
		toolBar.setFloatable(false);
		toolBar.setLayout(new BoxLayout(toolBar, BoxLayout.X_AXIS));
		
		contentPane.setLayout(new BorderLayout());
		contentPane.add((JComponent)BEV, BorderLayout.CENTER);
		
		contentPane.add(toolBar, BorderLayout.SOUTH);
		
		this.minusButton.setActionCommand(GUIUtility.SCALE_OUT);
		this.minusButton.setToolTipText(GUIUtility.SCALE_OUT);
		this.minusButton.addActionListener(this.bevDialogListener);
		toolBar.add(minusButton);	
		
		slider.addChangeListener(this.bevDialogListener);
		toolBar.add(slider);
		
		this.plusButton.setActionCommand(GUIUtility.SCALE_IN);
		this.plusButton.setToolTipText(GUIUtility.SCALE_IN);
		this.plusButton.addActionListener(this.bevDialogListener);
		toolBar.add(plusButton);
	}
}
