package ca.corefacility.gview.map.gui;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBoxMenuItem;

import ca.corefacility.gview.map.ElementControl;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.HideLabelsAction;
import ca.corefacility.gview.map.gui.action.ShowLabelsAction;

/**
 * Responsible for creating and managing the "Show Labels" menu item.
 * 
 * @author ericm
 *
 */
public class ShowLabelsMenuItem extends JCheckBoxMenuItem implements ItemListener
{
	private static final long serialVersionUID = -7757221658484529616L;
	
	private final GViewMap gViewMap;
	
	private final ElementControl control;
	
	/**
	 * Creates a new ShowLabelsMenuItem within the specified frame.
	 * @param frame The frame the ShowLabels menu item is applies to.
	 */
	public ShowLabelsMenuItem(GViewGUIFrame frame)
	{
		super(GUIUtility.SHOW_LABELS_TEXT);
		
		this.gViewMap = frame.getGViewMap();
		
		this.addItemListener(this);
		
		this.control = (this.gViewMap).getElementControl();
		
		this.setSelected(true);
	}

	@Override
	/**
	 * Listens for the menu item.
	 */
	public void itemStateChanged(ItemEvent e)
	{
		Action action;
		
		if (e.getStateChange() == ItemEvent.SELECTED)
		{
			action = new ShowLabelsAction(control);
			action.run();
		}
		else if (e.getStateChange() == ItemEvent.DESELECTED)
		{
			action = new HideLabelsAction(control);
			action.run();
		}
	}
	
	/**
	 * Updates the selected state of the menu item.
	 */
	public void update()
	{
		if(control.getLabelsDisplayed())
		{
			this.setSelected(true);
		}
		else
		{
			this.setSelected(false);
		}			
	}
	
}
