package ca.corefacility.gview.map.gui.action;

import javax.swing.undo.CannotUndoException;

import ca.corefacility.gview.map.ElementControl;

public class ShowLegendAction extends ShowItemAction 
{
	private final ElementControl control;
	
	public ShowLegendAction(ElementControl control)
	{
		this.control = control;
	}

	@Override
	public void undo() throws CannotUndoException 
	{
		control.setLegendDisplayed(false);
	}

	@Override
	public void run() 
	{
		control.setLegendDisplayed(true);
	}

}
