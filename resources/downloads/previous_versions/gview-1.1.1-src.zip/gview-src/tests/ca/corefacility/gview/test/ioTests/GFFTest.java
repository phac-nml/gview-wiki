package ca.corefacility.gview.test.ioTests;

import static org.junit.Assert.*;

import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;

import org.biojava.bio.Annotation;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FramedFeature;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.readers.GFF3Reader;
import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.GViewFileData;

public class GFFTest
{
	private GFF3Reader gffReader;
	
	@Before
	public void setup()
	{
		gffReader = new GFF3Reader();
	}
	
	@Test
	public void testFeatureAttributes() throws IOException, GViewDataParseException
	{
		StringReader gffString;
		GViewFileData gFileData = null;
		GenomeData genomeData = null;
		Sequence seq;
		
		// positive
		gffString = new StringReader(
				"##gff-version 3\n" +
				"seqname\tsource\tfType\t1\t2000\t.\t+\t.\tid=the_id ;\t id2= the_id2"
				);
		
		gFileData = gffReader.read(gffString);
		assertNotNull(gFileData.getGenomeData());
		genomeData = gFileData.getGenomeData();
		// get feature
		seq = genomeData.getSequence();
		assertEquals(2000, seq.length());
		
		Iterator<Feature> features = seq.features();
		assertTrue(features.hasNext());
		
		Feature f = features.next();
		Annotation a = f.getAnnotation();
		assertNotNull(a);
		
		Object attProp = a.getProperty("id");
		assertNotNull(attProp);
		assertEquals(String.class, attProp.getClass());
		String attStr = (String)attProp;
		assertEquals("the_id", attProp);
		
		attProp = a.getProperty("id2");
		assertNotNull(attProp);
		assertEquals(String.class, attProp.getClass());
		attStr = (String)attProp;
		assertEquals("the_id2", attProp);
		
		assertFalse(features.hasNext());
	}
	
	// TODO
	// how to handle the score of features?
	@Test
	public void testFeatureScore() throws IOException, GViewDataParseException
	{
		StringReader gffString;
		GViewFileData gFileData = null;
		GenomeData genomeData = null;
		Sequence seq;
		
		// positive
		gffString = new StringReader(
				"##gff-version 3\n" +
				"seqname\tsource\tfType\t1\t2000\t10.5\t+\t.\t"
				);
		
		gFileData = gffReader.read(gffString);
		assertNotNull(gFileData.getGenomeData());
		genomeData = gFileData.getGenomeData();
		// get feature
		seq = genomeData.getSequence();
		assertEquals(2000, seq.length());
		
		Iterator<Feature> features = seq.features();
		assertTrue(features.hasNext());
		
		Feature f = features.next();
		Annotation a = f.getAnnotation();
		assertNotNull(a);
		
		Object scoreProp = a.getProperty("Score");
		assertNotNull(scoreProp);
		assertEquals(String.class, scoreProp.getClass());
		String scoreStr = (String)scoreProp;
		assertEquals("10.5", scoreStr);
		
		assertFalse(features.hasNext());
	}
	
	// TODO
	// modify GView later to properly handle multiple sequences
	@Test
	public void testSeqName() throws IOException, GViewDataParseException
	{
		StringReader gffString;
		GViewFileData gFileData = null;
		GenomeData genomeData = null;
		Sequence seq;
		
		// positive
		gffString = new StringReader(
				"##gff-version 3\n" +
				"seqname\tsource\tfType\t1\t2000\t.\t+\t.\t"
				);
		
		gFileData = gffReader.read(gffString);
		assertNotNull(gFileData.getGenomeData());
		genomeData = gFileData.getGenomeData();
		// get feature
		seq = genomeData.getSequence();
		assertEquals(2000, seq.length());
		
		Iterator<Feature> features = seq.features();
		assertTrue(features.hasNext());
		
		Feature f = features.next();
		Annotation a = f.getAnnotation();
		assertNotNull(a);
		
		Object nameProp = a.getProperty("SequenceName");
		assertNotNull(nameProp);
		assertEquals(String.class, nameProp.getClass());
		String nameStr = (String)nameProp;
		assertEquals("seqname", nameStr);
		
		assertFalse(features.hasNext());
	}
	
	@Test
	public void testFeatureLocation() throws IOException, GViewDataParseException
	{
		StringReader gffString;
		GViewFileData gFileData = null;
		GenomeData genomeData = null;
		Sequence seq;
		
		// positive
		gffString = new StringReader(
				"##gff-version 3\n" +
				"seqname\tsource\tfType\t1\t2000\t.\t+\t.\t"
				);
		
		gFileData = gffReader.read(gffString);
		assertNotNull(gFileData.getGenomeData());
		genomeData = gFileData.getGenomeData();
		// get feature
		seq = genomeData.getSequence();
		assertEquals(2000, seq.length());
		
		Iterator<Feature> features = seq.features();
		assertTrue(features.hasNext());
		
		Feature f = features.next();
		assertEquals(1, f.getLocation().getMin());
		assertEquals(2000, f.getLocation().getMax());
		
		assertFalse(features.hasNext());
		
		
		
		// positive
		gffString = new StringReader(
				"##gff-version 3\n" +
				"seqname\tsource\tfType\t10\t15\t.\t+\t.\t"
				);
		
		gFileData = gffReader.read(gffString);
		assertNotNull(gFileData.getGenomeData());
		genomeData = gFileData.getGenomeData();
		// get feature
		seq = genomeData.getSequence();
		assertEquals(15, seq.length());
		
		features = seq.features();
		assertTrue(features.hasNext());
		
		f = features.next();
		assertEquals(10, f.getLocation().getMin());
		assertEquals(15, f.getLocation().getMax());
		
		assertFalse(features.hasNext());
	}
	
	@Test
	public void testFeatureType() throws IOException, GViewDataParseException
	{
		StringReader gffString;
		GViewFileData gFileData = null;
		GenomeData genomeData = null;
		Sequence seq;
		
		// positive
		gffString = new StringReader(
				"##gff-version 3\n" +
				"seqname\tsource\tfType\t1\t2000\t.\t+\t.\t"
				);
		
		gFileData = gffReader.read(gffString);
		assertNotNull(gFileData.getGenomeData());
		genomeData = gFileData.getGenomeData();
		// get feature
		seq = genomeData.getSequence();
		assertEquals(2000, seq.length());
		
		Iterator<Feature> features = seq.features();
		assertTrue(features.hasNext());
		
		Feature f = features.next();
		assertEquals("fType", f.getType());
		
		assertFalse(features.hasNext());
	}

	@Test
	public void testPositiveStrandedFeature() throws IOException, GViewDataParseException
	{
		StringReader gffString;
		GViewFileData gFileData = null;
		GenomeData genomeData = null;
		Sequence seq;
		
		// positive
		gffString = new StringReader(
				"##gff-version 3\n" +
				"seqname\tsource\ttype\t1\t2000\t.\t+\t.\t"
				);
		
		gFileData = gffReader.read(gffString);
		assertNotNull(gFileData.getGenomeData());
		genomeData = gFileData.getGenomeData();
		// get feature
		seq = genomeData.getSequence();
		assertEquals(2000, seq.length());
		
		Iterator<Feature> features = seq.features();
		assertTrue(features.hasNext());
		
		Feature f = features.next();
		assertTrue(f instanceof StrandedFeature);
		StrandedFeature s = (StrandedFeature)f;
		assertEquals(StrandedFeature.POSITIVE, s.getStrand());
		
		assertFalse(features.hasNext());
	}
	
	@Test
	public void testNegativeStrandedFeature() throws IOException, GViewDataParseException
	{
		StringReader gffString;
		GViewFileData gFileData = null;
		GenomeData genomeData = null;
		Sequence seq;
		
		gffString = new StringReader(
				"##gff-version 3\n" +
				"seqname\tsource\ttype\t1\t2000\t.\t-\t.\t"
				);
		
		gFileData = gffReader.read(gffString);
		assertNotNull(gFileData.getGenomeData());
		genomeData = gFileData.getGenomeData();
		// get feature
		seq = genomeData.getSequence();
		assertEquals(2000, seq.length());
		
		Iterator<Feature> features = seq.features();
		assertTrue(features.hasNext());
		
		Feature f = features.next();
		assertTrue(f instanceof StrandedFeature);
		StrandedFeature s = (StrandedFeature)f;
		assertEquals(StrandedFeature.NEGATIVE, s.getStrand());
		
		assertFalse(features.hasNext());
	}
	
	@Test
	public void testUnknownStrandedFeature() throws IOException, GViewDataParseException
	{
		StringReader gffString;
		GViewFileData gFileData = null;
		GenomeData genomeData = null;
		Sequence seq;
		
		gffString = new StringReader(
				"##gff-version 3\n" +
				"seqname\tsource\ttype\t1\t2000\t.\t.\t.\t"
				);
		
		gFileData = gffReader.read(gffString);
		assertNotNull(gFileData.getGenomeData());
		genomeData = gFileData.getGenomeData();
		// get feature
		seq = genomeData.getSequence();
		assertEquals(2000, seq.length());
		
		Iterator<Feature> features = seq.features();
		assertTrue(features.hasNext());
		
		Feature f = features.next();
		assertTrue(f instanceof StrandedFeature);
		StrandedFeature s = (StrandedFeature)f;
		assertEquals(StrandedFeature.UNKNOWN, s.getStrand());
		
		assertFalse(features.hasNext());
	}
}
