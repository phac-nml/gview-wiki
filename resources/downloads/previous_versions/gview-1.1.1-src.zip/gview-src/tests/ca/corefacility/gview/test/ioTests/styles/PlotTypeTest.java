package ca.corefacility.gview.test.ioTests.styles;


import java.awt.BasicStroke;
import java.io.IOException;
import java.io.StringReader;

import org.junit.Assert;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.layout.PlotDrawer;
import ca.corefacility.gview.layout.PlotDrawerBar;
import ca.corefacility.gview.layout.PlotDrawerLine;
import ca.corefacility.gview.style.io.gss.PlotTypeHandler;
import ca.corefacility.gview.style.io.gss.exceptions.UnknownPlotTypeException;

public class PlotTypeTest
{	
	@Test(expected=UnknownPlotTypeException.class)
	public void unknownType() throws CSSException, IOException, UnknownPlotTypeException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("unknown")));
		PlotTypeHandler.decode(currUnit);
	}
	
	@Test
	public void testDecodePlotType() throws CSSException, IOException, CloneNotSupportedException, UnknownPlotTypeException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		PlotDrawer expectedDrawer;
		PlotDrawer actualDrawer;
		
		LexicalUnit currUnit;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("line")));
		
		// setup expected style
		expectedDrawer = new PlotDrawerLine(new BasicStroke(0.5f));
		
		actualDrawer = PlotTypeHandler.decode(currUnit);
		
		Assert.assertEquals(expectedDrawer, actualDrawer);
		
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("bar")));
		
		// setup expected style
		expectedDrawer = new PlotDrawerBar();
		
		actualDrawer = PlotTypeHandler.decode(currUnit);
		
		Assert.assertEquals(expectedDrawer, actualDrawer);
	}
}
