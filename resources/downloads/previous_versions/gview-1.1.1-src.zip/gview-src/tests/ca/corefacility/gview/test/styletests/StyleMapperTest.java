package ca.corefacility.gview.test.styletests;

import static org.junit.Assert.*;

import java.awt.Color;

import org.biojava.bio.BioException;
import org.biojava.bio.SimpleAnnotation;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.impl.SimpleSequenceFactory;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.bio.symbol.SymbolList;
import org.biojava.utils.ChangeVetoException;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.Slot;
import ca.corefacility.gview.map.items.FeatureItem;
import ca.corefacility.gview.map.items.FeatureItemImp;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.datastyle.mapper.ContinuousStyleMapper;
import ca.corefacility.gview.style.datastyle.mapper.DiscretePaintMapper;
import ca.corefacility.gview.style.datastyle.mapper.DiscreteStyleMapper;
import ca.corefacility.gview.style.datastyle.mapper.OpacityFeatureStyleMapper;

public class StyleMapperTest
{
	private final float delta = 0.00001f;
	
	private MapStyle mapStyle;
	private FeatureHolderStyle featureHolderStyle;
	
	@Before
	public void setup()
	{
		mapStyle = new MapStyle();
		DataStyle dataStyle = mapStyle.getDataStyle();
		SlotStyle slotStyle = dataStyle.createSlotStyle(Slot.FIRST_UPPER);
		featureHolderStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.all);
	}
	
	private Feature buildFeatureNoAnnotation() throws ChangeVetoException, BioException
	{
		SymbolList blankList = new BlankSymbolList(100);
		SimpleSequenceFactory seqFactory = new SimpleSequenceFactory();
		Sequence blankSequence = seqFactory.createSequence(blankList, null, null, null);

		
		Feature.Template basic = new Feature.Template();
		basic.location = new RangeLocation(1,9);
		basic.annotation = null;
		
		
		return blankSequence.createFeature(basic);
	}
	
	@Test
	public void continuousOpacityStyleTest() throws ChangeVetoException, BioException
	{
		Feature f;
		FeatureItemImp item;
		
		ContinuousStyleMapper mapper = new OpacityFeatureStyleMapper();
				
		f = buildFeatureNoAnnotation();
		item = new FeatureItemImp(featureHolderStyle, f);

		mapper.mapValueToStyle(0.0f, item);
		assertEquals(0.0f, item.getTransparency(), delta);
		
		
		mapper.mapValueToStyle(0.5f, item);
		assertEquals(0.5f, item.getTransparency(), delta);
		
		
		mapper.mapValueToStyle(1.0f, item);
		assertEquals(1.0f, item.getTransparency(), delta);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void continuousOpacityStyleTestOutOfRange() throws ChangeVetoException, BioException
	{
		Feature f;
		FeatureItemImp item;
		
		ContinuousStyleMapper mapper = new OpacityFeatureStyleMapper();
				
		f = buildFeatureNoAnnotation();
		item = new FeatureItemImp(featureHolderStyle, f);
		
		mapper.mapValueToStyle(1.1f, item);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void continuousOpacityStyleTestOutOfRange2() throws ChangeVetoException, BioException
	{
		Feature f;
		FeatureItemImp item;
		
		ContinuousStyleMapper mapper = new OpacityFeatureStyleMapper();
				
		f = buildFeatureNoAnnotation();
		item = new FeatureItemImp(featureHolderStyle, f);
		
		mapper.mapValueToStyle(-1.0f, item);
		assertEquals(1.0f, item.getTransparency(), delta);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void discreteColorMapperTestOutOfBounds() throws ChangeVetoException, BioException
	{
		Feature f;
		FeatureItem item;
		
		DiscreteStyleMapper mapper;
		
		mapper = new DiscretePaintMapper(new Color[]{Color.BLUE});
		
		f = buildFeatureNoAnnotation();
		item = new FeatureItemImp(featureHolderStyle, f);

		mapper.mapValueToStyle(-1, item);
	}
	
	@Test(expected=IndexOutOfBoundsException.class)
	public void discreteColorMapperTestOutOfBounds2() throws ChangeVetoException, BioException
	{
		Feature f;
		FeatureItem item;
		
		DiscreteStyleMapper mapper;
		
		mapper = new DiscretePaintMapper(new Color[]{Color.BLUE});
		
		f = buildFeatureNoAnnotation();
		item = new FeatureItemImp(featureHolderStyle, f);

		mapper.mapValueToStyle(1, item);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void discreteColorMapperTestNull()
	{
		new DiscretePaintMapper(new Color[]{null});
	}
	
	@Test
	public void discreteColorMapperTest() throws ChangeVetoException, BioException
	{
		Feature f;
		FeatureItem item;
		
		DiscreteStyleMapper mapper;
		
		mapper = new DiscretePaintMapper(new Color[]{Color.BLUE});
		assertEquals(1, mapper.getNumberOfCategories());
		assertTrue(mapper.valueInBounds(0));
		assertFalse(mapper.valueInBounds(1));
		assertFalse(mapper.valueInBounds(-1));
		
		featureHolderStyle.setPaint(Color.RED);
		f = buildFeatureNoAnnotation();
		item = new FeatureItemImp(featureHolderStyle, f);
		assertEquals(Color.RED, item.getPaint());

		mapper.mapValueToStyle(0, item);
		assertEquals(Color.BLUE, item.getPaint());
		
		
		
		mapper = new DiscretePaintMapper(new Color[]{Color.BLUE, Color.GREEN});
		assertEquals(2, mapper.getNumberOfCategories());
		assertTrue(mapper.valueInBounds(0));
		assertTrue(mapper.valueInBounds(1));
		assertFalse(mapper.valueInBounds(2));
		assertFalse(mapper.valueInBounds(-1));
		
		featureHolderStyle.setPaint(Color.RED);
		f = buildFeatureNoAnnotation();
		item = new FeatureItemImp(featureHolderStyle, f);
		assertEquals(Color.RED, item.getPaint());

		mapper.mapValueToStyle(0, item);
		assertEquals(Color.BLUE, item.getPaint());
		
		mapper.mapValueToStyle(1, item);
		assertEquals(Color.GREEN, item.getPaint());
	}
}
