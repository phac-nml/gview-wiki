package ca.corefacility.gview.test.ioTests.styles;


import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.LabelStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.io.gss.coders.GSSWriter;
import ca.corefacility.gview.style.io.gss.coders.LabelCoder;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.textextractor.LocationExtractor;

public class LabelCoderTest
{
	private LabelCoder coder;
	
	@Before
	public void setup()
	{
		coder = new LabelCoder();
	}
	
	@Test(expected=ParseException.class)
	public void testDecodeInvalid() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LabelStyle workingStyle = new LabelStyle();
		LabelStyle expectedStyle;
		
		LexicalUnit currUnit;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		// setup expected style
		expectedStyle = (LabelStyle)workingStyle.clone();
		expectedStyle.setTextPaint(Color.red);
		
		coder.decodeProperty(workingStyle, "invalid", currUnit, null);
	}
	
	@Test
	public void testDecode() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LabelStyle workingStyle = new LabelStyle();
		LabelStyle expectedStyle;
		
		LexicalUnit currUnit;
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		// setup expected style
		expectedStyle = (LabelStyle)workingStyle.clone();
		expectedStyle.setTextPaint(Color.red);
		
		coder.decodeProperty(workingStyle, "text-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"blue\")")));
		
		// setup expected style
		expectedStyle = (LabelStyle)workingStyle.clone();
		expectedStyle.setBackgroundPaint(Color.blue);
		
		coder.decodeProperty(workingStyle, "background-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("font(\"SansSerif\", \"plain\", 19)")));
		
		// setup expected style
		expectedStyle = (LabelStyle)workingStyle.clone();
		expectedStyle.setFont(new Font("SansSerif", Font.PLAIN, 19));
		
		coder.decodeProperty(workingStyle, "font", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("text-extractor(\"location\")")));
		
		// setup expected style
		expectedStyle = (LabelStyle)workingStyle.clone();
		expectedStyle.setLabelExtractor(new LocationExtractor());
		
		coder.decodeProperty(workingStyle, "label-extractor", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("\"true\"")));
		
		// setup expected style
		expectedStyle = (LabelStyle)workingStyle.clone();
		expectedStyle.setShowLabels(true);
		
		coder.decodeProperty(workingStyle, "show-labels", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testEncode()
	{
		LabelCoder labelCoder = new LabelCoder();
		LabelStyle labelStyle = new LabelStyle();
		
		String expectedEncoding;
		
		StringWriter expectedStringWriter;
		GSSWriter expectedGssWriter;
		
		StringWriter actualStringWriter;
		GSSWriter actualEncodingGSS;
		
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		String baseSelector = "slot#1";
		
		// setup feature set 
		expectedGssWriter.startSelector(baseSelector + " " + "labels");
		expectedGssWriter.writeProperty("text-color", "color(\"blue\")");
		expectedGssWriter.writeProperty("background-color", "color(\"orange\")");
		expectedGssWriter.writeProperty("font", "font(\"SansSerif\",\"plain\",19)");
		expectedGssWriter.writeProperty("label-extractor", "text-extractor(\"location\")");
		expectedGssWriter.writeProperty("show-labels", "\"true\"");
		expectedGssWriter.endSelector();
		expectedEncoding = expectedStringWriter.toString();
		
		// setup map
		labelStyle.setTextPaint(Color.blue);
		labelStyle.setBackgroundPaint(new Color(255, 153, 0)); // orange
		labelStyle.setFont(new Font("SansSerif", Font.PLAIN, 19));
		labelStyle.setLabelExtractor(new LocationExtractor());
		labelStyle.setShowLabels(true);
		
		labelCoder.encodeStyle(labelStyle, baseSelector, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
	}
}
