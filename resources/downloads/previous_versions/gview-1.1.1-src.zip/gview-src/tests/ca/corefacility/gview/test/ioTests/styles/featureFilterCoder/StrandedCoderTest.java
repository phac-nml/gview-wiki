package ca.corefacility.gview.test.ioTests.styles.featureFilterCoder;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.io.gss.featureFilterCoder.FeatureFilterCoder;
import ca.corefacility.gview.style.io.gss.featureFilterCoder.StrandedCoder;

public class StrandedCoderTest
{
	@Test
	public void testEncode() throws CSSException, IOException
	{
		String encoded;
		FeatureFilterCoder coder = new StrandedCoder();
		
		assertTrue(coder.canCode(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE)));
		
		encoded = coder.encode(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		assertEquals("strand(\"positive\")", encoded);
		
		encoded = coder.encode(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		assertEquals("strand(\"negative\")", encoded);
		
		encoded = coder.encode(new FeatureFilter.StrandFilter(StrandedFeature.UNKNOWN));
		assertEquals("strand(\"unknown\")", encoded);
	}
	
	@Test
	public void testDecode() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		FeatureFilterCoder coder = new StrandedCoder();
		LexicalUnit currUnit;
		FeatureFilter filter;
		FeatureFilter.StrandFilter strandFilter;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("strand(\"positive\")")));
		filter = coder.decode(currUnit);
		assertNotNull(filter);
		assertEquals(FeatureFilter.StrandFilter.class, filter.getClass());
		strandFilter = (FeatureFilter.StrandFilter)filter;
		assertEquals(StrandedFeature.POSITIVE, strandFilter.getStrand());
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("strand(\"negative\")")));
		filter = coder.decode(currUnit);
		assertNotNull(filter);
		assertEquals(FeatureFilter.StrandFilter.class, filter.getClass());
		strandFilter = (FeatureFilter.StrandFilter)filter;
		assertEquals(StrandedFeature.NEGATIVE, strandFilter.getStrand());
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("strand(\"unknown\")")));
		filter = coder.decode(currUnit);
		assertNotNull(filter);
		assertEquals(FeatureFilter.StrandFilter.class, filter.getClass());
		strandFilter = (FeatureFilter.StrandFilter)filter;
		assertEquals(StrandedFeature.UNKNOWN, strandFilter.getStrand());
	}
}
