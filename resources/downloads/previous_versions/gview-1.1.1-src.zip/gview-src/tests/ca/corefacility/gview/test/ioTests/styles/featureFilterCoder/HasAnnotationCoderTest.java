package ca.corefacility.gview.test.ioTests.styles.featureFilterCoder;

import static org.junit.Assert.*;

import java.io.IOException;
import java.io.StringReader;

import org.biojava.bio.seq.FeatureFilter;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.io.StyleIO;
import ca.corefacility.gview.style.io.StyleIOGSS;
import ca.corefacility.gview.style.io.gss.featureFilterCoder.FeatureFilterCoder;
import ca.corefacility.gview.style.io.gss.featureFilterCoder.HasAnnotationCoder;

public class HasAnnotationCoderTest
{
	@Test
	public void testEncode() throws CSSException, IOException
	{
		String encoded;
		FeatureFilterCoder hasAnnotationCoder = new HasAnnotationCoder();
		FeatureFilter annFilter;
		
		annFilter = new FeatureFilter.HasAnnotation("key1");
		assertTrue(hasAnnotationCoder.canCode(annFilter));
		
		encoded = hasAnnotationCoder.encode(annFilter);
		
		assertEquals("hasAnnotation(\"key1\")", encoded);
	}
	
	@Test
	public void testDecode() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		FeatureFilterCoder hasAnnotationCoder = new HasAnnotationCoder();
		LexicalUnit currUnit;
		FeatureFilter annFilter;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("hasAnnotation(\"key1\")")));
		
		annFilter = hasAnnotationCoder.decode(currUnit);
		
		assertNotNull(annFilter);
		assertEquals(FeatureFilter.HasAnnotation.class, annFilter.getClass());
		assertEquals("key1", ((FeatureFilter.HasAnnotation)annFilter).getKey());
	}
}
