package ca.corefacility.gview.test.translatetests;


import java.awt.geom.Dimension2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.impl.SimpleSequence;
import org.biojava.bio.symbol.SymbolList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.prototype.SequencePoint;
import ca.corefacility.gview.layout.prototype.SequencePointImp;
import ca.corefacility.gview.layout.sequence.Backbone;
import ca.corefacility.gview.layout.sequence.LocationConverter;
import ca.corefacility.gview.layout.sequence.SequenceRectangle;
import ca.corefacility.gview.layout.sequence.circular.BackboneCircular.ClashShiftException;
import ca.corefacility.gview.layout.sequence.linear.BackboneLinear;
import ca.corefacility.gview.map.event.BackboneZoomEvent;
import ca.corefacility.gview.map.event.GViewEvent;
import ca.corefacility.gview.map.event.GViewEventListener;
import ca.corefacility.gview.map.event.ZoomEvent;
import ca.corefacility.gview.utils.Dimension2DDouble;

public class BackboneLinearTest
{
	private final static int WIDTH = 100;
	private double maxScale;

	private Backbone backbone = null;

	private GenomeData data = null;

	private double delta = 0.0000000001;

	private int sequenceLength = 100;

	@Before
	public void setup()
	{
		SymbolList list = new BlankSymbolList(sequenceLength);
		Sequence seq = new SimpleSequence(list, null, null, null);

		data = GenomeDataFactory.createGenomeData(seq);

		backbone = new BackboneLinear(new LocationConverter(data), WIDTH);
		maxScale = backbone.getMaxScale();
	}

	// tests whether Backbone can properly send/receive events
	@Test
	public void event()
	{
		backbone.addEventListener(new GViewEventListener() {
			public void eventOccured(GViewEvent event)
			{
				Assert.assertTrue(event instanceof BackboneZoomEvent);

				if (event instanceof BackboneZoomEvent)
				{
					BackboneZoomEvent zoomEvent = (BackboneZoomEvent) event;
					Assert.assertNotNull(zoomEvent.getBackbone());
				}
			}
		});

		Point2D zoomPoint = new Point2D.Double();
		backbone.eventOccured(new ZoomEvent(2.0, zoomPoint, this));
		backbone.eventOccured(new ZoomEvent(3.0, zoomPoint, this));
		backbone.eventOccured(new ZoomEvent(100.5, zoomPoint, this));
	}

	@Test
	public void testGetSpannedBases()
	{
		// assumes sequenceLength = 100, and WIDTH = 100
		double spannedBases;

		// scale=1
		spannedBases = backbone.getSpannedBases(0);
		Assert.assertEquals(0, spannedBases, delta);

		spannedBases = backbone.getSpannedBases(50);
		Assert.assertEquals(50, spannedBases, delta);

		spannedBases = backbone.getSpannedBases(100);
		Assert.assertEquals(100, spannedBases, delta);

		for (double scale = 1.5; scale < 10; scale += 0.5)
		{
			backbone.eventOccured(new ZoomEvent(scale, null, this));

			spannedBases = backbone.getSpannedBases(0);
			Assert.assertEquals(0 / scale, spannedBases, delta);

			spannedBases = backbone.getSpannedBases(50);
			Assert.assertEquals(50 / scale, spannedBases, delta);

			spannedBases = backbone.getSpannedBases(100);
			Assert.assertEquals(100 / scale, spannedBases, delta);
		}
	}

	@Test
	public void testTranslateToSeqPoint()
	{
		Point2D translatePoint = new Point2D.Double();
		SequencePoint sequencePoint;
		double expectedBase, expectedHeight;

		double maxScaleToUse = Math.min(maxScale, 100);

		for (double scale = 0.1; scale < maxScaleToUse; scale += 1.0)
		{
			double actualLength = WIDTH * scale;
			backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this)); // set scale

			// 0 base
			translatePoint.setLocation(-actualLength / 2, 0);
			sequencePoint = backbone.translate(translatePoint);
			expectedBase = 0;
			expectedHeight = 0;
			Assert.assertEquals(expectedBase, sequencePoint.getBase(), delta);
			Assert.assertEquals(expectedHeight, sequencePoint.getHeightFromBackbone(), delta);

			// quarter sequence length
			translatePoint.setLocation(-actualLength / 4, 0);
			sequencePoint = backbone.translate(translatePoint);
			expectedBase = sequenceLength / 4.0;
			expectedHeight = 0;
			Assert.assertEquals(expectedBase, sequencePoint.getBase(), delta);
			Assert.assertEquals(expectedHeight, sequencePoint.getHeightFromBackbone(), delta);

			// half sequence length
			translatePoint.setLocation(0, 0);
			sequencePoint = backbone.translate(translatePoint);
			expectedBase = 2 * sequenceLength / 4.0;
			expectedHeight = 0;
			Assert.assertEquals(expectedBase, sequencePoint.getBase(), delta);
			Assert.assertEquals(expectedHeight, sequencePoint.getHeightFromBackbone(), delta);

			// 3rd quarter sequence length
			translatePoint.setLocation(actualLength / 4, 0);
			sequencePoint = backbone.translate(translatePoint);
			expectedBase = 3 * sequenceLength / 4.0;
			expectedHeight = 0;
			Assert.assertEquals(expectedBase, sequencePoint.getBase(), delta);
			Assert.assertEquals(expectedHeight, sequencePoint.getHeightFromBackbone(), delta);

			// sequence length
			translatePoint.setLocation(actualLength / 2, 0);
			sequencePoint = backbone.translate(translatePoint);
			expectedBase = 4 * sequenceLength / 4.0;
			expectedHeight = 0;
			Assert.assertEquals(expectedBase, sequencePoint.getBase(), delta);
			Assert.assertEquals(expectedHeight, sequencePoint.getHeightFromBackbone(), delta);

			// before 0 base
			translatePoint.setLocation(-actualLength, 0);
			sequencePoint = backbone.translate(translatePoint);
			expectedBase = -sequenceLength / 2.0;
			expectedHeight = 0;
			Assert.assertEquals(expectedBase, sequencePoint.getBase(), delta);
			Assert.assertEquals(expectedHeight, sequencePoint.getHeightFromBackbone(), delta);

			// after sequenceLength base
			translatePoint.setLocation(actualLength, 0);
			sequencePoint = backbone.translate(translatePoint);
			expectedBase = 3 * sequenceLength / 2.0;
			expectedHeight = 0;
			Assert.assertEquals(expectedBase, sequencePoint.getBase(), delta);
			Assert.assertEquals(expectedHeight, sequencePoint.getHeightFromBackbone(), delta);
		}
	}

	@Test
	public void testGetSpannedRectangle()
	{
		double leftX = -WIDTH / 2;
		Rectangle2D view;
		SequenceRectangle actualSequenceRectangle;

		Assert.assertEquals(100, sequenceLength);
		Assert.assertEquals(100, WIDTH);

		// rectangle at left
		view = new Rectangle2D.Double(leftX, -10, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(0, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(20, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-10, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(10, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle in middle
		view = new Rectangle2D.Double(leftX + 40, -10, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(40, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(60, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-10, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(10, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle at right
		view = new Rectangle2D.Double(leftX + 80, -10, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(80, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(100, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-10, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(10, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle above backbone
		// rectangle at left
		view = new Rectangle2D.Double(leftX, -100, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(0, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(20, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(80, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(100, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle in middle
		view = new Rectangle2D.Double(leftX + 40, -100, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(40, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(60, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(80, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(100, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle at right
		view = new Rectangle2D.Double(leftX + 80, -100, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(80, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(100, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(80, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(100, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle below backbone
		// rectangle at left
		view = new Rectangle2D.Double(leftX, 100, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(0, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(20, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-120, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(-100, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle in middle
		view = new Rectangle2D.Double(leftX + 40, 100, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(40, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(60, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-120, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(-100, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle at right
		view = new Rectangle2D.Double(leftX + 80, 100, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(80, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(100, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-120, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(-100, actualSequenceRectangle.getEndHeight(), delta);

		// case where left is outside of sequence
		// should give negative base coordinates
		view = new Rectangle2D.Double(leftX - 10, -10, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(-10, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(10, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-10, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(10, actualSequenceRectangle.getEndHeight(), delta);

		view = new Rectangle2D.Double(leftX - 20, -10, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(-20, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(0, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-10, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(10, actualSequenceRectangle.getEndHeight(), delta);

		view = new Rectangle2D.Double(leftX - 30, -10, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(-30, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(-10, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-10, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(10, actualSequenceRectangle.getEndHeight(), delta);

		// case where right is outside of sequence
		// expect to only go up to 100 base
		view = new Rectangle2D.Double(leftX + 90, -10, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(90, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(110, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-10, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(10, actualSequenceRectangle.getEndHeight(), delta);

		view = new Rectangle2D.Double(leftX + 100, -10, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(100, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(120, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-10, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(10, actualSequenceRectangle.getEndHeight(), delta);

		view = new Rectangle2D.Double(leftX + 110, -10, 20, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(110, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(130, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(-10, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(10, actualSequenceRectangle.getEndHeight(), delta);
	}

	// tests translations along backbone at different heights
	@Test
	public void translate()
	{
		for (double height = -10; height < 10; height += 0.5)
		{
			translateHeight(height);
		}
	}

	private void translateHeight(double height)
	{
		Point2D zoomPoint = new Point2D.Double(0, 0);

		double expectedY = -height;

		double maxScaleToUse = Math.min(maxScale, 100);

		for (double scale = 0.1; scale < maxScaleToUse; scale += 1.0)
		{
			Point2D point = null;
			backbone.eventOccured(new ZoomEvent(scale, zoomPoint, this)); // set scale

			// test zero case
			point = backbone.translate(0, height);
			Assert.assertEquals(-50 * scale, point.getX(), delta);
			Assert.assertEquals(expectedY, point.getY(), delta);

			// 1st quarter
			point = backbone.translate(25, height);
			Assert.assertEquals(-25 * scale, point.getX(), delta);
			Assert.assertEquals(expectedY, point.getY(), delta);

			// test halfway
			point = backbone.translate(50, height);
			Assert.assertEquals(0 * scale, point.getX(), delta);
			Assert.assertEquals(expectedY, point.getY(), delta);

			// test 3rd quarter
			point = backbone.translate(75, height);
			Assert.assertEquals(25 * scale, point.getX(), delta);
			Assert.assertEquals(expectedY, point.getY(), delta);

			// test final
			point = backbone.translate(100, height);
			Assert.assertEquals(50 * scale, point.getX(), delta);
			Assert.assertEquals(expectedY, point.getY(), delta);
		}
	}

	@Test
	public void testClashShift()
	{
		SequencePointImp pinnedPoint;
		double heightLimit;

		double height = 10;
		double width = 10;

		double expectedShift;
		double actualShift;

		try
		{
			pinnedPoint = null;
			heightLimit = 0;
			expectedShift = 0;
			actualShift = backbone.calculateClashShift(null, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(expectedShift, actualShift, delta);

			// rectangle below backbone
			pinnedPoint = new SequencePointImp(0, -5);

			heightLimit = 0;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(10, actualShift, delta);

			heightLimit = 0;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(0, actualShift, delta);

			heightLimit = 10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(20, actualShift, delta);

			heightLimit = 10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(0, actualShift, delta);

			heightLimit = -10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(0, actualShift, delta);

			heightLimit = -10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(-10, actualShift, delta);

			heightLimit = -20;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(0, actualShift, delta);

			heightLimit = -20;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(-20, actualShift, delta);

			// rectangle above backbone
			pinnedPoint = new SequencePointImp(0, 5);

			heightLimit = 0;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(0, actualShift, delta);

			heightLimit = 0;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(-10, actualShift, delta);

			heightLimit = 10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(10, actualShift, delta);

			heightLimit = 10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(0, actualShift, delta);

			heightLimit = -10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(0, actualShift, delta);

			heightLimit = -10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(-20, actualShift, delta);

			// rectangle in middle of backbone
			pinnedPoint = new SequencePointImp(0, 0);

			heightLimit = 0;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(5, actualShift, delta);

			heightLimit = 0;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(-5, actualShift, delta);

			heightLimit = 10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(15, actualShift, delta);

			heightLimit = 10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(0, actualShift, delta);

			heightLimit = -10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(0, actualShift, delta);

			heightLimit = -10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(-15, actualShift, delta);
		}
		catch (ClashShiftException e)
		{
			Assert.fail();
		}
	}
	
	@Test
	public void testCalculateIntersectionScale()
	{
		SymbolList list = new BlankSymbolList(100);
		Sequence seq = new SimpleSequence(list, null, null, null);

		data = GenomeDataFactory.createGenomeData(seq);

		backbone = new BackboneLinear(new LocationConverter(data), 100);
		maxScale = backbone.getMaxScale();
		
		Dimension2D dim1, dim2;
		SequencePoint center1, center2;
		double expectedScale, actualScale;
		
		// case, two rectangles on either side of center base (base 50), touching at scale = 1.
		dim1 = new Dimension2DDouble(50, 10); // rectangle starting at leftmost base, and extending to center base (50)
		dim2 = new Dimension2DDouble(50, 10); // rectangle starting at center base, and extending to rightmost base
		
		center1 = new SequencePointImp(25, 0); // rectangle 1 is centered at base 25, height 5
		center2 = new SequencePointImp(75, 0); // rectangle 1 is centered at base 75, height 5
		
		expectedScale = 1.0; // scale at which the rectangles don't overlap anymore should be 1
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, two rectangles on either side of center base (base 50), completely covering sequence at scale 1
		dim1 = new Dimension2DDouble(100, 10); // rectangle starting at leftmost base, and extending to center base (50)
		dim2 = new Dimension2DDouble(100, 10); // rectangle starting at center base, and extending to rightmost base
		
		center1 = new SequencePointImp(25, 0); // rectangle 1 is centered at base -25, height 5
		center2 = new SequencePointImp(75, 0); // rectangle 1 is centered at base 25, height 5
		
		expectedScale = 2.0; // scale at which the rectangles don't overlap anymore should be 2
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, same as above, but swap rectangles
		dim1 = new Dimension2DDouble(100, 10); // rectangle starting at center base, and extending to rightmost base
		dim2 = new Dimension2DDouble(100, 10); // rectangle starting at leftmost base, and extending to center base (50)
		
		
		center1 = new SequencePointImp(75, 0); // rectangle 1 is centered at base 25, height 5
		center2 = new SequencePointImp(25, 0); // rectangle 1 is centered at base -25, height 5
		
		expectedScale = 2.0; // scale at which the rectangles don't overlap anymore should be 2
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, two rectangles centered at same point, should give result of maxScale
		dim1 = new Dimension2DDouble(100, 10); // rectangle starting at leftmost base, and extending to center base (50)
		dim2 = new Dimension2DDouble(100, 10); // rectangle starting at center base, and extending to rightmost base
		
		center1 = new SequencePointImp(25, 0); // rectangle 1 is centered at base -25, height 5
		center2 = new SequencePointImp(25, 0); // rectangle 1 is centered at base 25, height 5
		
		expectedScale = maxScale; // there is no scale where rectangles don't overlap
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, one rectangle at -26, other at -25
		dim1 = new Dimension2DDouble(10, 10); // rectangle centered at base -26, of length 10
		dim2 = new Dimension2DDouble(10, 10); // rectangle centered at base -25, length 10
		
		center1 = new SequencePointImp(24, 0); // rectangle 1 is centered at base 24, height 5
		center2 = new SequencePointImp(25, 0); // rectangle 1 is centered at base 25, height 5
		
		expectedScale = 10; // scale at which the rectangles don't overlap anymore should be 10
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, one rectangle at -26, other at -25, different widths
		dim1 = new Dimension2DDouble(10, 10); // rectangle centered at base -26, of length 10
		dim2 = new Dimension2DDouble(20, 10); // rectangle centered at base -25, length 10
		
		center1 = new SequencePointImp(24, 0); // rectangle 1 is centered at base 24, height 5
		center2 = new SequencePointImp(25, 0); // rectangle 1 is centered at base 25, height 5
		
		expectedScale = 15; // scale at which the rectangles don't overlap anymore
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, two rectangles on either side of center base (base 50), completely covering sequence at scale 1
		// heights offset from each other, but rectangles can still overlap
		dim1 = new Dimension2DDouble(100, 10); // rectangle starting at leftmost base, and extending to center base (50)
		dim2 = new Dimension2DDouble(100, 10); // rectangle starting at center base, and extending to rightmost base
		
		center1 = new SequencePointImp(25, 0); // rectangle 1
		center2 = new SequencePointImp(75, -1); // rectangle 2
		
		expectedScale = 2.0; // scale at which the rectangles don't overlap anymore should be 2
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		Assert.assertEquals(expectedScale, actualScale, delta);

		
		// case, two rectangles on either side of center base (base 50), completely covering sequence at scale 1
		// heights offset from each other and rectangles can't overlap
		dim1 = new Dimension2DDouble(100, 10); 
		dim2 = new Dimension2DDouble(100, 10);
		
		center1 = new SequencePointImp(25, 5); // rectangle 1
		center2 = new SequencePointImp(75, -5); // rectangle 2
		
		expectedScale = 0.0; // rectangles should never overlap
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		Assert.assertEquals(expectedScale, actualScale, delta);
	}
}
