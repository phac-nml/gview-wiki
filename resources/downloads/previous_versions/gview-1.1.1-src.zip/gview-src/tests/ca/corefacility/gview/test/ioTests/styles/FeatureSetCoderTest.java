package ca.corefacility.gview.test.ioTests.styles;


import java.awt.Color;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.DescendantSelector;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;
import org.w3c.css.sac.Selector;
import org.w3c.css.sac.SimpleSelector;

import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.map.effects.OutlineEffect;
import ca.corefacility.gview.map.effects.OutsideEffect;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.datastyle.mapper.AnnotationMapper;
import ca.corefacility.gview.style.datastyle.mapper.COGMapper;
import ca.corefacility.gview.style.datastyle.mapper.DiscretePaintMapper;
import ca.corefacility.gview.style.datastyle.mapper.OpacityFeatureStyleMapper;
import ca.corefacility.gview.style.datastyle.mapper.PropertyMapperScore;
import ca.corefacility.gview.style.datastyle.mapper.PropertyStyleContinuous;
import ca.corefacility.gview.style.datastyle.mapper.PropertyStyleDiscrete;
import ca.corefacility.gview.style.io.FeatureSetMap;
import ca.corefacility.gview.style.io.gss.coders.FeatureSetCoder;
import ca.corefacility.gview.style.io.gss.coders.GSSWriter;
import ca.corefacility.gview.style.io.gss.coders.LabelCoder;
import ca.corefacility.gview.style.io.gss.coders.SlotCoder;
import ca.corefacility.gview.style.io.gss.exceptions.NoStyleExistsException;
import ca.corefacility.gview.style.io.gss.exceptions.NoSuchFilterException;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.textextractor.AnnotationExtractor;
import ca.corefacility.gview.textextractor.LocationExtractor;

import com.steadystate.css.parser.selectors.ConditionalSelectorImpl;
import com.steadystate.css.parser.selectors.DescendantSelectorImpl;
import com.steadystate.css.parser.selectors.ElementSelectorImpl;
import com.steadystate.css.parser.selectors.IdConditionImpl;

public class FeatureSetCoderTest
{
	private FeatureSetCoder coder;
	private FeatureSetMap filtersMap;
	private MapStyle mapStyle;
	
	@Before
	public void setup()
	{
		coder = new FeatureSetCoder();
		filtersMap = new FeatureSetMap();
		
		filtersMap.put("positive", new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		filtersMap.put("all", FeatureFilter.all);
		
		mapStyle = new MapStyle();
	}
	
	private SimpleSelector buildFeatureSelector(String setName)
	{
		SimpleSelector featureSelector = new ConditionalSelectorImpl(new ElementSelectorImpl("FeatureSet"), new IdConditionImpl(setName));
		
		return featureSelector;
	}
	
	private DescendantSelector buildDescendantSelector(Selector base, SimpleSelector descendant)
	{
		DescendantSelector descSel = new DescendantSelectorImpl(base, descendant);
		
		return descSel;
	}
	
	private Selector buildSlotSelector(String slotNumber)
	{
		Selector slotSelector = new ConditionalSelectorImpl(new ElementSelectorImpl("slot"), new IdConditionImpl(slotNumber));
		
		return slotSelector;
	}
	
	@Test(expected=ParseException.class)
	public void testDecodeInvalid() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		//setup parameters
		FeatureHolderStyle workingStyle;
		SlotStyle currentSlot;
		DataStyle dataStyle = mapStyle.getDataStyle();
		// create initial feature holder style
		currentSlot = dataStyle.createSlotStyle(1);
		workingStyle = currentSlot.createFeatureHolderStyle(filtersMap.get("positive"));
		LexicalUnit currUnit = parser.parsePropertyValue(new InputSource(new StringReader("0.75")));
		
		// setup expected style
		FeatureHolderStyle expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setThickness(0.75);
		
		coder.decodeProperty(workingStyle, "invalid", currUnit, null);
	}
	
	@Test(expected=ParseException.class)
	public void testThicknessInvalid() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		//setup parameters
		FeatureHolderStyle workingStyle;
		SlotStyle currentSlot;
		DataStyle dataStyle = mapStyle.getDataStyle();
		// create initial feature holder style
		currentSlot = dataStyle.createSlotStyle(1);
		workingStyle = currentSlot.createFeatureHolderStyle(filtersMap.get("positive"));
		LexicalUnit currUnit = parser.parsePropertyValue(new InputSource(new StringReader("0.75")));
		
		// setup expected style
		FeatureHolderStyle expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setThickness(0.75);
		
		coder.decodeProperty(workingStyle, "thickness", currUnit, null);		
	}
	
	@Test
	public void testDecode() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		FeatureHolderStyle workingStyle;
		LexicalUnit currUnit;
		
		SlotStyle currentSlot;
		FeatureHolderStyle expectedStyle;
		
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// create initial feature holder style
		currentSlot = dataStyle.createSlotStyle(1);
		workingStyle = currentSlot.createFeatureHolderStyle(filtersMap.get("positive"));
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setPaint(new Color(255,0,0));
		
		coder.decodeProperty(workingStyle, "color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("0.75")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setThickness(0.75);
		
		coder.decodeProperty(workingStyle, "thickness-proportion", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("shape-effect(\"outline\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setShapeEffectRenderer(new OutlineEffect());
		
		coder.decodeProperty(workingStyle, "feature-effect", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("shape(\"counterclockwise-arrow\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);
		
		coder.decodeProperty(workingStyle, "feature-shape", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("text-extractor(\"location\")")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setToolTipExtractor(new LocationExtractor());
		
		coder.decodeProperty(workingStyle, "tooltip-text", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("text-extractor(annotation(\"h1\"))")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setHyperlinkExtractor(new AnnotationExtractor("h1"));
		
		coder.decodeProperty(workingStyle, "hyperlink", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("continuous-map(score(0,100), opacity)")));
		
		// setup expected style
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setPropertyStyle(new PropertyStyleContinuous(new PropertyMapperScore(0.0f,100.0f), new OpacityFeatureStyleMapper()));
		
		coder.decodeProperty(workingStyle, "property-mapper", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("discrete-map(cog(" +
				"\"A\", \"B\"), colors(color(\"red\"), color(\"blue\")))")));
		
		expectedStyle = (FeatureHolderStyle)workingStyle.clone();
		expectedStyle.setPropertyStyle(new PropertyStyleDiscrete(new COGMapper(new String[]{"A", "B"}),
				new DiscretePaintMapper(new Color[]{Color.RED, Color.BLUE})));
		
		coder.decodeProperty(workingStyle, "property-mapper", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testEncode()
	{
		SlotStyle slotStyle = mapStyle.getDataStyle().createSlotStyle(1);
		LabelCoder labelCoder = new LabelCoder();
		
		FeatureHolderStyle holderStyle = slotStyle.createFeatureHolderStyle(filtersMap.get("positive"));
		String expectedEncoding, actualEncoding;
		
		StringWriter expectedStringWriter;
		GSSWriter expectedGssWriter;
		
		StringWriter actualStringWriter;
		GSSWriter actualEncodingGSS;
		
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup feature set 
		expectedGssWriter.startSelector("slot#1 FeatureSet#positive");
		expectedGssWriter.writeProperty("color", "color(\"blue\")");
		expectedGssWriter.writeProperty("feature-effect", "shape-effect(\"outline\")");
		expectedGssWriter.writeProperty("feature-shape", "shape(\"clockwise-arrow\")");
		expectedGssWriter.writeProperty("hyperlink", "text-extractor(annotation(\"h1\"))");
		expectedGssWriter.writeProperty("thickness-proportion", "0.5");
		expectedGssWriter.writeProperty("tooltip-text", "text-extractor(annotation(\"product\"))");
		expectedGssWriter.endSelector();
		labelCoder.encodeStyle(holderStyle.getLabelStyle(), "slot#1 FeatureSet#positive", expectedGssWriter);
		expectedEncoding = expectedStringWriter.toString();
		
		// setup map
		holderStyle.setPaint(Color.blue);
		holderStyle.setThickness(0.5);
		holderStyle.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW);
		holderStyle.setShapeEffectRenderer(new OutlineEffect());
		holderStyle.setToolTipExtractor(new AnnotationExtractor("product"));
		holderStyle.setHyperlinkExtractor(new AnnotationExtractor("h1"));
		
		coder.encodeStyle(holderStyle, "slot#1", filtersMap, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
	}
	
	@Test
	public void testEncodeLayered()
	{
		SlotStyle slotStyle = mapStyle.getDataStyle().createSlotStyle(-1);
		LabelCoder labelCoder = new LabelCoder();
		
		FeatureHolderStyle tmpHolderStyle = slotStyle.createFeatureHolderStyle(filtersMap.get("all"));
		FeatureHolderStyle holderStyle = tmpHolderStyle.createFeatureHolderStyle(filtersMap.get("positive"));
		String expectedEncoding;
		
		StringWriter expectedStringWriter;
		GSSWriter expectedGssWriter;
		
		StringWriter actualStringWriter;
		GSSWriter actualEncodingGSS;
		
//		Selector selector;
//		selector = buildSelector("1", "positive");
		
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup feature set 
		expectedGssWriter.startSelector("slot#-1 FeatureSet#all FeatureSet#positive");
		expectedGssWriter.writeProperty("color", "color(\"blue\")");
		expectedGssWriter.writeProperty("feature-effect", "shape-effect(\"outline\")");
		expectedGssWriter.writeProperty("feature-shape", "shape(\"clockwise-arrow\")");
		expectedGssWriter.writeProperty("hyperlink", "text-extractor(annotation(\"h1\"))");
		expectedGssWriter.writeProperty("thickness-proportion", "0.5");
		expectedGssWriter.writeProperty("tooltip-text", "text-extractor(annotation(\"product\"))");
		expectedGssWriter.endSelector();
		labelCoder.encodeStyle(holderStyle.getLabelStyle(), "slot#-1 FeatureSet#all FeatureSet#positive", expectedGssWriter);
		expectedEncoding = expectedStringWriter.toString();
		
		// setup map
		holderStyle.setPaint(Color.blue);
		holderStyle.setThickness(0.5);
		holderStyle.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW);
		holderStyle.setShapeEffectRenderer(new OutlineEffect());
		holderStyle.setToolTipExtractor(new AnnotationExtractor("product"));
		holderStyle.setHyperlinkExtractor(new AnnotationExtractor("h1"));
		
		coder.encodeStyle(holderStyle, "slot#-1 FeatureSet#all", filtersMap, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
	}
}
