package ca.corefacility.gview.test.ioTests.cgviewxml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;

import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.FeatureHolder;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.symbol.Location;
import org.biojava.bio.symbol.RangeLocation;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.GViewFileData;
import ca.corefacility.gview.data.readers.GViewFileReader;
import ca.corefacility.gview.data.readers.cgview.CGViewXMLReader;
import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.map.effects.OutsideEffect;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.SlotItemStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.textextractor.FeatureTextExtractor;

public class FeatureElementTest
{
	private static final ShapeEffectRenderer noShading = ShapeEffectRenderer.NO_SELECT_RENDERER;
	private static final ShapeEffectRenderer shading = new OutsideEffect(new Color(0,0,0,128));
	
	private CGViewXMLReader cgviewReader;
	private double delta = 0.0000001;
	
	@Before
	public void setup()
	{
		cgviewReader = new CGViewXMLReader();
	}
	
	/**
	 * Tests for and returns the single FeatureHolderStyle within the passed slot.  Assumes there exists only 1 FeatureHolderStyle.
	 * @param slotStyle  The SlotStyle to extract the FeatureHolderStyle from.
	 * @return  The first FeatureHolderStyle encountered.
	 */
	private FeatureHolderStyle getAndTestForFeatureHolderStyle(SlotStyle slotStyle)
	{
		FeatureHolderStyle holderStyle = null;
		
		assertNotNull(slotStyle);
		
		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		assertTrue(styleIter.hasNext());
		
		while (styleIter.hasNext() && holderStyle == null)
		{
			SlotItemStyle currItemStyle = styleIter.next();
			assertNotNull(currItemStyle);
			
			if (currItemStyle instanceof FeatureHolderStyle)
			{
				holderStyle = (FeatureHolderStyle)currItemStyle;
			}
		}
		
		assertNotNull(holderStyle);
		
		return holderStyle;
	}
	
	/**
	 * Tests to make sure only a single feature exists in the passed FeatureHolder, and returns this feature.
	 * @param holder  The FeatureHolder to check.
	 * @return  The single feature in this FeatureHolder.
	 */
	private Feature getAndTestForSingleFeatureInFeatureHolder(FeatureHolder holder)
	{
		Feature feature = null;
		
		assertNotNull(holder);
		
		Iterator<Feature> featuresIter = holder.features();
		assertNotNull(featuresIter);
		assertTrue(featuresIter.hasNext());
		
		feature = featuresIter.next();
		
		assertNotNull(feature);
		assertFalse(featuresIter.hasNext());
		
		return feature;
	}
	
	/**
	 * Performs the test read for testFeatureProperties, using the passed property string.
	 * @param featurePropertyString  A string defining the property to test.
	 * @return  The FeatureHolderStyle for the particular feature.
	 * @throws GViewDataParseException 
	 * @throws IOException 
	 */
	private FeatureHolderStyle performTestForFeatureProperties(String featurePropertyString) throws IOException, GViewDataParseException
	{
		SlotStyle slotStyle = null;
		FeatureHolderStyle featureHolderStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\">" +
		"<featureSlot strand=\"direct\">" +
			"<feature " + featurePropertyString + ">" +
				"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		return featureHolderStyle;
	}

	
	private void handleFeatureForMouseoverMultipleFeatures(Location[] locationObjs,
			Feature currentFeature, FeatureTextExtractor labelTextExtractor, String[] mouseover)
	{	
		boolean notHandled = true;
		
		// handle the correct feature
		for (int i = 0; i < locationObjs.length && notHandled; i++)
		{
			Location currentLocationObj = currentFeature.getLocation();
			if (locationObjs[i].equals(currentLocationObj)) // if this is location 1
			{
				// make sure mouseover is set properly for FeatureHolderStyle for the feature
				assertEquals(mouseover[i], labelTextExtractor.extractText(
						currentFeature)); // test that label is set properly
				
				notHandled = false;
			}

		}
		
		if (notHandled)
		{
			fail("Location=" + currentFeature.getLocation() + " not one of the valid options.");
		}
	}
	
	@Test
	public void testColor() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		// test color (default)
		featureHolderStyle = performTestForFeatureProperties("");
		assertEquals(Color.blue, featureHolderStyle.getPaint()[0]);
		
		// test color
		featureHolderStyle = performTestForFeatureProperties("color=\"white\"");
		assertEquals(Color.white, featureHolderStyle.getPaint()[0]);
		
		// test color
		featureHolderStyle = performTestForFeatureProperties("color=\"red\"");
		assertEquals(Color.red, featureHolderStyle.getPaint()[0]);
	}
	
	@Test
	public void testDecoration() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		// test decoration (default)
		featureHolderStyle = performTestForFeatureProperties("");
		assertEquals(FeatureShapeRealizer.NO_ARROW, featureHolderStyle.getFeatureShapeRealizer());

		// test decoration
		featureHolderStyle = performTestForFeatureProperties("decoration=\"arc\"");
		assertEquals(FeatureShapeRealizer.NO_ARROW, featureHolderStyle.getFeatureShapeRealizer());
		
		// test decoration
		featureHolderStyle = performTestForFeatureProperties("decoration=\"hidden\"");
		assertEquals(FeatureShapeRealizer.HIDDEN, featureHolderStyle.getFeatureShapeRealizer());
		
		// test decoration
		featureHolderStyle = performTestForFeatureProperties("decoration=\"clockwise-arrow\"");
		assertEquals(FeatureShapeRealizer.CLOCKWISE_ARROW, featureHolderStyle.getFeatureShapeRealizer());
		
		// test decoration
		featureHolderStyle = performTestForFeatureProperties("decoration=\"counterclockwise-arrow\"");
		assertEquals(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW, featureHolderStyle.getFeatureShapeRealizer());
	}
	
	@Test
	public void testLabelFont() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		// test label font
		featureHolderStyle = performTestForFeatureProperties("font=\"SansSerif, bold, 20\"");
		assertEquals(new Font("SansSerif", Font.BOLD, 20), featureHolderStyle.getLabelStyle().getFont());
		
		// test label font
		featureHolderStyle = performTestForFeatureProperties("font=\"SansSerif, italic, 18\"");
		assertEquals(new Font("SansSerif", Font.ITALIC, 18), featureHolderStyle.getLabelStyle().getFont());
	}
	
	// test default label font from cgview element
	@Test
	public void testLabelFontInherited() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		SlotStyle slotStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\" labelFont=\"SansSerif,bold,20\">" +
		"<featureSlot strand=\"direct\">" +
			"<feature>" +
				"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		// test label font
		assertEquals(new Font("SansSerif", Font.BOLD, 20), featureHolderStyle.getLabelStyle().getFont());
	}
	
	@Test
	public void testHyperLink() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		SlotStyle slotStyle = null;
		FeatureHolder holder;
		String actualHyperlink;
		
		GViewFileData cgviewData;
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\">" +
		"<featureSlot strand=\"direct\">" +
			"<feature hyperlink=\"hyperlink1\">" +
				"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		holder = cgviewData.getGenomeData().getAllFeatures(featureHolderStyle);
		
		Iterator<Feature> featureIter = holder.features();
		assertTrue(featureIter.hasNext());
		
		Feature feature = featureIter.next();
		assertNotNull(feature);
		assertFalse(featureIter.hasNext());
		
		// make sure label is set in annotation
		assertEquals("hyperlink1", feature.getAnnotation().getProperty("CGView_Hyperlink"));
		
		// make sure hyperlink is extracted properly
		actualHyperlink = featureHolderStyle.getHyperlinkExtractor().extractText(feature);
		assertEquals("hyperlink1", actualHyperlink);
	}
	
	@Test
	public void testLabel() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		SlotStyle slotStyle = null;
		FeatureHolder holder;
		
		GViewFileData cgviewData;
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\">" +
		"<featureSlot strand=\"direct\">" +
			"<feature label=\"label1\">" +
				"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		holder = cgviewData.getGenomeData().getAllFeatures(featureHolderStyle);
		
		Iterator<Feature> featureIter = holder.features();
		assertTrue(featureIter.hasNext());
		
		Feature feature = featureIter.next();
		assertNotNull(feature);
		assertFalse(featureIter.hasNext());
		
		// make sure label is set in annotation
		assertEquals("label1", feature.getAnnotation().getProperty("CGView_Label"));
		
		// test that label is extracted properly
		assertEquals("label1", featureHolderStyle.getLabelStyle().getLabelExtractor().extractText(
				feature));
	}
	
	@Test
	public void testMouseover() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		SlotStyle slotStyle = null;
		FeatureHolder holder;
		
		GViewFileData cgviewData;
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\">" +
		"<featureSlot strand=\"direct\">" +
			"<feature mouseover=\"the_mouseover_label\">" +
				"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		holder = cgviewData.getGenomeData().getAllFeatures(featureHolderStyle);
		
		Iterator<Feature> featureIter = holder.features();
		assertTrue(featureIter.hasNext());
		
		Feature feature = featureIter.next();
		assertNotNull(feature);
		
		assertEquals("the_mouseover_label", featureHolderStyle.getToolTipExtractor().extractText(
				feature)); // test that label is set properly
	}
	
	@Ignore
	@Test
	public void testMultipleMouseover() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		MapStyle mapStyle;
		GenomeData genomeData;
		FeatureTextExtractor mouseoverTextExtractor;
		
		SlotStyle slotStyle = null;
		
		SlotItemStyle currItemStyle;
		
		FeatureHolder holder;
		
		String[] mouseover = {
				"mouseover1",
				"mouseover2",
				"mouseover3"
		};
		
		String[] locations = {
				  "start=\"1\" stop=\"2\"",
				  "start=\"2\" stop=\"4\"",
				  "start=\"4\" stop=\"8\""
				  };

		Location[] locationObjs = {
			new RangeLocation(1,2),
			new RangeLocation(2,4),
			new RangeLocation(4,8)
			};
		
		GViewFileData cgviewData;
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\">" +
		"<featureSlot strand=\"direct\">" +
			"<feature label=\"" + mouseover[0] + "\">" +
				"<featureRange " + locations[0] + ">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
			"<feature label=\"" + mouseover[1] + "\">" +
				"<featureRange " + locations[1] + ">"+
				"</featureRange>"+
			"</feature>"+
			"<feature label=\"" + mouseover[2] + "\">" +
				"<featureRange " + locations[2] + ">"+
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		genomeData = cgviewData.getGenomeData();
		
		slotStyle = mapStyle.getDataStyle().getSlotStyle(1);
		
		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		featureHolderStyle = null;
				
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		mouseoverTextExtractor = featureHolderStyle.getToolTipExtractor();
		assertNotNull(mouseoverTextExtractor);
		
		// get features from this style
		holder = genomeData.getAllFeatures(featureHolderStyle);
		
		Iterator<Feature> featureIter = holder.features();
		assertTrue(featureIter.hasNext());

		Feature currentFeaturea = featureIter.next();
		assertNotNull(currentFeaturea);
		handleFeatureForMouseoverMultipleFeatures(locationObjs, currentFeaturea,
				mouseoverTextExtractor, mouseover);
		
		Feature currentFeatureb = featureIter.next();
		assertNotNull(currentFeatureb);
		assertFalse(currentFeaturea.equals(currentFeatureb)); // feature b should not equal feature a
		handleFeatureForMouseoverMultipleFeatures(locationObjs, currentFeatureb,
				mouseoverTextExtractor, mouseover);
		
		
		Feature currentFeaturec = featureIter.next();
		assertNotNull(currentFeaturec);
		assertFalse(currentFeaturec.equals(currentFeatureb)); // feature c should not equal feature b
		assertFalse(currentFeaturec.equals(currentFeaturea)); // or feature a
		handleFeatureForMouseoverMultipleFeatures(locationObjs, currentFeaturec,
				mouseoverTextExtractor, mouseover);
	}
	
	@Test
	public void testOpacity() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		Color featureColor;
		Iterator<SlotItemStyle> styleIter;
		
		// test default opacity
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature color=\"red\">" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		featureColor = (Color)featureHolderStyle.getPaint()[0];
		assertEquals(0xFFFF0000, featureColor.getRGB());
		assertEquals(255, featureColor.getAlpha());
		
		// test 1.0
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature color=\"red\" opacity=\"1.0\">" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		featureColor = (Color)featureHolderStyle.getPaint()[0];
		assertEquals(0xFFFF0000, featureColor.getRGB());
		assertEquals(255, featureColor.getAlpha());
		
		// test 0.0
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature color=\"red\" opacity=\"0.0\">" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		featureColor = (Color)featureHolderStyle.getPaint()[0];
		assertEquals(0x00FF0000, featureColor.getRGB());
		assertEquals(0, featureColor.getAlpha());
	}
	
	@Test
	public void testProportionOfThickness() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		// test proportion of thickness (default)
		featureHolderStyle = performTestForFeatureProperties("");
		assertEquals(1.0, featureHolderStyle.getThickness(), delta);
		
		// test proportion of thickness
		featureHolderStyle = performTestForFeatureProperties("proportionOfThickness=\"0.0\"");
		assertEquals(0.0, featureHolderStyle.getThickness(), delta);
		
		// test proportion of thickness
		featureHolderStyle = performTestForFeatureProperties("proportionOfThickness=\"0.5\"");
		assertEquals(0.5, featureHolderStyle.getThickness(), delta);
		
		// test proportion of thickness
		featureHolderStyle = performTestForFeatureProperties("proportionOfThickness=\"1.0\"");
		assertEquals(1.0, featureHolderStyle.getThickness(), delta);
	}
	
	@Test
	public void testRadiusAdjustement() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		// test radiusAdjustment (default)
		featureHolderStyle = performTestForFeatureProperties("");
		assertEquals(0.0, featureHolderStyle.getHeightAdjust(), delta);
		
		// test radiusAdjustment
		// no proportionOfThickness set, so radiusAdjustment has no effect
		featureHolderStyle = performTestForFeatureProperties("radiusAdjustment=\"0.0\"");
		assertEquals(0.0, featureHolderStyle.getHeightAdjust(), delta);
		
		// test radiusAdjustment
		// no proportionOfThickness set, so radiusAdjustment has no effect
		featureHolderStyle = performTestForFeatureProperties("radiusAdjustment=\"0.5\"");
		assertEquals(0.0, featureHolderStyle.getHeightAdjust(), delta);
		
		// test radiusAdjustment
		featureHolderStyle = performTestForFeatureProperties("proportionOfThickness=\"0.5\" radiusAdjustment=\"0.0\"");
		assertEquals(-1.0, featureHolderStyle.getHeightAdjust(), delta);
		
		// test radiusAdjustment
		featureHolderStyle = performTestForFeatureProperties("proportionOfThickness=\"0.5\" radiusAdjustment=\"0.5\"");
		assertEquals(0.0, featureHolderStyle.getHeightAdjust(), delta);
	}
	
	@Test
	public void testShowLabel() throws IOException, GViewDataParseException
	{
		FeatureHolderStyle featureHolderStyle = null;
		
		// test showLabel (default)
		featureHolderStyle = performTestForFeatureProperties(""); // need to also set label
		assertEquals(true, featureHolderStyle.getLabelStyle().showLabels());
		
		// test showLabel
		featureHolderStyle = performTestForFeatureProperties("label=\"the_label\" showLabel=\"true\""); // need to also set label
		assertEquals(true, featureHolderStyle.getLabelStyle().showLabels());
		
		// test showLabel
		featureHolderStyle = performTestForFeatureProperties("label=\"the_label\" showLabel=\"false\""); // need to also set label
		assertEquals(false, featureHolderStyle.getLabelStyle().showLabels());
	}
	
	@Test
	public void testGlobalLabel() throws IOException, GViewDataParseException
	{		
		FeatureHolderStyle featureHolderStyle = null;
				
		SlotStyle slotStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		
		// test true case
		xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\" globalLabel=\"true\">" +
		"<featureSlot strand=\"direct\" showLabel=\"false\">" +
			"<feature>" +
				"<featureRange start=\"1\" stop=\"2\">"+
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		assertTrue(featureHolderStyle.getLabelStyle().showLabels());
		
		
		// test false case
		xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\" globalLabel=\"false\">" +
		"<featureSlot strand=\"direct\" showLabel=\"true\">" +
			"<feature>" +
				"<featureRange start=\"1\" stop=\"2\">"+
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		assertFalse(featureHolderStyle.getLabelStyle().showLabels());
	}
	
	@Test
	public void testShowShading() throws IOException, GViewDataParseException
	{		
		FeatureHolderStyle featureHolderStyle = null;
		
		// test showShading
		featureHolderStyle = performTestForFeatureProperties("showShading=\"false\"");
		assertEquals(noShading, featureHolderStyle.getShapeEffectRenderer());
		
		// test showShading
		featureHolderStyle = performTestForFeatureProperties("showShading=\"true\"");
		assertEquals(shading, featureHolderStyle.getShapeEffectRenderer());
	}
	
	@Test
	public void testShowShadingInherited() throws IOException, GViewDataParseException
	{		
		FeatureHolderStyle featureHolderStyle = null;
				
		SlotStyle slotStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\" font=\"SansSerif,bold,20\">" +
		"<featureSlot strand=\"direct\" showShading=\"true\">" +
			"<feature>" +
				"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		assertEquals(shading, featureHolderStyle.getShapeEffectRenderer());
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" font=\"SansSerif,bold,20\">" +
				"<featureSlot strand=\"direct\" showShading=\"false\">" +
					"<feature>" +
						"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
						"</featureRange>"+
					"</feature>"+
				"</featureSlot>"+
				"</cgview>");
				
				cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
				slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
				featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
				
				assertEquals(noShading, featureHolderStyle.getShapeEffectRenderer());
	}
	
	/**
	 * Used to check if the feature created in <feature></feature> tags is the same as what would be contained in the created FeatureHolderStyle.
	 * @throws IOException
	 * @throws GViewDataParseException
	 */
	@Test
	public void testFeatureAndFeatureHolderStyle() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		SlotStyle slotStyle = null;
		FeatureHolderStyle featureHolderStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		Sequence sequence;
		FeatureHolder singleFeatureHolder;
		Feature featureFromPredefinedFilter;
		FeatureFilter filterFromHolder;
		FeatureFilter.ByFeature filterFromHolderByFeature;
		Feature featureFromFeatureHolder;
		Iterator<Feature> featureIter;
		
		// test feature defined, and style for that feature defined
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a location for a feature
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		genomeData = cgviewData.getGenomeData();
		assertNotNull(genomeData);
		
		sequence = genomeData.getSequence();
		assertNotNull(sequence);
		assertEquals(1, sequence.countFeatures()); // should be 1 feature on this sequence
		
		// get the single feature that was created on this sequence
		singleFeatureHolder = sequence.filter(new FeatureFilter.ContainedByLocation(new RangeLocation(1,2)));
		featureFromPredefinedFilter = getAndTestForSingleFeatureInFeatureHolder(singleFeatureHolder);
		
		assertNotNull(featureFromPredefinedFilter);
		assertEquals(new RangeLocation(1,2), featureFromPredefinedFilter.getLocation());
		
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		featureIter = genomeData.getAllFeatures(featureHolderStyle).features();
		assertTrue(featureIter.hasNext());
		featureFromFeatureHolder = featureIter.next();
				
		// make sure the two features (from the pre-defined filter and from the feature holder style) are the same
		assertEquals(featureFromPredefinedFilter, featureFromFeatureHolder);
		
		
		// test feature defined, and style for that feature defined
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"4\" stop=\"5\">"+ // need featureRange here, otherwise we won't have a location for a feature
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		genomeData = cgviewData.getGenomeData();
		assertNotNull(genomeData);
		
		sequence = genomeData.getSequence();
		assertNotNull(sequence);
		assertEquals(1, sequence.countFeatures()); // should be 1 feature on this sequence
		
		// get the single feature that was created on this sequence
		singleFeatureHolder = sequence.filter(new FeatureFilter.ContainedByLocation(new RangeLocation(4,5)));
		featureFromPredefinedFilter = getAndTestForSingleFeatureInFeatureHolder(singleFeatureHolder);
		
		assertNotNull(featureFromPredefinedFilter);
		assertEquals(new RangeLocation(4,5), featureFromPredefinedFilter.getLocation());
		
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		
		featureIter = genomeData.getAllFeatures(featureHolderStyle).features();
		assertTrue(featureIter.hasNext());
		featureFromFeatureHolder = featureIter.next();
		
		// make sure the two features (from the pre-defined filter and from the feature holder style) are the same
		assertEquals(featureFromPredefinedFilter, featureFromFeatureHolder);
	}
}
