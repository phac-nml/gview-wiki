package ca.corefacility.gview.test.ioTests.styles;

import java.awt.Color;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.*;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;
import org.w3c.css.sac.Selector;

import ca.corefacility.gview.map.effects.OutlineEffect;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.io.gss.PaintHandler;
import ca.corefacility.gview.style.io.gss.ShapeEffectHandler;
import ca.corefacility.gview.style.io.gss.PaintHandler.UnknownPaintException;
import ca.corefacility.gview.style.io.gss.coders.BackboneCoder;
import ca.corefacility.gview.style.io.gss.coders.GSSWriter;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.style.items.BackboneStyle;

import com.steadystate.css.parser.selectors.ElementSelectorImpl;


public class BackboneCoderTest
{
	private BackboneCoder coder;

	@Before
	public void setup()
	{
		coder = new BackboneCoder();
	}

	@Test(expected=ParseException.class)
	public void testDecodeInvalid() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		MapStyle map1 = new MapStyle();
		Selector selector = new ElementSelectorImpl("backbone");

		//setup parameters
		LexicalUnit currUnit = parser.parsePropertyValue(new InputSource(new StringReader("shape-effect(\"basic\")")));

		coder.decodeProperty(selector, map1, null, "invalid", currUnit, null);
	}

	@Test
	public void testDecode() throws CSSException, IOException, ParseException
	{
		MapStyle map1;

		Parser parser = new com.steadystate.css.parser.SACParserCSS2();

		BackboneStyle workingStyle;
		LexicalUnit currUnit;

		BackboneStyle expectedStyle;

		// setup encoding
		Selector selector;

		map1 = new MapStyle();
		workingStyle = map1.getGlobalStyle().getBackboneStyle();

		selector = new ElementSelectorImpl("backbone");

		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));

		// setup expected style
		expectedStyle = new BackboneStyle(workingStyle);
		expectedStyle.setPaint(Color.red);

		coder.decodeProperty(selector, map1, null, "color", currUnit, null);

		Assert.assertEquals(expectedStyle, workingStyle);

		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("shape-effect(\"basic\")")));

		// setup expected style
		expectedStyle = new BackboneStyle(workingStyle);
		expectedStyle.setShapeEffectRenderer(ShapeEffectRenderer.NO_SELECT_RENDERER);

		coder.decodeProperty(selector, map1, null, "backbone-effect", currUnit, null);

		Assert.assertEquals(expectedStyle, workingStyle);

		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("10.0")));

		// setup expected style
		expectedStyle = new BackboneStyle(workingStyle);
		expectedStyle.setThickness(10.0);

		coder.decodeProperty(selector, map1, null, "thickness", currUnit, null);

		Assert.assertEquals(expectedStyle, workingStyle);


		// another encoding
		map1 = new MapStyle();
		workingStyle = map1.getGlobalStyle().getBackboneStyle();

		selector = new ElementSelectorImpl("backbone");

		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"green\")")));

		// setup expected style
		expectedStyle = new BackboneStyle(workingStyle);
		expectedStyle.setPaint(new Color(0, 128, 0));

		coder.decodeProperty(selector, map1, null, "color", currUnit, null);

		Assert.assertEquals(expectedStyle, workingStyle);

		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("shape-effect(\"outline\")")));

		// setup expected style
		expectedStyle = new BackboneStyle(workingStyle);
		expectedStyle.setShapeEffectRenderer(new OutlineEffect());

		coder.decodeProperty(selector, map1, null, "backbone-effect", currUnit, null);

		Assert.assertEquals(expectedStyle, workingStyle);

		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("15.0")));

		// setup expected style
		expectedStyle = new BackboneStyle(workingStyle);
		expectedStyle.setThickness(15.0);

		coder.decodeProperty(selector, map1, null, "thickness", currUnit, null);

		Assert.assertEquals(expectedStyle, workingStyle);
	}

	@Test
	public void testEncode() throws UnknownPaintException
	{
		MapStyle mapStyle = new MapStyle();

		BackboneStyle backboneStyle = mapStyle.getGlobalStyle().getBackboneStyle();
		String expectedEncoding, actualEncoding;

		StringWriter expectedStringWriter;
		GSSWriter expectedGssWriter;

		StringWriter actualStringWriter;
		GSSWriter actualEncodingGSS;

		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);

		// setup expected values
		expectedGssWriter.startSelector("backbone");
		expectedGssWriter.writeProperty("color", PaintHandler.encode(Color.BLUE));
		expectedGssWriter.writeProperty("thickness", Double.toString(0.5));
		expectedGssWriter.writeProperty("backbone-effect", ShapeEffectHandler.encodeShapeEffect(ShapeEffectRenderer.NO_SELECT_RENDERER));
		expectedGssWriter.endSelector();
		expectedEncoding = expectedStringWriter.toString();

		// setup map
		backboneStyle.setPaint(Color.BLUE);
		backboneStyle.setThickness(0.5);
		backboneStyle.setShapeEffectRenderer(ShapeEffectRenderer.NO_SELECT_RENDERER);

		coder.encodeSelector(mapStyle, null, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
	}
}
