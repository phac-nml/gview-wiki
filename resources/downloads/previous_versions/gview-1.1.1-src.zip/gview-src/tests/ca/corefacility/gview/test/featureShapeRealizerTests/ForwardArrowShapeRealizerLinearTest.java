package ca.corefacility.gview.test.featureShapeRealizerTests;

import static org.junit.Assert.*;

import java.awt.BasicStroke;
import java.awt.Shape;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.impl.SimpleSequence;
import org.biojava.bio.symbol.Location;
import org.biojava.bio.symbol.PointLocation;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.bio.symbol.SymbolList;
import org.biojavax.bio.seq.RichLocation;
import org.biojavax.bio.seq.SimplePosition;
import org.biojavax.bio.seq.SimpleRichLocation;
import org.junit.*;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.layout.feature.ForwardArrowShapeRealizer;
import ca.corefacility.gview.layout.feature.NoArrowShapeRealizer;
import ca.corefacility.gview.layout.prototype.BackboneShape;
import ca.corefacility.gview.layout.prototype.CompositeShape;
import ca.corefacility.gview.layout.prototype.PinnableShape;
import ca.corefacility.gview.layout.prototype.SequencePoint;
import ca.corefacility.gview.layout.sequence.Backbone;
import ca.corefacility.gview.layout.sequence.LocationConverter;
import ca.corefacility.gview.layout.sequence.SlotPath;
import ca.corefacility.gview.layout.sequence.SlotRegion;
import ca.corefacility.gview.layout.sequence.SlotTranslator;
import ca.corefacility.gview.layout.sequence.SlotTranslatorImp;
import ca.corefacility.gview.layout.sequence.circular.BackboneCircular;
import ca.corefacility.gview.layout.sequence.circular.SlotRegionCircular;
import ca.corefacility.gview.layout.sequence.linear.BackboneLinear;
import ca.corefacility.gview.layout.sequence.linear.SlotRegionLinear;
import ca.corefacility.gview.map.event.ZoomEvent;
import ca.corefacility.gview.style.MapStyle;

public class ForwardArrowShapeRealizerLinearTest
{
	private Backbone backbone;

	private double width = 100;

	private LocationConverter locationConverter;
	
	private int sequenceLength = 100;
		
	private SlotRegion slotRegion;
	
	@Before
	public void setup()
	{
		GenomeData data = null;
		SymbolList list = new BlankSymbolList(sequenceLength);
		Sequence seq = new SimpleSequence(list, null, null, null);

		data = GenomeDataFactory.createGenomeData(seq);
		locationConverter = new LocationConverter(data);

		backbone = new BackboneLinear(new LocationConverter(data), width);
		
		MapStyle mapStyle = new MapStyle();
		mapStyle.getGlobalStyle().getBackboneStyle().setThickness(2.0);
		mapStyle.getGlobalStyle().setSlotSpacing(0.0);
		mapStyle.getGlobalStyle().getRulerStyle().setMajorTickLength(1.0);
		mapStyle.getGlobalStyle().getRulerStyle().setMinorTickLength(1.0);
		mapStyle.getDataStyle().createSlotStyle(1).setThickness(1.0);
		SlotTranslator slots = new SlotTranslatorImp(mapStyle);
		
		slotRegion = new SlotRegionLinear(backbone, slots);
	}
	
	@Test
	public void testSinglePointFeature()
	{
		double arrowLength = 5.0;
		FeatureShapeRealizer shapeRealizer = new ForwardArrowShapeRealizer(arrowLength);
		
		SlotPath path = slotRegion.getSlotPath(1);
		Location location = new PointLocation(0);
		double thickness = 1.0;
		double heightAdjust = 0.0;
		
		Shape shape;
		Rectangle2D bounds;
		backbone.eventOccured(new ZoomEvent(1.0, new Point2D.Double(), this));
		
		shape = shapeRealizer.createFeaturePrototype(locationConverter, path, location, thickness, heightAdjust);
		assertTrue(shape instanceof BackboneShape);
		assertFalse(shape instanceof CompositeShape); // single point should not be composite shape
		
		bounds = shape.getBounds2D();
		
		// bounds should contain an arrowhead centered at 0
		// so bounds length should at least go from -arrowLength=5.0/2 to +arrowLength=5.0/2 
		// height should go from bottom of slot to top (thickness is 1.0, so height should be 1.0)
		assertTrue("arrowLength=" + arrowLength + " <= bounds.getWidth()=" + bounds.getWidth(), arrowLength <= bounds.getWidth());
		assertTrue("height=" + 1.0 + " <= bounds.getHeight()=" + bounds.getHeight(), 1.0 <= bounds.getHeight());
		
		// middle of slot 1 is backboneThickness/2 + slotHeight/2 = 2.0/2 + 1.0/2 = 1.5
		// height above backbone is 50 to middle of backbone + 1.5
		double x,y;
		
		// test middle of arrowhead
		x=-50.0;
		y=-1.5;
		assertTrue("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// left edge
		x=-50.0 - arrowLength/2.0 + 0.001;
		y=-1.5;
		assertTrue("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// beyond left edge
		x=-50.0 - arrowLength/2.0 - 0.001;
		y=-1.5;
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// right edge
		x=-50.0 + arrowLength/2.0 - 0.001;
		y=-1.5;
		assertTrue("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// beyond right edge
		x=-50.0 + arrowLength/2.0 + 0.001;
		y=-1.5;
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
	}
	
	@Test
	public void testRangeLocationFeature()
	{
		FeatureShapeRealizer shapeRealizer = new NoArrowShapeRealizer();
		
		SlotPath path = slotRegion.getSlotPath(1);
		Location location = new RangeLocation(0,25); // 1/4
		double thickness = 1.0;
		double heightAdjust = 0.0;
		
		Shape shape;
		Rectangle2D bounds;
		backbone.eventOccured(new ZoomEvent(1.0, new Point2D.Double(), this));
		
		shape = shapeRealizer.createFeaturePrototype(locationConverter, path, location, thickness, heightAdjust);
		assertTrue(shape instanceof BackboneShape);
		
		bounds = shape.getBounds2D();
		
		assertTrue("width=" + 25 + " <= bounds.getWidth()=" + bounds.getWidth(), 25 <= bounds.getWidth());
		assertTrue("height=" + 1.0 + " <= bounds.getHeight()=" + bounds.getHeight(), 1.0 <= bounds.getHeight());
		
		// middle of slot 1 is backboneThickness/2 + slotHeight/2 = 2.0/2 + 1.0/2 = 1.5
		double x,y;
		x=-50.0 + 0.001;
		y=-1.5;
		// test whether the arc contains certain points
		assertTrue("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just above of height of slot (2.0)
		x=-50.0 + 0.001;
		y=2.01;
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just below height of slot (1.0)
		x=-50.0 + 0.001;
		y=0.99;
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just left of slot
		x=-50.0 - 0.001;
		y=-1.5;
		// test whether the arc contains certain points
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		
		//// end
		x=-25.0 - 0.001;
		y=-1.5;
		// test whether the arc contains certain points
		assertTrue("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just above of height of slot (2.0)
		x=-25.0 - 0.001;
		y=-2.01;
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just below height of slot (1.0)
		x=-25.0 - 0.001;
		y=-0.99;
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just right of slot
		x=-25.0 + 0.001;
		y=-1.5;
		// test whether the arc contains certain points
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should contain in middle of arc in first quadrant (base location 12.5)
		double x_base12_5 = -50 + 12.5;
		x=x_base12_5;
		y=-1.5;
		assertTrue("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
	}
	
	@Test
	public void testNonContiguousRangeLocationFeature()
	{
		FeatureShapeRealizer shapeRealizer = new NoArrowShapeRealizer();
		
		SlotPath path = slotRegion.getSlotPath(1);
		Location location = (new RangeLocation(0,10)).union(new RangeLocation(15,25));
		double thickness = 1.0;
		double heightAdjust = 0.0;
		
		Shape shape;
		Rectangle2D bounds;
		backbone.eventOccured(new ZoomEvent(1.0, new Point2D.Double(), this));
		
		shape = shapeRealizer.createFeaturePrototype(locationConverter, path, location, thickness, heightAdjust);
		assertTrue(shape instanceof BackboneShape);
		
		bounds = shape.getBounds2D();
		
		assertTrue("width=" + 25 + " <= bounds.getWidth()=" + bounds.getWidth(), 25 <= bounds.getWidth());
		assertTrue("height=" + 1.0 + " <= bounds.getHeight()=" + bounds.getHeight(), 1.0 <= bounds.getHeight());
		
		// middle of slot 1 is backboneThickness/2 + slotHeight/2 = 2.0/2 + 1.0/2 = 1.5
		double x,y;
		x=-50.0 + 0.001;
		y=-1.5;
		// test whether the arc contains certain points
		assertTrue("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just above of height of slot (2.0)
		x=-50.0 + 0.001;
		y=2.01;
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just below height of slot (1.0)
		x=-50.0 + 0.001;
		y=0.99;
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just left of slot
		x=-50.0 - 0.001;
		y=-1.5;
		// test whether the arc contains certain points
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		
		//// end
		x=-25.0 - 0.001;
		y=-1.5;
		// test whether the arc contains certain points
		assertTrue("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just above of height of slot (2.0)
		x=-25.0 - 0.001;
		y=-2.01;
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just below height of slot (1.0)
		x=-25.0 - 0.001;
		y=-0.99;
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain just right of slot
		x=-25.0 + 0.001;
		y=-1.5;
		// test whether the arc contains certain points
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
		
		// should not contain in middle of arc in first quadrant (base location 12.5)
		double x_base12_5 = -50 + 12.5;
		x=x_base12_5;
		y=-1.5;
		assertFalse("shape.contains(x,y=(" + x + "," + y +"))", shape.contains(x,y));
	}
}
