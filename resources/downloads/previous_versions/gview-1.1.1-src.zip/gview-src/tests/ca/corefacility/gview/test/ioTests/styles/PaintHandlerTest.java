package ca.corefacility.gview.test.ioTests.styles;


import java.awt.Color;
import java.awt.GradientPaint;
import java.io.IOException;
import java.io.StringReader;

import org.junit.Assert;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.io.gss.PaintHandler;
import ca.corefacility.gview.style.io.gss.TextExtractorHandler;
import ca.corefacility.gview.style.io.gss.PaintHandler.UnknownPaintException;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.style.io.gss.exceptions.UnknownFunctionException;
import ca.corefacility.gview.textextractor.AnnotationExtractor;
import ca.corefacility.gview.textextractor.FeatureTextExtractor;
import ca.corefacility.gview.textextractor.GeneTextExtractor;
import ca.corefacility.gview.textextractor.LocationExtractor;
import ca.corefacility.gview.textextractor.SymbolsExtractor;

public class PaintHandlerTest
{
	@Test
	public void encodeTests() throws UnknownPaintException
	{
		// test constants
		Assert.assertEquals("color(\"red\")", PaintHandler.encode(Color.red));
		Assert.assertEquals("color(\"blue\")", PaintHandler.encode(Color.blue));
		Assert.assertEquals("color(\"green\")", PaintHandler.encode(new Color(0, 128, 0)));
		Assert.assertEquals("color(\"orange\")", PaintHandler.encode(new Color(255, 153, 0)));
		Assert.assertEquals("color(\"yellow\")", PaintHandler.encode(Color.yellow));
		Assert.assertEquals("color(\"purple\")", PaintHandler.encode(new Color(128, 0, 128)));
		Assert.assertEquals("color(\"black\")", PaintHandler.encode(Color.black));
		Assert.assertEquals("color(\"white\")", PaintHandler.encode(Color.white));
		Assert.assertEquals("color(\"gray\")", PaintHandler.encode(Color.gray));
		Assert.assertEquals("color(\"fuchsia\")", PaintHandler.encode(new Color(255, 0, 255)));
		Assert.assertEquals("color(\"none\")", PaintHandler.encode(null));
		
		// test conversion of arbitrary color
		Assert.assertEquals("color(1,2,3,4)", PaintHandler.encode(new Color(1, 2, 3, 4)));
		Assert.assertEquals("color(5,6,7,8)", PaintHandler.encode(new Color(5,6,7,8)));
	}
	
	@Test(expected=UnknownPaintException.class)
	public void encodeNonColorPaintTest() throws UnknownPaintException
	{
		PaintHandler.encode(new GradientPaint(0, 0, Color.red, 0, 0, Color.blue));
	}
	
	@Test
	public void decodeTest() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		InputSource currEncodedString;
		LexicalUnit currUnit;
				
		currEncodedString = new InputSource(new StringReader("color(\"red\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(Color.red, PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(\"blue\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(Color.blue, PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(\"green\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(new Color(0, 128, 0), PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(\"orange\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(new Color(255, 153, 0), PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(\"yellow\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(Color.yellow, PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(\"purple\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(new Color(128, 0, 128), PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(\"black\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(Color.black, PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(\"white\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(Color.white, PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(\"gray\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(Color.gray, PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(\"fuchsia\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(new Color(255, 0, 255), PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(\"none\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertNull(PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(1,2,3,4)"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(new Color(1,2,3,4), PaintHandler.decode(currUnit));
		
		currEncodedString = new InputSource(new StringReader("color(5,6,7,8)"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(new Color(5,6,7,8), PaintHandler.decode(currUnit));
	}
	
	@Test(expected=NullPointerException.class)
	public void testNullParameter() throws ParseException
	{
		PaintHandler.decode(null);
	}
	
	@Test(expected=UnknownFunctionException.class)
	public void testUnknownString() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit unit = parser.parsePropertyValue(new InputSource(new StringReader("paint(\"red\")")));
		PaintHandler.decode(unit);
	}
}
