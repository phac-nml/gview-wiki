package ca.corefacility.gview.test.ioTests.cgviewxml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;

import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureHolder;
import org.biojava.bio.symbol.Location;
import org.biojava.bio.symbol.RangeLocation;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.GViewFileData;
import ca.corefacility.gview.data.readers.GViewFileReader;
import ca.corefacility.gview.data.readers.cgview.CGViewXMLReader;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.LabelStyle;
import ca.corefacility.gview.style.datastyle.SlotItemStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.textextractor.FeatureTextExtractor;

public class LabelsTest
{
	private CGViewXMLReader cgviewReader;
	private double delta = 0.0000001;
	
	@Before
	public void setup()
	{
		cgviewReader = new CGViewXMLReader();
	}
	
	/**
	 * Given the passed property in the cgview tag (for a label test), gets the corresponding LabelStyle
	 * @param cgviewProperty  The cgview property string to test out.
	 * @return  The corresponding LabelStyle.
	 * @throws GViewDataParseException 
	 * @throws IOException 
	 */
	private LabelStyle getStyleForLabelTest(String cgviewProperty) throws IOException, GViewDataParseException
	{
		LabelStyle labelStyle = null;
		
		SlotStyle slotStyle = null;
		FeatureHolderStyle featureHolderStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\" " + cgviewProperty + ">" +
		"<featureSlot strand=\"direct\">" +
			"<feature label=\"the_label\">" +
				"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		slotStyle = cgviewData.getMapStyle().getDataStyle().getSlotStyle(1);
		featureHolderStyle = getAndTestForFeatureHolderStyle(slotStyle);
		labelStyle = featureHolderStyle.getLabelStyle();
		
		return labelStyle;
	}
	
	/**
	 * Tests for and returns the single FeatureHolderStyle within the passed slot.  Assumes there exists only 1 FeatureHolderStyle.
	 * @param slotStyle  The SlotStyle to extract the FeatureHolderStyle from.
	 * @return  The first FeatureHolderStyle encountered.
	 */
	private FeatureHolderStyle getAndTestForFeatureHolderStyle(SlotStyle slotStyle)
	{
		FeatureHolderStyle holderStyle = null;
		
		assertNotNull(slotStyle);
		
		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		assertTrue(styleIter.hasNext());
		
		while (styleIter.hasNext() && holderStyle == null)
		{
			SlotItemStyle currItemStyle = styleIter.next();
			assertNotNull(currItemStyle);
			
			if (currItemStyle instanceof FeatureHolderStyle)
			{
				holderStyle = (FeatureHolderStyle)currItemStyle;
			}
		}
		
		assertNotNull(holderStyle);
		
		return holderStyle;
	}
	
	@Test
	public void testCGViewLabels() throws IOException, GViewDataParseException
	{
		LabelStyle labelStyle;
		
		// globalLabel
		labelStyle = getStyleForLabelTest("globalLabel=\"false\"");
		assertEquals(false, labelStyle.showLabels());
		
		// globalLabel
		labelStyle = getStyleForLabelTest("globalLabel=\"true\"");
		assertEquals(true, labelStyle.showLabels());
		
		// globalLabel
		labelStyle = getStyleForLabelTest("globalLabel=\"auto\"");
		assertEquals(true, labelStyle.showLabels());
		
		// globalLabelColor
		labelStyle = getStyleForLabelTest("globalLabelColor=\"white\"");
		assertEquals(Color.white, labelStyle.getTextPaint());
		
		// globalLabelColor
		labelStyle = getStyleForLabelTest("globalLabelColor=\"blue\"");
		assertEquals(Color.blue, labelStyle.getTextPaint());
		
		// labelFont
		labelStyle = getStyleForLabelTest("labelFont=\"SansSerif, plain, 18\"");
		assertEquals(new Font("SansSerif", Font.PLAIN, 18), labelStyle.getFont());
		
		// labelFont
		labelStyle = getStyleForLabelTest("labelFont=\"SansSerif, bold, 11\"");
		assertEquals(new Font("SansSerif", Font.BOLD, 11), labelStyle.getFont());
		
		// labelLineLength
		
		// labelLineThickness
		labelStyle = getStyleForLabelTest("labelLineThickness=\"10\"");
		assertEquals(10, labelStyle.getLineThickness(), delta);
		
		// labelLineThickness
		labelStyle = getStyleForLabelTest("labelLineThickness=\"15.5\"");
		assertEquals(15.5, labelStyle.getLineThickness(), delta);
		
		// labelPlacementQuality?
		
		// labelsToKeep?
		
		// useColoredLabelBackgrounds
		labelStyle = getStyleForLabelTest("useColoredLabelBackgrounds=\"true\" globalLabelColor=\"blue\""); // need to set globalLabelColor for this test
		assertEquals(Color.white, labelStyle.getTextPaint()); // text color should be "white" on a "globalLabelColor" background
		assertEquals(Color.blue, labelStyle.getBackgroundPaint());
		assertFalse(labelStyle.isAutoLabelLinePaint());
		assertEquals(Color.blue, labelStyle.getLabelLinePaint());
		
		// useColoredLabelBackgrounds
		labelStyle = getStyleForLabelTest("useColoredLabelBackgrounds=\"true\" globalLabelColor=\"yellow\""); // need to set globalLabelColor for this test
		assertEquals(Color.white, labelStyle.getTextPaint()); // text color should be "white" on a "globalLabelColor" background
		assertEquals(Color.yellow, labelStyle.getBackgroundPaint());
		assertFalse(labelStyle.isAutoLabelLinePaint());
		assertEquals(Color.yellow, labelStyle.getLabelLinePaint());
		
		// useColoredLabelBackgrounds
		labelStyle = getStyleForLabelTest("useColoredLabelBackgrounds=\"false\" globalLabelColor=\"yellow\""); // need to set globalLabelColor for this test
		assertEquals(Color.yellow, labelStyle.getTextPaint());
		
		// useColoredLabelBackgrounds
		labelStyle = getStyleForLabelTest("useColoredLabelBackgrounds=\"false\" globalLabelColor=\"blue\""); // need to set globalLabelColor for this test
		assertEquals(Color.blue, labelStyle.getTextPaint());
		
		// useInnerLabels
	}
	
	private void handleFeatureForLabelMultipleFeatures(Location[] locationObjs,
			Feature currentFeature, FeatureTextExtractor labelTextExtractor, String[] labels)
	{	
		boolean notHandled = true;
		
		// handle the correct feature
		for (int i = 0; i < locationObjs.length && notHandled; i++)
		{
			Location currentLocationObj = currentFeature.getLocation();
			if (locationObjs[i].equals(currentLocationObj)) // if this is location 1
			{
				// make sure label is set properly for FeatureHolderStyle for the feature
				assertEquals(labels[i], labelTextExtractor.extractText(
						currentFeature)); // test that label is set properly
				
				notHandled = false;
			}

		}
		
		if (notHandled)
		{
			fail("Location=" + currentFeature.getLocation() + " not one of the valid options.");
		}
	}
	
	/**
	 * Test the case of having multiple features, with different labels.  Make sure label text gets set correctly.
	 * @throws IOException
	 * @throws GViewDataParseException
	 */
	@Test
	public void testFeaturePropertiesLabelMultipleFeatures() throws IOException, GViewDataParseException
	{
		SlotStyle slotStyle = null;
		
		SlotItemStyle currItemStyle;
		
		GViewFileData cgviewData;
		GenomeData genomeData;
		MapStyle mapStyle;
		
		FeatureHolder featureHolder = null;
		FeatureTextExtractor labelTextExtractor = null;
		
		String[] locations = {"start=\"1\" stop=\"2\"",
							  "start=\"2\" stop=\"4\"",
							  "start=\"4\" stop=\"8\""};
		
		Location[] locationObjs = {
				new RangeLocation(1,2),
				new RangeLocation(2,4),
				new RangeLocation(4,8)
				};
		
		String[] labels = {
				"label(1,2)",
				"label(2,4)",
				"label(4,8)"
				};

		
		StringReader xmlReader = new StringReader(
		"<cgview sequenceLength=\"10\">" +
		"<featureSlot strand=\"direct\">" +
			"<feature label=\"" + labels[0] + "\">" +
				"<featureRange " + locations[0] + ">"+ // need featureRange here, otherwise we won't have a FeatureHolderStyle created
				"</featureRange>"+
			"</feature>"+
			"<feature label=\"" + labels[1] + "\">" +
				"<featureRange " + locations[1] + ">"+
				"</featureRange>"+
			"</feature>"+
			"<feature label=\"" + labels[2] + "\">" +
				"<featureRange " + locations[2] + ">"+
			"</featureRange>"+
		"</feature>"+
		"</featureSlot>"+
		"</cgview>");
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		genomeData = cgviewData.getGenomeData();
		
		slotStyle = mapStyle.getDataStyle().getSlotStyle(1);
		
		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		FeatureHolderStyle featureHolderStyle = null;
				
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		labelTextExtractor = featureHolderStyle.getLabelStyle().getLabelExtractor();
		assertNotNull(labelTextExtractor);
		
		// get features from this style
		featureHolder = genomeData.getAllFeatures(featureHolderStyle);
		
		Iterator<Feature> featureIter = featureHolder.features();
		assertTrue(featureIter.hasNext());

		Feature currentFeaturea = featureIter.next();
		assertNotNull(currentFeaturea);
		handleFeatureForLabelMultipleFeatures(locationObjs, currentFeaturea,
				labelTextExtractor, labels);
		
		Feature currentFeatureb = featureIter.next();
		assertNotNull(currentFeatureb);
		assertFalse(currentFeaturea.equals(currentFeatureb)); // feature b should not equal feature a
		handleFeatureForLabelMultipleFeatures(locationObjs, currentFeatureb,
				labelTextExtractor, labels);
		
		
		Feature currentFeaturec = featureIter.next();
		assertNotNull(currentFeaturec);
		assertFalse(currentFeaturec.equals(currentFeatureb)); // feature c should not equal feature b
		assertFalse(currentFeaturec.equals(currentFeaturea)); // or feature a
		handleFeatureForLabelMultipleFeatures(locationObjs, currentFeaturec,
				labelTextExtractor, labels);
	}
}
