package ca.corefacility.gview.test.translatetests;

import static org.junit.Assert.*;

import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Path2D;

import org.junit.Ignore;
import org.junit.Test;

import ca.corefacility.gview.utils.geom.Arc2DPrecision;
import ca.corefacility.gview.utils.geom.CircularUtils;

/**
 * Tests to make sure that the Arc2DPrecision class keeps the maximum error difference in the radius
 * 	for circles to a minimum.
 * @author aaron
 *
 */
public class Arc2DPrecisionTest
{
	private final static double acceptableError = 0.01;
	
	private final static AffineTransform MIRROR_Y = new AffineTransform(1,0,0,-1,0,0);
	
	private static Shape createPathFromShape(Shape s)
	{
		Path2D arcPath = new Path2D.Double();
		// convert arc to Path2D
		arcPath.append(s, true);
		arcPath.closePath();
		
		return arcPath;
	}
	
	// creates an arc by correctly drawing clockwise
	private Shape createArcClockwiseNormal(double radius, double startAngleDeg, double extentAngleDeg, int type)
	{
		// we invert start angle, draw arc, then invert arc so start/end points are correct
		
		Arc2D arc = null;
		
		startAngleDeg = -startAngleDeg;
		
		// the height of the bounding box of the arc
		double height = radius*2;
		
		// width should be same as height
		double width = height;
		
		// upper left corner of bounding box
		double boundsX = -radius;
		double boundsY = -radius;
		
		// defines the arc to draw
		arc = new Arc2D.Double(boundsX, boundsY, width, height, startAngleDeg,
								extentAngleDeg, type);
		
		return MIRROR_Y.createTransformedShape(arc);
	}
	
	// creates an arc by correctly drawing counter-clockwise
	private static Shape createArcCounterClockwiseNormal(double radius, double startAngleDeg, double extentAngleDeg, int type)
	{		
		// the height of the bounding box of the arc
		double height = radius*2;
		
		// width should be same as height
		double width = height;
		
		// upper left corner of bounding box
		double boundsX = -radius;
		double boundsY = -radius; // this shouldn't be negative, but appears to fix y-coord problem
		
		// defines the arc to draw
		return new Arc2D.Double(boundsX, boundsY, width, height, startAngleDeg,
								extentAngleDeg, type);
	}
	
	// this shows how using normal Arc2D results in very high errors
	@Ignore
	@Test
	public void testFullNormalArcAdjust()
	{		
		final int type = Arc2D.CHORD;
		
		double realRadius, startAngleDeg, extentAngleDeg, acceptableError, actualError;
		Shape arcShape;
		Shape fullCircle;
		
		startAngleDeg = 0;
		extentAngleDeg = 360;
		
		// test at radius
		realRadius = 5.0;
		arcShape = createArcCounterClockwiseNormal(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		System.out.println("radius=" + realRadius + " maxError=" + actualError);
		
		
		// test at radius
		realRadius = 50;
		arcShape = createArcCounterClockwiseNormal(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		System.out.println("radius=" + realRadius + " maxError=" + actualError);
		
		// test at radius
		realRadius = 500;
		arcShape = createArcCounterClockwiseNormal(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		System.out.println("radius=" + realRadius + " maxError=" + actualError);
		
		
		// test at radius
		realRadius = 5000;
		arcShape = createArcCounterClockwiseNormal(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		System.out.println("radius=" + realRadius + " maxError=" + actualError);
		
		// test at radius
		realRadius = 50000;
		arcShape = createArcCounterClockwiseNormal(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		System.out.println("radius=" + realRadius + " maxError=" + actualError);
	}
	
	@Test
	public void testFullPartialArcAdjust()
	{		
		final int type = Arc2D.PIE;
		
		double realRadius, startAngleDeg, extentAngleDeg, actualError;
		Shape arcShape;
		Shape circle;
		
		startAngleDeg = 0;
		extentAngleDeg = 90;
				
		// test counter clockwise
		realRadius = 0.05;
		arcShape = CircularUtils.createArcCounterClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		circle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(circle, realRadius, 1.0f, 89.0f);
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		// test clockwise
		realRadius = 0.05;
		arcShape = CircularUtils.createArcClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		circle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(circle, realRadius, 271.0f, 359.0f);
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		// test counter clockwise
		realRadius = 5e8;
		arcShape = CircularUtils.createArcCounterClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		circle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(circle, realRadius, 1.0f, 89.0f);
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		// test clockwise
		realRadius = 5e8;
		arcShape = CircularUtils.createArcClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		circle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(circle, realRadius, 271.0f, 359.0f);
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
	}
	
	@Test
	public void testFullArcAdjust()
	{		
		final int type = Arc2D.CHORD;
		
		double realRadius, startAngleDeg, extentAngleDeg, actualError;
		Shape arcShape;
		Shape fullCircle;
		
		startAngleDeg = 0;
		extentAngleDeg = 360;
				
		// test counter clockwise
		realRadius = 0.05;
		arcShape = CircularUtils.createArcCounterClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		// test clockwise
		realRadius = 0.05;
		arcShape = CircularUtils.createArcClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		
		// test counter clockwise
		realRadius = 50;
		arcShape = CircularUtils.createArcCounterClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		// test clockwise
		realRadius = 50;
		arcShape = CircularUtils.createArcClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		// test counter clockwise
		realRadius = 50000;
		arcShape = CircularUtils.createArcCounterClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		// test clockwise
		realRadius = 50000;
		arcShape = CircularUtils.createArcClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		
		// test counter clockwise
		realRadius = 5e6;
		arcShape = CircularUtils.createArcCounterClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		// test clockwise
		realRadius = 5e6;
		arcShape = CircularUtils.createArcClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		
		// test counter clockwise
		realRadius = 5e8;
		arcShape = CircularUtils.createArcCounterClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
		
		// test clockwise
		realRadius = 5e8;
		arcShape = CircularUtils.createArcClockwise(realRadius, startAngleDeg, extentAngleDeg, type);
		fullCircle = createPathFromShape(arcShape);
		actualError = determineMaxRadiusError(fullCircle, realRadius,
				(float)startAngleDeg, (float)(startAngleDeg + extentAngleDeg));
		assertTrue(actualError + " <= " + acceptableError, actualError <= acceptableError);
	}
	
	/**
	 * Determines the maximum error in the passed circles radius
	 * @param circle  The circle to check
	 * @param realRadius  The real radius of the circle
	 * @param startAngle  The starting angle to check (in degrees)
	 * @param endAngle  The ending angle to check (in degrees), startAngle < endAngle
	 * @return
	 */
	public static double determineMaxRadiusError(Shape circle, double realRadius, float startAngle, float endAngle)
	{
		double radiusError = 0;
		
		double degInc = 1;
		double acceptableErrorPrecision = 1e-7;
		for (double deg = startAngle; deg < endAngle; deg += degInc)
		{				
			double radiusShapeFullC = determineRadiusOfTransition(circle, realRadius, deg*(Math.PI/180), acceptableErrorPrecision);
			
			double diffRad = Math.abs(radiusShapeFullC-realRadius);
			if (diffRad > radiusError)
			{
				radiusError = diffRad;
			}
		}
		
		return radiusError;
	}
	
	/**
	 * Determines the actual radius of the passed arc (as a shape).  Does this by starting from some value lower
	 * 	than approxRad, and incrementing until we hit a point where shape.contains() will return false.
	 * @param s  The circular arc (as a shape) to check.
	 * @param approxRad  The approximate radius of this shape.
	 * @param theta  The angle (in radians) to check the radius along
	 * @param error  The acceptable error.
	 * @return  The actual radius of the shape, or -1 if passed radius not in shape.
	 * 	or -2 if we never hit a point where we transition from inside to outside shape.
	 */
	private static double determineRadiusOfTransition(Shape s, double approxRad, double theta, double error)
	{	
		double lowerRad = approxRad - approxRad/100;
		double upperRad = approxRad + approxRad/10;
		
		double negsintheta = -Math.sin(theta); // want negative as y-coords go up in negative direction
		double costheta = Math.cos(theta); 
		
		double x,y;
		
		if (!s.contains(lowerRad*costheta, lowerRad*negsintheta))
		{
			System.err.println("warning, passed radius=" + approxRad + " not ever in shape ");
			return -1;
		}
		else if (s.contains(upperRad*costheta, upperRad*negsintheta))
		{
			System.err.println("warning, upperRadius not high enough (still in shape)");
			return -1;
		}
		else
		{
			// perform binary search to find cross over point
			
			double currUpperBound = upperRad;
			double currLowerBound = lowerRad;
			double currEstimate = currLowerBound + (currUpperBound-currLowerBound)/2.0;
			double currError = (currUpperBound-currLowerBound)/2.0;
			
			// while our current error on the estimate is not small enough
			while (currError > error)
			{
				x = currEstimate*costheta;
				y = currEstimate*negsintheta;
				
				if (s.contains(x, y)) // (x,y) in shape, so currEstimate is below transition
				{
					currLowerBound = currEstimate;
				}
				else // (x,y) not in shape, so currEstimate is above transition
				{
					currUpperBound = currEstimate;
				}
				
				currError = (currUpperBound-currLowerBound)/2.0;
				currEstimate = currLowerBound + (currUpperBound-currLowerBound)/2.0;
			}
			
			currEstimate = ((long)(currEstimate/error))*error;
			
			return currEstimate;
		}
	}

}
