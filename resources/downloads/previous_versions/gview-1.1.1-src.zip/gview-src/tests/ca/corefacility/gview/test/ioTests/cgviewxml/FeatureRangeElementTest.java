package ca.corefacility.gview.test.ioTests.cgviewxml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;

import org.biojava.bio.Annotation;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.FeatureHolder;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.symbol.Location;
import org.biojava.bio.symbol.RangeLocation;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.GViewFileData;
import ca.corefacility.gview.data.readers.GViewFileReader;
import ca.corefacility.gview.data.readers.cgview.CGViewXMLReader;
import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.map.effects.OutsideEffect;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.SlotItemStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;

public class FeatureRangeElementTest
{
	private CGViewXMLReader cgviewReader;
	private double delta = 0.0000001;
	
	private static final ShapeEffectRenderer noShading = ShapeEffectRenderer.NO_SELECT_RENDERER;
	private static final ShapeEffectRenderer shading = new OutsideEffect(new Color(0,0,0,128));
	
	@Before
	public void setup()
	{
		cgviewReader = new CGViewXMLReader();
	}
	
	/**
	 * Checks if the locations defined in <featureRange></featureRange> tags are properly set as the location for the Feature object in biojava
	 * @throws IOException
	 * @throws GViewDataParseException
	 */
	@Test
	public void testFeatureRangeLocations() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		Sequence sequence;
		
		Location expectedLocation;
		FeatureHolder singleFeatureHolder;
		Feature feature;

		// test single feature location
		expectedLocation = new RangeLocation(1,2);
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\">"+ // need featureRange here, otherwise we won't have a location for a feature
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		genomeData = cgviewData.getGenomeData();
		assertNotNull(genomeData);
		
		sequence = genomeData.getSequence();
		assertNotNull(sequence);
		assertEquals(1, sequence.countFeatures()); // should be 1 feature on this sequence
		
		// get the single feature that was created on this sequence
		singleFeatureHolder = sequence.filter(new FeatureFilter.ContainedByLocation(new RangeLocation(1,2)));
		feature = getAndTestForSingleFeatureInFeatureHolder(singleFeatureHolder);
		
		assertNotNull(feature);
		assertEquals(expectedLocation, feature.getLocation());
		
		
		// test single feature location
		expectedLocation = new RangeLocation(5,10);
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"5\" stop=\"10\">"+ // need featureRange here, otherwise we won't have a location for a feature
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		genomeData = cgviewData.getGenomeData();
		assertNotNull(genomeData);
		
		sequence = genomeData.getSequence();
		assertNotNull(sequence);
		assertEquals(1, sequence.countFeatures()); // should be 1 feature on this sequence
		
		// get the single feature that was created on this sequence
		singleFeatureHolder = sequence.filter(new FeatureFilter.ContainedByLocation(new RangeLocation(5,10)));
		feature = getAndTestForSingleFeatureInFeatureHolder(singleFeatureHolder);
		
		assertNotNull(feature);
		assertEquals(expectedLocation, feature.getLocation());
		

	}
	
	// make sure that multiple feature ranges are treated as multiple features
	@Test
	public void testMultipleFeatureRanges() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		Sequence sequence;
		
		Location expectedLocation;
		FeatureHolder singleFeatureHolder;
		Feature feature;
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
							"<featureRange start=\"4\" stop=\"7\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		genomeData = cgviewData.getGenomeData();
		assertNotNull(genomeData);
		
		sequence = genomeData.getSequence();
		assertNotNull(sequence);
		assertEquals(2, sequence.countFeatures()); // should be 2 features on this sequence
		
		// get the 1st feature on the sequence
		expectedLocation = new RangeLocation(1,2);
		singleFeatureHolder = sequence.filter(new FeatureFilter.ContainedByLocation(expectedLocation));
		feature = getAndTestForSingleFeatureInFeatureHolder(singleFeatureHolder);
		
		assertNotNull(feature);
		assertEquals(expectedLocation, feature.getLocation());
		
		// get the 2nd feature on the sequence
		expectedLocation = new RangeLocation(4,7);
		singleFeatureHolder = sequence.filter(new FeatureFilter.ContainedByLocation(expectedLocation));
		feature = getAndTestForSingleFeatureInFeatureHolder(singleFeatureHolder);
		
		assertNotNull(feature);
		assertEquals(expectedLocation, feature.getLocation());
	}
	
	// make sure that multiple feature ranges are treated as multiple features
	// test extraction of features through a FeatureHolderStyle object
	@Test
	public void testMultipleFeatureRangeStyles() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle = null;
		
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		StringReader xmlReader;
		Sequence sequence;
		
		Location[] expectedLocations = {
				new RangeLocation(1,2),
				new RangeLocation(4,7)
			};
		
		FeatureHolder featureHolder;
		Feature feature1, feature2;
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
							"<featureRange start=\"4\" stop=\"7\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		genomeData = cgviewData.getGenomeData();
		assertNotNull(genomeData);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);
		
		sequence = genomeData.getSequence();
		assertNotNull(sequence);
		assertEquals(2, sequence.countFeatures()); // should be 2 features on this sequence
		
		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		// get features from this style
		featureHolder = genomeData.getAllFeatures(featureHolderStyle);
		
		Iterator<Feature> featureIter = featureHolder.features();
		assertTrue(featureIter.hasNext());
		
		feature1 = featureIter.next();
		assertTrue(testFeatureForMultipleRangeElements(feature1, expectedLocations));
		
		assertTrue(featureIter.hasNext());
		feature2 = featureIter.next();
		assertFalse(feature1.equals(feature2));
		assertTrue(testFeatureForMultipleRangeElements(feature2, expectedLocations));
	}
	
	@Test
	public void testFeatureRangeStylesDefault() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertTrue(featureHolderStyle.getLabelStyle().showLabels());
	}
	
	@Test
	public void testFeatureRangeStyles() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" color=\"red\" decoration=\"arc\" "+
							"font=\"SansSerif,bold,16\" proportionOfThickness=\"0.5\" " +
							"radiusAdjustment=\"0.25\" showLabel=\"false\" showShading=\"false\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertEquals(Color.red, featureHolderStyle.getPaint()[0]);
		assertEquals(FeatureShapeRealizer.NO_ARROW, featureHolderStyle.getFeatureShapeRealizer());
		assertEquals(new Font("SansSerif", Font.BOLD, 16), featureHolderStyle.getLabelStyle().getFont());
		assertEquals(0.5, featureHolderStyle.getThickness(), delta);
		assertEquals(-0.5, featureHolderStyle.getHeightAdjust(), delta);
		assertFalse(featureHolderStyle.getLabelStyle().showLabels());
		assertEquals(noShading, featureHolderStyle.getShapeEffectRenderer());
	}
	
	// make sure featureRange properly inherits style information from parent 'feature' element
	@Test
	public void testFeatureRangeStylesFromParent() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature  color=\"red\" decoration=\"arc\" "+
							"font=\"SansSerif,bold,16\" proportionOfThickness=\"0.5\" " +
							"radiusAdjustment=\"0.25\" showShading=\"false\">" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertEquals(Color.red, featureHolderStyle.getPaint()[0]);
		assertEquals(FeatureShapeRealizer.NO_ARROW, featureHolderStyle.getFeatureShapeRealizer());
		assertEquals(new Font("SansSerif", Font.BOLD, 16), featureHolderStyle.getLabelStyle().getFont());
		assertEquals(0.5, featureHolderStyle.getThickness(), delta);
		assertEquals(-0.5, featureHolderStyle.getHeightAdjust(), delta);
		assertEquals(noShading, featureHolderStyle.getShapeEffectRenderer());
	}
	
	@Test
	public void testFeatureRangeOpacity() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		Color featureColor;
		Iterator<SlotItemStyle> styleIter;
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" color=\"red\" opacity=\"1.0\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		featureColor = (Color)featureHolderStyle.getPaint()[0];
		assertEquals(0xFFFF0000, featureColor.getRGB());
		assertEquals(255, featureColor.getAlpha());
		
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" color=\"red\" opacity=\"0.0\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		featureColor = (Color)featureHolderStyle.getPaint()[0];
		assertEquals(0x00FF0000, featureColor.getRGB());
		assertEquals(0, featureColor.getAlpha());
	}
	
	@Test
	public void testFeatureRangeOpacityParent() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		Color featureColor;
		Iterator<SlotItemStyle> styleIter;
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature color=\"red\" opacity=\"1.0\">" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		featureColor = (Color)featureHolderStyle.getPaint()[0];
		assertEquals(0xFFFF0000, featureColor.getRGB());
		assertEquals(255, featureColor.getAlpha());
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature color=\"red\" opacity=\"0.0\">" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		featureColor = (Color)featureHolderStyle.getPaint()[0];
		assertEquals(0x00FF0000, featureColor.getRGB());
		assertEquals(0, featureColor.getAlpha());
	}
	
	// test that global show labels is picked up correctly
	@Test
	public void testGlobalLabels() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		
		// test true case
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" globalLabel=\"true\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"false\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertTrue(featureHolderStyle.getLabelStyle().showLabels());
		
		// test false case
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" globalLabel=\"false\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"true\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertFalse(featureHolderStyle.getLabelStyle().showLabels());
	}
	
	// test feature text
	@Test
	public void testFeatureRangeStylesText() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		
		FeatureHolder featureHolder;
		Feature feature;
		
		GenomeData genomeData;
		
		Annotation annotation;
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" hyperlink=\"hyperlink1\" " +
							"label=\"label1\" mouseover=\"mouseover1\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		genomeData = cgviewData.getGenomeData();
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		// get features from this style
		featureHolder = genomeData.getAllFeatures(featureHolderStyle);
		
		Iterator<Feature> featureIter = featureHolder.features();
		assertTrue(featureIter.hasNext());
		
		feature = featureIter.next();
		assertNotNull(feature);
		
		assertEquals(new RangeLocation(1,2), feature.getLocation()); // make sure this is the correct feature
		
		annotation = feature.getAnnotation();
		assertNotNull(annotation);
		
		// test to make sure text in annotation is set correctly
		assertEquals("hyperlink1", annotation.getProperty("CGView_Hyperlink"));
		assertEquals("label1", annotation.getProperty("CGView_Label"));
		assertEquals("mouseover1", annotation.getProperty("CGView_Mouseover"));
	}
	
	// make sure text (mouseover, label, etc) is properly inherited from parent 'feature' element
	@Test
	public void testFeatureRangeStylesTextParent() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		
		FeatureHolder featureHolder;
		Feature feature;
		
		GenomeData genomeData;
		
		Annotation annotation;
		
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature hyperlink=\"hyperlink1\" " +
							"label=\"label1\" mouseover=\"mouseover1\">" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		genomeData = cgviewData.getGenomeData();
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		// get features from this style
		featureHolder = genomeData.getAllFeatures(featureHolderStyle);
		
		Iterator<Feature> featureIter = featureHolder.features();
		assertTrue(featureIter.hasNext());
		
		feature = featureIter.next();
		assertNotNull(feature);
		
		assertEquals(new RangeLocation(1,2), feature.getLocation()); // make sure this is the correct feature
		
		annotation = feature.getAnnotation();
		assertNotNull(annotation);
		
		// test to make sure text in annotation is set correctly
		assertEquals("hyperlink1", annotation.getProperty("CGView_Hyperlink"));
		assertEquals("label1", annotation.getProperty("CGView_Label"));
		assertEquals("mouseover1", annotation.getProperty("CGView_Mouseover"));
	}
	
	
	private boolean testFeatureForMultipleRangeElements(Feature feature, Location[] expectedLocations)
	{
		for (int i = 0; i < expectedLocations.length; i++)
		{
			assertNotNull(feature);
			if (feature.getLocation().equals(expectedLocations[i]))
			{
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * Tests to make sure only a single feature exists in the passed FeatureHolder, and returns this feature.
	 * @param holder  The FeatureHolder to check.
	 * @return  The single feature in this FeatureHolder.
	 */
	private Feature getAndTestForSingleFeatureInFeatureHolder(FeatureHolder holder)
	{
		Feature feature = null;
		
		assertNotNull(holder);
		
		Iterator<Feature> featuresIter = holder.features();
		assertNotNull(featuresIter);
		assertTrue(featuresIter.hasNext());
		
		feature = featuresIter.next();
		
		assertNotNull(feature);
		assertFalse(featuresIter.hasNext());
		
		return feature;
	}
}
