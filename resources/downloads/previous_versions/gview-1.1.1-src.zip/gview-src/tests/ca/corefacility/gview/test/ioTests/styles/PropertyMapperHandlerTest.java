package ca.corefacility.gview.test.ioTests.styles;

import static org.junit.Assert.*;

import java.awt.Color;
import java.io.IOException;
import java.io.StringReader;

import org.junit.*;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.CSSParseException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.datastyle.mapper.AnnotationMapper;
import ca.corefacility.gview.style.datastyle.mapper.COGMapper;
import ca.corefacility.gview.style.datastyle.mapper.DiscretePaintMapper;
import ca.corefacility.gview.style.datastyle.mapper.OpacityFeatureStyleMapper;
import ca.corefacility.gview.style.datastyle.mapper.PropertyMapperScore;
import ca.corefacility.gview.style.datastyle.mapper.PropertyStyle;
import ca.corefacility.gview.style.datastyle.mapper.PropertyStyleContinuous;
import ca.corefacility.gview.style.datastyle.mapper.PropertyStyleDiscrete;
import ca.corefacility.gview.style.io.gss.PropertyMapperHandler;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedDeclarationException;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;

public class PropertyMapperHandlerTest
{
	@Test(expected=ParseException.class)
	public void testInvalidFunction() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("invalid-map(score, opacity)")));
		PropertyMapperHandler.decode(currUnit);		
	}
	
	@Test(expected=ParseException.class)
	public void testInvalidProperty() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("continuous-map(none, opacity)")));
		PropertyMapperHandler.decode(currUnit);		
	}
	
	@Test(expected=ParseException.class)
	public void testInvalidStyle() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("continuous-map(score, none)")));
		PropertyMapperHandler.decode(currUnit);		
	}
	
	@Test(expected=ParseException.class)
	public void testNoComma() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("continuous-map(score opacity)")));
		PropertyMapperHandler.decode(currUnit);		
	}
	
	@Test(expected=ParseException.class)
	public void testMissingScoreMax() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("continuous-map(score(10.5), opacity)")));
		PropertyMapperHandler.decode(currUnit);		
	}
	
	
	@Test(expected=CSSParseException.class)
	public void testMissingScoreMin() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("continuous-map(score(,10.5), opacity)")));
		PropertyMapperHandler.decode(currUnit);		
	}
	
	@Test(expected=CSSParseException.class)
	public void testMissingScoreParameters() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("continuous-map(score(), opacity)")));
		PropertyMapperHandler.decode(currUnit);		
	}
	
	@Test(expected=ParseException.class)
	public void testMissingScoreParameters2() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("continuous-map(score, opacity)")));
		PropertyMapperHandler.decode(currUnit);		
	}
	
	@Test
	public void testDecodeContinuous() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		PropertyStyle expected;
		PropertyStyle actual;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("continuous-map(score(0,100), opacity)")));
		expected = new PropertyStyleContinuous(new PropertyMapperScore(0.0f,100.0f), new OpacityFeatureStyleMapper());
		
		actual = PropertyMapperHandler.decode(currUnit);
		
		assertEquals(expected, actual);
		
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("continuous-map(score(110,115.4), opacity)")));
		expected = new PropertyStyleContinuous(new PropertyMapperScore(110.0f,115.4f), new OpacityFeatureStyleMapper());
		
		actual = PropertyMapperHandler.decode(currUnit);
		
		assertEquals(expected, actual);
	}
	
	@Test(expected=MalformedDeclarationException.class)
	public void testMissingColor() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;

		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("discrete-map(cog(\"A\", \"B\")," +
		" colors(color(\"red\")))")));
		
		PropertyMapperHandler.decode(currUnit);
	}
	
	@Test(expected=MalformedDeclarationException.class)
	public void testMissingCOG() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;

		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("discrete-map(cog(\"A\")," +
		" colors(color(\"red\"), color(0,0,0,0)))")));
		
		PropertyMapperHandler.decode(currUnit);
	}
	
	@Test(expected=CSSParseException.class)
	public void testInvalidColor() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();

		parser.parsePropertyValue(new InputSource(new StringReader("discrete-map(cog(\"A\")," +
		" colors(color(\"red)))")));
	}
	
	@Test(expected=CSSParseException.class)
	public void testInvalidColor2() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();

		parser.parsePropertyValue(new InputSource(new StringReader("discrete-map(cog(\"A\")," +
		" colors(color(0,0,)))")));
	}
	
	@Test
	public void testDecodeDiscrete() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		PropertyStyle expected;
		PropertyStyle actual;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("discrete-map(cog(\"A\")," +
																				" colors(color(\"red\")))")));
		expected = new PropertyStyleDiscrete(new COGMapper(new String[]{"A"}),
				new DiscretePaintMapper(new Color[]{Color.RED}));
		
		actual = PropertyMapperHandler.decode(currUnit);
		
		assertEquals(expected, actual);
		
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("discrete-map(cog(\"A\", \"B\")," +
		" colors(color(\"red\"), color(0,0,0,0)))")));
		expected = new PropertyStyleDiscrete(new COGMapper(new String[]{"A", "B"}),
		new DiscretePaintMapper(new Color[]{Color.RED, new Color(0,0,0,0)}));
		
		actual = PropertyMapperHandler.decode(currUnit);
		
		assertEquals(expected, actual);
	}
}
