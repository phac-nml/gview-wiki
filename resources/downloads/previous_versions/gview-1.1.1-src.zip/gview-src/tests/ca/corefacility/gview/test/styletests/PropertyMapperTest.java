package ca.corefacility.gview.test.styletests;

import static org.junit.Assert.*;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.SimpleAnnotation;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.impl.SimpleSequenceFactory;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.bio.symbol.SymbolList;
import org.biojava.utils.ChangeVetoException;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.style.datastyle.mapper.AnnotationMapper;
import ca.corefacility.gview.style.datastyle.mapper.ContinuousPropertyMapper;
import ca.corefacility.gview.style.datastyle.mapper.DiscretePropertyMapper;
import ca.corefacility.gview.style.datastyle.mapper.PropertyMapperScore;


public class PropertyMapperTest
{
	private final float delta = 0.00001f;
	
	private Feature buildFeature(String key, String value) throws ChangeVetoException, BioException
	{
		SymbolList blankList = new BlankSymbolList(100);
		SimpleSequenceFactory seqFactory = new SimpleSequenceFactory();
		Sequence blankSequence = seqFactory.createSequence(blankList, null, null, null);

		
		Feature.Template basic = new Feature.Template();
		basic.location = new RangeLocation(1,9);
		basic.annotation = new SimpleAnnotation();
		basic.annotation.setProperty(key, value);
		
		
		return blankSequence.createFeature(basic);
	}
	
	private Feature buildFeatureNoAnnotation() throws ChangeVetoException, BioException
	{
		SymbolList blankList = new BlankSymbolList(100);
		SimpleSequenceFactory seqFactory = new SimpleSequenceFactory();
		Sequence blankSequence = seqFactory.createSequence(blankList, null, null, null);

		
		Feature.Template basic = new Feature.Template();
		basic.location = new RangeLocation(1,9);
		basic.annotation = null;
		
		
		return blankSequence.createFeature(basic);
	}
	
	@Test
	public void testContinuousScoreMapper() throws ChangeVetoException, BioException
	{
		ContinuousPropertyMapper mapper;
		Feature f;
		float actualValue;
		
		mapper = new PropertyMapperScore(0,100);
		f = buildFeature("Score", "50");
		actualValue = mapper.propertyValue(f);
		assertEquals(0.5f, actualValue, delta);
		
		f = buildFeature("Score", "1");
		actualValue = mapper.propertyValue(f);
		assertEquals(0.01f, actualValue, delta);
		
		f = buildFeature("Score", "0");
		actualValue = mapper.propertyValue(f);
		assertEquals(0.0f, actualValue, delta);
		
		f = buildFeature("Score", "-1");
		actualValue = mapper.propertyValue(f);
		assertEquals(0.0f, actualValue, delta);
		
		f = buildFeature("Score", "99");
		actualValue = mapper.propertyValue(f);
		assertEquals(0.99f, actualValue, delta);
		
		f = buildFeature("Score", "100");
		actualValue = mapper.propertyValue(f);
		assertEquals(1.0f, actualValue, delta);
		
		f = buildFeature("Score", "101");
		actualValue = mapper.propertyValue(f);
		assertEquals(1.0f, actualValue, delta);
		
		
		mapper = new PropertyMapperScore(10,20);
		
		f = buildFeature("Score", "15");
		actualValue = mapper.propertyValue(f);
		assertEquals(0.5f, actualValue, delta);
		
		f = buildFeature("Score", "10");
		actualValue = mapper.propertyValue(f);
		assertEquals(0.0f, actualValue, delta);
		
		f = buildFeature("Score", "9");
		actualValue = mapper.propertyValue(f);
		assertEquals(0.0f, actualValue, delta);
		
		f = buildFeature("Score", "20");
		actualValue = mapper.propertyValue(f);
		assertEquals(1.0f, actualValue, delta);
		
		f = buildFeature("Score", "21");
		actualValue = mapper.propertyValue(f);
		assertEquals(1.0f, actualValue, delta);
		
		// invalid
		mapper = new PropertyMapperScore(0,100);
		f = buildFeature("score", "20");
		actualValue = mapper.propertyValue(f);
		assertEquals(ContinuousPropertyMapper.INVALID, actualValue, delta);
		
		mapper = new PropertyMapperScore(0,100);
		f = buildFeatureNoAnnotation();
		actualValue = mapper.propertyValue(f);
		assertEquals(ContinuousPropertyMapper.INVALID, actualValue, delta);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testAnnotationDiscreteMapperNull()
	{
		new AnnotationMapper("COG", new String[]{null});
	}
	
	@Test
	public void testAnnotationDiscreteMapper() throws ChangeVetoException, BioException
	{
		DiscretePropertyMapper mapper;
		Feature f;
		int actualValue;
		
		mapper = new AnnotationMapper("COG", new String[]{"A"});
		assertEquals(1,mapper.getNumberOfCategories());
		f = buildFeature("COG", "A");

		actualValue = mapper.propertyValue(f);
		assertEquals(0, actualValue);
		
		mapper = new AnnotationMapper("COG", new String[]{"A"});
		assertEquals(1,mapper.getNumberOfCategories());
		f = buildFeature("COG", "B");

		actualValue = mapper.propertyValue(f);
		assertEquals(DiscretePropertyMapper.INVALID, actualValue);
		
		
		mapper = new AnnotationMapper("COG", new String[]{"A", "B"});
		assertEquals(2,mapper.getNumberOfCategories());
		f = buildFeature("COG", "A");

		actualValue = mapper.propertyValue(f);
		assertEquals(0, actualValue);
		
		
		mapper = new AnnotationMapper("COG", new String[]{"A", "B"});
		assertEquals(2,mapper.getNumberOfCategories());
		f = buildFeature("COG", "B");

		actualValue = mapper.propertyValue(f);
		assertEquals(1, actualValue);
		
		
		mapper = new AnnotationMapper("C", new String[]{"A", "B"});
		assertEquals(2,mapper.getNumberOfCategories());
		f = buildFeature("COG", "A");

		actualValue = mapper.propertyValue(f);
		assertEquals(DiscretePropertyMapper.INVALID, actualValue);
		
		
		mapper = new AnnotationMapper("COG", new String[]{"A", "B"});
		assertEquals(2,mapper.getNumberOfCategories());
		f = buildFeature("C", "A");

		actualValue = mapper.propertyValue(f);
		assertEquals(DiscretePropertyMapper.INVALID, actualValue);
		
		
		mapper = new AnnotationMapper("COG", new String[]{"A", "B"});
		assertEquals(2,mapper.getNumberOfCategories());
		f = buildFeatureNoAnnotation();
		
		actualValue = mapper.propertyValue(f);
		assertEquals(DiscretePropertyMapper.INVALID, actualValue);
		
		
		mapper = new AnnotationMapper("COG", new String[]{});
		assertEquals(0,mapper.getNumberOfCategories());
		f = buildFeature("COG", "A");

		actualValue = mapper.propertyValue(f);
		assertEquals(DiscretePropertyMapper.INVALID, actualValue);
	}
}
