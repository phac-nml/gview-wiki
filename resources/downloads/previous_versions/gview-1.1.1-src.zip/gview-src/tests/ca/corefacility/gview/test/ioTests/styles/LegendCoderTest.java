package ca.corefacility.gview.test.ioTests.styles;

import static org.junit.Assert.*;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Iterator;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;
import org.w3c.css.sac.Selector;

import com.steadystate.css.parser.selectors.ConditionalSelectorImpl;
import com.steadystate.css.parser.selectors.ElementSelectorImpl;
import com.steadystate.css.parser.selectors.IdConditionImpl;

import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.LabelStyle;
import ca.corefacility.gview.style.io.gss.coders.GSSWriter;
import ca.corefacility.gview.style.io.gss.coders.LabelCoder;
import ca.corefacility.gview.style.io.gss.coders.LegendCoder;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.style.items.LegendStyle;
import ca.corefacility.gview.textextractor.LocationExtractor;

public class LegendCoderTest
{
	private LegendCoder coder;
	
	private Selector buildLegendSelector(String legendId)
	{
		Selector legendSelector = new ConditionalSelectorImpl(new ElementSelectorImpl("legend"), new IdConditionImpl(legendId));
		
		return legendSelector;
	}
	
	@Before
	public void setup()
	{
		coder = new LegendCoder();
	}
	
	@Test(expected=ParseException.class)
	public void testDecodeInvalid() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		MapStyle workingStyle = new MapStyle();
		
		Iterator<LegendStyle> lStylesIter;
		
		LexicalUnit currUnit;
		
		lStylesIter = workingStyle.getGlobalStyle().legendStyles();
		assertFalse(lStylesIter.hasNext()); // no legend style should exist at this stage
		
		Selector selector = buildLegendSelector("0");
		coder.startSelector(selector, null, workingStyle); // creates legend style for id 0
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		coder.decodeProperty(selector, workingStyle, null, "invalid", currUnit, null);
	}
	
	@Test
	public void testDecode() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		MapStyle workingStyle = new MapStyle();
		LegendStyle workingLegendStyle;
		LegendStyle expectedStyle;
		
		Iterator<LegendStyle> lStylesIter;
		
		LexicalUnit currUnit;
		
		lStylesIter = workingStyle.getGlobalStyle().legendStyles();
		assertFalse(lStylesIter.hasNext()); // no legend style should exist at this stage
		
		Selector selector = buildLegendSelector("0");
		coder.startSelector(selector, null, workingStyle); // creates legend style for id 0
		
		// pull out legend style
		lStylesIter = workingStyle.getGlobalStyle().legendStyles();
		assertTrue(lStylesIter.hasNext()); // legend style should exist now
		
		workingLegendStyle = lStylesIter.next();
		assertNotNull(workingLegendStyle);
		assertFalse(lStylesIter.hasNext());
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		// setup expected style
		expectedStyle = (LegendStyle)workingLegendStyle.clone();
		expectedStyle.setBackgroundPaint(Color.red);
		coder.decodeProperty(selector, workingStyle, null, "background-color", currUnit, null);
		assertEquals(expectedStyle, workingLegendStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"blue\")")));
		// setup expected style
		expectedStyle = (LegendStyle)workingLegendStyle.clone();
		expectedStyle.setOutlinePaint(Color.blue);
		coder.decodeProperty(selector, workingStyle, null, "border-color", currUnit, null);
		assertEquals(expectedStyle, workingLegendStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"yellow\")")));
		// setup expected style
		expectedStyle = (LegendStyle)workingLegendStyle.clone();
		expectedStyle.setDefaultFontPaint(Color.yellow);
		coder.decodeProperty(selector, workingStyle, null, "text-color", currUnit, null);
		assertEquals(expectedStyle, workingLegendStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("font(\"SansSerif\", \"italic\", 24)")));
		// setup expected style
		expectedStyle = (LegendStyle)workingLegendStyle.clone();
		expectedStyle.setDefaultFont(new Font("SansSerif", Font.ITALIC, 24));
		coder.decodeProperty(selector, workingStyle, null, "text-font", currUnit, null);
		assertEquals(expectedStyle, workingLegendStyle);
	}
	
	@Test
	public void testEncode()
	{
//		LabelCoder labelCoder = new LabelCoder();
//		LabelStyle labelStyle = new LabelStyle();
//		
//		String expectedEncoding;
//		
//		StringWriter expectedStringWriter;
//		GSSWriter expectedGssWriter;
//		
//		StringWriter actualStringWriter;
//		GSSWriter actualEncodingGSS;
//		
//		expectedStringWriter = new StringWriter();
//		expectedGssWriter = new GSSWriter(expectedStringWriter);
//		actualStringWriter = new StringWriter();
//		actualEncodingGSS = new GSSWriter(actualStringWriter);
//		
//		String baseSelector = "slot#1";
//		
//		// setup feature set 
//		expectedGssWriter.startSelector(baseSelector + " " + "labels");
//		expectedGssWriter.writeProperty("text-color", "color(\"blue\")");
//		expectedGssWriter.writeProperty("background-color", "color(\"orange\")");
//		expectedGssWriter.writeProperty("font", "font(\"SansSerif\",\"plain\",19)");
//		expectedGssWriter.writeProperty("label-extractor", "text-extractor(\"location\")");
//		expectedGssWriter.writeProperty("show-labels", "\"true\"");
//		expectedGssWriter.endSelector();
//		expectedEncoding = expectedStringWriter.toString();
//		
//		// setup map
//		labelStyle.setTextPaint(Color.blue);
//		labelStyle.setBackgroundPaint(new Color(255, 153, 0)); // orange
//		labelStyle.setFont(new Font("SansSerif", Font.PLAIN, 19));
//		labelStyle.setLabelExtractor(new LocationExtractor());
//		labelStyle.setShowLabels(true);
//		
//		labelCoder.encodeStyle(labelStyle, baseSelector, actualEncodingGSS);
//		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
	}
}
