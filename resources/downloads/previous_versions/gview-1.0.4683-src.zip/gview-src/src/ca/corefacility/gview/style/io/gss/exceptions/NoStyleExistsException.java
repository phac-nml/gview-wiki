package ca.corefacility.gview.style.io.gss.exceptions;

public class NoStyleExistsException extends ParseException
{

	public NoStyleExistsException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public NoStyleExistsException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoStyleExistsException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoStyleExistsException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
