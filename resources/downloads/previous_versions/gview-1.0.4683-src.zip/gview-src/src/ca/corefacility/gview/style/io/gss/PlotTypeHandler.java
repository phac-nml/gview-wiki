package ca.corefacility.gview.style.io.gss;


import java.awt.BasicStroke;

import org.w3c.css.sac.LexicalUnit;

import ca.corefacility.gview.layout.PlotDrawer;
import ca.corefacility.gview.layout.PlotDrawerBar;
import ca.corefacility.gview.layout.PlotDrawerCenter;
import ca.corefacility.gview.layout.PlotDrawerLine;
import ca.corefacility.gview.style.io.gss.exceptions.UnknownPlotTypeException;

public class PlotTypeHandler
{
	private static final String LINE_TYPE_NAME = "line";
	private static final String BAR_TYPE_NAME = "bar";
	private static final String	CENTER_TYPE_NAME	= "center";

	public static PlotDrawer decode(LexicalUnit currUnit) throws UnknownPlotTypeException
	{
		PlotDrawer plotDrawer = null;

		if (currUnit != null)
		{
			if (currUnit.getLexicalUnitType() == LexicalUnit.SAC_IDENT)
			{
				String value = currUnit.getStringValue();

				if ( LINE_TYPE_NAME.equalsIgnoreCase( value ) )
				{
					plotDrawer = new PlotDrawerLine(new BasicStroke(0.5f));
				}
				else if ( BAR_TYPE_NAME.equalsIgnoreCase( value ) )
				{
					plotDrawer = new PlotDrawerBar();
				}
				else if ( CENTER_TYPE_NAME.equalsIgnoreCase( value ) )
				{
					plotDrawer = new PlotDrawerCenter();
				}
				else
				{
					throw new UnknownPlotTypeException("unkown plot " + value);
				}
			}
			else
			{
				throw new UnknownPlotTypeException("unknown plot " + currUnit);
			}
		}
		else
		{
			throw new UnknownPlotTypeException("unknown plot " + currUnit);
		}

		return plotDrawer;
	}

}
