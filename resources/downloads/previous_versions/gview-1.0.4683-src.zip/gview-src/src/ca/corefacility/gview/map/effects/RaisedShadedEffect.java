package ca.corefacility.gview.map.effects;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;

public class RaisedShadedEffect extends AbstractAllEffectRenderer
{
	private Paint outlinePaint;
	private Stroke stroke;
	
	private AffineTransform raisedTransform;
	
	public RaisedShadedEffect()
	{
		this.outlinePaint = new Color(0,0,0,100);
		this.stroke = new BasicStroke();
		
		raisedTransform = new AffineTransform();
		raisedTransform.setToTranslation(0, 10);
	}
	
	protected void paintNormal(Shape shape, Graphics2D g, Paint paint)
	{
		g.setPaint(paint);
		g.fill(shape);
		
		g.setStroke(stroke);
		g.setPaint(outlinePaint);
		g.draw(shape);
	}

	protected void paintSelected(Shape shape, Graphics2D g, Paint paint)
	{
		g.setPaint(Color.YELLOW);
		g.fill(shape);
		
		g.setStroke(stroke);
		g.setPaint(outlinePaint);
		g.draw(shape);
	}
	
	protected void paintMouseOver(Shape shape, Graphics2D g, Paint paint)
	{
		AffineTransform previousTransform = g.getTransform();
		g.transform(raisedTransform);
		
		g.setPaint(Color.GREEN);
		g.fill(shape);
		
		g.setStroke(stroke);
		g.setPaint(outlinePaint);
		g.draw(shape);
		
		g.setTransform(previousTransform);
	}
	
	protected void paintMouseOverSelected(Shape shape, Graphics2D g, Paint paint)
	{
		AffineTransform previousTransform = g.getTransform();
		g.transform(raisedTransform);
		
		g.setPaint(Color.GREEN);
		g.fill(shape);
		
		g.setStroke(stroke);
		g.setPaint(outlinePaint);
		g.draw(shape);
		
		g.setTransform(previousTransform);
	}
}
