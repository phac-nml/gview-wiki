package ca.corefacility.gview.layout;


import java.awt.Shape;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.layout.sequence.SlotPath;

public class PlotBuilderPoints extends PlotBuilder
{
	SortedMap<Integer, Double> points;

//	private final static int NO_BASE = -1;
//
//	private static final double bottomHeight = -1;
//	private static final double topHeight = 1;
//	private static final double centerHeight = 0;

	public PlotBuilderPoints()
	{
		this.points = new TreeMap<Integer, Double>();

		this.minValue = -1;
		this.maxValue = 1;
	}

	/**
	 * Adds a point to this plot
	 * @param point
	 * @param height
	 */
	public void addPoint(int point, double height)
	{
		if (point < 0)
			throw new IllegalArgumentException("base point cannot be null");
		// TODO, checks to make sure point is in range
		this.points.put(point, height);
	}

	public void addRange(int startBase, int endBase, double height)
	{
		// TODO, fix add Range
		// for now, just adds 2 points
		addPoint(startBase, height);
		addPoint(endBase, height);
	}

	@Override
	public void autoScale()
	{
		double minValue = Double.MAX_VALUE;
		double maxValue = Double.MIN_VALUE;
		double currValue;

		for (int base : this.points.keySet())
		{
			currValue = this.points.get(base);

			if (currValue < minValue)
			{
				minValue = currValue;
			}

			if (currValue > maxValue)
			{
				maxValue = currValue;
			}
		}

		scale(minValue, maxValue);
	}

	@Override
	public Shape[][] createPlot(GenomeData genomeData, SlotPath path, PlotDrawer plotDrawer)
	{
		int currBase;
		double currHeight;
		Shape plotShape = null;

		Set<Integer> baseSet = this.points.keySet();
		Iterator<Integer> baseIterator = baseSet.iterator();

		while (baseIterator.hasNext())
		{
			currBase = baseIterator.next();
			currHeight = getScaledHeight(this.points.get(currBase));

			plotDrawer.drawPoint(currBase, currHeight, path);
		}

		plotShape = plotDrawer.finishPlotPoint(path);

		return new Shape[][]{{plotShape}};
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + (this.points == null ? 0 : this.points.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlotBuilderPoints other = (PlotBuilderPoints) obj;
		if (this.points == null)
		{
			if (other.points != null)
				return false;
		}
		else if (!this.points.equals(other.points))
			return false;
		return true;
	}

	@Override
	public int getNumPoints()
	{
		// TODO Auto-generated method stub
		return this.points.size();
	}

	@Override
	public void autoScaleCenter()
	{
		// TODO Auto-generated method stub

	}

	@Override
	public double[] getMaxMinValues()
	{
		// TODO Auto-generated method stub
		return null;
	}
}
