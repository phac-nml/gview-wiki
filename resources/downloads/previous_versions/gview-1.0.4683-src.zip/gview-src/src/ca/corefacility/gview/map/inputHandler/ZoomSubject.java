package ca.corefacility.gview.map.inputHandler;

import edu.umd.cs.piccolo.PCamera;

import java.awt.geom.Point2D;

import ca.corefacility.gview.layout.prototype.SequencePoint;
import ca.corefacility.gview.layout.sequence.Backbone;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.event.GViewEvent;
import ca.corefacility.gview.map.event.GViewEventListener;
import ca.corefacility.gview.map.event.GViewEventSubjectImp;
import ca.corefacility.gview.map.event.LayoutChangedEvent;
import ca.corefacility.gview.map.event.ZoomEvent;

/**
 * Handles zooming in GView.  Methods here are called in order to zoom in on the GView map.
 * 
 * @author Aaron Petkau
 *
 */
public class ZoomSubject extends GViewEventSubjectImp implements GViewEventListener
{
	private double minScale = 0;
	private double maxScale = Double.MAX_VALUE;
	
	/**
	 * Stores the previous scale we were at.
	 */
	private double previousScale;
	
	// these are only placed here so that we can set centre point correctly after zooming
	private Backbone backbone;
	private GViewMap gViewMap;
	
	/**
	 * Creates a new ZoomSubject to control zooming on the passed GViewMap.
	 */
	public ZoomSubject(GViewMap gViewMap)
	{
		if (gViewMap == null)
		{
			throw new NullPointerException("gViewMap is null");
		}
		
		this.backbone = null;
		this.gViewMap = gViewMap;
		
		previousScale = 1.0;
	}
	
	/**
	 * Multiplies the current zoom factor by the passed delta.
	 * @param scaleDelta
	 * @param zoomPoint
	 */
	public Point2D zoomStretch(double scaleDelta, Point2D zoomPoint)
	{
		Point2D newViewPoint = zoomPoint;
		
		double newScale = previousScale * scaleDelta;

		if (minScale <= newScale && newScale <= maxScale)
		{
			newViewPoint = zoomToFactor(newScale, zoomPoint);
		}
		
		return newViewPoint;
	}
	
	/**
	 * Performs a "normal" zoom (scaling every point by the same amount).
	 * @param scaleDelta  The factor we should scale by.
	 * @param zoomPoint  The center point for the zoom.
	 * @param camera  The camera used to view the GView map.
	 */
	public void zoomNormal(double scaleDelta, Point2D zoomPoint, PCamera camera)
	{
		double newScale = previousScale * scaleDelta;

		if (newScale < minScale) {
			scaleDelta = minScale / previousScale;
		}
		if ((maxScale > 0) && (newScale > maxScale)) {
			scaleDelta = maxScale / previousScale;
		}
		
		camera.scaleViewAboutPoint(scaleDelta, zoomPoint.getX(), zoomPoint.getY());
	}
	
	/**
	 * Zooms in to the specified factor.  Performs a "stretch" style of zooming.
	 * 
	 * @param zoomFactor  The scale factor to zoom to.
	 * @param zoomPoint  The point we are zooming about.
	 */
	public Point2D zoomToFactor(double zoomFactor, Point2D zoomPoint)
	{
		Point2D newViewPoint = zoomPoint;
		
		assert (zoomFactor > 0);
		if (zoomFactor > 0)
		{
			previousScale = zoomFactor;
			
			SequencePoint seqPoint = backbone.translate(zoomPoint); // save old point on backbone
			// this is used so we can restore map to previous position after zoom (otherwise it shifts all over the place)
			
			fireEvent(new ZoomEvent(zoomFactor, zoomPoint, this));
			
			if (seqPoint != null)
			{
				newViewPoint = backbone.translate(seqPoint.getBase(), seqPoint.getHeightFromBackbone());
				if (newViewPoint == null) // if old point was not associated with a point on backbone
				{
					newViewPoint = zoomPoint;
				}
			}
			
			// the amount we should shift the gViewMap by
			Point2D zoomDelta = new Point2D.Double(zoomPoint.getX() - newViewPoint.getX(), zoomPoint.getY() - newViewPoint.getY());
			
			// center gViewMap on point
			gViewMap.translate(zoomDelta);
		}
		
		return newViewPoint;
	}

	// listens to SlotRegionChangedEvent in order to change backbone
	public void eventOccured(GViewEvent event)
	{
		if (event instanceof LayoutChangedEvent)
		{
			this.backbone = ((LayoutChangedEvent)event).getSlotRegion().getBackbone();
			
			maxScale = backbone.getMaxScale();
			minScale = backbone.getMinScale();
			// should I do anything else?
			// probably set minScale depending on number of number of slots in backbone, and backbone type
		}
	}
}
