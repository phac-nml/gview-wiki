package ca.corefacility.gview.data.readers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.NoSuchElementException;

import org.biojava.bio.BioException;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.SequenceIterator;
import org.biojavax.bio.seq.RichSequence;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.utils.Util;

/**
 * Reads in Genbank formatted files.
 * @author aaron
 *
 */
public class GenbankDNAFormatReader extends AbstractFileFormatReader implements FileFormatReader
{
	private GenomeData genomeData;
	
	/**
	 * Constructs an object used to read in a GenbankDNA format
	 */
	public GenbankDNAFormatReader()
	{
	}
	
	public GViewFileData read(File file) throws IOException, GViewDataParseException
	{
		if (file == null)
		{
			throw new IllegalArgumentException("File cannot be null");
		}
		else
		{
			return read(new FileReader(file));
		}
	}
	
	/**
	 * Reads a sequence from the passed reader.
	 * @param sequenceReader  The reader to read the sequence from.
	 * @return  The read in sequence object.
	 * @throws NoSuchElementException
	 * @throws BioException
	 */
	private Sequence readSequenceFromReader(Reader sequenceReader) throws NoSuchElementException, BioException
	{
		Sequence sequence = null;
		
		//read the file, attempts to guess correct format, throws IOException if it can't guess
		SequenceIterator sequences = RichSequence.IOTools.readGenbankDNA(new BufferedReader(sequenceReader), null);
    	
		// only obtain one sequence
		if (sequences.hasNext())
		{
        	// extract the sequence
        	sequence = sequences.nextSequence();
		}
		
		return sequence;
	}
	
	public boolean canRead(String file)
	{
		String extension = Util.extractExtension(file);
		
		return extension != null && extension.equals("gbk");
	}

	@Override
	public GViewFileData read(Reader reader) throws IOException, GViewDataParseException
	{
		if (reader != null)
		{
			Sequence sequence;
			try
			{
				sequence = readSequenceFromReader(reader);
				genomeData = GenomeDataFactory.createGenomeData(sequence);
			}
			catch (NoSuchElementException e)
			{
				throw new GViewDataParseException(e);
			}
			catch (BioException e)
			{
				throw new GViewDataParseException(e);
			}
		}
		else
		{
			throw new IllegalArgumentException("reader is null");
		}
		
		if (genomeData != null)
		{
			return new GViewFileData(genomeData, null); // no map style in biojava formats
		}
		else
		{
			return null;
		}
	}
}
