package ca.corefacility.gview.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

/**
 * A class which helps in locating files to read in for GView
 * @author aaron
 *
 */
public class FileLocationHandler
{
	public static Reader getReader(URI uri) throws IOException
	{
		if (uri == null)
		{
			throw new IllegalArgumentException("uri is null");
		}
		
		Reader reader = null;
		
		try
		{
			reader = getReader(uri.toURL());
		}
		catch (MalformedURLException e)
		{
			throw new IOException(e);
		}
		
		return reader;
	}
	
	public static URI getURI(String location) throws IOException
	{
		URI uri = null;
		
		if (location == null)
		{
			throw new NullPointerException("location is null");
		}
		else
		{
			URL url;
			try
			{
				url = new URL(location);
				uri = url.toURI();
			}
			catch (MalformedURLException e)
			{
				// attempt to check if the file is located in the jar or not
				File file = new File( location );
				
				if( !file.canRead() )
				{
					if (resourceExists(location))
					{
						File tempFile = createTempFileFromClassLoaderResource( location );
						uri = tempFile.toURI();
					}
					else
					{
						throw new FileNotFoundException("file located at " + location + " not found");
					}
				}
				else
				{
					uri = file.toURI();
				}
			}
			catch (URISyntaxException e)
			{
				e.printStackTrace();
			}
		}
		
		return uri;
	}
	
	public static Reader getReader(String location) throws IOException
	{
		Reader reader = null;
		
		URI uri = getURI(location);
		reader = getReader(uri);
		
		return reader;
	}
	
	public static Reader getReader(URL url) throws IOException
	{
		if (url == null)
		{
			throw new IllegalArgumentException("url is null");
		}
		
		Reader reader = null;
		URLConnection connection = null;
						
		ProxySelector proxySelector = ProxySelector.getDefault();
		
		try
		{
			if (!"file".equals(url.getProtocol()))
			{
				List<Proxy> proxies = proxySelector.select(url.toURI());
				
				if (proxies != null && proxies.size() == 1 && Proxy.NO_PROXY.equals(proxies.get(0)))
				{
					// no proxy
					connection = url.openConnection();
				}
				else
				{
					for (Proxy p : proxies)
					{
						if (p.type().equals(Proxy.Type.HTTP))
						{
							connection = url.openConnection(p);
							break;
						}
						else if (p.type().equals(Proxy.Type.SOCKS))
						{
							connection = url.openConnection(p);
							break;
						}
					}
				}
			}
			else
			{
				connection = url.openConnection();
			}
			
			InputStream iStream = connection.getInputStream();
			
			reader = new InputStreamReader(iStream);
		}
		catch (URISyntaxException e)
		{
			throw new IOException(e);
		}

			
		return reader;
	}
	
	private static boolean resourceExists(String resource)
	{
		return (FileLocationHandler.class.getClassLoader().getResourceAsStream( resource )
				!= null);
	}
	
	/**
	 * This method will attempt to find the given resource by using the classloader.
	 * This will enable resources embedded in the jar file being executed to be located and used.
	 * Best used to load default files
	 * @param resource  The resource to load within the jar file.
	 * @return  A temporary file containing this resource.
	 * @throws IOException
	 */
	private static File createTempFileFromClassLoaderResource( String resource ) throws IOException
	{
		InputStream stream = FileLocationHandler.class.getClassLoader().getResourceAsStream( resource );
		if( stream != null )
		{
			String end = resource.substring( resource.lastIndexOf( "." ) );
			File tempfile = File.createTempFile( "gviewtemp", end );
			tempfile.deleteOnExit();

			InputStreamReader reader = new InputStreamReader( stream );
			FileWriter writer = new FileWriter( tempfile );

			int read = reader.read();
			while( read != -1 )
			{
				writer.write( read );
				read = reader.read();
			}

			reader.close();
			writer.close();
			return tempfile;
		}
		else
		{
			throw new FileNotFoundException("resource " + resource + " could not be found");
		}
	}
}
