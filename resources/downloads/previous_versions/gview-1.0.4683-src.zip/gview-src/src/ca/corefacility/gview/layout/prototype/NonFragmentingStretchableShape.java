package ca.corefacility.gview.layout.prototype;


import java.awt.Shape;
import java.awt.geom.IllegalPathStateException;
import java.awt.geom.Path2D;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import ca.corefacility.gview.layout.prototype.segments.MoveSegment;
import ca.corefacility.gview.layout.prototype.segments.StretchableSegment;
import ca.corefacility.gview.layout.sequence.Backbone;

/**
 * A shape which can stretch itself along the backbone on receiving an event. Does not fragment
 * shape if it is cut off at some point. This class isn't important for any current code (could be
 * done directly in Stretchable Shape) but if there is to be other layouts (such as wrapped linear
 * layouts) Then we would need to divide StretchableShape into nonfragmenting/fragmenting since a
 * wrapped linear layout could cut off feature shapes and wrap them to a different location.
 * 
 * @author Aaron Petkau
 * 
 */
public class NonFragmentingStretchableShape extends StretchableShape
{
	/**
	 * Stores a list of segments which can be used to generate a scaled shape.
	 */
	List<StretchableSegment> stretchableSegments = new LinkedList<StretchableSegment>();
	
	private Path2D currentPath;
	private Shape currentShape;

	public NonFragmentingStretchableShape(Backbone backbone) // we need this so that we can create
																// the shape initally
	{
		super(backbone);
		
		currentPath = new Path2D.Double(Path2D.WIND_NON_ZERO);
		currentShape = currentPath;
	}

	/**
	 * Appends the passed segment onto this shape prototype.
	 * 
	 * @param segment
	 *            The segment to append.
	 */
	@Override
	public void appendSegment(StretchableSegment segment)
	{
		if (segment != null)
		{
			// this makes sure that a moveto is always the first segment added
			if (!(segment instanceof MoveSegment) && ((stretchableSegments.isEmpty()) || !(stretchableSegments.get(0) instanceof MoveSegment)))
			{
				throw new IllegalPathStateException("Missing moveto in path");
				// TODO should I use this exception, or create my own?
			}
			else
			{
				stretchableSegments.add(segment);
				shapeChanged = true;
			}
		}
		else
		{
			throw new IllegalArgumentException("segment is null");
		}
	}

	@Override
	protected Shape getCurrentShape()
	{
		return currentShape;
	}

	@Override
	protected void modifyShape(Backbone backbone)
	{
		if (!shapeChanged)
		{
			return;
		}

		// iterator through all segments, creating the new, scaled shape.
		if (backbone != null)
		{
			Iterator<StretchableSegment> segments = stretchableSegments.iterator();
			currentPath.reset();

			while (segments.hasNext())
			{
				StretchableSegment currSegment = segments.next();

				if (currSegment != null)
				{
					currSegment.appendWithScale(currentPath, backbone);
				}
			}

			shapeChanged = false;
		}
	}
}
