package ca.corefacility.gview.layout;


import java.awt.Shape;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.layout.sequence.SlotPath;

public abstract class PlotBuilder
{
	protected double minValue;
	protected double maxValue;

	/**
	 * Builds the plot defined by this builder within the passed path
	 * @param genomeData  The GenomeData we are using.
	 * @param path  The path to build the plot on
	 * @param plotDrawer  The PlotDrawer defining how to draw the plot.
	 * @return  A Shape defining the plot we created.
	 */
	public abstract Shape[][] createPlot(GenomeData genomeData, SlotPath path, PlotDrawer plotDrawer);

	/**
	 * Returns the heightInSlot corresponding to the passed height, scaled to be between [-1, 1]
	 * @param height  The height to scale.
	 */
	public double getScaledHeight(double height)
	{
		double totalDiff = this.maxValue - this.minValue;

		// cut off value if it exceeds bounds
		if (height > this.maxValue)
		{
			height = this.maxValue;
		}
		else if (height < this.minValue)
		{
			height = this.minValue;
		}

		// scale value between 0 and totalDiff
		height = height - this.minValue;

		// scale value between 0 and 2
		height = 2*height/ totalDiff;

		// scale value between -1 and 1
		height = height - 1;

		return height;
	}

	/**
	 * Automatically sets scaling of points so that max point is at top of slot, min is at bottom of slot.
	 */
	public abstract void autoScale();

	/**
	 * Automatically sets scaling of points so that the largest value on either side of the center point is the highest point above and below the line
	 */
	public abstract void autoScaleCenter();


	/**
	 * Scales the construction of this plot to be between (min, max).
	 * @param min
	 * @param max
	 */
	public void scale(double min, double max)
	{
		this.minValue = min;
		this.maxValue = max;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(this.maxValue);
		result = prime * result + (int) (temp ^ temp >>> 32);
		temp = Double.doubleToLongBits(this.minValue);
		result = prime * result + (int) (temp ^ temp >>> 32);
		return result;
	}

	public abstract int getNumPoints();

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlotBuilder other = (PlotBuilder) obj;
		if (Double.doubleToLongBits(this.maxValue) != Double
				.doubleToLongBits(other.maxValue))
			return false;
		if (Double.doubleToLongBits(this.minValue) != Double
				.doubleToLongBits(other.minValue))
			return false;
		return true;
	}

	public abstract double[] getMaxMinValues();

}