package ca.corefacility.gview.layout;


import java.awt.Shape;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.FeatureHolder;
import org.biojava.bio.symbol.Location;
import org.biojava.bio.symbol.RangeLocation;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.layout.sequence.SlotPath;

/**
 * Defines a plot whose values are specified in terms of an annotation/data value
 * ex. locus_tag, value
 * @author aaron
 *
 */
public class PlotBuilderAnnotation extends PlotBuilder
{
	private boolean autoscale;

	private Map<FeatureFilter, Double> annotationValuesMap;

	public PlotBuilderAnnotation()
	{
		this.autoscale = false;
		this.annotationValuesMap = new HashMap<FeatureFilter, Double>();
	}

	public void addAnnotationValue(String annotationType, String annotationValue, double dataValue)
	{
		if (annotationType == null)
			throw new IllegalArgumentException("annotationType cannot be null");

		if (annotationValue == null)
			throw new IllegalArgumentException("annotationValue cannot be null");

		// used to filter out features with the passed annotation/annotation value pair
		FeatureFilter filter = new FeatureFilter.ByAnnotation(annotationType, annotationValue);

		this.annotationValuesMap.put(filter, dataValue);
	}

	@Override
	public Shape[][] createPlot(GenomeData genomeData, SlotPath path, PlotDrawer plotDrawer)
	{
		SortedMap<RangeLocation, Double> rangeMap; // stores any ranges generated from the passed genome data

		RangeLocation currLocation;
		double currHeight;
		Shape plotShape = null;

		try
		{
			rangeMap = getRangesFor(genomeData);

			if (this.autoscale)
			{
				performAutoScale(rangeMap);
			}

			Set<RangeLocation> rangeSet = rangeMap.keySet();
			Iterator<RangeLocation> rangeIterator = rangeSet.iterator();

			while (rangeIterator.hasNext())
			{
				currLocation = rangeIterator.next();
				currHeight = getScaledHeight(rangeMap.get(currLocation));

				plotDrawer.drawRange(currLocation.getMin(), currLocation.getMax(), currHeight, path);
			}

			plotShape = plotDrawer.finishPlotRange(path)[0][0];
		}
		catch (NoAnnotationException e)
		{
			System.err.println(e);
		}

		return new Shape[][]{{plotShape}};
	}

	private void performAutoScale(SortedMap<RangeLocation, Double> rangeMap)
	{
		double minValue = Double.MAX_VALUE;
		double maxValue = Double.MIN_VALUE;
		double currValue;

		for (RangeLocation range : rangeMap.keySet())
		{
			currValue = rangeMap.get(range);

			if (currValue < minValue)
			{
				minValue = currValue;
			}

			if (currValue > maxValue)
			{
				maxValue = currValue;
			}
		}

		super.scale(minValue, maxValue);
	}

	public SortedMap<RangeLocation, Double> getRangesFor(GenomeData data) throws NoAnnotationException
	{
		SortedMap<RangeLocation, Double> rangeMap = new TreeMap<RangeLocation, Double>(new RangeLocationComparator());

		// iterates through all feature filters, extracts the features, and adds the ranges
		// note: this performs a linear search per each feature filter, possibly slow?
		for (FeatureFilter currFilter : this.annotationValuesMap.keySet())
		{
			FeatureHolder currHolder = data.getFeatures(currFilter);

			if (currHolder == null || currHolder.countFeatures() == 0)
				throw new NoAnnotationException("no features for annotation " + currFilter);

			Iterator<Feature> featureIterator = currHolder.features();
			while (featureIterator.hasNext())
			{
				Feature currFeature = featureIterator.next();

				Location location = currFeature.getLocation();

				Iterator blockLocationIter = location.blockIterator();
				while (blockLocationIter.hasNext())
				{
					Location block = (Location) blockLocationIter.next();

					RangeLocation range = new RangeLocation(block.getMin(), block.getMax());
					rangeMap.put(range, this.annotationValuesMap.get(currFilter)); // place range into map
				}
			}
		}

		return rangeMap;
	}

	/**
	 * Automatically sets scaling of points so that max point is at top of slot, min is at bottom of slot.
	 */
	@Override
	public void autoScale()
	{
		this.autoscale = true;
	}

	@Override
	public int getNumPoints()
	{
		return this.annotationValuesMap.size();
	}

	@Override
	public void autoScaleCenter()
	{
		// TODO Auto-generated method stub

	}

	@Override
	public double[] getMaxMinValues()
	{
		// TODO Auto-generated method stub
		return null;
	}
}
