package ca.corefacility.gview.style.io.gss.exceptions;

public class UnknownPropertyException extends ParseException
{
	public UnknownPropertyException()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public UnknownPropertyException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UnknownPropertyException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public UnknownPropertyException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
