package ca.corefacility.gview.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import ca.corefacility.gview.main.GViewMain;

/**
 * Extracts GView version information from the manifest file.
 * @author aaron
 *
 */
public class GViewInformation
{
	private static String version;
	private static String buildDate;
	private static String buildRevision;
	
	/**
	 * Initializes the GView information from the passed manifest file.
	 * @param manifestFile  The manifest file to extract the information from.
	 */
	public static void initalize(String manifestFile)
	{
		try
		{
			InputStream stream = GViewInformation.class.getResourceAsStream(manifestFile);
			
			if (stream == null)
			{
				System.err.println("Couldn't find manifest " + manifestFile + ".");
				return;
			}
			
			Manifest manifest = new Manifest(stream);
			
			Attributes attributes = manifest.getMainAttributes();
			
			version = attributes.getValue("Implementation-Version");
			buildDate = attributes.getValue("Built-Date");
			buildRevision = attributes.getValue("Build-SVN-Revision");
		}
		catch (IOException e)
		{
			System.err.println("Couldn't find manifest " + manifestFile + " " + e);
		}
	}
	
	public static String getVersion()
	{
		return version;
	}
	
	public static String getBuildDate()
	{
		return buildDate;
	}
	
	public static String getBuildRevision()
	{
		return buildRevision;
	}
}
