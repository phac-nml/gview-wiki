package ca.corefacility.gview.map.effects;


import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;

import ca.corefacility.gview.map.items.MapItemState;

public interface ShapeEffectRenderer
{
	public static final ShapeEffectRenderer STANDARD_RENDERER = new StandardEffectMouseOverSelect();
	public static final ShapeEffectRenderer SELECT_RENDERER = new StandardEffectSelect();
	public static final ShapeEffectRenderer NO_SELECT_RENDERER = new StandardEffect();
	
	/**
	 * Defines how to paint out the passed shape on the passed graphics context.
	 * @param shape  The shape to paint.
	 * @param g  The graphics context to paint onto.
	 * @param paint  The paint object to use when painting.
	 * @param state The current state of the shape to render.
	 */
	public void paint(Shape shape, Graphics2D g, Paint paint, MapItemState state);
	
	/**
	 * Indicates if the paint method is changed between the two states.
	 * @param previousState
	 * @param nextState
	 * @return  True if the paint needs to be changed between the two states, false otherwise.
	 */
	public boolean paintChanged(MapItemState previousState, MapItemState nextState);
	
	public boolean equals(Object o);
}
