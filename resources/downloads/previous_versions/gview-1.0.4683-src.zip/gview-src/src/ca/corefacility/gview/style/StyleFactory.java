package ca.corefacility.gview.style;


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.awt.Stroke;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;

import ca.corefacility.gview.data.Slot;
import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.map.effects.OutlineEffect;
import ca.corefacility.gview.map.effects.OutsideEffect;
import ca.corefacility.gview.map.effects.ShadowEffect;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.map.effects.StandardEffect;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.LabelStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.items.BackboneStyle;
import ca.corefacility.gview.style.items.RulerStyle;
import ca.corefacility.gview.style.items.TooltipStyle;
import ca.corefacility.gview.textextractor.AnnotationExtractor;
import ca.corefacility.gview.textextractor.GeneTextExtractor;
import ca.corefacility.gview.textextractor.LocationExtractor;

/**
 * A class which stores/creates some styles that are used many times.
 * 
 * @author Aaron Petkau
 * 
 */
public class StyleFactory
{
	public static MapStyle createDefaultStyle()
	{
		MapStyle style = new MapStyle();

		// set the style
		GlobalStyle gStyle = style.getGlobalStyle();
		gStyle.setDefaultHeight(700);
		gStyle.setDefaultWidth(700);

		gStyle.setBackgroundPaint(Color.BLACK);
		gStyle.setShowBorder(true);
		// gStyle.setBorderPaint(Color.BLACK);
		gStyle.setTitle("Test1");
		gStyle.setTitlePaint(Color.BLACK);
		gStyle.setTitleFont(new Font("SansSerif", Font.PLAIN, 20));
		gStyle.setSlotSpacing(10.0);

		TooltipStyle tStyle = gStyle.getTooltipStyle();
		tStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tStyle.setBackgroundPaint(new Color(0, 0, 0, 0.7f));
		tStyle.setTextPaint(Color.RED);

		BackboneStyle bStyle = gStyle.getBackboneStyle();
		bStyle.setPaint(Color.GRAY);
		bStyle.setThickness(5.0);
		bStyle.setShapeEffectRenderer(ShapeEffectRenderer.NO_SELECT_RENDERER);

		RulerStyle rStyle = gStyle.getRulerStyle();
		rStyle.setMajorTickLength(15.0);
		rStyle.setTickThickness(2.0);
		rStyle.setMinorTickPaint(Color.LIGHT_GRAY);
		rStyle.setMajorTickPaint(Color.DARK_GRAY);
		rStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		rStyle.setTextPaint(Color.WHITE);
		rStyle.setTextBackgroundPaint( new Color( 0,0,0,200 ) );
		// rStyle.setShapeEffectRenderer(new HighlightEffect());

		style.setDataStyle(createDataStyle());

		return style;
	}

	@SuppressWarnings("unused")
	private static void createDefaultDataStyle(DataStyle dataStyle)
	{
		SlotStyle slot1 = dataStyle.createSlotStyle(1);

		slot1.setPaint(Color.BLUE);
		slot1.setThickness(30);

		FeatureHolderStyle all = slot1.createFeatureHolderStyle(FeatureFilter.all);
		all.setToolTipExtractor(new GeneTextExtractor());
		all.setFeatureShapeRealizer(FeatureShapeRealizer.NO_ARROW);
	}

	public static DataStyle createDataStyle()
	{
		DataStyle dataStyle = new DataStyle();

		SlotStyle positive = dataStyle.createSlotStyle(Slot.FIRST_UPPER);

		positive.setPaint(Color.BLUE);
		positive.setThickness(35);
		positive.setShapeEffectRenderer(ShapeEffectRenderer.STANDARD_RENDERER);

		FeatureHolderStyle positiveHolder = positive.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positiveHolder.setTransparency(0.7f);
		positiveHolder.setToolTipExtractor(new GeneTextExtractor());
		positiveHolder.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW); // Note: this
		// part doesn't
		// work for now
		// and isn't
		// really needed

		LabelStyle posLabels = positiveHolder.getLabelStyle();
		posLabels.setLabelExtractor(new LocationExtractor());
		posLabels.setShowLabels(true);
		posLabels.setInitialLineLength(50);
		posLabels.setBackgroundPaint( new Color( 255, 255, 255, 200 ) );

		SlotStyle negative = dataStyle.createSlotStyle(Slot.FIRST_LOWER);

		negative.setPaint(Color.RED); // this paint may be useless, since paints in featureholders
		// override it
		negative.setThickness(35);
		negative.setTransparency(1.0f);
		negative.setShapeEffectRenderer(ShapeEffectRenderer.STANDARD_RENDERER);

		FeatureHolderStyle negativeHolder = negative.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeHolder.setTransparency(0.7f);
		negativeHolder.setToolTipExtractor(new AnnotationExtractor("product"));
		negativeHolder.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);

		LabelStyle negLabels = negativeHolder.getLabelStyle();
		negLabels.setLabelExtractor(new LocationExtractor());
		negLabels.setShowLabels(true);
		negLabels.setInitialLineLength(50);
		negLabels.setBackgroundPaint( new Color( 255, 255, 255, 200 ) );

		SlotStyle extra = dataStyle.createSlotStyle(Slot.FIRST_UPPER + 1);

		extra.setPaint(Color.GREEN);
		extra.setThickness(40);
		extra.setTransparency(1.0f);
		extra.setShapeEffectRenderer(new OutlineEffect());

		extra.createFeatureHolderStyle(new FeatureFilter.HasAnnotation("product"));

		return dataStyle;
	}

	public static MapStyle createPosterStyle()
	{
		// final Paint shading = new Color(0.0f, 0.0f, 0.0f, 0.2f);
		// final Stroke shadeStroke = new BasicStroke(1.0f);

		MapStyle style = new MapStyle();

		// set the style
		GlobalStyle gStyle = style.getGlobalStyle();
		gStyle.setDefaultHeight(700);
		gStyle.setDefaultWidth(700);

		gStyle.setBackgroundPaint(Color.WHITE);
		gStyle.setShowBorder(true);
		// gStyle.setBorderPaint(Color.BLACK);
		// gStyle.setTitle("Test1");
		gStyle.setTitlePaint(Color.BLACK);
		gStyle.setTitleFont(new Font("SansSerif", Font.PLAIN, 20));
		gStyle.setSlotSpacing(10.0);

		TooltipStyle tStyle = gStyle.getTooltipStyle();
		tStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tStyle.setTextPaint(Color.BLACK);
		tStyle.setBackgroundPaint(new Color(134, 134, 255));
		tStyle.setOutlinePaint(new Color(0.0f, 0.0f, 0.0f, 0.5f));

		BackboneStyle bStyle = gStyle.getBackboneStyle();
		bStyle.setPaint(Color.GRAY);
		bStyle.setThickness(5.0);
		bStyle.setShapeEffectRenderer(ShapeEffectRenderer.NO_SELECT_RENDERER);
		bStyle.setShapeEffectRenderer(new StandardEffect());

		RulerStyle rStyle = gStyle.getRulerStyle();
		rStyle.setMajorTickLength(8.0);
		rStyle.setMinorTickLength(3.0);
		rStyle.setTickDensity(0.5f);
		rStyle.setTickThickness(2.0);
		rStyle.setMinorTickPaint(Color.GREEN.darker().darker());
		rStyle.setMajorTickPaint(Color.GREEN.darker().darker());
		rStyle.setFont(new Font("SansSerif", Font.BOLD, 12));
		rStyle.setTextPaint(Color.BLACK);
		rStyle.setTextBackgroundPaint( new Color( 255,255,255,200 ) );
		rStyle.setShapeEffectRenderer(new StandardEffect());

		DataStyle dataStyle = style.getDataStyle();

		SlotStyle positive = dataStyle.createSlotStyle(Slot.FIRST_UPPER);

		positive.setPaint(Color.BLUE);
		positive.setThickness(35);
		positive.setTransparency(1.0f);
		positive.setShapeEffectRenderer(new OutsideEffect(new Color(0.0f, 0.0f, 0.0f, 0.7f)));

		FeatureHolderStyle positiveHolder = positive.createFeatureHolderStyle(new FeatureFilter.And(new FeatureFilter.StrandFilter(
				StrandedFeature.POSITIVE), new FeatureFilter.ByType("CDS")));
		positiveHolder.setToolTipExtractor(new AnnotationExtractor("product"));
		positiveHolder.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW); // Note: this
		// part doesn't
		// work for now
		// and isn't
		// really needed

		LabelStyle posLabels = positiveHolder.getLabelStyle();
		posLabels.setLabelExtractor(new AnnotationExtractor("product"));
		posLabels.setShowLabels(true);
		posLabels.setInitialLineLength(50);
		posLabels.setTextPaint(Color.BLUE);
		posLabels.setBackgroundPaint( new Color( 255, 255, 255, 200 ) );


		SlotStyle negative = dataStyle.createSlotStyle(Slot.FIRST_LOWER);

		negative.setPaint(Color.RED); // this paint may be useless, since paints in featureholders
		// override it
		negative.setThickness(35);
		negative.setTransparency(1.0f);
		negative.setShapeEffectRenderer(new OutsideEffect(new Color(0.0f, 0.0f, 0.0f, 0.7f)));

		FeatureHolderStyle negativeHolder = negative.createFeatureHolderStyle(new FeatureFilter.And(new FeatureFilter.StrandFilter(
				StrandedFeature.NEGATIVE), new FeatureFilter.ByType("CDS")));
		negativeHolder.setToolTipExtractor(new AnnotationExtractor("product"));
		negativeHolder.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);

		LabelStyle negLabels = negativeHolder.getLabelStyle();
		negLabels.setLabelExtractor(new AnnotationExtractor("product"));
		negLabels.setShowLabels(true);
		negLabels.setInitialLineLength(50);
		negLabels.setTextPaint(Color.BLUE);
		negLabels.setBackgroundPaint( new Color( 255, 255, 255, 200 ) );

		return style;
	}

	public static MapStyle createPosterStyleNoLabels()
	{
		final Paint shading = new Color(0.0f, 0.0f, 0.0f, 0.2f);
		final Stroke shadeStroke = new BasicStroke(1.0f);

		MapStyle style = new MapStyle();

		// set the style
		GlobalStyle gStyle = style.getGlobalStyle();
		gStyle.setDefaultHeight(700);
		gStyle.setDefaultWidth(700);

		gStyle.setBackgroundPaint(Color.WHITE);
		gStyle.setShowBorder(true);
		// gStyle.setBorderPaint(Color.BLACK);
		// gStyle.setTitle("Test1");
		gStyle.setTitlePaint(Color.BLACK);
		gStyle.setTitleFont(new Font("SansSerif", Font.PLAIN, 20));
		gStyle.setSlotSpacing(10.0);

		TooltipStyle tStyle = gStyle.getTooltipStyle();
		tStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tStyle.setBackgroundPaint(new Color(0, 0, 0, 0.7f));
		tStyle.setTextPaint(Color.BLACK);
		tStyle.setBackgroundPaint(new Color(134, 134, 255));
		tStyle.setOutlinePaint(new Color(0.0f, 0.0f, 0.0f, 0.5f));

		BackboneStyle bStyle = gStyle.getBackboneStyle();
		bStyle.setPaint(Color.GRAY);
		bStyle.setThickness(5.0);
		bStyle.setShapeEffectRenderer(ShapeEffectRenderer.NO_SELECT_RENDERER);
		bStyle.setShapeEffectRenderer(new StandardEffect(shading, new BasicStroke(1.2f)));

		RulerStyle rStyle = gStyle.getRulerStyle();
		rStyle.setMajorTickLength(15.0);
		rStyle.setTickThickness(2.0);
		rStyle.setMinorTickPaint(Color.GREEN.darker().darker());
		rStyle.setMajorTickPaint(Color.GREEN.darker().darker());
		rStyle.setFont(null);
		rStyle.setTextPaint(null);
		rStyle.setShapeEffectRenderer(new StandardEffect(shading, new BasicStroke(1.2f)));

		DataStyle dataStyle = style.getDataStyle();

		SlotStyle positive = dataStyle.createSlotStyle(Slot.FIRST_UPPER);

		positive.setPaint(Color.BLUE);
		positive.setThickness(35);
		positive.setTransparency(1.0f);
		positive.setShapeEffectRenderer(new OutsideEffect(shading, shadeStroke));

		FeatureHolderStyle positiveHolder = positive.createFeatureHolderStyle(new FeatureFilter.And(new FeatureFilter.StrandFilter(
				StrandedFeature.POSITIVE), new FeatureFilter.ByType("CDS")));
		positiveHolder.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW); // Note: this
		// part doesn't
		// work for now
		// and isn't
		// really needed

		SlotStyle negative = dataStyle.createSlotStyle(Slot.FIRST_LOWER);

		negative.setPaint(Color.RED); // this paint may be useless, since paints in featureholders
		// override it
		negative.setThickness(35);
		negative.setTransparency(1.0f);
		negative.setShapeEffectRenderer(new OutsideEffect(shading, shadeStroke));

		FeatureHolderStyle negativeHolder = negative.createFeatureHolderStyle(new FeatureFilter.And(new FeatureFilter.StrandFilter(
				StrandedFeature.NEGATIVE), new FeatureFilter.ByType("CDS")));
		negativeHolder.setToolTipExtractor(new AnnotationExtractor("product"));
		negativeHolder.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);

		return style;
	}

	public static MapStyle createPosterStyle2()
	{
		final Paint shading = new Color(0.0f, 0.0f, 0.0f, 0.2f);
		final Stroke shadeStroke = new BasicStroke(1.0f);

		MapStyle style = new MapStyle();

		// set the style
		GlobalStyle gStyle = style.getGlobalStyle();
		gStyle.setDefaultHeight(700);
		gStyle.setDefaultWidth(700);

		gStyle.setBackgroundPaint(Color.WHITE);
		gStyle.setShowBorder(true);
		// gStyle.setBorderPaint(Color.BLACK);
		// gStyle.setTitle("Test1");
		gStyle.setTitlePaint(Color.BLACK);
		gStyle.setTitleFont(new Font("SansSerif", Font.PLAIN, 20));
		gStyle.setSlotSpacing(10.0);

		TooltipStyle tStyle = gStyle.getTooltipStyle();
		tStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tStyle.setBackgroundPaint(new Color(0, 0, 0, 0.7f));
		tStyle.setTextPaint(Color.BLACK);
		tStyle.setBackgroundPaint(new Color(134, 134, 255));
		tStyle.setOutlinePaint(new Color(0.0f, 0.0f, 0.0f, 0.5f));

		BackboneStyle bStyle = gStyle.getBackboneStyle();
		bStyle.setPaint(Color.GRAY);
		bStyle.setThickness(5.0);
		bStyle.setShapeEffectRenderer(ShapeEffectRenderer.NO_SELECT_RENDERER);
		bStyle.setShapeEffectRenderer(new StandardEffect(shading, new BasicStroke(1.2f)));

		RulerStyle rStyle = gStyle.getRulerStyle();
		rStyle.setMajorTickLength(15.0);
		rStyle.setTickThickness(2.0);
		rStyle.setMinorTickPaint(Color.GREEN.darker().darker());
		rStyle.setMajorTickPaint(Color.GREEN.darker().darker());
		rStyle.setFont(new Font("SansSerif", Font.PLAIN, 12));
		rStyle.setTextPaint(Color.BLACK);
		rStyle.setTextBackgroundPaint( new Color( 255,255,255,200 ) );
		rStyle.setShapeEffectRenderer(new StandardEffect(shading, new BasicStroke(1.2f)));

		DataStyle dataStyle = style.getDataStyle();

		SlotStyle positive = dataStyle.createSlotStyle(Slot.FIRST_UPPER);

		positive.setPaint(Color.BLUE);
		positive.setThickness(35);
		positive.setTransparency(1.0f);
		positive.setShapeEffectRenderer(new ShadowEffect());

		FeatureHolderStyle positiveHolder = positive.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		positiveHolder.setToolTipExtractor(new AnnotationExtractor("product"));
		positiveHolder.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW); // Note: this
		// part doesn't
		// work for now
		// and isn't
		// really needed

		LabelStyle posLabels = positiveHolder.getLabelStyle();
		posLabels.setLabelExtractor(new AnnotationExtractor("gene"));
		posLabels.setShowLabels(true);
		posLabels.setInitialLineLength(50);
		posLabels.setTextPaint(Color.BLUE);
		posLabels.setBackgroundPaint( new Color( 255, 255, 255, 200 ) );

		SlotStyle negative = dataStyle.createSlotStyle(Slot.FIRST_LOWER);

		negative.setPaint(Color.RED); // this paint may be useless, since paints in featureholders
		// override it
		negative.setThickness(35);
		negative.setTransparency(1.0f);
		negative.setShapeEffectRenderer(new ShadowEffect());

		FeatureHolderStyle negativeHolder = negative.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		negativeHolder.setToolTipExtractor(new AnnotationExtractor("product"));
		negativeHolder.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);

		LabelStyle negLabels = negativeHolder.getLabelStyle();
		negLabels.setLabelExtractor(new AnnotationExtractor("gene"));
		negLabels.setShowLabels(true);
		negLabels.setInitialLineLength(50);
		negLabels.setTextPaint(Color.BLUE);
		negLabels.setBackgroundPaint( new Color( 255, 255, 255, 200 ) );

		return style;
	}
}
