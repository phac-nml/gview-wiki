package ca.corefacility.gview.map.effects;


import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;

import ca.corefacility.gview.map.items.MapItemState;

public class StandardEffect implements ShapeEffectRenderer
{
	private Paint outlinePaint;
	private Stroke stroke;
	
	public StandardEffect()
	{
		this(null, new BasicStroke(1.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
	}
	
	public StandardEffect(Paint outlinePaint, Stroke stroke)
	{
		this.outlinePaint = outlinePaint;
		this.stroke = stroke;
	}
	
	public void paint(Shape shape, Graphics2D g, Paint paint, MapItemState state)
	{
		g.setPaint(paint);
		g.fill(shape);
		
		if (outlinePaint != null)
		{
			g.setStroke(stroke);
			g.setPaint(outlinePaint);
			g.draw(shape);
		}
	}

	public boolean paintChanged(MapItemState previousState,
			MapItemState nextState)
	{
		return false;
	}
}
