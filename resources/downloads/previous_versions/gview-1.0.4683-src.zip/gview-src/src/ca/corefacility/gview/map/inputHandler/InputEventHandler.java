package ca.corefacility.gview.map.inputHandler;

import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.items.MapItem;
import ca.corefacility.gview.writers.ImageWriter;
import ca.corefacility.gview.writers.ImageWriterFactory;
import ca.corefacility.gview.writers.ImageWriterFilter;

import edu.umd.cs.piccolo.PCamera;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.event.PBasicInputEventHandler;
import edu.umd.cs.piccolo.event.PInputEvent;

/**
 * Handles keyboard and mouse events on the GView map.
 * @author aaron
 *
 */
public class InputEventHandler extends PBasicInputEventHandler
{
	private PCamera camera;

	private ZoomSubject zoomSubject;
	private SelectHandler selectHandler;
	private MouseOverHandler mouseOverHandler;

	private GViewMap gviewMap;

	private Point2D lastPosition = new Point2D.Double(0,0);

	private static final char RE_CENTER = 'C';
	private static final char ZOOM_OUT = '-';
	private static final char ZOOM_IN = '=';
	private static final char EXPORT = 'E';
	private static final char VIEW_ALL = 'V';
	private static final char VIEW_LEGEND = 'L';

	final private JFileChooser exportDialog;
	
	private LegendHandler legendHandler = null;

	/**
	 * Handles all keyboard/mouse input events.
	 * @param camera  The camera used to view the GView map.
	 * @param gviewMap  The GView map itself.
	 * @param zoomSubject  The object used to handle zooming.
	 * @param selectHandler  The object used to handle selection of items.
	 * @param toolTipHandler  The object used to control the display of the tooltip.
	 */
	public InputEventHandler(PCamera camera, GViewMap gviewMap, ZoomSubject zoomSubject, SelectHandler selectHandler,
			LegendHandler legendHandler, ToolTipHandler toolTipHandler)
	{
		this.camera = camera;

		this.gviewMap = gviewMap;
		this.zoomSubject = zoomSubject;
		this.selectHandler = selectHandler;
		
		this.legendHandler = legendHandler;

		this.mouseOverHandler = new MouseOverHandler(toolTipHandler);

		this.exportDialog = makeExporteDialog();
	}

	/**
	 * Builds the dialog used to export to an image file.
	 * @return  A JFileChooser used to export to an image file.
	 */
	private JFileChooser makeExporteDialog()
	{
		JFileChooser saveDialog = new JFileChooser();
		JPanel selectorPanel = new JPanel();
		JRadioButton currentScreenButton = new JRadioButton("Current View");

		selectorPanel.add(currentScreenButton);

		saveDialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
		saveDialog.setFileFilter(new ImageWriterFilter());

		//saveDialog.setAccessory(selectorPanel);

		return saveDialog;
	}

	/**
	 * Performs the export to an image file.  Displays the export dialog allowing the user to save to a file.
	 */
	private void performExport()
	{
		int chooserState;
		boolean continueToShow = true;

		while (continueToShow)
		{
			continueToShow = false;

			chooserState = this.exportDialog.showDialog(null, "Export");

			if (chooserState == JFileChooser.APPROVE_OPTION)
			{
				File saveFile = this.exportDialog.getSelectedFile();

				// if file to save to already exists
				if (saveFile.exists())
				{
					int choice = JOptionPane.showConfirmDialog(null,
							"File " + saveFile.getName() + " already exists.  Are you sure you wish to overwrite it?",
							"File already exists", JOptionPane.YES_NO_OPTION);

					if (choice == JOptionPane.YES_OPTION)
					{
						continueToShow = false;
						doSave(saveFile);
					}
					else
					{
						continueToShow = true;
					}
				}
				else
				{
					doSave(saveFile);
				}
			}
		}
	}

	/**
	 * Performs the actual saving to an image file.
	 * @param saveFile  The File to save the current view to.
	 */
	private void doSave(File saveFile)
	{
		ImageWriter writer;
		try
		{
			if (ImageWriterFactory.acceptsFile(saveFile))
			{
				writer = ImageWriterFactory.createImageWriter(saveFile);
				writer.writeToImage(this.gviewMap, saveFile);
			}
			else
			{
				System.out.println("Unsupported file type " + ImageWriterFactory.extractExtension(saveFile.getName()));
				System.out.print("Extension should be one of ");

				String[] acceptedExtensions = ImageWriterFactory.getAcceptedExtensions();

				for (int i = 0; i < acceptedExtensions.length; i++)
				{
					System.out.print(acceptedExtensions[i] + ",");
				}
				System.out.println("\nDefaulting to png format");

				writer = ImageWriterFactory.createImageWriter("png");
				writer.writeToImage(this.gviewMap, saveFile.getAbsolutePath() + ".png");
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	@Override
	public void keyPressed(PInputEvent event)
	{
		char keyChar = (char)event.getKeyCode(); // returns letters as capitals

		if (RE_CENTER == keyChar && event.isControlDown())
		{
			this.gviewMap.setCenter(0);
		}
		else if (ZOOM_IN == keyChar && event.isControlDown())
		{
			this.lastPosition = this.zoomSubject.zoomStretch(1.2, this.lastPosition);
		}
		else if (ZOOM_OUT == keyChar && event.isControlDown())
		{
			this.lastPosition = this.zoomSubject.zoomStretch(0.8, this.lastPosition);
		}
		else if (VIEW_ALL == keyChar && event.isControlDown())
		{
			this.gviewMap.viewAll();
		}
		else if (EXPORT == keyChar && event.isControlDown() && event.isAltDown() )
		{
			performExport();
		}
		else if (VIEW_LEGEND == keyChar && event.isControlDown())
		{
			legendHandler.toggleLegend();
		}
	}

	// TODO properly handle these
	@Override
	public void keyboardFocusGained(PInputEvent event)
	{

	}

	@Override
	public void keyboardFocusLost(PInputEvent event)
	{

	}

	@Override
	public void mouseClicked(PInputEvent event)
	{
		if (null != event)
		{
			PNode clickedNode = event.getInputManager().getMouseOver().getPickedNode();

			if (clickedNode instanceof MapItem)
			{
				MapItem clickedItem = (MapItem)clickedNode;

				// only select the item clicked on, unless control is down
				if (event.isControlDown())
				{
					this.selectHandler.multiItemSelect(clickedItem);
				}
				else
				{
					this.selectHandler.singleItemSelect(clickedItem);
				}
			}
			else
			{
				this.selectHandler.unselectAll();
			}
		}
	}

	@Override
	public void mousePressed(PInputEvent event)
	{

	}

	@Override
	public void mouseWheelRotated(PInputEvent event)
	{
		// look at mouse wheel rotation more closely
		final double ROTATE_SCALE_DELTA = 0.1;
		final double INITAL_SCALE_FACTOR = 1.0;

		double scaleDelta = INITAL_SCALE_FACTOR - event.getWheelRotation()*ROTATE_SCALE_DELTA;

		Point2D zoomPoint = event.getPosition();

		if (!event.isControlDown())
		{
			this.zoomSubject.zoomStretch(scaleDelta, zoomPoint);
		}
		else
		{
			// TODO I probably don't want to pass camera into here
			this.zoomSubject.zoomNormal(scaleDelta, zoomPoint, this.camera);
		}
	}

	@Override
	public void mouseMoved(PInputEvent event)
	{
		handleNode(event);

		event.getInputManager().setKeyboardFocus(this); // sets this class as the class to handle keyboard events

		this.lastPosition = event.getPosition();
	}

	@Override
	public void mouseDragged(PInputEvent event)
	{
		handleNode(event);

		this.lastPosition = event.getPosition();
	}

	/**
	 * Handles the node the current event is over.
	 * @param event  The current event to handle.
	 */
	private void handleNode(PInputEvent event)
	{
		PNode n = event.getInputManager().getMouseOver().getPickedNode();

		// not sure if this is the best way
		if (n instanceof MapItem)
		{
			MapItem item = (MapItem)n;

			Point2D itemCursorPosition = event.getCanvasPosition();
			event.getPath().canvasToLocal(itemCursorPosition, this.camera);

			this.mouseOverHandler.mouseOver(item, itemCursorPosition);
		}
		else
		{
			this.mouseOverHandler.mouseOver(null, null);
		}
	}
}
