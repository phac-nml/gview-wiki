package ca.corefacility.gview.layout;


import java.awt.Shape;

import org.biojava.bio.seq.DNATools;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.symbol.Symbol;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.layout.sequence.SlotPath;

public class PlotBuilderGC extends PlotBuilderRange
{
	// TODO:  These variables are parameters used to define the size of the sliding window when calculating the GC content and GC skew.  Change this so that the parameters are able to be specified through GSS.
	private static final int DIVISION_WIDTH = 100;
	private static final int WINDOW_SIZE_MODIFIER = 120;
	private boolean	doGCContent;
	public PlotBuilderGC( boolean content )
	{
		this.minValue = -1;
		this.maxValue = 1;
		this.doGCContent = content;
	}

	@Override
	public Shape[][] createPlot(GenomeData genomeData, SlotPath path, PlotDrawer plotDrawer)
	{
		int left = 1 - DIVISION_WIDTH * WINDOW_SIZE_MODIFIER;
		int right = 1 + DIVISION_WIDTH * WINDOW_SIZE_MODIFIER;
		final int WINDOW_SIZE = DIVISION_WIDTH * WINDOW_SIZE_MODIFIER * 2 + 1;
		// I used the same class to do GC Content and GC Skew.  The differences are really minimal, and really the class just
		// needs to generate the data needed then pass the work onto the subclasses.
		if( this.doGCContent )
		{
			int totalGC = 0;
			int gc = 0;

			System.out.print( "Calculating GC Content..." );
			Sequence seq = genomeData.getSequence();

			for( int i = 1; i <= seq.length(); i++ )
			{
				Symbol sym = seq.symbolAt( i );

				if (sym.equals( DNATools.g() ) || sym.equals( DNATools.c() ) )
				{
					totalGC++;
				}
			}
			double averageGC = (double)totalGC / seq.length();
			setCenterHeight( averageGC );
			// Fill the queue with values on either side of the origin
			for( int currentBase = left; currentBase <= right; currentBase++ )
			{
				int symbolLoc = currentBase;
				if( symbolLoc <= 0 )
				{
					symbolLoc = currentBase + seq.length();
				}

				Symbol sym = seq.symbolAt( symbolLoc );

				if (sym.equals( DNATools.g() ) || sym.equals( DNATools.c() ) )
				{
					gc++;
				}
			}

			addRange( 1, 1 + DIVISION_WIDTH, (double)gc / WINDOW_SIZE );
			for( int currentBase = 1; currentBase < seq.length(); currentBase += DIVISION_WIDTH )
			{
				for( int j = 0; j < DIVISION_WIDTH; j++ )
				{
					int base = currentBase - DIVISION_WIDTH * WINDOW_SIZE_MODIFIER + j;
					if( base <= 0 )
					{
						base = base + seq.length();
					}

					Symbol sym = seq.symbolAt( base );
					if (sym.equals( DNATools.g() ) || sym.equals( DNATools.c() ) )
					{
						gc--;
					}


					base = currentBase + DIVISION_WIDTH + j;
					if( base > seq.length() )
					{
						base = base - seq.length();
					}
					sym = seq.symbolAt( base );
					if (sym.equals( DNATools.g() ) || sym.equals( DNATools.c() ) )
					{
						gc++;
					}
				}
				addRange( currentBase + DIVISION_WIDTH, currentBase + DIVISION_WIDTH + DIVISION_WIDTH, (double)gc / WINDOW_SIZE );
			}
		}
		else // Do GC Skew
		{
			int g = 0;
			int c = 0;
			System.out.print("Calculating GC Skew...");
			setCenterHeight( 0 );
			Sequence seq = genomeData.getSequence();
			// Fill the queue with values on either side of the origin
			for( int currentBase = left; currentBase <= right; currentBase++ )
			{
				int symbolLoc = currentBase;
				if( symbolLoc <= 0 )
				{
					symbolLoc = currentBase + seq.length();
				}

				Symbol sym = seq.symbolAt( symbolLoc );

				if (sym.equals( DNATools.g() ) )
				{
					g++;
				}
				else if ( sym.equals( DNATools.c() ) )
				{
					c++;
				}
			}

			addRange( 1, 1 + DIVISION_WIDTH, (g - c)/(double)(g + c) );
			for( int currentBase = 1; currentBase <= seq.length(); currentBase += DIVISION_WIDTH )
			{
				for( int j = 0; j < DIVISION_WIDTH; j++ )
				{
					int base = currentBase - DIVISION_WIDTH * WINDOW_SIZE_MODIFIER + j;
					if( base <= 0 )
					{
						base = base + seq.length();
					}

					Symbol sym = seq.symbolAt( base );
					if (sym.equals( DNATools.g() ) )
					{
						g--;
					}
					else if( sym.equals( DNATools.c() ) )
					{
						c--;
					}

					base = currentBase + DIVISION_WIDTH + j;
					if( base > seq.length() )
					{
						base = base - seq.length();
					}
					sym = seq.symbolAt( base );
					if (sym.equals( DNATools.g() ) )
					{
						g++;
					}
					else if( sym.equals( DNATools.c() ) )
					{
						c++;
					}
				}
				addRange( currentBase + DIVISION_WIDTH, currentBase + DIVISION_WIDTH + DIVISION_WIDTH, (g - c)/(double)(g + c) );
			}

		}
		System.out.println("done");
		autoScaleCenter();
		return super.createPlot( genomeData, path, plotDrawer );
	}

	private double getGCContentFor( int startBase, int stopBase, GenomeData genomeData )
	{
		int gcNumber = 0;
		int totalBases = 0;

		Sequence seq = genomeData.getSequence();

		for( int currBase = startBase - DIVISION_WIDTH * 50; currBase <= stopBase + DIVISION_WIDTH * 50; currBase++ )
		{
			int symbolLoc = currBase;
			// Handle getting bases across the origin
			if( symbolLoc <= 0 )
			{
				symbolLoc = currBase + seq.length();
			}
			Symbol sym = seq.symbolAt( symbolLoc );

			if (sym.equals( DNATools.g() ) || sym.equals( DNATools.c() ) )
			{
				gcNumber++;
			}
			totalBases++;
		}

		return (double)gcNumber / totalBases;
	}

	private double getGCSkewFor(int startBase, int stopBase, GenomeData genomeData)
	{
		int gNumber = 0;
		int cNumber = 0;

		Sequence seq = genomeData.getSequence();

		for (int currBase = startBase - DIVISION_WIDTH * 50; currBase <= stopBase + DIVISION_WIDTH * 50; currBase++)
		{
			int symbolLoc = currBase;
			// Handle getting bases across the origin
			if( symbolLoc <= 0 )
			{
				symbolLoc = currBase + seq.length();
			}
			Symbol sym = seq.symbolAt( symbolLoc );

			if (sym.equals( DNATools.g() ) )
			{
				gNumber++;
			}
			else if ( sym.equals( DNATools.c() ) )
			{
				cNumber++;
			}
		}

		return (gNumber - cNumber)/(double)(gNumber + cNumber);
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + this.DIVISION_WIDTH;
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlotBuilderGC other = (PlotBuilderGC) obj;
		if (this.DIVISION_WIDTH != other.DIVISION_WIDTH)
			return false;
		return true;
	}
}
