package ca.corefacility.gview.data.readers.cgview;

import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.seq.impl.SimpleSequenceFactory;
import org.biojava.bio.symbol.Location;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.bio.symbol.SymbolList;
import org.xml.sax.Attributes;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.AttributesImpl;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.data.readers.AbstractFileFormatReader;
import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.GViewFileData;
import ca.corefacility.gview.layout.PlotBuilderRange;
import ca.corefacility.gview.layout.PlotDrawerCenter;
import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.map.effects.OutsideEffect;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.style.GlobalStyle;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.LabelStyle;
import ca.corefacility.gview.style.datastyle.PlotStyle;
import ca.corefacility.gview.style.datastyle.SlotItemStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.items.LegendAlignment;
import ca.corefacility.gview.style.items.LegendItemStyle;
import ca.corefacility.gview.style.items.LegendStyle;
import ca.corefacility.gview.style.items.RulerStyle;
import ca.corefacility.gview.style.items.TooltipStyle;
import ca.corefacility.gview.textextractor.StringBuilder;
import ca.corefacility.gview.textextractor.StringExtractor;
import ca.corefacility.gview.utils.Util;

/**
 * A FileFormatReader for handling CGView xml file formats.
 *
 * @author Aaron Petkau
 *
 */
@SuppressWarnings( {"unused"})
public class CGViewXMLReader extends AbstractFileFormatReader
{

	/**
	 * Constructs an object to read in information from the CGView xml format.
	 */
	public CGViewXMLReader()
	{

	}

	@Override
	public GViewFileData read(File file) throws IOException, GViewDataParseException
	{
		if (file == null)
		{
			throw new NullPointerException("file is null");
		}

		return read(new FileReader(file));
	}

	@Override
	public GViewFileData read(Reader reader) throws IOException,
			GViewDataParseException
	{
		if (reader == null)
		{
			throw new IllegalArgumentException("reader is null");
		}

		GViewFileData gviewFileData = null;

		CGViewXMLHandler xmlHandler = new CGViewXMLHandler();

		gviewFileData = xmlHandler.read(reader);

		return gviewFileData;
	}

	@Override
	public boolean canRead(String file)
	{
		String extension = Util.extractExtension(file);

		return extension != null && extension.equals("xml");
	}
}
