import java.io.File;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.readers.GViewFileData;
import ca.corefacility.gview.data.readers.GViewFileReader;
import ca.corefacility.gview.layout.sequence.LayoutFactory;
import ca.corefacility.gview.layout.sequence.circular.LayoutFactoryCircular;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.GViewMapFactory;
import ca.corefacility.gview.style.MapStyle;

import edu.umd.cs.piccolo.PCanvas;
import edu.umd.cs.piccolox.PFrame;

public class ExampleCGViewFile extends PFrame
{
	private static final long serialVersionUID = 3216300435741784341L;

	public ExampleCGViewFile(String title, PCanvas canvas)
	{
		super(title, false, canvas);
	}
	
	public static void main(String[] args)
	{
		
		try
		{
			GViewFileData gviewFileData = GViewFileReader.read("example_data/cybercell.xml");
			
			GenomeData data = gviewFileData.getGenomeData();
			MapStyle style = gviewFileData.getMapStyle();
			
			LayoutFactory lFactory = new LayoutFactoryCircular();
			
			GViewMap gViewMap = GViewMapFactory.createMap(data, style, lFactory);
			gViewMap.setVisible(true); // isn't necessary, defaults to visible
			
			new ExampleCGViewFile("cgviewExample", (PCanvas)gViewMap);
			
		}
		catch (Exception e)
		{
			System.err.println(e);
			e.printStackTrace();
		}
	}
}
