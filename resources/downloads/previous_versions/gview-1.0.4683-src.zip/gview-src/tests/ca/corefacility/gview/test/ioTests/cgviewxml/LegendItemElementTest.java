package ca.corefacility.gview.test.ioTests.cgviewxml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;

import org.junit.*;

import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.GViewFileData;
import ca.corefacility.gview.data.readers.GViewFileReader;
import ca.corefacility.gview.data.readers.cgview.CGViewXMLReader;
import ca.corefacility.gview.style.GlobalStyle;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.items.LegendItemStyle;
import ca.corefacility.gview.style.items.LegendStyle;
import ca.corefacility.gview.style.items.LegendTextAlignment;

public class LegendItemElementTest
{
	private CGViewXMLReader cgviewReader;

	@Before
	public void setup()
	{
		cgviewReader = new CGViewXMLReader();
	}
	
	private StringReader generateLegendElementPropertiesText(String legendProperties)
	{
		return new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<legend position=\"upper-right\">\n"+
						"<legendItem " + legendProperties + "/>\n"+
					"</legend>\n"+
				"</cgview>"
				);
	}
	
	private StringReader generateLegendPropertiesText(String legendProperties)
	{
		return new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<legend position=\"upper-right\" " + legendProperties + ">\n"+
						"<legendItem text=\"the_text\"/>\n"+
					"</legend>\n"+
				"</cgview>"
				);
	}
	
	private LegendItemStyle getAndTestForSingleLegendItemStyle(GViewFileData cgviewData)
	{
		MapStyle mapStyle;
		GlobalStyle globalStyle;
		Iterator<LegendStyle> legendStyles;
		LegendStyle legendStyle;
		Iterator<LegendItemStyle> legendItems;
		LegendItemStyle legendItemStyle;
		
		assertNotNull(cgviewData);
		mapStyle = cgviewData.getMapStyle();
		assertNotNull(mapStyle);
		globalStyle = mapStyle.getGlobalStyle();
		assertNotNull(globalStyle);
		legendStyles = globalStyle.legendStyles();
		assertNotNull(legendStyles);
		assertTrue(legendStyles.hasNext());
		legendStyle = legendStyles.next();
		assertFalse(legendStyles.hasNext());
		assertNotNull(legendStyle);
		
		legendItems = legendStyle.legendItems();
		assertNotNull(legendItems);
		assertTrue(legendItems.hasNext());
		legendItemStyle = legendItems.next();
		assertFalse(legendItems.hasNext());
		assertNotNull(legendItemStyle);
		
		return legendItemStyle;
	}
	
	@Test
	public void testOverrideParentProperties() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		LegendItemStyle legendItemStyle;
		
		xmlReader = generateLegendPropertiesText("font=\"SansSerif,bold,12\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(new Font("SansSerif", Font.BOLD, 12), legendItemStyle.getTextFont());
		
		xmlReader = generateLegendPropertiesText("font=\"SansSerif,plain,10\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(new Font("SansSerif", Font.PLAIN, 10), legendItemStyle.getTextFont());
		
		xmlReader = generateLegendPropertiesText("fontColor=\"white\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(Color.white, legendItemStyle.getTextPaint());
		
		xmlReader = generateLegendPropertiesText("fontColor=\"black\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(Color.black, legendItemStyle.getTextPaint());
		
		// test textAlignment?
	}
	
	@Test(expected=GViewDataParseException.class)
	public void testNoText() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		
		xmlReader = generateLegendElementPropertiesText("");
		GViewFileReader.read(xmlReader, cgviewReader);
	}
	
	@Test
	public void testText() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		LegendItemStyle legendItemStyle;
		
		xmlReader = generateLegendElementPropertiesText("text=\"text1\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals("text1", legendItemStyle.getText());
		
		xmlReader = generateLegendElementPropertiesText("text=\"text2\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals("text2", legendItemStyle.getText());
	}
	
	@Test
	public void testPropertiesInherited() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		LegendItemStyle legendItemStyle;
		
		// font
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<legend font=\"SansSerif,bold,12\" position=\"upper-right\">\n"+
						"<legendItem text=\"text1\"/>\n"+
					"</legend>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(new Font("SansSerif", Font.BOLD, 12), legendItemStyle.getTextFont());
		
		// font color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<legend fontColor=\"red\" position=\"upper-right\">\n"+
						"<legendItem text=\"text1\"/>\n"+
					"</legend>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(Color.red, legendItemStyle.getTextPaint());
		
		// text alignment
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<legend textAlignment=\"center\" position=\"upper-right\">\n"+
						"<legendItem text=\"text1\"/>\n"+
					"</legend>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(LegendTextAlignment.CENTER, legendItemStyle.getTextAlignment());
	}
	
	@Test
	public void testProperties() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		LegendItemStyle legendItemStyle;
		
		// test drawSwatch default
		xmlReader = generateLegendElementPropertiesText("text=\"text1\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(false, legendItemStyle.isShowSwatch());
		
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" drawSwatch=\"false\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(false, legendItemStyle.isShowSwatch());
		
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" drawSwatch=\"true\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(true, legendItemStyle.isShowSwatch());
		
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" font=\"SansSerif,bold,12\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(new Font("SansSerif", Font.BOLD, 12), legendItemStyle.getTextFont());
		
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" font=\"SansSerif,plain,10\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(new Font("SansSerif", Font.PLAIN, 10), legendItemStyle.getTextFont());
		
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" fontColor=\"white\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(Color.white, legendItemStyle.getTextPaint());
		
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" fontColor=\"black\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(Color.black, legendItemStyle.getTextPaint());
		
		// test swatchColor default
		xmlReader = generateLegendElementPropertiesText("text=\"text1\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(Color.black, legendItemStyle.getSwatchPaint());
		
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" swatchColor=\"red\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(Color.red, legendItemStyle.getSwatchPaint());
		
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" swatchColor=\"white\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(Color.white, legendItemStyle.getSwatchPaint());
		
		// test swatch opacity default
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" swatchColor=\"red\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(Color.red, legendItemStyle.getSwatchPaint());
		
		// test swatch opacity
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" swatchColor=\"red\" swatchOpacity=\"1.0\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(0xFFFF0000, ((Color)legendItemStyle.getSwatchPaint()).getRGB());
		assertEquals(255, ((Color)legendItemStyle.getSwatchPaint()).getAlpha());
		
		// test swatch opacity
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" swatchColor=\"red\" swatchOpacity=\"0.0\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(0x00FF0000, ((Color)legendItemStyle.getSwatchPaint()).getRGB());
		assertEquals(0, ((Color)legendItemStyle.getSwatchPaint()).getAlpha());
		
		// test text alignment
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" textAlignment=\"left\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(LegendTextAlignment.LEFT, legendItemStyle.getTextAlignment());
		
		// test text alignment
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" textAlignment=\"center\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(LegendTextAlignment.CENTER, legendItemStyle.getTextAlignment());
		
		// test text alignment
		xmlReader = generateLegendElementPropertiesText("text=\"text1\" textAlignment=\"right\"");
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		legendItemStyle = getAndTestForSingleLegendItemStyle(cgviewData);
		assertEquals(LegendTextAlignment.RIGHT, legendItemStyle.getTextAlignment());
	}
}
