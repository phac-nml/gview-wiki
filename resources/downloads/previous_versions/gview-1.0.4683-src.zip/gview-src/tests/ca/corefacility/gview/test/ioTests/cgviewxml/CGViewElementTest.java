package ca.corefacility.gview.test.ioTests.cgviewxml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;
import java.util.Iterator;

import junit.framework.Assert;

import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureHolder;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.GViewFileData;
import ca.corefacility.gview.data.readers.GViewFileReader;
import ca.corefacility.gview.data.readers.cgview.CGViewXMLReader;
import ca.corefacility.gview.map.effects.OutsideEffect;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.style.GlobalStyle;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.SlotItemStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.items.BackboneStyle;
import ca.corefacility.gview.textextractor.FeatureTextExtractor;

public class CGViewElementTest
{
	private CGViewXMLReader cgviewReader;
	private double delta = 0.0000001;
	
	private static final ShapeEffectRenderer noShading = ShapeEffectRenderer.NO_SELECT_RENDERER;
	private static final ShapeEffectRenderer shading = new OutsideEffect(new Color(0,0,0,128));
	
	@Before
	public void setup()
	{
		cgviewReader = new CGViewXMLReader();
	}
	
	// expect an exception for 0 sequence length
	@Test(expected=GViewDataParseException.class)
	public void testElementZeroLength() throws IOException, GViewDataParseException
	{
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"0\">\n" +
				"</cgview>"
				);
		
		GViewFileReader.read(xmlReader, cgviewReader);
	}
	
	// expect an exception for negative sequence length
	@Test(expected=GViewDataParseException.class)
	public void testElementNegativeLength() throws IOException, GViewDataParseException
	{
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"0\">\n" +
				"</cgview>"
				);
		
		GViewFileReader.read(xmlReader, cgviewReader);
	}
	
	// expect an exception for no listed sequence length
	@Test(expected=GViewDataParseException.class)
	public void testElementNoSequenceLength() throws IOException, GViewDataParseException
	{
		StringReader xmlReader = new StringReader(
				"<cgview>\n" +
				"</cgview>"
				);
		
		GViewFileReader.read(xmlReader, cgviewReader);
	}
	
	@Test
	public void testElementNoProperties() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"1\">\n" +
				"</cgview>"
				);
		
		GViewFileData cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		Assert.assertNotNull(cgviewData);
		
		genomeData = cgviewData.getGenomeData();
		mapStyle = cgviewData.getMapStyle();
		
		Assert.assertNotNull(genomeData);
		Assert.assertNotNull(mapStyle);
		
		Assert.assertEquals(1, genomeData.getSequenceLength());
		
		dataStyle = mapStyle.getDataStyle();
		assertNotNull(dataStyle);
		
		// should be no slots
		assertEquals(0, dataStyle.getLowerSlot());
		assertEquals(0, dataStyle.getUpperSlot());
	}
	
	@Test
	public void testFeatureThickness() throws IOException, GViewDataParseException
	{
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		SlotStyle slotStyle = null;
		
		GViewFileData cgviewData;
		StringReader xmlReader;
		
		// test default featureThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(8.0, slotStyle.getThickness(), delta);
		
		// test featureThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" featureThickness=\"10.0\">\n" +
					"<featureSlot strand=\"direct\">\n" +
					"</featureSlot>\n"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		dataStyle = mapStyle.getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertEquals(10.0, slotStyle.getThickness(), delta);
	}
	
	@Test
	public void testGiveFeaturePositions() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		FeatureHolder featureHolder;
		Feature feature;
		GenomeData genomeData;
		Iterator<Feature> featureIter;
		FeatureTextExtractor labelExtractor;
		
		// test default giveFeaturePositions
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature label=\"label1\">" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"true\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		genomeData = cgviewData.getGenomeData();
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		// get features from this style
		featureHolder = genomeData.getAllFeatures(featureHolderStyle);
		
		featureIter = featureHolder.features();
		assertTrue(featureIter.hasNext());
		
		feature = featureIter.next();
		assertNotNull(feature);
		
		labelExtractor = featureHolderStyle.getLabelStyle().getLabelExtractor();
		assertNotNull(labelExtractor);
		
		// no feature positions added to label
		assertEquals("label1", labelExtractor.extractText(feature));
		
		// test false giveFeaturePositions
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" giveFeaturePositions=\"false\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature label=\"label1\">" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"true\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		genomeData = cgviewData.getGenomeData();
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		// get features from this style
		featureHolder = genomeData.getAllFeatures(featureHolderStyle);
		
		featureIter = featureHolder.features();
		assertTrue(featureIter.hasNext());
		
		feature = featureIter.next();
		assertNotNull(feature);
		
		labelExtractor = featureHolderStyle.getLabelStyle().getLabelExtractor();
		assertNotNull(labelExtractor);
		
		// no feature positions added to label
		assertEquals("label1", labelExtractor.extractText(feature));
		
		// test true giveFeaturePositions
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" giveFeaturePositions=\"true\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature label=\"label1\">" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"true\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		genomeData = cgviewData.getGenomeData();
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		// get features from this style
		featureHolder = genomeData.getAllFeatures(featureHolderStyle);
		
		featureIter = featureHolder.features();
		assertTrue(featureIter.hasNext());
		
		feature = featureIter.next();
		assertNotNull(feature);
		
		labelExtractor = featureHolderStyle.getLabelStyle().getLabelExtractor();
		assertNotNull(labelExtractor);
		
		// feature positions added to label
		assertEquals("label1 1-2", labelExtractor.extractText(feature));
		
		
		// test auto giveFeaturePositions
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" giveFeaturePositions=\"auto\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature label=\"label1\">" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"true\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		genomeData = cgviewData.getGenomeData();
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		// get features from this style
		featureHolder = genomeData.getAllFeatures(featureHolderStyle);
		
		featureIter = featureHolder.features();
		assertTrue(featureIter.hasNext());
		
		feature = featureIter.next();
		assertNotNull(feature);
		
		labelExtractor = featureHolderStyle.getLabelStyle().getLabelExtractor();
		assertNotNull(labelExtractor);
		
		// feature positions added to label
		assertEquals("label1 1-2", labelExtractor.extractText(feature));
	}
	
	// test globalLabel
	
	@Test
	public void testGlobalLabelColor() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		
		// test default color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"false\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertNull(featureHolderStyle.getLabelStyle().getBackgroundPaint());
		
		// test color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" globalLabelColor=\"red\" useColoredLabelBackgrounds=\"true\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"false\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertEquals(Color.red, featureHolderStyle.getLabelStyle().getBackgroundPaint());
	}
	
	@Test
	public void testLabelFont() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		
		// test default font
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"false\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertEquals(new Font("SansSerif", Font.PLAIN, 10), featureHolderStyle.getLabelStyle().getFont());
	}
	
	@Test
	public void testShowShading() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		
		// test default showShading
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertEquals(shading, featureHolderStyle.getShapeEffectRenderer());
		
		// test showShading
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" showShading=\"true\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertEquals(shading, featureHolderStyle.getShapeEffectRenderer());
		
		// test showShading
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" showShading=\"false\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertEquals(noShading, featureHolderStyle.getShapeEffectRenderer());
	}
	
	@Test
	public void testUseColoredLabelBackgrounds() throws IOException, GViewDataParseException
	{
		StringReader xmlReader;
		GViewFileData cgviewData;
		DataStyle dataStyle;
		SlotStyle slotStyle;
		SlotItemStyle currItemStyle;
		FeatureHolderStyle featureHolderStyle;
		
		// test default
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" globalLabelColor=\"red\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"false\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		Iterator<SlotItemStyle> styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertNull(featureHolderStyle.getLabelStyle().getBackgroundPaint());
		
		// test false
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" globalLabelColor=\"red\" useColoredLabelBackgrounds=\"false\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"false\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertNull(featureHolderStyle.getLabelStyle().getBackgroundPaint());
		
		// test true
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" globalLabelColor=\"red\" useColoredLabelBackgrounds=\"true\">" +
					"<featureSlot strand=\"direct\">" +
						"<feature>" +
							"<featureRange start=\"1\" stop=\"2\" showLabel=\"false\">"+
							"</featureRange>"+
						"</feature>"+
					"</featureSlot>"+
				"</cgview>"
				);
		
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		dataStyle = cgviewData.getMapStyle().getDataStyle();
		slotStyle = dataStyle.getSlotStyle(1);
		assertNotNull(slotStyle);

		styleIter = slotStyle.styles();
		assertNotNull(styleIter);
		
		assertTrue(styleIter.hasNext());
		currItemStyle = styleIter.next();
		assertNotNull(currItemStyle);
		assertFalse(styleIter.hasNext());
		featureHolderStyle = null;
		
		assertTrue(currItemStyle instanceof FeatureHolderStyle);
		featureHolderStyle = (FeatureHolderStyle)currItemStyle;
		
		assertEquals(Color.red, featureHolderStyle.getLabelStyle().getBackgroundPaint());
	}
	
	@Test
	public void testElementProperties() throws IOException, GViewDataParseException
	{
		GenomeData genomeData = null;
		MapStyle mapStyle = null;
		DataStyle dataStyle = null;
		GlobalStyle globalStyle = null;
		BackboneStyle backboneStyle = null;
		
		// test color green
		StringReader xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneColor=\"green\">\n" +
				"</cgview>"
				);
		
		GViewFileData cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		
		Assert.assertNotNull(cgviewData);
		
		genomeData = cgviewData.getGenomeData();
		mapStyle = cgviewData.getMapStyle();
		
		Assert.assertNotNull(genomeData);
		Assert.assertNotNull(mapStyle);
		
		Assert.assertEquals(10, genomeData.getSequenceLength());
		
		dataStyle = mapStyle.getDataStyle();
		assertNotNull(dataStyle);
		
		// should be no slots
		assertEquals(0, dataStyle.getLowerSlot());
		assertEquals(0, dataStyle.getUpperSlot());
		
		globalStyle = mapStyle.getGlobalStyle();
		assertNotNull(globalStyle);
		
		backboneStyle = globalStyle.getBackboneStyle();
		assertNotNull(backboneStyle);
		
		assertEquals(new Color(0,128,0), backboneStyle.getPaint());
		
		// arrowheadLength
		
		// test default backbone color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.gray, mapStyle.getGlobalStyle().getBackboneStyle().getPaint());
		
		// test backbone color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneColor=\"red\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.red, mapStyle.getGlobalStyle().getBackboneStyle().getPaint());
		
		
		// test default backboneRadius
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(190.0*Math.PI*2, mapStyle.getGlobalStyle().getBackboneStyle().getInitialBackboneLength(), delta);
		
		// test backboneRadius
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneRadius=\"10.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(10.0*Math.PI*2, mapStyle.getGlobalStyle().getBackboneStyle().getInitialBackboneLength(), delta); // setting radius should set the "backboneLength" in gview
		
		// test backboneRadius
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneRadius=\"550.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(550.0*Math.PI*2, mapStyle.getGlobalStyle().getBackboneStyle().getInitialBackboneLength(), delta);
		
		// test default backbone thickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(5.0, mapStyle.getGlobalStyle().getBackboneStyle().getThickness(), delta);
		
		// test backbone thickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneThickness=\"15.2\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(15.2, mapStyle.getGlobalStyle().getBackboneStyle().getThickness(), delta);
		
		// test backbone thickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backboneThickness=\"xx-large\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(8.0, mapStyle.getGlobalStyle().getBackboneStyle().getThickness(), delta);
		
		// test default background color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.white, mapStyle.getGlobalStyle().getBackgroundPaint());
		
		// test background color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backgroundColor=\"white\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.white, mapStyle.getGlobalStyle().getBackgroundPaint());
		
		// test background color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" backgroundColor=\"blue\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.blue, mapStyle.getGlobalStyle().getBackgroundPaint());
		
		// borderColor?
		
		// test default featureSlotSpacing
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(4.0, mapStyle.getGlobalStyle().getSlotSpacing(), delta);
		
		// test featureSlotSpacing
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" featureSlotSpacing=\"15.5\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(15.5, mapStyle.getGlobalStyle().getSlotSpacing(), delta);
		
		// test featureSlotSpacing
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" featureSlotSpacing=\"20.5\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(20.5, mapStyle.getGlobalStyle().getSlotSpacing(), delta);
						
		// default height
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(700.0, mapStyle.getGlobalStyle().getDefaultHeight(), delta);
		
		// height
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" height=\"100\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(100.0, mapStyle.getGlobalStyle().getDefaultHeight(), delta);
		
		// height
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" height=\"150\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(150.0, mapStyle.getGlobalStyle().getDefaultHeight(), delta);
		
		// isLinear?
		// labelLineLength?
		// labelLineThickness?
		// labelPlacementQuality?
		// labelsToKeep?
		
		// test default longTickColor
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.black, mapStyle.getGlobalStyle().getRulerStyle().getMajorTickPaint());
		
		// longTickColor
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" longTickColor=\"blue\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.blue, mapStyle.getGlobalStyle().getRulerStyle().getMajorTickPaint());
		
		// longTickColor
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" longTickColor=\"white\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.white, mapStyle.getGlobalStyle().getRulerStyle().getMajorTickPaint());
		
		// minimumFeatureLength
		
		// moveInnerLabelsToOuter?
		
		// origin
		
		// test default rulerFont
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(new Font("SansSerif", Font.PLAIN, 8), mapStyle.getGlobalStyle().getRulerStyle().getFont());
		
		// test rulerFont
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" rulerFont=\"SansSerif, plain, 18\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(new Font("SansSerif", Font.PLAIN, 18), mapStyle.getGlobalStyle().getRulerStyle().getFont());
		
		// test rulerFont
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" rulerFont=\"SansSerif, bold, 20\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(new Font("SansSerif", Font.BOLD, 20), mapStyle.getGlobalStyle().getRulerStyle().getFont());
		
		// test default ruler font color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.black, mapStyle.getGlobalStyle().getRulerStyle().getTextPaint());
		
		// test ruler font color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" rulerFontColor=\"white\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.white, mapStyle.getGlobalStyle().getRulerStyle().getTextPaint());
		
		// test ruler font color
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" rulerFontColor=\"blue\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.blue, mapStyle.getGlobalStyle().getRulerStyle().getTextPaint());
		
		// rulerPadding?
		
		// rulerUnits?
		
		// default shortTickColor
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.black, mapStyle.getGlobalStyle().getRulerStyle().getMinorTickPaint());
		
		// shortTickColor
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" shortTickColor=\"blue\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.blue, mapStyle.getGlobalStyle().getRulerStyle().getMinorTickPaint());
		
		// shortTickColor
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" shortTickColor=\"white\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(Color.white, mapStyle.getGlobalStyle().getRulerStyle().getMinorTickPaint());
		
		// shortTickThickness
		
		// showBorder?
				
		// showWarning?
		
		// default tickDensity
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(1.0, mapStyle.getGlobalStyle().getRulerStyle().getTickDensity(), delta);
		
		// tickDensity
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickDensity=\"0.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(0.0, mapStyle.getGlobalStyle().getRulerStyle().getTickDensity(), delta);
		
		// tickDensity
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickDensity=\"0.5\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(0.5, mapStyle.getGlobalStyle().getRulerStyle().getTickDensity(), delta);
		
		// tickDensity
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickDensity=\"1.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(1.0, mapStyle.getGlobalStyle().getRulerStyle().getTickDensity(), delta);
		
		// test default tickLength
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(7.0, mapStyle.getGlobalStyle().getRulerStyle().getMajorTickLength(), delta);
		
		// test tickLength
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickLength=\"10.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(10.0, mapStyle.getGlobalStyle().getRulerStyle().getMajorTickLength(), delta);
		
		// test tickLength
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickLength=\"xxx-large\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(11.0, mapStyle.getGlobalStyle().getRulerStyle().getMajorTickLength(), delta);
		
		// test default tickThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(2.0, mapStyle.getGlobalStyle().getRulerStyle().getTickThickness(), delta);
		
		// test tickThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickThickness=\"5.0\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(5.0, mapStyle.getGlobalStyle().getRulerStyle().getTickThickness(), delta);
		
		// test tickThickness
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" tickThickness=\"x-large\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(3.0, mapStyle.getGlobalStyle().getRulerStyle().getTickThickness(), delta);
		
		// title?
		
		// titleFontColor
		
		// titleFont
		
		// useInnerLabels
		
		// warningFont
		
		// warningFontColor
		
		// default width
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(700.0, mapStyle.getGlobalStyle().getDefaultWidth(), delta);
		
		// width
		xmlReader = new StringReader(
				"<cgview sequenceLength=\"10\" width=\"100\">\n" +
				"</cgview>"
				);
		cgviewData = GViewFileReader.read(xmlReader, cgviewReader);
		mapStyle = cgviewData.getMapStyle();
		assertEquals(100.0, mapStyle.getGlobalStyle().getDefaultWidth(), delta);
		
		// zeroTickColor
	}
}
