package ca.corefacility.gview.test.ioTests.styles.featureFilterCoder;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.biojava.bio.seq.FeatureFilter;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.io.gss.FeatureFilterHandler;

public class OrCoderTest
{
	@Test
	public void testEncode() throws CSSException, IOException
	{
		String encoded;
		FeatureFilter andFilter;
		
		andFilter = new FeatureFilter.Or(FeatureFilter.all, FeatureFilter.all);		
		encoded = FeatureFilterHandler.encode(andFilter);
		assertEquals("feature-filter(or(\"all\",\"all\"))", encoded);
	}
	
	@Test
	public void testDecode() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		FeatureFilter filter;
		FeatureFilter.Or orFilter;
		FeatureFilter.Or child2Filter;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(" +
				"or(\"all\",\"all\"))")));
		filter = FeatureFilterHandler.decode(currUnit);
		assertNotNull(filter);
		assertEquals(FeatureFilter.Or.class, filter.getClass());
		orFilter = (FeatureFilter.Or)filter;
		assertEquals(FeatureFilter.all, orFilter.getChild1());
		assertEquals(FeatureFilter.all, orFilter.getChild2());
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(" +
		"or(\"all\",\"all\",\"all\"))")));
		filter = FeatureFilterHandler.decode(currUnit);
		assertNotNull(filter);
		assertEquals(FeatureFilter.Or.class, filter.getClass());
		orFilter = (FeatureFilter.Or)filter;
		assertEquals(FeatureFilter.all, orFilter.getChild1());
		assertEquals(FeatureFilter.Or.class, orFilter.getChild2().getClass());
		child2Filter = (FeatureFilter.Or)orFilter.getChild2();
		assertEquals(FeatureFilter.all, child2Filter.getChild1());
		assertEquals(FeatureFilter.all, child2Filter.getChild2());
	}
}
