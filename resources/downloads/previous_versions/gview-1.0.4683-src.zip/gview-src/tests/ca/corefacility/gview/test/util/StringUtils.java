package ca.corefacility.gview.test.util;

import java.io.File;

public class StringUtils
{
	/**
	 * Escaped path separator char if needed (if running under Windows)
	 * @param s
	 * @return
	 */
	public static String escapePathSeparator(String s)
	{
		if (!File.separator.equals("\\"))
		{
			return s;
		}
		
		StringBuffer escapedBuffer = new StringBuffer(s);
		int originalIndex, escapedIndex;
		
		// replace all '\' with '\\'
		for (originalIndex = 0, escapedIndex = 0;originalIndex < s.length(); originalIndex++, escapedIndex++)
		{
			if (s.charAt(originalIndex) == '\\')
			{
				escapedBuffer.insert(escapedIndex, '\\');
				escapedIndex++;
			}
		}
		
		return escapedBuffer.toString();
	}
}
