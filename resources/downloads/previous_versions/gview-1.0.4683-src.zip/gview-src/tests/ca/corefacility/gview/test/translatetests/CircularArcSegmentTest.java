package ca.corefacility.gview.test.translatetests;


import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;

import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.impl.SimpleSequence;
import org.biojava.bio.symbol.SymbolList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.Direction;
import ca.corefacility.gview.layout.prototype.SequencePoint;
import ca.corefacility.gview.layout.prototype.SequencePointImp;
import ca.corefacility.gview.layout.prototype.segments.CircularArcSegment;
import ca.corefacility.gview.layout.sequence.Backbone;
import ca.corefacility.gview.layout.sequence.LocationConverter;
import ca.corefacility.gview.layout.sequence.circular.BackboneCircular;
import ca.corefacility.gview.layout.sequence.circular.Polar;
import ca.corefacility.gview.map.event.ZoomEvent;

public class CircularArcSegmentTest
{
	private Backbone backbone = null;

	private GenomeData data = null;

	private double delta = 0.000000001;

	private double initialRadius = 50;

	private final static int sequenceLength = 100; // must be divisible by 4

	final private AffineTransform MIRROR_Y = new AffineTransform(1, 0, 0, -1, 0, 0);

	@Before
	public void setup()
	{
		SymbolList list = new BlankSymbolList(sequenceLength);
		Sequence seq = new SimpleSequence(list, null, null, null);

		data = GenomeDataFactory.createGenomeData(seq);

		backbone = new BackboneCircular(new LocationConverter(data), initialRadius, 0);
	}
	
	@Test
	public void testAppendWithScale()
	{
		// test 0 height
		testAppendAtHeight(0.0);

		// test other heights
		testAppendAtHeight(-25.0);
		testAppendAtHeight(25.0);
	}

	@Test
	public void testPoints()
	{
		SequencePoint startPoint = new SequencePointImp(0, 0);
		SequencePoint endPoint = new SequencePointImp(sequenceLength, 0);

		// double radius;
		// double startAngle;
		// double extentAngle;
		Point2D startPointScaled;
		Point2D endPointScaled;
		Polar polarStart;
		Polar polarEnd;
		double scale = 1;

		// test at scale 1
		startPointScaled = backbone.translate(startPoint);
		Assert.assertNotNull(startPointScaled);

		endPointScaled = backbone.translate(endPoint);
		Assert.assertNotNull(endPointScaled);

		// this is done to account for mirrored y-coords
		startPointScaled.setLocation(startPointScaled.getX(), -startPointScaled.getY());
		endPointScaled.setLocation(endPointScaled.getX(), -endPointScaled.getY());

		polarStart = Polar.createPolar(startPointScaled);
		polarEnd = Polar.createPolar(endPointScaled);
		Assert.assertEquals(polarStart.getRadius(), polarEnd.getRadius(), delta);
		Assert.assertEquals(polarStart.getRadius(), initialRadius * scale, delta);

		// test at lower scale
		scale = 0.01;
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		startPointScaled = backbone.translate(startPoint);
		Assert.assertNotNull(startPointScaled);

		endPointScaled = backbone.translate(endPoint);
		Assert.assertNotNull(endPointScaled);

		// this is done to account for mirrored y-coords
		startPointScaled.setLocation(startPointScaled.getX(), -startPointScaled.getY());
		endPointScaled.setLocation(endPointScaled.getX(), -endPointScaled.getY());

		polarStart = Polar.createPolar(startPointScaled);
		polarEnd = Polar.createPolar(endPointScaled);
		Assert.assertEquals(polarStart.getRadius(), polarEnd.getRadius(), delta);
		Assert.assertEquals(polarStart.getRadius(), initialRadius * scale, delta);

		// test at higher scale
		scale = backbone.getMaxScale();
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		startPointScaled = backbone.translate(startPoint);
		Assert.assertNotNull(startPointScaled);

		endPointScaled = backbone.translate(endPoint);
		Assert.assertNotNull(endPointScaled);

		// this is done to account for mirrored y-coords
		startPointScaled.setLocation(startPointScaled.getX(), -startPointScaled.getY());
		endPointScaled.setLocation(endPointScaled.getX(), -endPointScaled.getY());

		polarStart = Polar.createPolar(startPointScaled);
		polarEnd = Polar.createPolar(endPointScaled);
		Assert.assertEquals(polarStart.getRadius(), polarEnd.getRadius(), delta);
		Assert.assertEquals(polarStart.getRadius(), initialRadius * scale, delta);
	}

	private void testAppendAtHeight(double height)
	{

//		CircularArcSegment fullSegment;
		CircularArcSegment quarter1;
		CircularArcSegment quarter2;
		CircularArcSegment quarter3;
		CircularArcSegment quarter4;

		SequencePointImp start, end;

		 // create a circular arc which wraps all the way around
//		 start = new SequencePointImp(0, height);
//		 end = new SequencePointImp(sequenceLength, height);
//		 fullSegment = new CircularArcSegment(start, end, Direction.INCREASING);

		start = new SequencePointImp(0, height);
		end = new SequencePointImp(sequenceLength / 4, height);
		quarter1 = new CircularArcSegment(start, end, Direction.INCREASING);

		start = new SequencePointImp(sequenceLength / 4, height);
		end = new SequencePointImp(2 * sequenceLength / 4, height);
		quarter2 = new CircularArcSegment(start, end, Direction.INCREASING);

		start = new SequencePointImp(2 * sequenceLength / 4, height);
		end = new SequencePointImp(3 * sequenceLength / 4, height);
		quarter3 = new CircularArcSegment(start, end, Direction.INCREASING);

		 start = new SequencePointImp(3 * sequenceLength / 4, height);
		 end = new SequencePointImp(4 * sequenceLength / 4, height);
		 quarter4 = new CircularArcSegment(start, end, Direction.INCREASING);

		double maxScale = Math.min(backbone.getMaxScale(), 1000);

		// test the different segments with different scales
		double scale = 1.0;
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));

//		testCircularArcSegmentRadius(initialRadius * scale + height, 0, 360, fullSegment);

		testCircularArcSegmentRadius(initialRadius * scale + height, 0, 90, quarter1);
		testCircularArcSegmentRadius(initialRadius * scale + height, 270, 0, quarter2);
		testCircularArcSegmentRadius(initialRadius * scale + height, 180, 270, quarter3);
		testCircularArcSegmentRadius(initialRadius * scale + height, 270, 0, quarter4);
		
		// test the different segments with different scales
		scale = maxScale/2;
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		testCircularArcSegmentRadius(initialRadius * scale + height, 0, 90, quarter1);
		testCircularArcSegmentRadius(initialRadius * scale + height, 270, 0, quarter2);
		testCircularArcSegmentRadius(initialRadius * scale + height, 180, 270, quarter3);
		testCircularArcSegmentRadius(initialRadius * scale + height, 270, 0, quarter4);
		
		
		// test the different segments with different scales
		scale = maxScale;
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		testCircularArcSegmentRadius(initialRadius * scale + height, 0, 90, quarter1);
		testCircularArcSegmentRadius(initialRadius * scale + height, 270, 0, quarter2);
		testCircularArcSegmentRadius(initialRadius * scale + height, 180, 270, quarter3);
		testCircularArcSegmentRadius(initialRadius * scale + height, 270, 0, quarter4);
	}

	// tests if the circular arc segment defined by the passed angles does not have too much of an error from the real readius
	private void testCircularArcSegmentRadius(double actualRadius, float startDeg, float endDeg, CircularArcSegment segment)
	{
		final float acceptableError = 0.01f;
		
		Path2D arcPath = new Path2D.Double(Path2D.WIND_EVEN_ODD);

		arcPath.reset();

		arcPath.moveTo(0,0);
		segment.appendWithScale(arcPath, backbone);
		arcPath.closePath();

		double error = Arc2DPrecisionTest.determineMaxRadiusError(arcPath, actualRadius, startDeg+0.01f, endDeg-0.01f);

		Assert.assertTrue(error + " <= " + acceptableError, error <= acceptableError);
	}
}
