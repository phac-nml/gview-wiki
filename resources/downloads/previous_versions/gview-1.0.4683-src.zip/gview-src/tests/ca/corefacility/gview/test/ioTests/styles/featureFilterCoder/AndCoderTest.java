package ca.corefacility.gview.test.ioTests.styles.featureFilterCoder;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.biojava.bio.seq.FeatureFilter;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.io.gss.FeatureFilterHandler;

public class AndCoderTest
{
	@Test
	public void testEncode() throws CSSException, IOException
	{
		String encoded;
		FeatureFilter andFilter;
		
		andFilter = new FeatureFilter.And(FeatureFilter.all, FeatureFilter.all);		
		encoded = FeatureFilterHandler.encode(andFilter);
		assertEquals("feature-filter(and(\"all\",\"all\"))", encoded);
	}
	
	@Test
	public void testDecode() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		LexicalUnit currUnit;
		FeatureFilter filter;
		FeatureFilter.And andFilter;
		FeatureFilter.And child2Filter;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(" +
				"and(\"all\",\"all\"))")));
		filter = FeatureFilterHandler.decode(currUnit);
		assertNotNull(filter);
		assertEquals(FeatureFilter.And.class, filter.getClass());
		andFilter = (FeatureFilter.And)filter;
		assertEquals(FeatureFilter.all, andFilter.getChild1());
		assertEquals(FeatureFilter.all, andFilter.getChild2());
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("feature-filter(" +
		"and(\"all\",\"all\",\"all\"))")));
		filter = FeatureFilterHandler.decode(currUnit);
		assertNotNull(filter);
		assertEquals(FeatureFilter.And.class, filter.getClass());
		andFilter = (FeatureFilter.And)filter;
		assertEquals(FeatureFilter.all, andFilter.getChild1());
		assertEquals(FeatureFilter.And.class, andFilter.getChild2().getClass());
		child2Filter = (FeatureFilter.And)andFilter.getChild2();
		assertEquals(FeatureFilter.all, child2Filter.getChild1());
		assertEquals(FeatureFilter.all, child2Filter.getChild2());
	}
}
