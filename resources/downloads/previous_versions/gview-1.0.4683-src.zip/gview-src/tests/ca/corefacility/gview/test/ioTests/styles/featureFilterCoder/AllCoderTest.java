package ca.corefacility.gview.test.ioTests.styles.featureFilterCoder;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;

import org.biojava.bio.seq.FeatureFilter;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.io.gss.featureFilterCoder.AllCoder;
import ca.corefacility.gview.style.io.gss.featureFilterCoder.FeatureFilterCoder;
import ca.corefacility.gview.style.io.gss.featureFilterCoder.HasAnnotationCoder;

public class AllCoderTest
{
	@Test
	public void testEncode() throws CSSException, IOException
	{
		String encoded;
		FeatureFilterCoder coder = new AllCoder();
		
		assertTrue(coder.canCode(FeatureFilter.all));
		
		encoded = coder.encode(FeatureFilter.all);
		
		assertEquals("\"all\"", encoded);
	}
	
	@Test
	public void testDecode() throws CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		FeatureFilterCoder coder = new AllCoder();
		LexicalUnit currUnit;
		FeatureFilter filter;
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("\"all\"")));
		
		filter = coder.decode(currUnit);
		
		assertNotNull(filter);
		assertEquals(FeatureFilter.all.getClass(), filter.getClass());
	}
}
