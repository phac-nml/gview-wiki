package ca.corefacility.gview.test.ioTests.styles;

import java.io.IOException;
import java.io.StringReader;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.junit.*;
import org.w3c.css.sac.*;

import com.steadystate.css.parser.SACParserCSS2;
import com.steadystate.css.parser.selectors.IdConditionImpl;

import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.io.FeatureSetMap;
import ca.corefacility.gview.style.io.gss.GSSErrorHandler;
import ca.corefacility.gview.style.io.gss.GSSSelectorFactory;
import ca.corefacility.gview.style.io.gss.StyleConverter;
import ca.corefacility.gview.style.io.gss.StyleHandler;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;

public class GSSSelectorsTest
{
	private Parser parser;
	
	@Before
	public void setup()
	{
		// build an error handler to re-throw the exceptions so I can test for them
		GSSErrorHandler errorHandler = new GSSErrorHandler()
		{
			@Override
			public void warning(ParseException e) throws ParseException
			{
				throw e;
			}

			@Override
			public void error(ParseException e) throws ParseException
			{
				throw e;
			}

			@Override
			public void fatalError(ParseException e) throws ParseException
			{
				throw e;
			}
			
		};
		
		GSSSelectorFactory selectorFactory = new GSSSelectorFactory();
		StyleConverter globalConverter = new StyleConverter();
		parser = new SACParserCSS2();
		parser.setErrorHandler(errorHandler);
		parser.setSelectorFactory(selectorFactory);
		
		MapStyle mapStyle = new MapStyle();
		StyleHandler styleHandler = new StyleHandler(globalConverter, errorHandler, mapStyle, null);
		parser.setDocumentHandler(styleHandler);
	}
	
	
	@Test(expected=CSSException.class)
	public void testInvalidSelector() throws CSSException, IOException
	{		
		InputSource input = new InputSource(new StringReader("invalid{}"));	
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testFeatureFilterEmpty() throws CSSException, IOException
	{		
		InputSource input = new InputSource(new StringReader("FeatureFilter{}"));	
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testFeatureFilter() throws CSSException, IOException
	{		
		InputSource input = new InputSource(new StringReader("FeatureFilter{set : \"all\";}"));	
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testBackboneSelector() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader("backbone{}"));
		
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testBackgroundSelector() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader("background{}"));
		
		parser.parseStyleSheet(input);		
	}
	
	@Ignore
	@Test
	public void testLegendSelector() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader("legend{}"));
		
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testLegendSpecificSelector() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader("legend#1{}"));
		
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testLegendItemSelector() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader("legend#0 legenditem#1{}"));
		
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testTooltipSelector() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader("tooltip{}"));
		
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testPlotCoder() throws CSSException, IOException
	{		
		InputSource input = new InputSource(new StringReader("slot#-1 plot{}"));	
		parser.parseStyleSheet(input);		
	}
	
	@Test(expected=CSSException.class)
	public void testPlotCoderFeatureSet() throws CSSException, IOException
	{		
		InputSource input = new InputSource(new StringReader(
				"FeatureFilter {set1 : \"all\";}" +
				"slot#-1 FeatureSet#set1 plot{}"));	
		parser.parseStyleSheet(input);		
	}
	
	@Test(expected=CSSException.class)
	public void testPlotCoderSubFeatureSet() throws CSSException, IOException
	{		
		InputSource input = new InputSource(new StringReader(
				"FeatureFilter {set1 : \"all\";}" +
				"slot#-1 FeatureSet#set1{}" +
				"slot#-1 FeatureSet#set1 FeatureSet#set1 plot{}"));	
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testLabelsCoder() throws CSSException, IOException
	{		
		InputSource input = new InputSource(new StringReader("slot#-1 labels{}"));	
		parser.parseStyleSheet(input);		
	}
	
	public void testLabelsCoderFeatureSet() throws CSSException, IOException
	{		
		InputSource input = new InputSource(new StringReader(
				"FeatureFilter {set1 : \"all\";}" +
				"slot#-1 FeatureSet#set1 labels{}"));	
		parser.parseStyleSheet(input);		
	}
	
	public void testLabelsCoderSubFeatureSet() throws CSSException, IOException
	{		
		InputSource input = new InputSource(new StringReader(
				"FeatureFilter {set1 : \"all\";}" +
				"slot#-1 FeatureSet#set1{}" +
				"slot#-1 FeatureSet#set1 FeatureSet#set1 labels{}"));	
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testRulerSelector() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader("ruler{}"));
		
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testSlotSelector() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader("slot{}"));
		
		parser.parseStyleSheet(input);		
	}
	
	@Test(expected=CSSException.class)
	public void testInvalidDescendentSlotSelector() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader("slot ruler{}"));
		
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testComplexSlotSelector() throws CSSException, IOException
	{		
		InputSource input = new InputSource(new StringReader("slot#-1{}"));	
		parser.parseStyleSheet(input);		
	}
	
	@Test
	public void testFeatureSetSelector() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader(
				"FeatureFilter{set1 : \"all\";}\n" + // need to have a FeatureFilter defined
				"slot#1{}\n"+
				"slot#1 FeatureSet#set1{}"));
				
		parser.parseStyleSheet(input);
	}
	
	@Test
	public void testSubFeatureSetSelector() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader(
				"FeatureFilter{set1 : \"all\"; set2 : \"all\";}\n" + // need to have a FeatureFilter defined
				"slot#1{}\n"+
				"slot#1 FeatureSet#set1{}\n"+
				"slot#1 FeatureSet#set1 FeatureSet#set2{}"));
				
		parser.parseStyleSheet(input);
	}
	
	@Ignore
	@Test
	public void testSubFeatureSetSelectorNoDefinedParent() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader(
				"FeatureFilter{set1 : \"all\"; set2 : \"all\";}\n" + // need to have a FeatureFilter defined
				"slot#1{}\n"+
				"slot#1 FeatureSet#set1 FeatureSet#set2{}"));
				
		parser.parseStyleSheet(input);
	}
	
	@Ignore
	@Test
	public void testFeatureSetSelectorNoSlot() throws CSSException, IOException
	{
		InputSource input = new InputSource(new StringReader(
				"FeatureFilter{set1 : \"all\";}\n" + // need to have a FeatureFilter defined
				"slot#1 FeatureSet#set1{}"));
				
		parser.parseStyleSheet(input);
	}
}
