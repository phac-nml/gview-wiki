package ca.corefacility.gview.test.translatetests;


import java.awt.Shape;
import java.awt.geom.Point2D;

import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.impl.SimpleSequence;
import org.biojava.bio.symbol.SymbolList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.Direction;
import ca.corefacility.gview.layout.prototype.NonFragmentingStretchableShape;
import ca.corefacility.gview.layout.prototype.SequencePointImp;
import ca.corefacility.gview.layout.prototype.StretchableShape;
import ca.corefacility.gview.layout.prototype.segments.CircularArcSegment;
import ca.corefacility.gview.layout.prototype.segments.LineSegment;
import ca.corefacility.gview.layout.prototype.segments.MoveSegment;
import ca.corefacility.gview.layout.sequence.Backbone;
import ca.corefacility.gview.layout.sequence.LocationConverter;
import ca.corefacility.gview.layout.sequence.circular.BackboneCircular;
import ca.corefacility.gview.map.event.ZoomEvent;

public class StretchableShapeTest
{
	private GenomeData data = null;

	private double initialRadius = 50;

	private int sequenceLength = 100;

	private final static double THICKNESS = 2.0; // thickness of shape to test

	@Before
	public void setup()
	{
		SymbolList list = new BlankSymbolList(sequenceLength);
		Sequence seq = new SimpleSequence(list, null, null, null);

		data = GenomeDataFactory.createGenomeData(seq);
	}

	// tests to make sure the shapes defining features stretch out properly when zooming in
	@Test
	public void testBackboneZoomEventCircular()
	{
		Backbone backbone = new BackboneCircular(new LocationConverter(data), initialRadius, 0);
		
		double height;
		double scale;
		
		height = -45;
		Shape actualShape = buildStretchableShapeCircular(backbone, height, 0, sequenceLength/2);
		
		// test initial scale
		scale = 1.0;
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		// test the edges of the shape (starting at 90 deg, ending at 270 deg)
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 90-0.01);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 0);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 270+0.01);
		
		
		// test zoomed in scale
		scale = backbone.getMaxScale();
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		// test the edges of the shape (starting at 90 deg, ending at 270 deg)
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 90-0.01);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 0);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 270+0.01);
		
		
		// test 0 height
		height = 0;
		actualShape = buildStretchableShapeCircular(backbone, height, 0, sequenceLength/2);
		
		// test initial scale
		scale = 1.0;
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		// test the edges of the shape (starting at 90 deg, ending at 270 deg)
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 90-0.01);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 0);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 270+0.01);
		
		
		// test zoomed in scale
		scale = backbone.getMaxScale();
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		// test the edges of the shape (starting at 90 deg, ending at 270 deg)
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 90-0.01);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 0);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 270+0.01);
		
		
		// test positive height
		height = 45;
		actualShape = buildStretchableShapeCircular(backbone, height, 0, sequenceLength/2);
		
		// test initial scale
		scale = 1.0;
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		// test the edges of the shape (starting at 90 deg, ending at 270 deg)
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 90-0.01);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 0);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 270+0.01);
		
		
		// test zoomed in scale
		scale = backbone.getMaxScale();
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		// test the edges of the shape (starting at 90 deg, ending at 270 deg)
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 90-0.01);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 0);
		testPointsInShapeCircular(actualShape, scale*initialRadius + height, THICKNESS, 270+0.01);
	}
	
	private void testPointsInShapeCircular(Shape stretchableShape, double radius, double thickness, double angleDeg)
	{
		double px,py;
		
		final double offset = 0.01;
		double angleRad = angleDeg * Math.PI/180;
		
		// test center point in shape
		px = radius*Math.cos(angleRad);
		py = radius*Math.sin(angleRad);
		Assert.assertTrue("stretchableShape.contains(new Point2D.Double("+px+","+py+"))", stretchableShape.contains(new Point2D.Double(px,py)));
		
		// test top point in shape
		px = (radius+thickness/2 - offset)*Math.cos(angleRad);
		py = (radius+thickness/2 - offset)*Math.sin(angleRad);
		Assert.assertTrue("stretchableShape.contains(new Point2D.Double("+px+","+py+"))", stretchableShape.contains(new Point2D.Double(px,py)));
		
		// test top point in shape
		px = (radius+thickness/2 + offset)*Math.cos(angleRad);
		py = (radius+thickness/2 + offset)*Math.sin(angleRad);
		Assert.assertFalse("stretchableShape.contains(new Point2D.Double("+px+","+py+"))", stretchableShape.contains(new Point2D.Double(px,py)));
		
		// test bottom point in shape
		px = (radius-thickness/2 + offset)*Math.cos(angleRad);
		py = (radius-thickness/2 + offset)*Math.sin(angleRad);
		Assert.assertTrue("stretchableShape.contains(new Point2D.Double("+px+","+py+"))", stretchableShape.contains(new Point2D.Double(px,py)));
		
		// test bottom point in shape
		px = (radius-thickness/2 - offset)*Math.cos(angleRad);
		py = (radius-thickness/2 - offset)*Math.sin(angleRad);
		Assert.assertFalse("stretchableShape.contains(new Point2D.Double("+px+","+py+"))", stretchableShape.contains(new Point2D.Double(px,py)));
	}

	private StretchableShape buildStretchableShapeCircular(Backbone backbone, double centerHeight, double startBase, double endBase)
	{
		StretchableShape shape = null;

		double top = centerHeight + THICKNESS / 2;
		double bottom = centerHeight - THICKNESS / 2;

		SequencePointImp startTop = new SequencePointImp(startBase, top);
		SequencePointImp endTop = new SequencePointImp(endBase, top);
		SequencePointImp endBottom = new SequencePointImp(endBase, bottom);
		SequencePointImp startBottom = new SequencePointImp(startBase, bottom);

		shape = new NonFragmentingStretchableShape(backbone);

		shape.appendSegment(new MoveSegment(startTop));
		shape.appendSegment(new CircularArcSegment(startTop, endTop, Direction.INCREASING));
		shape.appendSegment(new LineSegment(endBottom));
		shape.appendSegment(new CircularArcSegment(endBottom, startBottom, Direction.DECREASING));
		// shape.appendSegment(new LineSegment(startTop));

		backbone.addEventListener(shape);

		return shape;
	}
}
