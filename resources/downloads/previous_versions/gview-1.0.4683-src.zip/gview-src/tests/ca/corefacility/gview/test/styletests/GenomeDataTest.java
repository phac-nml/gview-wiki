package ca.corefacility.gview.test.styletests;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;


import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.seq.Feature;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.FeatureHolder;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.seq.impl.SimpleSequenceFactory;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.utils.ChangeVetoException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;

public class GenomeDataTest
{
	private GenomeData genomeData;
	
	private int sequenceLength;
	
	private Feature pos1, pos2;
	private Feature neg1, neg2;
	
	private SlotStyle slotStyle;
	
	@Before
	public void setup()
	{
		sequenceLength = 40;
		
		MapStyle mapStyle = new MapStyle();
		
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		slotStyle = dataStyle.createSlotStyle(1);
		
		genomeData = buildData(sequenceLength);
	}
	
	// builds data to use
	private GenomeData buildData(int sequenceLength)
	{
		SimpleSequenceFactory seqFactory = new SimpleSequenceFactory();
		
		Sequence seq = seqFactory.createSequence(new BlankSymbolList(sequenceLength), null, null, null);
		

		StrandedFeature.Template ft = new StrandedFeature.Template();
		ft.annotation = Annotation.EMPTY_ANNOTATION;
		ft.type = "test";
		ft.source = "testsource";

		// 2 negative features, 2 positive features
		try
		{
			ft.strand = StrandedFeature.POSITIVE;
			ft.location = new RangeLocation(0, 10);
			pos1 = seq.createFeature(ft);
			ft.location = new RangeLocation(10, 20);
			pos2 = seq.createFeature(ft);
			
			ft.strand = StrandedFeature.NEGATIVE;	
			ft.location = new RangeLocation(20, 30);
			neg1 = seq.createFeature(ft);
			ft.location = new RangeLocation(30, 40);
			neg2 = seq.createFeature(ft);
		}
		catch (ChangeVetoException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		catch (BioException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return GenomeDataFactory.createGenomeData(seq);
	}
	
	// deterines if the passed list of features
	private boolean featuresIn(FeatureHolder featureHolder, List<Feature> features)
	{
		boolean isEqual = true;
		
		// should contain same number of features
		isEqual = (features.size() == featureHolder.countFeatures()); 
		
		if (isEqual)
		{
			for (Feature f : features)
			{
				isEqual = (isEqual && featureHolder.containsFeature(f));
			}
			
			Iterator<Feature> fIter = featureHolder.features();
			while (isEqual && fIter.hasNext())
			{
				Feature f = fIter.next();
				
				isEqual = (isEqual && features.contains(f));
			}
		}
		
		return isEqual;
	}
	
	@Test
	public void testValues()
	{
		Assert.assertEquals(sequenceLength, genomeData.getSequenceLength());
		Assert.assertEquals(0, genomeData.getInitialBase());
		
		Assert.assertTrue(genomeData.baseOnSequence(0));
		Assert.assertTrue(genomeData.baseOnSequence(20));
		Assert.assertTrue(genomeData.baseOnSequence(40));
		
		Assert.assertFalse(genomeData.baseOnSequence(-1));
		Assert.assertFalse(genomeData.baseOnSequence(41));
	}
	
	@Test
	public void testFilterData()
	{
		List<Feature> allFeatures = new LinkedList<Feature>();
		allFeatures.add(pos1);
		allFeatures.add(pos2);
		allFeatures.add(neg1);
		allFeatures.add(neg2);
		
		List<Feature> posFeatures = new LinkedList<Feature>();
		posFeatures.add(pos1);
		posFeatures.add(pos2);
		
		List<Feature> negFeatures = new LinkedList<Feature>();
		negFeatures.add(neg1);
		negFeatures.add(neg2);
		
		List<Feature> noFeatures = new LinkedList<Feature>();
		
		FeatureHolderStyle currHolderStyle;
		FeatureHolder currHolder;
		
		// test all features
		currHolderStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.all);
		currHolder = genomeData.getAllFeatures(currHolderStyle);
		Assert.assertTrue(featuresIn(currHolder, allFeatures));
		
		// test positive features
		currHolderStyle = slotStyle.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		currHolder = genomeData.getAllFeatures(currHolderStyle);
		Assert.assertTrue(featuresIn(currHolder, posFeatures));
		
		// test negative features
		currHolderStyle = slotStyle.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));
		currHolder = genomeData.getAllFeatures(currHolderStyle);
		Assert.assertTrue(featuresIn(currHolder, negFeatures));
		
		// test no features
		currHolderStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.none);
		currHolder = genomeData.getAllFeatures(currHolderStyle);
		Assert.assertTrue(featuresIn(currHolder, noFeatures));
		
		
		// test sub styles (positive sub style)
		FeatureHolderStyle allFeaturesStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.all);
		FeatureHolderStyle posSubStyle = allFeaturesStyle.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE));
		
		currHolder = genomeData.getAllFeatures(posSubStyle);
		Assert.assertTrue(featuresIn(currHolder, posFeatures));
		currHolder = genomeData.getOnlyFeatures(posSubStyle);
		Assert.assertTrue(featuresIn(currHolder, posFeatures));
		currHolder = genomeData.getAllFeatures(allFeaturesStyle);
		Assert.assertTrue(featuresIn(currHolder, allFeatures));
		currHolder = genomeData.getOnlyFeatures(allFeaturesStyle);
		Assert.assertTrue(featuresIn(currHolder, negFeatures));
		
		// test sub styles (negative sub style)
		allFeaturesStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.all);
		FeatureHolderStyle negSubStyle = allFeaturesStyle.createFeatureHolderStyle(new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE));

		currHolder = genomeData.getAllFeatures(negSubStyle);
		Assert.assertTrue(featuresIn(currHolder, negFeatures));
		currHolder = genomeData.getOnlyFeatures(negSubStyle);
		Assert.assertTrue(featuresIn(currHolder, negFeatures));
		currHolder = genomeData.getAllFeatures(allFeaturesStyle);
		Assert.assertTrue(featuresIn(currHolder, allFeatures));
		currHolder = genomeData.getOnlyFeatures(allFeaturesStyle);
		Assert.assertTrue(featuresIn(currHolder, posFeatures));
		
		// test sub styles (all sub style)
		allFeaturesStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.all);
		FeatureHolderStyle allSubStyle = allFeaturesStyle.createFeatureHolderStyle(FeatureFilter.all);

		currHolder = genomeData.getAllFeatures(allSubStyle);
		Assert.assertTrue(featuresIn(currHolder, allFeatures));
		currHolder = genomeData.getOnlyFeatures(allSubStyle);
		Assert.assertTrue(featuresIn(currHolder, allFeatures));
		currHolder = genomeData.getAllFeatures(allFeaturesStyle);
		Assert.assertTrue(featuresIn(currHolder, allFeatures));
		currHolder = genomeData.getOnlyFeatures(allFeaturesStyle);
		Assert.assertTrue(featuresIn(currHolder, noFeatures));
		
		// test sub styles (none sub style)
		allFeaturesStyle = slotStyle.createFeatureHolderStyle(FeatureFilter.all);
		FeatureHolderStyle noneSubStyle = allFeaturesStyle.createFeatureHolderStyle(FeatureFilter.none);

		currHolder = genomeData.getAllFeatures(noneSubStyle);
		Assert.assertTrue(featuresIn(currHolder, noFeatures));
		currHolder = genomeData.getOnlyFeatures(noneSubStyle);
		Assert.assertTrue(featuresIn(currHolder, noFeatures));
		currHolder = genomeData.getAllFeatures(allFeaturesStyle);
		Assert.assertTrue(featuresIn(currHolder, allFeatures));
		currHolder = genomeData.getOnlyFeatures(allFeaturesStyle);
		Assert.assertTrue(featuresIn(currHolder, allFeatures));
	}
}
