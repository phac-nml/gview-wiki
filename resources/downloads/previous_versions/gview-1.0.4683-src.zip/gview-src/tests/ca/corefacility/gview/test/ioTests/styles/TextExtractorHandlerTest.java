package ca.corefacility.gview.test.ioTests.styles;

import java.io.IOException;
import java.io.StringReader;


import org.junit.*;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.style.io.gss.TextExtractorHandler;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.textextractor.*;

public class TextExtractorHandlerTest
{
	@Test
	public void encodeDecodeTests()
	{
		FeatureTextExtractor currTextExtractor = new GeneTextExtractor();
		String currEncodedString = "text-extractor(\"gene\")";
		
		Assert.assertEquals(currEncodedString, TextExtractorHandler.encode(currTextExtractor));
		
		currTextExtractor = new LocationExtractor();
		currEncodedString = "text-extractor(\"location\")";
		Assert.assertEquals(currEncodedString, TextExtractorHandler.encode(currTextExtractor));
		
		currTextExtractor = new SymbolsExtractor();
		currEncodedString = "text-extractor(\"symbols\")";
		Assert.assertEquals(currEncodedString, TextExtractorHandler.encode(currTextExtractor));
		
		currTextExtractor = new AnnotationExtractor("ann1");
		currEncodedString = "text-extractor(annotation(\"ann1\"))";
		Assert.assertEquals(currEncodedString, TextExtractorHandler.encode(currTextExtractor));
		
		currTextExtractor = new AnnotationExtractor("ann2");
		currEncodedString = "text-extractor(annotation(\"ann2\"))";
		Assert.assertEquals(currEncodedString, TextExtractorHandler.encode(currTextExtractor));
		
		currTextExtractor = null;
		currEncodedString = "text-extractor(\"null\")";
		Assert.assertEquals(currEncodedString, TextExtractorHandler.encode(currTextExtractor));
	}
	
	@Test(expected=ParseException.class)
	public void decodeInvalidTest() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		FeatureTextExtractor currTextExtractor;
		InputSource currEncodedString = new InputSource(new StringReader("text-extractor(\"invalid\")"));
		LexicalUnit currUnit = parser.parsePropertyValue(currEncodedString);
		TextExtractorHandler.decode(currUnit);
	}
	
	@Test(expected=ParseException.class)
	public void decodeNullTest() throws CSSException, IOException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		FeatureTextExtractor currTextExtractor;
		InputSource currEncodedString = new InputSource(new StringReader("text-extractor(\"null\")"));
		LexicalUnit currUnit = parser.parsePropertyValue(currEncodedString);
		TextExtractorHandler.decode(currUnit);
	}
	
	@Test
	public void decodeTest() throws ParseException, CSSException, IOException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		FeatureTextExtractor currTextExtractor;
		InputSource currEncodedString = new InputSource(new StringReader("text-extractor(\"gene\")"));
		LexicalUnit currUnit = parser.parsePropertyValue(currEncodedString);
		
		Assert.assertEquals(GeneTextExtractor.class, TextExtractorHandler.decode(currUnit).getClass());
		
		currEncodedString = new InputSource(new StringReader("text-extractor(\"location\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(LocationExtractor.class, TextExtractorHandler.decode(currUnit).getClass());
		
		currEncodedString = new InputSource(new StringReader("text-extractor(\"symbols\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(SymbolsExtractor.class, TextExtractorHandler.decode(currUnit).getClass());
		
		currTextExtractor = new AnnotationExtractor("ann1");
		currEncodedString = new InputSource(new StringReader("text-extractor(annotation(\"ann1\"))"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(currTextExtractor, TextExtractorHandler.decode(currUnit));
		
		currTextExtractor = new AnnotationExtractor("ann2");
		currEncodedString = new InputSource(new StringReader("text-extractor(annotation(\"ann2\"))"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(currTextExtractor, TextExtractorHandler.decode(currUnit));
	}
}
