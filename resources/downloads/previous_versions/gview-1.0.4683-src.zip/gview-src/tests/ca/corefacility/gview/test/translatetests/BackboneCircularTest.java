package ca.corefacility.gview.test.translatetests;


import java.awt.geom.Dimension2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.impl.SimpleSequence;
import org.biojava.bio.symbol.SymbolList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.prototype.SequencePoint;
import ca.corefacility.gview.layout.prototype.SequencePointImp;
import ca.corefacility.gview.layout.sequence.Backbone;
import ca.corefacility.gview.layout.sequence.LocationConverter;
import ca.corefacility.gview.layout.sequence.SequenceRectangle;
import ca.corefacility.gview.layout.sequence.circular.BackboneCircular;
import ca.corefacility.gview.layout.sequence.circular.BackboneCircular.ClashShiftException;
import ca.corefacility.gview.layout.sequence.linear.BackboneLinear;
import ca.corefacility.gview.map.event.ZoomEvent;
import ca.corefacility.gview.utils.Dimension2DDouble;

public class BackboneCircularTest
{
	private Backbone backbone;

	private double radius = 50;
	private double maxScale;

	private GenomeData data = null;

	private double delta = 0.0000000001;

	private int sequenceLength = 100;

	@Before
	public void setup()
	{

		SymbolList list = new BlankSymbolList(sequenceLength);
		Sequence seq = new SimpleSequence(list, null, null, null);

		data = GenomeDataFactory.createGenomeData(seq);

		backbone = new BackboneCircular(new LocationConverter(data), radius, 0);
		maxScale = backbone.getMaxScale();
	}

	@Test
	public void translate()
	{
		for (double height = -100; height < 100; height += 0.5)
		{
			translateHeight(height);
		}
	}

	private void assertEqualsOneOf(double expected1, double expected2, double actual, double delta)
	{
		if (!(Math.abs(expected1 - actual) < delta || (Math.abs(expected2 - actual) < delta)))
		{
			Assert.fail();
		}
	}

	@Test
	public void testGetSpannedRectangle()
	{
		Rectangle2D view;
		// BaseRange actualLocation;

		double minHeight = -radius; // minimum height allowed until we reach center of circle

		SequenceRectangle actualSequenceRectangle;

		// sequenceLength needs to be this for tests to run
		Assert.assertEquals(100, sequenceLength);

		// rectangle covering 1st quadrant
		view = new Rectangle2D.Double(0, -radius, radius, radius);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(0, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(25, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(minHeight, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals((Math.sqrt(2) - 1) * radius, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle covering 2nd quadrant
		view = new Rectangle2D.Double(-radius, -radius, radius, radius);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(75, actualSequenceRectangle.getStartBase(), delta);
		assertEqualsOneOf(100, 0, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(minHeight, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals((Math.sqrt(2) - 1) * radius, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle covering 3rd quadrant
		view = new Rectangle2D.Double(-radius, 0, radius, radius);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(50, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(75, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(minHeight, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals((Math.sqrt(2) - 1) * radius, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle covering 4th quadrant
		view = new Rectangle2D.Double(0, 0, radius, radius);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(25, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(50, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(minHeight, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals((Math.sqrt(2) - 1) * radius, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle covering 1st and 2nd quadrant
		view = new Rectangle2D.Double(-radius, -radius, 2 * radius, radius);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(75, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(25, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(minHeight, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals((Math.sqrt(2) - 1) * radius, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle covering 3rd and 4th quadrant
		view = new Rectangle2D.Double(-radius, 0, 2 * radius, radius);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(25, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(75, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(minHeight, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals((Math.sqrt(2) - 1) * radius, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle covering 4th and 1st quadrant
		view = new Rectangle2D.Double(0, -radius, radius, 2 * radius);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(0, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(50, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(minHeight, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals((Math.sqrt(2) - 1) * radius, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle covering 2nd and 3rd quadrant
		view = new Rectangle2D.Double(-radius, -radius, radius, 2 * radius);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(50, actualSequenceRectangle.getStartBase(), delta);
		assertEqualsOneOf(100, 0, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(minHeight, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals((Math.sqrt(2) - 1) * radius, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle covering whole backbone
		view = new Rectangle2D.Double(-radius, -radius, 2 * radius, 2 * radius);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(0, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(100, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(minHeight, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals((Math.sqrt(2) - 1) * radius, actualSequenceRectangle.getEndHeight(), delta); // expect
		// height
		// equal
		// to
		// one
		// of
		// the
		// corners
		// of
		// the
		// view
		// rectangle
		// note: height is the height above the backbone, so this value is the distance from the
		// center to a corner minus the radius (distance from center to backbone)

		// rectangle with 0 width
		view = new Rectangle2D.Double(0, -10, 0, 20);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(0, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(0, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(0, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(0, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle with 0 height
		view = new Rectangle2D.Double(-10, 0, 20, 0);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(0, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(0, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(0, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(0, actualSequenceRectangle.getEndHeight(), delta);

		// rectangle covering nothing
		view = new Rectangle2D.Double(0, 0, 0, 0);
		actualSequenceRectangle = backbone.getSpannedRectangle(view);
		Assert.assertEquals(0, actualSequenceRectangle.getStartBase(), delta);
		Assert.assertEquals(0, actualSequenceRectangle.getEndBase(), delta);
		Assert.assertEquals(0, actualSequenceRectangle.getStartHeight(), delta);
		Assert.assertEquals(0, actualSequenceRectangle.getEndHeight(), delta);
		//		
		// // test with rectangle covering whole sequence
		// view = new Rectangle2D.Double(-50, -50, 100, 100);
		// actualLocation = backbone.getSpannedLocation(view);
		// Assert.assertEquals(0, actualLocation.getStartBase(), delta);
		// Assert.assertEquals(100, actualLocation.getEndBase(), delta);
		//		
		// // test with rectangle in centre, not touching backbone
		// view = new Rectangle2D.Double(-10,-10,10,10);
		// actualLocation = backbone.getSpannedLocation(view);
		// Assert.assertEquals(0, actualLocation.getStartBase(), delta);
		// Assert.assertEquals(100, actualLocation.getEndBase(), delta);
	}

	@Test
	public void testTranslateToSeqPoint()
	{
		Point2D translatePoint = new Point2D.Double();
		SequencePoint sequencePoint;
		double expectedBase, expectedHeight;
		double maxScaleToUse = Math.min(maxScale, 100);

		for (double scale = 0.1; scale < maxScaleToUse; scale += 1.0)
		{
			double actualRadius = radius * scale;
			backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this)); // set scale

			translatePoint.setLocation(0, -actualRadius);
			sequencePoint = backbone.translate(translatePoint);
			expectedBase = 0;
			expectedHeight = 0;
			Assert.assertEquals(expectedBase, sequencePoint.getBase(), delta);
			Assert.assertEquals(expectedHeight, sequencePoint.getHeightFromBackbone(), delta);

			translatePoint.setLocation(actualRadius, 0);
			sequencePoint = backbone.translate(translatePoint);
			expectedBase = sequenceLength / 4.0;
			expectedHeight = 0;
			Assert.assertEquals(expectedBase, sequencePoint.getBase(), delta);
			Assert.assertEquals(expectedHeight, sequencePoint.getHeightFromBackbone(), delta);

			translatePoint.setLocation(0, actualRadius);
			sequencePoint = backbone.translate(translatePoint);
			expectedBase = 2 * sequenceLength / 4.0;
			expectedHeight = 0;
			Assert.assertEquals(expectedBase, sequencePoint.getBase(), delta);
			Assert.assertEquals(expectedHeight, sequencePoint.getHeightFromBackbone(), delta);

			translatePoint.setLocation(-actualRadius, 0);
			sequencePoint = backbone.translate(translatePoint);
			expectedBase = 3 * sequenceLength / 4.0;
			expectedHeight = 0;
			Assert.assertEquals(expectedBase, sequencePoint.getBase(), delta);
			Assert.assertEquals(expectedHeight, sequencePoint.getHeightFromBackbone(), delta);
		}
	}

	@Test
	public void testGetSpannedBases()
	{
		// assumes sequenceLength = 100, and radius = 50
		double spannedBases;
		double length;

		// scale=1

		length = 0;
		spannedBases = backbone.getSpannedBases(length);
		Assert.assertEquals(0, spannedBases, delta);

		// expected number of bases is fraction of the length we are testing out of the whole
		// circles circumference
		// multiplied by the sequenceLength
		length = 10;
		spannedBases = backbone.getSpannedBases(length);
		Assert.assertEquals(length * sequenceLength / (2 * Math.PI * radius), spannedBases, delta);

		length = 50;
		spannedBases = backbone.getSpannedBases(length);
		Assert.assertEquals(length * sequenceLength / (2 * Math.PI * radius), spannedBases, delta);

		length = 2 * Math.PI * radius;
		spannedBases = backbone.getSpannedBases(length);
		Assert.assertEquals(length * sequenceLength / (2 * Math.PI * radius), spannedBases, delta);

		for (double scale = 1.5; scale < 10; scale += 0.5)
		{
			backbone.eventOccured(new ZoomEvent(scale, null, this));

			length = 0;
			spannedBases = backbone.getSpannedBases(length);
			Assert.assertEquals(0, spannedBases, delta);

			// expected number of bases is fraction of the length we are testing out of the whole
			// circles circumference
			// multiplied by the sequenceLength
			length = 10;
			spannedBases = backbone.getSpannedBases(length);
			Assert.assertEquals(length * sequenceLength / (2 * Math.PI * radius * scale), spannedBases, delta);

			length = 50;
			spannedBases = backbone.getSpannedBases(length);
			Assert.assertEquals(length * sequenceLength / (2 * Math.PI * radius * scale), spannedBases, delta);

			length = 2 * Math.PI * radius;
			spannedBases = backbone.getSpannedBases(length);
			Assert.assertEquals(length * sequenceLength / (2 * Math.PI * radius * scale), spannedBases, delta);
		}
	}

	private void translateHeight(double height)
	{
		Point2D zoomPoint = new Point2D.Double(0, 0);

		double maxScaleToUse = Math.min(maxScale, 1000);

		for (double scale = 0.1; scale < maxScaleToUse; scale += 10.0)
		{
			Point2D point = null;
			backbone.eventOccured(new ZoomEvent(scale, zoomPoint, this)); // set scale

			double scaledRadius = radius * scale;

			// test zero case
			point = backbone.translate(0, height);
			Assert.assertEquals(0, point.getX(), delta);
			Assert.assertEquals(-(scaledRadius + height), point.getY(), delta);

			// test 1st quarter
			point = backbone.translate(25, height);
			Assert.assertEquals(scaledRadius + height, point.getX(), delta);
			Assert.assertEquals(0, point.getY(), delta);

			// test halfway
			point = backbone.translate(50, height);
			Assert.assertEquals(0, point.getX(), delta);
			Assert.assertEquals(scaledRadius + height, point.getY(), delta);

			// test 3rd quarter
			point = backbone.translate(75, height);
			Assert.assertEquals(-(scaledRadius + height), point.getX(), delta);
			Assert.assertEquals(0, point.getY(), delta);

			// test last
			point = backbone.translate(100, height);
			Assert.assertEquals(0, point.getX(), delta);
			Assert.assertEquals(-(scaledRadius + height), point.getY(), delta);
		}
	}

	@Test
	public void testFindZoomLengthFor()
	{
		double resultScale;

		resultScale = backbone.findZoomForLength(0, 10);
		Assert.assertTrue(resultScale <= 0);

		resultScale = backbone.findZoomForLength(100, 2 * Math.PI * radius);
		Assert.assertEquals(1, resultScale, delta);

		resultScale = backbone.findZoomForLength(100, 2 * Math.PI * radius / 2);
		Assert.assertEquals(0.5, resultScale, delta);

		resultScale = backbone.findZoomForLength(100, 2 * 2 * Math.PI * radius);
		Assert.assertEquals(2, resultScale, delta);

		resultScale = backbone.findZoomForLength(50, 2 * Math.PI * radius);
		Assert.assertEquals(2, resultScale, delta);

		resultScale = backbone.findZoomForLength(50, 2 * Math.PI * radius / 2);
		Assert.assertEquals(1, resultScale, delta);

		resultScale = backbone.findZoomForLength(50, 2 * 2 * Math.PI * radius);
		Assert.assertEquals(4, resultScale, delta);
	}

	@Test
	public void testClashShift()
	{
		SequencePoint pinnedPoint;
		double heightLimit;

		double height = 10;
		double width = 10;

		double expectedShift;
		double actualShift;

		try
		{
			pinnedPoint = null;
			heightLimit = 0;
			expectedShift = 0;
			actualShift = backbone.calculateClashShift(null, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(expectedShift, actualShift, delta);

			// rectangle below backbone
			pinnedPoint = new SequencePointImp(0, -10);

			Assert.assertEquals(50, radius, delta); // radius should be 50 for these tests

			heightLimit = 0;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(15, actualShift, delta);

			heightLimit = 0;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(0, actualShift, delta);

			heightLimit = 10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(25, actualShift, delta);

			heightLimit = 10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.BELOW);
			Assert.assertEquals(0, actualShift, delta);

			heightLimit = -10;
			actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height, Backbone.ShiftDirection.ABOVE);
			Assert.assertEquals(5, actualShift, delta);

			// heightLimit = -10;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height,
			// Backbone.ShiftDirection.BELOW);
			// Assert.assertTrue(actualShift <= -5.313730034);

			// heightLimit = -20;
			// expectedShift = 0;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = -30;
			// expectedShift = 0;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			//		
			// // rectangle above backbone
			// pinnedPoint = new SequencePointImp(0,5);
			//		
			// heightLimit = 0;
			// expectedShift = 0;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = 10;
			// expectedShift = 0;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = 20;
			// expectedShift = 0;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = 30;
			// expectedShift = 0;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = -10;
			// expectedShift = -10;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = -20;
			// expectedShift = -20;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = -30;
			// expectedShift = -30;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			//		
			// // rectangle in middle of backbone
			// pinnedPoint = new SequencePointImp(0,0);
			//		
			// heightLimit = 0;
			// expectedShift = 5;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = 10;
			// expectedShift = 15;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = 20;
			// expectedShift = 25;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = 30;
			// expectedShift = 35;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = -10;
			// expectedShift = -15;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = -20;
			// expectedShift = -25;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
			//		
			// heightLimit = -30;
			// expectedShift = -35;
			// actualShift = backbone.calculateClashShift(pinnedPoint, heightLimit, width, height);
			// Assert.assertEquals(expectedShift, actualShift, delta);
		}
		catch (ClashShiftException e)
		{
			Assert.fail();
		}

	}
	
	@Test
	public void testCalculateIntersectionScale()
	{
		SymbolList list = new BlankSymbolList(100);
		Sequence seq = new SimpleSequence(list, null, null, null);

		data = GenomeDataFactory.createGenomeData(seq);

		backbone = new BackboneCircular(new LocationConverter(data), radius, 0);
		maxScale = backbone.getMaxScale();
		
		Dimension2D dim1, dim2;
		SequencePoint center1, center2;
		double expectedScale, actualScale;
		
		// case, two rectangles at same position (should always overlap)
		dim1 = new Dimension2DDouble(20, 20);
		dim2 =  new Dimension2DDouble(20, 20);
		
		center1 = new SequencePointImp(0, -50); // rectangle 1 is centered at center of circle (initially)
		center2 = new SequencePointImp(0, -50); // rectangle 2 is centered at center of circle (initially)
		
		expectedScale = backbone.getMaxScale(); // rectangles should always overlap
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, two rectangles on x-axis
		dim1 =  new Dimension2DDouble(20, 20);
		dim2 =  new Dimension2DDouble(20, 20);
		
		center1 = new SequencePointImp(75, 0); // rectangle 1 is on left side
		center2 = new SequencePointImp(25, 0); // rectangle 2 is on right side
		
		expectedScale = 20.0/100.0; // scale at which the rectangles don't overlap anymore (start at distance 100 apart, end at distance 20 apart)
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, two rectangles on x-axis
		dim1 =  new Dimension2DDouble(20, 20);
		dim2 =  new Dimension2DDouble(40, 20); // twice as large as previous case
		
		center1 = new SequencePointImp(75, 0); // rectangle 1 is on left side
		center2 = new SequencePointImp(25, 0); // rectangle 2 is on right side
		
		expectedScale = 30.0/100.0; // scale at which the rectangles don't overlap anymore (start at distance 100 apart, end at distance 30 apart)
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, two rectangles on x-axis, one offset from previous case
		dim1 =  new Dimension2DDouble(20, 20);
		dim2 =  new Dimension2DDouble(20, 20); 
		
		center1 = new SequencePointImp(75, -10); // rectangle 1 is on left side
		center2 = new SequencePointImp(25, 0); // rectangle 2 is on right side
		
		expectedScale = 30.0/100.0; // scale at which the rectangles don't overlap anymore (start at distance 100 apart, end at distance 30 apart)
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, two rectangles on y-axis
		dim1 =  new Dimension2DDouble(20, 20);
		dim2 =  new Dimension2DDouble(20, 20);
		
		center1 = new SequencePointImp(0, 0); // rectangle 1 is on top side
		center2 = new SequencePointImp(50, 0); // rectangle 2 is on bottom side
		
		expectedScale = 20.0/100.0; // scale at which the rectangles don't overlap anymore (start at distance 100 apart, end at distance 20 apart)
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, two rectangles on y-axis
		dim1 =  new Dimension2DDouble(20, 20);
		dim2 =  new Dimension2DDouble(20, 40);
		
		center1 = new SequencePointImp(0, 0); // rectangle 1 is on top side
		center2 = new SequencePointImp(50, 0); // rectangle 2 is on bottom side
		
		expectedScale = 30.0/100.0; // scale at which the rectangles don't overlap anymore (start at distance 100 apart, end at distance 20 apart)
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, two rectangles on y-axis
		dim1 =  new Dimension2DDouble(20, 20);
		dim2 =  new Dimension2DDouble(20, 40);
		
		center1 = new SequencePointImp(0, 0); // rectangle 1 is on top side
		center2 = new SequencePointImp(50, -20); // rectangle 2 is on bottom side
		
		expectedScale = 50.0/100.0; // scale at which the rectangles don't overlap anymore (start at distance 100 apart, end at distance 50 apart)
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, two rectangles on circle, 90 degrees apart
		dim1 =  new Dimension2DDouble(20, 20);
		dim2 =  new Dimension2DDouble(20, 20);
		
		center1 = new SequencePointImp(87.5, 0); // rectangle 1 is on left (45 degrees from vertical)
		center2 = new SequencePointImp(12.5, 0); // rectangle 2 is on right (45 degrees from vertical)
		
		// scale at which the rectangles don't overlap anymore (start at distance 2*50*cos(pi/4) apart, down to 20 apart in x direction)
		expectedScale = 20.0/(2*50*Math.cos(Math.PI/4));
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
		
		// case, one very long rectangle at the top, another starting "above" it
		dim1 =  new Dimension2DDouble(1000, 10);
		dim2 =  new Dimension2DDouble(20, 20);
		
		center1 = new SequencePointImp(0, 0); // rectangle 1 is at very top
		
		// rectangle 2 will start out "above" rectangle 1, that is it must satisfy
		//	height of rectangle 2 bottom initially >= height of rectangle 1 top initially
		//	(radius + heightAboveBackbone)*sin(pi/4) - 10 >= radius + 5
		//  heightAboveBackbone >= (65-50*sin(pi/4))/sin(pi/4)
		//  heightAboveBackbone >= 41.9
		center2 = new SequencePointImp(12.5, 50); // rectangle 2 at base 12.5, corresponding to angle pi/4
		
		// value returned should be at a scale where rectangle 2 is below rectangle 1
		// that is where
		//	height of rectangle 2 top <= height of rectangle 1 bottom
		//	(z*radius + heightAboveBackbone)*sin(pi/4) + 10 <= z*radius - 5
		//	z*radius*(sin(pi/4)-1) <= -15-heightAboveBackbone*sin(pi/4)
		//	z >= (-15-50*sin(pi/4))/(50*(sin(pi/4)-1))
		//	so,
		//	z = (-15-50*sin(pi/4))/(50*(sin(pi/4)-1))   (min value of z where rectangles don't overlap anymore)
		expectedScale = (-15-50*Math.sin(Math.PI/4))/(50*(Math.sin(Math.PI/4) - 1));
		actualScale = backbone.calculateIntersectionScale(center1, dim1, center2, dim2);
		
		Assert.assertEquals(expectedScale, actualScale, delta);
	}
}
