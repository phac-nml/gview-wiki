package ca.corefacility.gview.map.gui.editor;

import java.awt.BorderLayout;
import java.awt.DisplayMode;
import java.awt.FlowLayout;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.JButton;
import javax.swing.JSplitPane;
import javax.swing.BoxLayout;
import javax.swing.JScrollPane;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.gui.GViewGUIFrame;
import ca.corefacility.gview.map.gui.action.Action;
import ca.corefacility.gview.map.gui.action.style.ApplyStyleAction;
import ca.corefacility.gview.map.gui.editor.node.StyleEditorNode;

/**
 * The main frame of GView's Style Editor.
 * 
 * @author Eric Marinier
 *
 */
public class StyleEditorFrame extends JFrame implements TreeSelectionListener
{
	private static final long serialVersionUID = 1L;	//requested by java
	
	private static final int DEFAULT_WIDTH = 800;
	private static final int DEFAULT_HEIGHT = 400;
	private static final int DEFAULT_DIVIDER_LOCATION = 250;
	
	private final JPanel contentPane;	
	private final JScrollPane contextPane;
	private final JSplitPane splitPane;
	private final JScrollPane treePane;
	private final StyleEditorTreeComboBox styleComboBox;
	
	private final StyleEditorMenuBar menuBar;	
	private final StyleEditorToolBar styleEditorToolBar;
	private final GViewGUIFrame gViewGUIFrame;	//don't create a get() method for this!
	
	private final GenomeData genomeData;
	
	private final ArrayList<StyleEditorTree> styles = new ArrayList<StyleEditorTree>();;	
	private StyleEditorTree currentStyle;
	
	private File currentDirectory;

	/**
	 * 
	 * @param gViewGUIFrame The related GView GUI frame.
	 * @param gViewMap The gViewMap to use on initialize with.
	 * @param initialGSSFile The GSS file to initialize with.
	 */
	public StyleEditorFrame(GViewGUIFrame gViewGUIFrame, GViewMap gViewMap, URI initialGSSFile) 
	{
		super("Style Editor");
		
		if(gViewGUIFrame == null)
			throw new IllegalArgumentException("GViewGUIFrame is null.");
		
		if(gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		this.gViewGUIFrame = gViewGUIFrame;
		this.genomeData = gViewMap.getGenomeData();
		
		//Frame
		setFrameSizeAndPosition();
		this.setDefaultCloseOperation(HIDE_ON_CLOSE);
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.contentPane.setLayout(new BorderLayout(0, 0));
		this.setContentPane(contentPane);
		
		//Split pane
		this.splitPane = new JSplitPane();
		this.contentPane.add(splitPane, BorderLayout.CENTER);
		
		//tree pane (left side)
		JPanel panel = new JPanel();
		this.splitPane.setLeftComponent(panel);
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		
		this.treePane = new JScrollPane();
		panel.add(treePane);
		
		//Tree object
		this.currentStyle = new StyleEditorTree(this, gViewMap, initialGSSFile);
		this.treePane.setViewportView(this.currentStyle);
		this.currentStyle.updateTree();
		
		//Context pane (right side)
		JPanel panel_1 = new JPanel();
		this.splitPane.setRightComponent(panel_1);
		panel_1.setLayout(new BoxLayout(panel_1, BoxLayout.X_AXIS));
		
		this.contextPane = new JScrollPane();
		panel_1.add(contextPane);
		
		JPanel buttonPanel = createButtonPanel();
		this.add(buttonPanel, BorderLayout.SOUTH);
		
		this.splitPane.setDividerLocation(DEFAULT_DIVIDER_LOCATION);			
		
		//Menu bar
		this.menuBar = new StyleEditorMenuBar(this);
		this.setJMenuBar(menuBar);
		
		//Tool bar
		this.styleEditorToolBar = new StyleEditorToolBar(this);
		this.add(styleEditorToolBar, BorderLayout.NORTH);
		
		//TODO make combo box here
		
		//Combo box (from tool bar)
		this.styleComboBox = this.styleEditorToolBar.getComboBox();
		
		this.addStyle(this.currentStyle);	//add the initial style; should be towards the end		
		this.contextPane.setViewportView(currentStyle.getTop().getPanel());		
	}
	
	private JPanel createButtonPanel()
	{
		final String OK_COMMAND = "Ok";
		final String CANCEL_COMMAND = "Cancel";
		final String APPLY_COMMAND = "Apply";
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
		ActionListener buttonListener = new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				if(e.getActionCommand().equals(OK_COMMAND))
				{
					if (StyleEditorFrame.this.updateCurrentStyle())
					{
						StyleEditorFrame.this.applyCurrentStyle();
					}
					StyleEditorFrame.this.setVisible(false);
				}
				else if(e.getActionCommand().equals(CANCEL_COMMAND))
				{
					StyleEditorFrame.this.setVisible(false);
				}
				else if (e.getActionCommand().equals(APPLY_COMMAND))
				{
					if (StyleEditorFrame.this.updateCurrentStyle())
					{
						StyleEditorFrame.this.applyCurrentStyle();
					}
				}
			}
		};
		
		{
			JButton applyButton = new JButton("Apply");
			applyButton.setActionCommand(APPLY_COMMAND);
			buttonPanel.add(applyButton);
			applyButton.addActionListener(buttonListener);
		}
		{
			JButton okButton = new JButton("Ok");
			okButton.setActionCommand(OK_COMMAND);
			buttonPanel.add(okButton);
			okButton.addActionListener(buttonListener);
		}
		{
			JButton cancelButton = new JButton("Cancel");
			cancelButton.setActionCommand(CANCEL_COMMAND);
			buttonPanel.add(cancelButton);
			getRootPane().setDefaultButton(cancelButton);
			cancelButton.addActionListener(buttonListener);
		}
		
		return buttonPanel;
	}

	/**
	 * 
	 * @param gViewGUIFrame The related GView GUI frame.
	 * @param gViewMap The gViewMap to use on initialize with.
	 */
	public StyleEditorFrame(GViewGUIFrame gViewGUIFrame, GViewMap gViewMap)
	{
		this(gViewGUIFrame, gViewMap, null);
	}
	
	/**
	 * Sets the frame size and position.
	 */
	private void setFrameSizeAndPosition()
	{
		// get screen size for displaying splash screen
		// assumes possibility of more than one display
		int screenWidth, screenHeight;
		
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice[] gd = ge.getScreenDevices();
		if (gd == null || gd.length == 0)
		{
			System.err.println("[warning] - could not get screen resolution");
			screenWidth = 800;
			screenHeight = 600;
		}
		else
		{
			DisplayMode d = gd[0].getDisplayMode();
			
			if(d != null)
			{
				screenWidth = d.getWidth();
				screenHeight = d.getHeight();	
			}
			else
			{
				System.err.println("[warning] - could not get screen resolution");
				screenWidth = 800;
				screenHeight = 600;
			}			
		}
		
		this.setSize(DEFAULT_WIDTH, DEFAULT_HEIGHT);
		this.setLocation((screenWidth - DEFAULT_WIDTH) / 2,(screenHeight - DEFAULT_HEIGHT) / 2);
	}

	@Override
	public void valueChanged(TreeSelectionEvent e) 
	{
		if(this.currentStyle == null)
			throw new IllegalArgumentException("StyleEditorTree is null.");
		
	    DefaultMutableTreeNode temp = (DefaultMutableTreeNode)this.currentStyle.getLastSelectedPathComponent();
	    StyleEditorNode currentNode;
	    JPanel currentPanel;

	    if (temp == null || !(temp instanceof StyleEditorNode))	
	        return;

	    currentNode = (StyleEditorNode)temp;
	    currentPanel = currentNode.getPanel();
	    this.contextPane.setViewportView(currentPanel);
	}
	
	/**
	 * Sets the current tree to be used in the style editor.
	 * 
	 * @param style The tree to be used in the style editor.
	 */
	public void setCurrentStyle(StyleEditorTree style)
	{
		if(style == null)
			throw new IllegalArgumentException("StyleEditorTree is null.");
		
		if(this.styleComboBox == null)
			throw new NullPointerException("StyleEditorTreeComboBox is null.");
		
		JPanel currentPanel;
		
		Object selectedNode = style.getLastSelectedPathComponent();
		StyleEditorNode currentNode;
		
		this.currentStyle = style;
		this.treePane.setViewportView(style);
		
		if(selectedNode instanceof StyleEditorNode)
		{
			currentNode = (StyleEditorNode)selectedNode;
			currentPanel = currentNode.getPanel();
			this.contextPane.setViewportView(currentPanel);
		}
		
		this.gViewGUIFrame.setGViewMap(style.getGViewMap());		
		this.styleComboBox.updateSelection(style);
	}
	
	/**
	 * Returns the genome data being used by the style editor.
	 * 
	 * @return The genome data.
	 */
	public GenomeData getGenomeData()
	{
		if(this.genomeData == null)
			throw new NullPointerException("GenomeData is null.");
		
		return this.genomeData;
	}
	
	/**
	 * Returns the current style editor tree.
	 * 
	 * @return The style editor tree.
	 */
	public StyleEditorTree getCurrentStyle()
	{
		if(this.currentStyle == null)
			throw new NullPointerException("StyleEditorTree is null.");
		
		return this.currentStyle;
	}
	
	/**
	 * Forces the BEV dialog on the main GViewGUIFrame to reload itself.
	 */
	public void updateBEVDialog(GViewMap gViewMap)
	{
		if(gViewMap == null)
			throw new IllegalArgumentException("GViewMap is null.");
		
		this.gViewGUIFrame.getBEVDialog().setGViewMap(gViewMap);
	}
	
	/**
	 * Adds the style sets it as the current style.
	 * 
	 * @param style The style to add.
	 */
	public void addStyle(StyleEditorTree style)
	{
		if(style == null)
			throw new IllegalArgumentException("StyleEditorTree is null");
		
		if(this.styleComboBox == null)
			throw new NullPointerException("StyleEditorTreeComboBox is null.");
		
		this.styles.add(style);
		this.styleComboBox.update();
		this.styleComboBox.setSelectedItem(style);
	}
	
	/**
	 * Removes the style.
	 * 
	 * @param style The style to remove.
	 */
	public void removeStyle(StyleEditorTree style)
	{
		if(style == null)
			throw new IllegalArgumentException("StyleEditorTree is null");
		
		if(this.styleComboBox == null)
			throw new NullPointerException("StyleEditorTreeComboBox is null.");
		
		//allows want to have at least one style
		if(this.styles.size() > 1)
		{
			this.styles.remove(style);
			this.styleComboBox.update();
			this.styleComboBox.setSelectedItem(this.styles.get(0));	//set the selection to something
		}
	}
	
	/**
	 * Returns the GView map within the current style tree.
	 * @return The current GView map.
	 */
	public GViewMap getGViewMap()
	{
		if(this.currentStyle == null)
			throw new NullPointerException("StyleEditorTree is null.");
		
		if(this.currentStyle.getGViewMap() == null)
			throw new NullPointerException("GViewMap is null.");
		
		return this.currentStyle.getGViewMap();
	}
	
	/**
	 * Returns the current directory.
	 * Intended to be used with a JFileChooser.
	 * 
	 * @return The current directory.
	 */
	public File getCurrentDirectory()
	{
		return this.currentDirectory;
	}
	
	/**
	 * Sets the current directory.
	 * Intended to be used with a JFileChooser.
	 * 
	 * @param current The new current directory.
	 */
	public void setCurrentDirectory(File current)
	{
		this.currentDirectory = current;
	}
	
	/**
	 * Sets the name of the current style.
	 * Handles updating the appropriate GUI components.
	 * 
	 * @param name The new name of the current style.
	 */
	public void setStyleName(String name)
	{
		if(name != null)
		{
			this.currentStyle.setTreeName(name);
			this.styleComboBox.repaint();
		}
	}
	
	/**
	 * Returns an iterator of all the styles.
	 * 
	 * @return Iterator of all the styles.
	 */
	public Iterator<StyleEditorTree> getStyles()
	{
		return this.styles.iterator();
	}
	
	/**
	 * Instructs the frame to run the passed action. The action will be added to the appropriate undo manager.
	 * @param action The action to run.
	 */
	public void doAction (Action action)
	{
		if(action == null)
			throw new IllegalArgumentException("Action is null.");
		
		//forward it
		this.gViewGUIFrame.doAction(action);
	}

	/**
	 * Applies the changes to the current style.
	 */
	public void applyCurrentStyle()
	{
		if(this.gViewGUIFrame == null)
			throw new NullPointerException("GViewGUIFrame is null.");
		
		this.doAction(new ApplyStyleAction(this.gViewGUIFrame));		
	}
	
	private boolean updateCurrentStyle()
	{
		StyleEditorTree currentTree = getCurrentStyle();
		return currentTree.updateCurrentStyle();
	}
}
