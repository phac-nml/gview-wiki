package ca.corefacility.gview.layout.sequence.circular;

import java.awt.geom.Point2D;

import ca.corefacility.gview.layout.sequence.AbstractSlotRegion;
import ca.corefacility.gview.layout.sequence.Backbone;
import ca.corefacility.gview.layout.sequence.SequencePath;
import ca.corefacility.gview.layout.sequence.SlotTranslator;
import ca.corefacility.gview.managers.ResolutionManager;

public class SlotRegionCircular extends AbstractSlotRegion
{		
	public SlotRegionCircular(Backbone backbone, SlotTranslator slots)
	{
		super(backbone, slots);
		
		sequencePath = new SequencePathCircular(backbone);
	}
	
	public SequencePath getSequencePath()
	{
		return new SequencePathCircular(backbone);
	}

	@Override
	public Point2D getCenter()
	{
		return new Point2D.Float(0,0);
	}
}
