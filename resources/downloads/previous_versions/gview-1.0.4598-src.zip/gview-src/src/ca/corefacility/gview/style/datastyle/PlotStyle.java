package ca.corefacility.gview.style.datastyle;


import java.awt.BasicStroke;
import java.awt.Paint;

import ca.corefacility.gview.layout.PlotBuilder;
import ca.corefacility.gview.layout.PlotDrawer;
import ca.corefacility.gview.layout.PlotDrawerLine;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;

public class PlotStyle extends SlotItemStyle
{
	private PlotBuilder plotBuilder;

	private PlotDrawer plotDrawer = new PlotDrawerLine(new BasicStroke(1.0f));

	private int gridLines = 0;
	private Paint gridPaint = null;
	private float gridLineThickness = 0.3f;

	private ShapeEffectRenderer shapeEffectRenderer = ShapeEffectRenderer.NO_SELECT_RENDERER;

	public PlotStyle()
	{
	}

	protected PlotStyle(PlotStyle style)
	{
		super(style);

		this.plotBuilder = style.plotBuilder;
		this.plotDrawer = style.plotDrawer;
		this.shapeEffectRenderer = style.shapeEffectRenderer;

		this.gridLines = style.gridLines;
		this.gridPaint = style.gridPaint;
		this.gridLineThickness = style.gridLineThickness;
	}

	public PlotBuilder getPlotBuilder()
	{
		return this.plotBuilder;
	}

	public void setPlotBuilder(PlotBuilder plotBuilder)
	{
		this.plotBuilder = plotBuilder;
	}

	public void setPlotDrawer(PlotDrawer plotDrawer)
	{
		this.plotDrawer = plotDrawer;
	}

	public PlotDrawer getPlotDrawer()
	{
		return this.plotDrawer;
	}

	public void setShapeEffectRenderer(ShapeEffectRenderer shapeEffectRenderer)
	{
		if (shapeEffectRenderer != null)
		{
			this.shapeEffectRenderer = shapeEffectRenderer;
		}
	}

	public ShapeEffectRenderer getShapeEffectRenderer()
	{
		return this.shapeEffectRenderer;
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Float.floatToIntBits(this.gridLineThickness);
		result = prime * result + this.gridLines;
		result = prime * result
		+ (this.gridPaint == null ? 0 : this.gridPaint.hashCode());
		result = prime * result
		+ (this.plotBuilder == null ? 0 : this.plotBuilder.hashCode());
		result = prime * result
		+ (this.plotDrawer == null ? 0 : this.plotDrawer.hashCode());
		result = prime
		* result
		+ (this.shapeEffectRenderer == null ? 0 : this.shapeEffectRenderer
				.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PlotStyle other = (PlotStyle) obj;
		if (Float.floatToIntBits(this.gridLineThickness) != Float
				.floatToIntBits(other.gridLineThickness))
			return false;
		if (this.gridLines != other.gridLines)
			return false;
		if (this.gridPaint == null)
		{
			if (other.gridPaint != null)
				return false;
		}
		else if (!this.gridPaint.equals(other.gridPaint))
			return false;
		if (this.plotBuilder == null)
		{
			if (other.plotBuilder != null)
				return false;
		}
		else if (!this.plotBuilder.equals(other.plotBuilder))
			return false;
		if (this.plotDrawer == null)
		{
			if (other.plotDrawer != null)
				return false;
		}
		else if (!this.plotDrawer.equals(other.plotDrawer))
			return false;
		if (this.shapeEffectRenderer == null)
		{
			if (other.shapeEffectRenderer != null)
				return false;
		}
		else if (!this.shapeEffectRenderer.equals(other.shapeEffectRenderer))
			return false;
		return true;
	}

	@Override
	public Object clone() throws CloneNotSupportedException
	{
		return new PlotStyle(this);
	}

	public void setGridLines(int gridLines)
	{
		this.gridLines = gridLines;
	}

	/**
	 * @return  The number of grid lines to display.
	 */
	public int getGridLines()
	{
		return this.gridLines;
	}

	public Paint getGridPaint()
	{
		return this.gridPaint;
	}

	public void setGridPaint(Paint paint)
	{
		this.gridPaint = paint;
	}

	public float getGridLineThickness()
	{
		return this.gridLineThickness;
	}

	public void setGridLineThickness(float thickness)
	{
		this.gridLineThickness = thickness;
	}
}
