package ca.corefacility.gview.layout.sequence.linear;

import java.awt.geom.Point2D;

import ca.corefacility.gview.layout.sequence.AbstractSlotRegion;
import ca.corefacility.gview.layout.sequence.Backbone;
import ca.corefacility.gview.layout.sequence.SequencePath;
import ca.corefacility.gview.layout.sequence.SlotTranslator;
import ca.corefacility.gview.managers.ResolutionManager;

public class SlotRegionLinear extends AbstractSlotRegion
{
	public SlotRegionLinear(Backbone backbone, SlotTranslator slots)
	{
		super(backbone, slots);
		
		sequencePath = new SequencePathLinear(backbone);
	}
	
	public SequencePath getSequencePath()
	{
		return new SequencePathLinear(backbone);
	}

	@Override
	public Point2D getCenter()
	{
		Point2D centerPoint = null;
		
		float top = (float)slots.getTopMostHeight();
		float bottom = (float)slots.getBottomMostHeight();
		
		float centerHeight = (top+bottom)/2;
		centerPoint = new Point2D.Float(0, -centerHeight);

		return centerPoint;
	}
}
