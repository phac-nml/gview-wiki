package ca.corefacility.gview.map.items;

/**
 * Describes a shape which is bound to the backbone.
 * @author aaron
 *
 */
public interface BackboneShapeItem extends ShapeItem, BackboneItem
{

}
