package ca.corefacility.gview.map.event;

import java.awt.geom.Rectangle2D;

public class DisplayUpdated extends GViewEvent
{
	private static final long serialVersionUID = 1107720499369373959L;
	private Rectangle2D viewBounds;
	private boolean displayBoundsChanged;
	
	private Rectangle2D cameraBounds;
	
	/**
	 * 
	 * @param source
	 * @param viewBounds
	 * @param cameraBounds
	 * @param displaySizeUpdated  If the display screen size was updated.
	 */
	public DisplayUpdated(Object source, Rectangle2D viewBounds, Rectangle2D cameraBounds, boolean displayBoundsChanged)
	{
		super(source);
		this.viewBounds = viewBounds;
		this.cameraBounds = cameraBounds;
		
		this.displayBoundsChanged = displayBoundsChanged;
	}
	
	public Rectangle2D getViewBounds()
	{
		return viewBounds;
	}
	
	public boolean isDisplayBoundsChanged()
	{
		return displayBoundsChanged;
	}
	
	public Rectangle2D getCameraBounds()
	{
		return cameraBounds;
	}
}
