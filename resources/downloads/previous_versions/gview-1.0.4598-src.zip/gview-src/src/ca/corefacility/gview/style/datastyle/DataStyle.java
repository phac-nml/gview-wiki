package ca.corefacility.gview.style.datastyle;


import java.util.Iterator;
import java.util.SortedMap;
import java.util.TreeMap;

import ca.corefacility.gview.map.event.GViewEvent;
import ca.corefacility.gview.map.event.GViewEventListener;
import ca.corefacility.gview.map.event.GViewEventSubject;
import ca.corefacility.gview.map.event.GViewEventSubjectImp;

/**
 * DataStyle controls any style information directly related to the specific genome data to use.  So, it can be used to control which genes to display where,
 * colors to use, slots, etc.
 * @author Aaron Petkau
 *
 */
public class DataStyle implements GViewEventListener, GViewEventSubject
{	
	private FeatureHolderStyleFactory holderFactory;
	
	private SortedMap<Integer, SlotStyle> slotStyles; // sorted so we can iterate through slots in order
	
	// for events
	private GViewEventSubjectImp eventSubject;
	
	/**
	 * Creates a new data style.
	 */
	public DataStyle()
	{
		slotStyles = new TreeMap<Integer, SlotStyle>();
		
		holderFactory = new FeatureHolderStyleFactory();
		
		eventSubject = new GViewEventSubjectImp();
	}

	/**
	 * Obtains a style for a feature holder with the passed name.
	 * 
	 * @param name  The name of the feature holder whose style to obtain.
	 * 
	 * @return The feature holder style (null if no style).
	 */
	/*public ItemHolderStyle getFeatureHolderStyle(String name)
	{
		return holderStyles.get(name);
	}*/
	
	/**
	 * Obtains an iterator for all the feature holder styles stored by this object.
	 * 
	 * @return  Iterator of all the feature holder styles.
	 */
	/*public Iterator<ItemHolderStyle> featureHoldersIterator() // do we need this?
	{
		return holderStyles.values().iterator();
	}*/
	
	/**
	 * Obtains an iterator for all the feature slot styles stored by this object.
	 * 
	 * @return  Iterator of all the feature slot styles.
	 */
	public Iterator<SlotStyle> slots() // do we need this?
	{
		return slotStyles.values().iterator();
	}
	
	/**
	 * @return  The lowest slot number in use.
	 */
	public int getLowerSlot()
	{
		int lowerSlot;
		
		if (slotStyles.isEmpty())
		{
			lowerSlot = 0;
		}
		else
		{
			Integer slot = slotStyles.firstKey();
			
			// this is done since if we only have positive slots, we still want to return 0
			if (slot.intValue() > 0)
			{
				lowerSlot = 0;
			}
			else
			{
				lowerSlot = slot.intValue();
			}
		}

		return lowerSlot;
	}
	
	/**
	 * @return  The greatest slot number in use.
	 */
	public int getUpperSlot()
	{
		int upperSlot;
		
		if (slotStyles.isEmpty())
		{
			upperSlot = 0;
		}
		else
		{
			Integer slot = slotStyles.lastKey();
			
			// this is done so that if we only have negative slots in use, we still want to return 0
			if (slot.intValue() < 0)
			{
				upperSlot = 0;
			}
			else
			{
				upperSlot = slot.intValue();
			}
		}

		return upperSlot;
	}
	
	/**
	 * Determines if this DataStyle contains a SlotStyle object for the passed slot number.
	 * @param slot  The slot number to check.
	 * @return  True if this DataStyle contains a SlotStyle object for the passed slot, false otherwise.
	 */
	public boolean containsSlotStyle(int slot)
	{
		return slotStyles.get(slot) != null;
	}
	
	/**
	 * Obtains a style for a feature slot with the passed name (creating it if necessary).
	 * 
	 * @param slot  The slot number of the feature slot whose style to obtain.
	 * 
	 * @return The feature slot style (null if no style).
	 */
	public SlotStyle getSlotStyle(int slot)
	{
		return slotStyles.get(slot);
	}
	
	/**
	 * Creates a new slot style with the passed slot.  Note:  you must create slots in order, so you can't create slot 1 and then slot 3 (must create slot 2 first).
	 * 
	 * @param slot  The slot that this slot style will refer to.
	 * 					Use one of Slot.FIRST_UPPER, or Slot.FIRST_LOWER, for the first upper/lower slots.
	 * 					Add numbers onto these values to increase/decrease the slot number.
	 * @return  The SlotStyle object for the newly created slot.
	 */
	public SlotStyle createSlotStyle(int slot)
	{
		SlotStyle style = null;
		
		// TODO clean this up later, we added 1 so that we could create a new slot after any currently created slots.
		// checks if passed slot is out of range (must create slots in order).
		if (!((getLowerSlot()-1 <= slot) && (slot <= (getUpperSlot()+1))))
		{
			throw new IllegalArgumentException("slot=" + slot + " out of range of [" + (getLowerSlot()-1) + ", " + getUpperSlot()+1 + "]");
		}
		else
		{
			style = new SlotStyle(slot, holderFactory);
			slotStyles.put(slot, style);
		}
		
		return style;
	}
	
	
	/**
	 * Event methods
	 */
	
	public void eventOccured(GViewEvent event)
	{
		// forward event to any listeners
		eventSubject.fireEvent(event);
	}

	public void addEventListener(GViewEventListener listener)
	{
		eventSubject.addEventListener(listener);
	}

	public void removeAllEventListeners()
	{
		eventSubject.removeAllEventListeners();
	}

	public void removeEventListener(GViewEventListener listener)
	{
		eventSubject.removeEventListener(listener);
	}
}
