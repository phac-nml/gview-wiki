package ca.corefacility.gview.map.effects;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;

public class StandardEffectMouseOverSelect extends AbstractAllEffectRenderer
{
	private static final Stroke outline = new BasicStroke(3.0f);
	
	protected void paintNormal(Shape shape, Graphics2D g, Paint paint)
	{
		g.setPaint(paint);
		g.fill(shape);
	}

	protected void paintSelected(Shape shape, Graphics2D g, Paint paint)
	{
		g.setPaint(paint);
		g.fill(shape);
		
		Stroke temp = g.getStroke();
		
		g.setStroke(outline);
		g.setPaint(Color.YELLOW);
		g.draw(shape);
		
		g.setStroke(temp);
	}

	protected void paintMouseOver(Shape shape, Graphics2D g, Paint paint)
	{
		g.setPaint(paint);
		g.fill(shape);
		
		Stroke temp = g.getStroke();
		
		g.setStroke(outline);
		g.setPaint(Color.GREEN);
		g.draw(shape);
		
		g.setStroke(temp);
	}
	
	protected void paintMouseOverSelected(Shape shape, Graphics2D g, Paint paint)
	{
		g.setPaint(Color.YELLOW);
		g.fill(shape);
		
		Stroke temp = g.getStroke();

		g.setStroke(outline);
		g.setPaint(paint);
		g.draw(shape);
		
		g.setStroke(temp);
	}
}
