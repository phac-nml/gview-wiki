package ca.corefacility.gview.layout.prototype;

import java.awt.Stroke;

import ca.corefacility.gview.layout.prototype.segments.StretchableSegment;
import ca.corefacility.gview.layout.sequence.Backbone;


public abstract class StretchableShape extends BackboneShape
{

	public StretchableShape(Backbone backbone)
	{
		super(backbone);
	}

	/**
	 * Appends the passed segment onto this shape prototype.
	 * 
	 * @param segment  The segment to append.
	 */
	public abstract void appendSegment(StretchableSegment segment);

	protected abstract void modifyShape(Backbone backbone);
}