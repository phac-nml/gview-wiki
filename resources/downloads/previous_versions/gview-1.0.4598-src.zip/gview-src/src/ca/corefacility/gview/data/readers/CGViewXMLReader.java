package ca.corefacility.gview.data.readers;

import java.awt.Color;
import java.awt.Font;
import java.awt.Paint;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.biojava.bio.Annotation;
import org.biojava.bio.BioException;
import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.seq.impl.SimpleSequenceFactory;
import org.biojava.bio.symbol.Location;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.bio.symbol.SymbolList;
import org.xml.sax.Attributes;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.AttributesImpl;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.PlotBuilderRange;
import ca.corefacility.gview.layout.PlotDrawerCenter;
import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.managers.LegendAlignment;
import ca.corefacility.gview.map.effects.OutsideEffect;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.style.GlobalStyle;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.LabelStyle;
import ca.corefacility.gview.style.datastyle.PlotStyle;
import ca.corefacility.gview.style.datastyle.SlotItemStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.items.LegendItemStyle;
import ca.corefacility.gview.style.items.LegendStyle;
import ca.corefacility.gview.style.items.RulerStyle;
import ca.corefacility.gview.style.items.TooltipStyle;
import ca.corefacility.gview.textextractor.StringBuilder;
import ca.corefacility.gview.textextractor.StringExtractor;
import ca.corefacility.gview.utils.Util;

/**
 * A FileFormatReader for handling CGView xml file formats (some aspects are still missing).
 * 
 * @author Aaron Petkau
 * 
 */
@SuppressWarnings( { "unchecked", "unused" })
public class CGViewXMLReader extends DefaultHandler implements FileFormatReader
{
	protected Sequence currentSequence = null;
	private MapStyle currentMapStyle = new MapStyle();

	private double featureThickness = FEATURE_THICKNESSES.get("medium");
	private boolean showShading = true;

	private FeatureSlotManager featureSlotManager;
	private HashMap<FeatureHolderStyle, Annotation>	annotationHolder;
	private int annotationKey = 0;
	private FeatureSlot currentFeatureSlot;
	private Feature currentFeature;
	private FeatureRange currentFeatureRange;
	private Plot currPlot;
	private Legend currentLegend;
	private LegendItem currentLegendItem;
	/**
	 * Used to determine if we have encountered a cgview tag already.
	 */
	private boolean cgviewTagEncountered = false;

	private Stack context = new Stack();

	// set to true if combining data
	private boolean ignoreCgviewTag = false;
	// private boolean ignoreLegendTag = false;
	// private boolean ignoreLegendItemTag = false;

	// properties of map
	private int cgviewLength;
	private int imageWidth;
	private int imageHeight;

	private boolean globalShowLabels = false; // if turned on, labels are shown
	private float globalLabelLineThickness = 1.0f;

	private StringBuffer content = new StringBuffer();
	private Locator locator;
	private SlotStyle	currentPlotSlot;

	private static final Font defaultLabelFont = new Font("SansSerif", Font.PLAIN, 10);

	// used for extracting text
	private static final Pattern fontDescriptionPattern = Pattern.compile("\\s*(\\S+)\\s*,\\s*(\\S+)\\s*,\\s*(\\d+)\\s*,*\\s*");
	private static final Pattern colorDescriptionPattern = Pattern.compile("\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,\\s*(\\d+)\\s*,*\\s*");

	private static final ShapeEffectRenderer shadedEffect = new OutsideEffect(new Color(0,0,0,128));
	private static final ShapeEffectRenderer normalEffect = ShapeEffectRenderer.NO_SELECT_RENDERER;

	// whole bunch of tables matching strings to values for the style info
	private final static Hashtable<String, Color> COLORS = new Hashtable<String, Color>();
	// private final static Hashtable LABEL_TYPES = new Hashtable();
	private final static Hashtable<String, Boolean> GLOBAL_LABEL_TYPES = new Hashtable<String, Boolean>();
	private final static Hashtable<String, FeatureShapeRealizer> DECORATIONS =
		new Hashtable<String, FeatureShapeRealizer>();
	// private final static Hashtable RULER_UNITS = new Hashtable();
	// private final static Hashtable USE_INNER_LABELS = new Hashtable();
	// private final static Hashtable GIVE_FEATURE_POSITIONS = new Hashtable();
	private final static Hashtable<String, Double> FEATURE_THICKNESSES = new Hashtable<String, Double>();
	private final static Hashtable FEATURESLOT_SPACINGS = new Hashtable();
	private final static Hashtable<String, Double> BACKBONE_THICKNESSES = new Hashtable<String, Double>();
	private final static Hashtable ARROWHEAD_LENGTHS = new Hashtable();
	private final static Hashtable MINIMUM_FEATURE_LENGTHS = new Hashtable();
	private final static Hashtable ORIGINS = new Hashtable();
	private final static Hashtable TICK_THICKNESSES = new Hashtable();
	private final static Hashtable<String, Double> TICK_LENGTHS = new Hashtable<String, Double>();
	private final static Hashtable LABEL_LINE_THICKNESSES = new Hashtable();
	private final static Hashtable LABEL_LINE_LENGTHS = new Hashtable();
	private final static Hashtable LABEL_PLACEMENT_QUALITIES = new Hashtable();
	private final static Hashtable<String, Boolean> BOOLEANS = new Hashtable<String, Boolean>();
	// private final static Hashtable SWATCH_TYPES = new Hashtable();
	 private final static Hashtable<String, LegendAlignment> LEGEND_POSITIONS = new Hashtable();
	// private final static Hashtable LEGEND_ALIGNMENTS = new Hashtable();
	// private final static Hashtable LEGEND_SHOW_ZOOM = new Hashtable();

	private final static int MAX_BASES = Integer.MAX_VALUE;
	private final static int MIN_BASES = 1;
	private final static double MIN_BACKBONE_RADIUS = 10.0d;
	private final static double MAX_BACKBONE_RADIUS = 12000.0d; //default is 190.0d
	private final static int MAX_IMAGE_WIDTH = 30000; // default is 700.0d
	private final static int MIN_IMAGE_WIDTH = 100;

	private final static int MAX_IMAGE_HEIGHT = 30000; // default is 700.0d
	private final static int MIN_IMAGE_HEIGHT = 100;

	// initialize hash tables
	static
	{
		COLORS.put("black", new Color(0, 0, 0));
		COLORS.put("silver", new Color(192, 192, 192));
		COLORS.put("gray", new Color(128, 128, 128)); // backbone default
		COLORS.put("grey", new Color(128, 128, 128));
		COLORS.put("white", new Color(255, 255, 255)); // background default
		COLORS.put("maroon", new Color(128, 0, 0));
		COLORS.put("red", new Color(255, 0, 0));
		COLORS.put("purple", new Color(128, 0, 128));
		COLORS.put("fuchsia", new Color(255, 0, 255));
		COLORS.put("green", new Color(0, 128, 0));
		COLORS.put("lime", new Color(0, 255, 0));
		COLORS.put("olive", new Color(128, 128, 0));
		COLORS.put("yellow", new Color(255, 255, 0));
		COLORS.put("orange", new Color(255, 153, 0));
		COLORS.put("navy", new Color(0, 0, 128));
		COLORS.put("blue", new Color(0, 0, 255)); // feature and featureRange default
		COLORS.put("teal", new Color(0, 128, 128));
		COLORS.put("aqua", new Color(0, 255, 255));

		// LABEL_TYPES.put("true", new Integer(LABEL));
		// LABEL_TYPES.put("false", new Integer(LABEL_NONE)); //default for feature and featureRange
		// LABEL_TYPES.put("force", new Integer(LABEL_FORCE));
		//
		GLOBAL_LABEL_TYPES.put("true", true); //default for Cgview
		GLOBAL_LABEL_TYPES.put("false", false);
		GLOBAL_LABEL_TYPES.put("auto", true); // auto stops labels on full resolution, which doesn't apply for gview
		//
		DECORATIONS.put("arc", FeatureShapeRealizer.NO_ARROW); //default for feature and featureRange
		DECORATIONS.put("hidden", FeatureShapeRealizer.HIDDEN);
		DECORATIONS.put("counterclockwise-arrow", FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);
		DECORATIONS.put("clockwise-arrow", FeatureShapeRealizer.CLOCKWISE_ARROW);
		//
		// RULER_UNITS.put("bases", new Integer(BASES)); //default for rulerUnits
		// RULER_UNITS.put("centisomes", new Integer(CENTISOMES));
		//
		// USE_INNER_LABELS.put("true", new Integer(INNER_LABELS_SHOW)); //should have true, false,
		// auto
		// USE_INNER_LABELS.put("false", new Integer(INNER_LABELS_NO_SHOW));
		// USE_INNER_LABELS.put("auto", new Integer(INNER_LABELS_AUTO));
		//
		// GIVE_FEATURE_POSITIONS.put("true", new Integer(POSITIONS_SHOW));
		// GIVE_FEATURE_POSITIONS.put("false", new Integer(POSITIONS_NO_SHOW)); //default
		// GIVE_FEATURE_POSITIONS.put("auto", new Integer(POSITIONS_AUTO));

		FEATURE_THICKNESSES.put("xxx-small", Double.valueOf(1.0));
		FEATURE_THICKNESSES.put("xx-small", Double.valueOf(2.0));
		FEATURE_THICKNESSES.put("x-small", Double.valueOf(4.0));
		FEATURE_THICKNESSES.put("small", Double.valueOf(6.0));
		FEATURE_THICKNESSES.put("medium", Double.valueOf(8.0)); // default for featureThickness
		FEATURE_THICKNESSES.put("large", Double.valueOf(10.0));
		FEATURE_THICKNESSES.put("x-large", Double.valueOf(12.0));
		FEATURE_THICKNESSES.put("xx-large", Double.valueOf(14.0));
		FEATURE_THICKNESSES.put("xxx-large", Double.valueOf(16.0));

		FEATURESLOT_SPACINGS.put("xxx-small", Double.valueOf(0.0));
		FEATURESLOT_SPACINGS.put("xx-small", Double.valueOf(1.0));
		FEATURESLOT_SPACINGS.put("x-small", Double.valueOf(2.0));
		FEATURESLOT_SPACINGS.put("small", Double.valueOf(3.0));
		FEATURESLOT_SPACINGS.put("medium", Double.valueOf(4.0)); // default for featureSlotSpacing
		FEATURESLOT_SPACINGS.put("large", Double.valueOf(5.0));
		FEATURESLOT_SPACINGS.put("x-large", Double.valueOf(6.0));
		FEATURESLOT_SPACINGS.put("xx-large", Double.valueOf(7.0));
		FEATURESLOT_SPACINGS.put("xxx-large", Double.valueOf(8.0));

		BACKBONE_THICKNESSES.put("xxx-small", Double.valueOf(1.0));
		BACKBONE_THICKNESSES.put("xx-small", Double.valueOf(2.0));
		BACKBONE_THICKNESSES.put("x-small", Double.valueOf(3.0));
		BACKBONE_THICKNESSES.put("small", Double.valueOf(4.0));
		BACKBONE_THICKNESSES.put("medium", Double.valueOf(5.0)); // default for backboneThickness
		BACKBONE_THICKNESSES.put("large", Double.valueOf(6.0));
		BACKBONE_THICKNESSES.put("x-large", Double.valueOf(7.0));
		BACKBONE_THICKNESSES.put("xx-large", Double.valueOf(8.0));
		BACKBONE_THICKNESSES.put("xxx-large", Double.valueOf(9.0));

		ARROWHEAD_LENGTHS.put("xxx-small", Double.valueOf(1.0d));
		ARROWHEAD_LENGTHS.put("xx-small", Double.valueOf(2.0d));
		ARROWHEAD_LENGTHS.put("x-small", Double.valueOf(3.0d));
		ARROWHEAD_LENGTHS.put("small", Double.valueOf(4.0d));
		ARROWHEAD_LENGTHS.put("medium", Double.valueOf(5.0d)); // default for arrowheadLength
		ARROWHEAD_LENGTHS.put("large", Double.valueOf(6.0d));
		ARROWHEAD_LENGTHS.put("x-large", Double.valueOf(7.0d));
		ARROWHEAD_LENGTHS.put("xx-large", Double.valueOf(8.0d));
		ARROWHEAD_LENGTHS.put("xxx-large", Double.valueOf(9.0d));

		TICK_LENGTHS.put("xxx-small", Double.valueOf(3.0));
		TICK_LENGTHS.put("xx-small", Double.valueOf(4.0));
		TICK_LENGTHS.put("x-small", Double.valueOf(5.0));
		TICK_LENGTHS.put("small", Double.valueOf(6.0));
		TICK_LENGTHS.put("medium", Double.valueOf(7.0)); // default for ticks
		TICK_LENGTHS.put("large", Double.valueOf(8.0));
		TICK_LENGTHS.put("x-large", Double.valueOf(9.0));
		TICK_LENGTHS.put("xx-large", Double.valueOf(10.0));
		TICK_LENGTHS.put("xxx-large", Double.valueOf(11.0));

		MINIMUM_FEATURE_LENGTHS.put("xxx-small", Double.valueOf(0.02d)); // default for
		// minimumFeatureLength
		MINIMUM_FEATURE_LENGTHS.put("xx-small", Double.valueOf(0.05d));
		MINIMUM_FEATURE_LENGTHS.put("x-small", Double.valueOf(0.1d));
		MINIMUM_FEATURE_LENGTHS.put("small", Double.valueOf(0.5d));
		MINIMUM_FEATURE_LENGTHS.put("medium", Double.valueOf(1.0d));
		MINIMUM_FEATURE_LENGTHS.put("large", Double.valueOf(1.5d));
		MINIMUM_FEATURE_LENGTHS.put("x-large", Double.valueOf(2.0d));
		MINIMUM_FEATURE_LENGTHS.put("xx-large", Double.valueOf(2.5d));
		MINIMUM_FEATURE_LENGTHS.put("xxx-large", Double.valueOf(3.0d));

		ORIGINS.put("1", Double.valueOf(60.0d));
		ORIGINS.put("2", Double.valueOf(30.0d));
		ORIGINS.put("3", Double.valueOf(0.0d));
		ORIGINS.put("4", Double.valueOf(-30.0d));
		ORIGINS.put("5", Double.valueOf(-60.0d));
		ORIGINS.put("6", Double.valueOf(-90.0d));
		ORIGINS.put("7", Double.valueOf(-120.0d));
		ORIGINS.put("8", Double.valueOf(-150.0d));
		ORIGINS.put("9", Double.valueOf(-180.0d));
		ORIGINS.put("10", Double.valueOf(-210.0d));
		ORIGINS.put("11", Double.valueOf(-240.0d));
		ORIGINS.put("12", Double.valueOf(90.0d)); // default for origin

		TICK_THICKNESSES.put("xxx-small", Double.valueOf(0.02));
		TICK_THICKNESSES.put("xx-small", Double.valueOf(0.5));
		TICK_THICKNESSES.put("x-small", Double.valueOf(1.0));
		TICK_THICKNESSES.put("small", Double.valueOf(1.5));
		TICK_THICKNESSES.put("medium", Double.valueOf(2.0)); // default for tickThickness
		TICK_THICKNESSES.put("large", Double.valueOf(2.5));
		TICK_THICKNESSES.put("x-large", Double.valueOf(3.0));
		TICK_THICKNESSES.put("xx-large", Double.valueOf(3.5));
		TICK_THICKNESSES.put("xxx-large", Double.valueOf(4.0));

		LABEL_LINE_THICKNESSES.put("xxx-small", Double.valueOf(0.02));
		LABEL_LINE_THICKNESSES.put("xx-small", Double.valueOf(0.25));
		LABEL_LINE_THICKNESSES.put("x-small", Double.valueOf(0.50));
		LABEL_LINE_THICKNESSES.put("small", Double.valueOf(0.75));
		LABEL_LINE_THICKNESSES.put("medium", Double.valueOf(1.0)); // default for labelLineThickness
		LABEL_LINE_THICKNESSES.put("large", Double.valueOf(1.25));
		LABEL_LINE_THICKNESSES.put("x-large", Double.valueOf(1.5));
		LABEL_LINE_THICKNESSES.put("xx-large", Double.valueOf(1.75));
		LABEL_LINE_THICKNESSES.put("xxx-large", Double.valueOf(2.0));

		LABEL_LINE_LENGTHS.put("xxx-small", Double.valueOf(10.0d));
		LABEL_LINE_LENGTHS.put("xx-small", Double.valueOf(20.0d));
		LABEL_LINE_LENGTHS.put("x-small", Double.valueOf(30.0d));
		LABEL_LINE_LENGTHS.put("small", Double.valueOf(40.0d));
		LABEL_LINE_LENGTHS.put("medium", Double.valueOf(50.0d)); // default for labelLineLength
		LABEL_LINE_LENGTHS.put("large", Double.valueOf(60.0d));
		LABEL_LINE_LENGTHS.put("x-large", Double.valueOf(70.0d));
		LABEL_LINE_LENGTHS.put("xx-large", Double.valueOf(80.0d));
		LABEL_LINE_LENGTHS.put("xxx-large", Double.valueOf(90.0d));

		LABEL_PLACEMENT_QUALITIES.put("good", Integer.valueOf(5));
		LABEL_PLACEMENT_QUALITIES.put("better", Integer.valueOf(8)); // default for
		// labelPlacementQuality
		LABEL_PLACEMENT_QUALITIES.put("best", Integer.valueOf(10));

		BOOLEANS.put("true", true); // default for showShading //default for
		// moveInnerLabelsToOuter
		BOOLEANS.put("false", false); // default for allowLabelClash //default for
		// showWarning

		 LEGEND_POSITIONS.put("upper-left", LegendAlignment.UPPER_LEFT);
		 LEGEND_POSITIONS.put("upper-center", LegendAlignment.UPPER_CENTER);
		 LEGEND_POSITIONS.put("upper-right", LegendAlignment.UPPER_RIGHT);
		 LEGEND_POSITIONS.put("middle-left", LegendAlignment.MIDDLE_LEFT);
		 //LEGEND_POSITIONS.put("middle-left-of-center", LegendAlignment.);
		 LEGEND_POSITIONS.put("middle-center", LegendAlignment.MIDDLE_CENTER);
		 //LEGEND_POSITIONS.put("middle-right-of-center", new
		 LEGEND_POSITIONS.put("middle-right", LegendAlignment.MIDDLE_RIGHT); //default for
		 LEGEND_POSITIONS.put("lower-left", LegendAlignment.LOWER_LEFT);
		 LEGEND_POSITIONS.put("lower-center", LegendAlignment.LOWER_CENTER);
		 LEGEND_POSITIONS.put("lower-right", LegendAlignment.LOWER_RIGHT);
		//
		// LEGEND_SHOW_ZOOM.put("true", new Integer(LEGEND_DRAW_ZOOMED)); //default for legend
		// LEGEND_SHOW_ZOOM.put("false", new Integer(LEGEND_NO_DRAW_ZOOMED));
		//
		// LEGEND_ALIGNMENTS.put("left", new Integer(LEGEND_ITEM_ALIGN_LEFT)); //default for legend
		// //default for legendItem
		// LEGEND_ALIGNMENTS.put("center", new Integer(LEGEND_ITEM_ALIGN_CENTER));
		// LEGEND_ALIGNMENTS.put("right", new Integer(LEGEND_ITEM_ALIGN_RIGHT));
		//
		// SWATCH_TYPES.put("true", new Integer(SWATCH_SHOW));
		// SWATCH_TYPES.put("false", new Integer(SWATCH_NO_SHOW)); //default for legendItem
	}

	/**
	 * Constructs an object to read in information from the CGView xml format.
	 */
	public CGViewXMLReader()
	{
		clear();
	}

	/**
	 * Clears out global variables so we can read in more data.
	 */
	private void clear()
	{
		this.currentSequence = null;
		this.currentMapStyle = new MapStyle();
		
		this.annotationHolder = null;
		
		this.showShading = true;

		this.featureThickness = FEATURE_THICKNESSES.get("medium");

		this.featureSlotManager = null;
		this.currentFeatureSlot = null;
		this.currentFeature = null;
		this.currentFeatureRange = null;
		this.currentPlotSlot = null;
		this.currPlot = null;
		this.currentLegend = null;
		this.currentLegendItem = null;

		this.cgviewTagEncountered = false;

		this.context = new Stack();

		// set to true if combining data
		this.ignoreCgviewTag = false;

		// properties of map
		this.cgviewLength = 0;
		this.imageWidth = 0;
		this.imageHeight = 0;

		this.globalShowLabels = false;
		this.globalLabelLineThickness = 1.0f;

		this.content = new StringBuffer();
		this.locator = null;
	}

	public GViewFileData read(File file) throws IOException, GViewDataParseException
	{
		if (file == null)
			throw new NullPointerException("file is null");

		// Pre-process the cgview xml, and create a temp file.
		// The pre-processing changes featureSlots that are to hold plots to plotSlots.
		// This makes the parsing process MUCH easier

		File tempXML = preprocess( file );
		//tempXML.deleteOnExit();

		return read(new FileReader(tempXML));
	}


	/**
	 * The method will pre-process the CGView XML file and modify some of the structure.
	 * When encountering a featureSlot, it is easier to turn the children nodes into
	 * plotSlots instead of leaving them as featureRange elements.
	 * @param file
	 * @return
	 * @throws IOException
	 */
	private File preprocess( File file ) throws IOException
	{
		File tempFile = File.createTempFile( "GViewXMLParser", ".tmp" );
		tempFile.deleteOnExit();

		boolean plotFound = false;

		String previous_2 = "";
		String previous_1 = "";
		String previous = "";
		String current = "";

		Pattern featureSlot = Pattern.compile( "<featureSlot\\s" );
		Pattern featureRange = Pattern.compile( "<featureRange\\s");
		Pattern feature = Pattern.compile( "<feature.*decoration=[^=]*\"arc\"" );
		Pattern endFeatureSlot = Pattern.compile( "</featureSlot>" );

		BufferedWriter writer = new BufferedWriter( new FileWriter( tempFile ) );
		BufferedReader reader = new BufferedReader( new FileReader( file ) );

		previous_2 = reader.readLine();
		if (previous_2 == null)
		{
			reader.close();
			writer.close();
			
			return tempFile;
		}
		
		previous_1 = reader.readLine();
		if (previous_1 == null)
		{
			reader.close();
			writer.write(previous_2 + "\n");
			writer.close();
			
			return tempFile;
		}
		
		previous = reader.readLine();
		if (previous == null)
		{
			reader.close();
			writer.write(previous_2 + "\n");
			writer.write(previous_1 + "\n");
			writer.close();
			
			return tempFile;
		}
		
		while( (current = reader.readLine() ) != null )
		{
			if( !plotFound )
			{
				// want to detect if we have <featureSlot ...> <feature ...> <featureRange .../> <featureRange .../>
				// if so, then we can be fairly sure that this featureSlot is defining a plot
				Matcher matcher = featureSlot.matcher( previous_2 );
				if( matcher.find() )
				{
					Matcher matcher2 = feature.matcher( previous_1 );
					if ( matcher2.find() )
					{
						Matcher matcher3 = featureRange.matcher(previous);
						if (matcher3.find())
						{
							Matcher matcher4 = featureRange.matcher(current);
							if (matcher4.find())
							{
								previous_2 = matcher.replaceFirst( "<plotSlot " );
								plotFound = true;
							}
						}
					}
				}
			}
			else // Must replace the closing featureSlot tag with a plotSlot tag
			{
				Matcher matcher = endFeatureSlot.matcher( current );
				if( matcher.find() )
				{
					current = matcher.replaceFirst( "</plotSlot>" );
					writer.write( previous_2 + "\n" );
					previous_2 = previous_1;
					previous_1 = previous;
					previous = current;
					current = reader.readLine();
					plotFound = false;
				}
			}
			
			writer.write( previous_2 + "\n" );
			previous_2 = previous_1;
			previous_1 = previous;
			previous = current;
		}
		
		writer.write( previous_2 + "\n" );
		writer.write( previous_1 + "\n" );
		writer.write( previous + "\n" );
		writer.flush();
		
		return tempFile;
	}

	@Override
	public GViewFileData read(Reader reader) throws IOException, GViewDataParseException
	{
		if (reader == null)
			throw new IllegalArgumentException("reader is null");

		clear();

		XMLReader xr = null;
		try
		{
			xr = XMLReaderFactory.createXMLReader();

			xr.setContentHandler(this);

			ErrorHandler handler = new ErrorHandler()
			{
				public void warning(SAXParseException e) throws SAXException
				{
					System.err.println("[warning] " + e.getMessage());
				}

				public void error(SAXParseException e) throws SAXException
				{
					System.err.println("[error] " + e.getMessage());
				}

				public void fatalError(SAXParseException e) throws SAXException
				{
					System.err.println("[fatal error] " + e.getMessage());
					throw e;
				}
			};

			xr.setErrorHandler(handler);
			xr.parse(new InputSource(reader));
		}
		catch (SAXException e2)
		{
			throw new GViewDataParseException(e2);
		}

		// TODO check if this worked or not
		// if (currentCgview == null) {
		// String error = "no cgview tags were encountered";
		// throw new SAXException(error);
		// }

		if (this.currentSequence != null && this.currentMapStyle != null)
			return new GViewFileData(GenomeDataFactory.createGenomeData(this.currentSequence), this.currentMapStyle);
		else
			return null;
	}

	/************************
	 * XML parser methods
	 ************************/

	@Override
	public void startDocument()
	{
		System.out.print("Parsing CGView XML input...");
	}

	@Override
	public void endDocument()
	{
		System.out.println("finished");
	}
	
	private int startElementCount = 0;
	
	@Override
	public void startElement(String uri, String name, String qName, Attributes atts) throws SAXException
	{
		ElementDetails details = new ElementDetails(name, atts);
		this.context.push(details);
		
		boolean ignoreLegendTag = false;
		boolean ignoreLegendItemTag = false;
		
		// keeping track of progress
		startElementCount++;
		if (startElementCount % 1000000 == 0)
		{
			System.out.print(".");
		}

		if (name.equalsIgnoreCase("cgview") && !this.ignoreCgviewTag)
		{
			handleCgview();
		}
		else if (name.equalsIgnoreCase("featureSlot"))
		{
			handleFeatureSlot();
		}
		else if (name.equalsIgnoreCase( "plotSlot" ))
		{
			handlePlotSlot();
		}
		else if (name.equalsIgnoreCase("feature"))
		{
			handleFeature();
		}
		else if (name.equalsIgnoreCase("featureRange"))
		{
			handleFeatureRange();
		}
		else if ((name.equalsIgnoreCase("legend")) && (!(ignoreLegendTag)))
		{
			handleLegend();
		}
		else if ((name.equalsIgnoreCase("legendItem")) && (!(ignoreLegendItemTag)))
		{
			handleLegendItem();
		}

		this.content.setLength(0);
	}
	
    private void handleLegendItem() throws SAXException
	{
        for (int p = context.size() - 1; p >= 0; p--)
        {
            ElementDetails elem = (ElementDetails) context.elementAt(p);
            
            if (elem.name.equalsIgnoreCase("legendItem"))
            {
                if (currentLegend == null)
                {
                    throw new SAXException(appendLocation("legendItem element encountered inside of legend element"));
                }
                else if (!cgviewTagEncountered)
                {
                    throw new SAXException(appendLocation("legendItem element encountered outside of a cgview element"));
                }
                else if (currentLegendItem != null)
                {
                    throw new SAXException(appendLocation("legendItem element encountered inside of another legendItem element"));
                }
                else if (elem.attributes.getValue("text") == null)
                {
                    throw new SAXException(appendLocation("legendItem element is missing 'text' attribute"));
                }

                currentLegendItem = currentLegend.createLegendItem(elem.attributes.getValue("text"));

                //optional tags
                //swatchOpacity
//                if (elem.attributes.getValue("swatchOpacity") != null) {
//                    float opacity;
//                    try {
//                        opacity = Float.parseFloat(elem.attributes.getValue("swatchOpacity"));
//                    } catch (NumberFormatException nfe) {
//                        String error = "value for 'swatchOpacity' attribute in legendItem element not understood";
//                        if (locator != null) {
//                            error = error + " in " + locator.getSystemId() + " at line " + locator.getLineNumber() + " column " + locator.getColumnNumber();
//                        }
//                        throw new SAXException(error);
//                    }
//
//                    if (opacity > 1.0f) {
//                        String error = "value for 'swatchOpacity' attribute in legendItem element must be between 0 and 1";
//                        if (locator != null) {
//                            error = error + " in " + locator.getSystemId() + " at line " + locator.getLineNumber() + " column " + locator.getColumnNumber();
//                        }
//                        throw new SAXException(error);
//                    }
//
//                    if (opacity < 0.0f) {
//                        String error = "value for 'swatchOpacity' attribute in legendItem element must be between 0 and 1";
//                        if (locator != null) {
//                            error = error + " in " + locator.getSystemId() + " at line " + locator.getLineNumber() + " column " + locator.getColumnNumber();
//                        }
//                        throw new SAXException(error);
//                    }
//
//                    currentLegendItem.setSwatchOpacity(opacity);
//                }
                
                //fontColor
                if (elem.attributes.getValue("fontColor") != null)
                {
                	Color color = extractColorFor("fontColor", elem);
                	if (color != null)
                	{
                		currentLegendItem.setFontColor(color);
                	}
                }

                //swatchColor
                if (elem.attributes.getValue("swatchColor") != null)
                {
                	Color color = extractColorFor("swatchColor", elem);
                	if (color != null)
                	{
                		currentLegendItem.setSwatchColor(color);
                	}
                }

                //drawSwatch
                if (elem.attributes.getValue("drawSwatch") != null)
                {
                	Boolean drawSwatch = BOOLEANS.get(elem.attributes.getValue("drawSwatch"));
                	
                	if (drawSwatch == null)
                	{
                		throw new SAXException(appendLocation("value for 'drawSwatch' attribute in legendItem element not understood"));
                	}
                	else
                	{
                		currentLegendItem.setDrawSwatch(drawSwatch);
                	}
                }

                //textAlignment
//                if (elem.attributes.getValue("textAlignment") != null) {
//                    if (LEGEND_ALIGNMENTS.get(((elem.attributes.getValue("textAlignment"))).toLowerCase()) != null) {
//                        currentLegendItem.setTextAlignment(((Integer) LEGEND_ALIGNMENTS.get(((elem.attributes.getValue("textAlignment"))).toLowerCase())).intValue());
//                    } else {
//                        String error = "value for 'textAlignment' attribute in legendItem element not understood";
//                        if (locator != null) {
//                            error = error + " in " + locator.getSystemId() + " at line " + locator.getLineNumber() + " column " + locator.getColumnNumber();
//                        }
//                        //throw new SAXException (error);
//                        System.err.println("[warning] " + error);
//                    }
//                }

                //font
                if (elem.attributes.getValue("font") != null)
                {
                	Font font = extractFontFor("font", elem);
                	if (font != null)
                	{
                		currentLegendItem.setFont(font);
                	}
                }

//		if (this.legendFontSize != -1) {
//		    if (currentLegendItem.getFont() != null) {
//			currentLegendItem.setFont(new Font(currentLegendItem.getFont().getName(), currentLegendItem.getFont().getStyle(), this.legendFontSize));
//		    }
//		    else if (currentLegend.getFont() != null) {
//			currentLegendItem.setFont(new Font(currentLegend.getFont().getName(), currentLegend.getFont().getStyle(), this.legendFontSize));
//		    }
//		    else {
//			currentLegendItem.setFont(new Font(currentCgview.getLegendFont().getName(), currentCgview.getLegendFont().getStyle(), this.legendFontSize));
//		    }
                
            }
		}
	}

	/**
     * Handles the legend element and its attributes.
     *
     * @throws SAXException
     */
    //required attributes: none.
    //optional attributes: font, fontColor, position, drawWhenZoomed, textAlignment, backgroundColor, backgroundOpacity, allowLabelClash.
    private void handleLegend() throws SAXException
    {
        for (int p = context.size() - 1; p >= 0; p--)
        {
            ElementDetails elem = (ElementDetails) context.elementAt(p);
            
            if (elem.name.equalsIgnoreCase("legend"))
            {
                if (currentLegend != null)
                {
                	throw new SAXException(appendLocation("legend element encountered inside of another legend element"));
                }
                else if (!cgviewTagEncountered)
                {
                    //an error because no currentCgview
                	throw new SAXException(appendLocation("legend element encountered outside of a cgview element"));
                }

                currentLegend = new Legend(this.currentMapStyle.getGlobalStyle().getBackgroundPaint());

                //optional tags
                //fontColor
                if (elem.attributes.getValue("fontColor") != null)
                {
                	Color color = extractColorFor("fontColor", elem);
                	if (color != null)
                	{
                		currentLegend.setFontColor(color);
                	}
                }

                //font
                if (elem.attributes.getValue("font") != null)
                {
                	Font font = extractFontFor("font", elem);
                	if (font != null)
                	{
                        currentLegend.setFont(font);
                	}
                }

                //position
                if (elem.attributes.getValue("position") != null)
                {
                    if (LEGEND_POSITIONS.get(((elem.attributes.getValue("position"))).toLowerCase()) != null)
                    {
                        currentLegend.setPosition(LEGEND_POSITIONS.get(elem.attributes.getValue("position")));
                    }
                    else
                    {
                        throw new SAXException(appendLocation("value for 'position' attribute in legend element not understood"));
                    }
                }

                //textAlignment
//                if (elem.attributes.getValue("textAlignment") != null) {
//                    if (LEGEND_ALIGNMENTS.get(((elem.attributes.getValue("textAlignment"))).toLowerCase()) != null) {
//                        currentLegend.setAlignment(((Integer) LEGEND_ALIGNMENTS.get(((elem.attributes.getValue("textAlignment"))).toLowerCase())).intValue());
//                    } else {
//                        String error = "value for 'textAlignment' attribute in legend element not understood";
//                        if (locator != null) {
//                            error = error + " in " + locator.getSystemId() + " at line " + locator.getLineNumber() + " column " + locator.getColumnNumber();
//                        }
//                        //throw new SAXException (error);
//                        System.err.println("[warning] " + error);
//                    }
//                }

                //drawWhenZoomed
//                if (elem.attributes.getValue("drawWhenZoomed") != null) {
//                    if (LEGEND_SHOW_ZOOM.get(((elem.attributes.getValue("drawWhenZoomed"))).toLowerCase()) != null) {
//                        currentLegend.setPosition(((Integer) LEGEND_POSITIONS.get(((elem.attributes.getValue("drawWhenZoomed"))).toLowerCase())).intValue());
//                    } else {
//                        String error = "value for 'drawWhenZoomed' attribute in legend element not understood";
//                        if (locator != null) {
//                            error = error + " in " + locator.getSystemId() + " at line " + locator.getLineNumber() + " column " + locator.getColumnNumber();
//                        }
//                        //throw new SAXException (error);
//                        System.err.println("[warning] " + error);
//                    }
//                }

                //backgroundOpacity
//                if (elem.attributes.getValue("backgroundOpacity") != null) {
//                    float opacity;
//                    try {
//                        opacity = Float.parseFloat(elem.attributes.getValue("backgroundOpacity"));
//                    } catch (NumberFormatException nfe) {
//                        String error = "value for 'backgroundOpacity' attribute in legend element not understood";
//                        if (locator != null) {
//                            error = error + " in " + locator.getSystemId() + " at line " + locator.getLineNumber() + " column " + locator.getColumnNumber();
//                        }
//                        throw new SAXException(error);
//                    }
//
//                    if (opacity > 1.0f) {
//                        String error = "value for 'backgroundOpacity' attribute in legend element must be between 0 and 1";
//                        if (locator != null) {
//                            error = error + " in " + locator.getSystemId() + " at line " + locator.getLineNumber() + " column " + locator.getColumnNumber();
//                        }
//                        throw new SAXException(error);
//                    }
//
//                    if (opacity < 0.0f) {
//                        String error = "value for 'backgroundOpacity' attribute in legend element must be between 0 and 1";
//                        if (locator != null) {
//                            error = error + " in " + locator.getSystemId() + " at line " + locator.getLineNumber() + " column " + locator.getColumnNumber();
//                        }
//                        throw new SAXException(error);
//                    }
//
//                    currentLegend.setBackgroundOpacity(opacity);
//                }

                //backgroundColor
                if (elem.attributes.getValue("backgroundColor") != null)
                {
                	Color color = extractColorFor("backgroundColor", elem);
                	if (color != null)
                	{
                		currentLegend.setBackgroundColor(color);
                	}
                }

                //allowLabelClash
//                if (elem.attributes.getValue("allowLabelClash") != null) {
//                    if (BOOLEANS.get(((elem.attributes.getValue("allowLabelClash"))).toLowerCase()) != null) {
//                        currentLegend.setAllowLabelClash(((Boolean) BOOLEANS.get(((elem.attributes.getValue("allowLabelClash"))).toLowerCase())).booleanValue());
//                    } else {
//                        String error = "value for 'allowLabelClash' attribute in legend element not understood";
//                        if (locator != null) {
//                            error = error + " in " + locator.getSystemId() + " at line " + locator.getLineNumber() + " column " + locator.getColumnNumber();
//                        }
//                        //throw new SAXException (error);
//                        System.err.println("[warning] " + error);
//                    }
//                }

//		if (this.legendFontSize != -1)
//		{
//		    if (currentLegend.getFont() != null) {
//			currentLegend.setFont(new Font(currentLegend.getFont().getName(), currentLegend.getFont().getStyle(), this.legendFontSize));
//		    }
//		    else {
//			currentLegend.setFont(new Font(currentCgview.getLegendFont().getName(), currentCgview.getLegendFont().getStyle(), this.legendFontSize));
//		    }
//		}
            }
        }
    }

	private void handlePlotSlot() throws SAXException
	{
		for (int p = this.context.size() - 1; p >= 0; p--)
		{
			ElementDetails elem = (ElementDetails) this.context.elementAt(p);
			if (elem.name.equalsIgnoreCase("plotSlot"))
			{
				// TODO account for currentSlotStyle?
				if (this.currentFeatureSlot != null)
					// an error because already in a FeatureSlot tag
					throw new SAXException(appendLocation("plotSlot element encountered inside of another featureSlot element"));
				else if (this.currentSequence == null)
					// an error because no currentSequence
					throw new SAXException(appendLocation("plotSlot element encountered outside of a cgview element"));
				else if (elem.attributes.getValue("strand") == null)
					// an error because no strand given
					throw new SAXException(appendLocation("plotSlot element is missing 'strand' attribute"));
				else
				{
					if (elem.attributes.getValue("strand").equalsIgnoreCase("direct"))
					{
						this.currentPlotSlot = this.featureSlotManager.createSlotStyle( StrandedFeature.POSITIVE );
					}
					else if (elem.attributes.getValue("strand").equalsIgnoreCase("reverse"))
					{
						this.currentPlotSlot = this.featureSlotManager.createSlotStyle( StrandedFeature.NEGATIVE );
					}
					else
					{
						// An error because strand could not be understood
						this.currentPlotSlot = null;
						throw new SAXException(appendLocation("value for 'strand' attribute in featureSlot element not understood"));
					}
				}

				// optional tags
				// featureThickness
				if (elem.attributes.getValue("featureThickness") != null)
				{
					try
					{
						double thickness = Double.parseDouble( elem.attributes.getValue( "featureThickness" ) );

						this.currentPlotSlot.setThickness( thickness );
					}
					catch (Exception e)
					{
						// throw new SAXException (error);
						printError("[warning] value for 'featureThickness' attribute in plotSlot element not understood");
					}
				}
			}
		}
	}

	@Override
	public void endElement(String uri, String name, String qName) throws SAXException
	{
		// System.out.println("End element: " + name);
		this.content.setLength(0);
		this.context.pop();

		if (name.equalsIgnoreCase("cgview"))
		{
			// currentCgview = null;
		}
		else if (name.equalsIgnoreCase("featureSlot"))
		{
			this.currentFeatureSlot = null;
		}
		else if( name.equalsIgnoreCase( "plotSlot" ))
		{
			Set<SlotItemStyle> plotStyles = this.currentPlotSlot.getPlotStyles();

			for( SlotItemStyle plotItemStyle : plotStyles )
			{
				if( plotItemStyle instanceof PlotStyle )
				{
					PlotStyle plotStyle = (PlotStyle)plotItemStyle;
					plotStyle.setPlotDrawer( new PlotDrawerCenter() );

					if( ( (PlotStyle) plotItemStyle ).getPlotBuilder().getNumPoints() > 1 )
					{
						( (PlotStyle) plotItemStyle ).getPlotBuilder().autoScaleCenter();
					}
					plotStyle.setPlotBuilder( ( (PlotStyle) plotItemStyle ).getPlotBuilder() );
				}
			}
			
			this.currentPlotSlot = null;
		}
		else if (name.equalsIgnoreCase("feature"))
		{
			if( this.currentFeature != null )
			{
				this.currentFeature.endFeature();
				this.currentFeature = null;
			}
			else if (this.currPlot != null)
			{
				this.currPlot.endPlot();
				this.currentPlotSlot.addStyleItem(currPlot.getPlotStyle());
				
				this.currPlot = null;
			}
		}
		else if (name.equalsIgnoreCase("featureRange"))
		{
			this.currentFeatureRange = null;
		}
		else if (name.equalsIgnoreCase("legend"))
		{
			currentLegend.endLegend();
			currentLegend = null;
		}
		else if (name.equalsIgnoreCase("legendItem"))
		{
			currentLegendItem = null;
		}
	}

	/**
	 * Extracts a base number on the sequence, performs error checking on value.
	 * 
	 * @param propertyType
	 *            The property type to extract.
	 * @param elem
	 *            The element details.
	 * @return The extracted base.
	 * @throws SAXException
	 *             if there was any problem with extracted value.
	 */
	private int extractSequenceValue(String propertyType, ElementDetails elem) throws SAXException
	{
		int base = -1;

		try
		{
			base = Integer.parseInt(elem.attributes.getValue(propertyType));
		}
		catch (NumberFormatException nfe)
		{
			throw new SAXException(appendLocation("value for '" + propertyType + "' attribute in " + elem.name + " element not understood"));
		}

		if (base > this.cgviewLength)
			throw new SAXException(appendLocation("value for '" + propertyType + "' attribute in " + elem.name
					+ " element must be less than or equal to the length of the plasmid"));

		if (base < 1)
			throw new SAXException(appendLocation("value for '" + propertyType + "' attribute in " + elem.name
					+ " element must be greater than or equal to 1"));

		return base;
	}

	/**
	 * Extracts a font for the given property name, from the passed element details.
	 * 
	 * @param propertyName
	 *            The name of the property to extract the font for.
	 * @param elem
	 *            The element details to extract the font for.
	 * @return The extracted font, or null if no font.
	 */
	private Font extractFontFor(String propertyName, ElementDetails elem)
	{
		Font font = null;

		if (elem.attributes.getValue(propertyName) != null)
		{
			Matcher m = fontDescriptionPattern.matcher(elem.attributes.getValue(propertyName));
			if (m.find())
			{
				try
				{

					String name = m.group(1);
					String style = m.group(2);
					int size = Integer.parseInt(m.group(3));
					int intStyle = Font.PLAIN;

					if (style.equalsIgnoreCase("bold"))
					{
						intStyle = Font.BOLD;
					}
					else if (style.equalsIgnoreCase("italic") || style.equalsIgnoreCase("italics"))
					{
						intStyle = Font.ITALIC;
					}
					else if (style.equalsIgnoreCase("bold-italic") || style.equalsIgnoreCase("italic-bold"))
					{
						intStyle = Font.ITALIC + Font.BOLD;
					}

					font = new Font(name, intStyle, size);

				}
				catch (NumberFormatException e)
				{
					printError("[warning] value for '" + propertyName + "' attribute in " + elem.name + " element not understood");
				}
			}
			else
			{
				// throw new SAXException (error);
				printError("[warning] value for '" + propertyName + "' attribute in " + elem.name + " element not understood");
			}
		}

		return font;
	}

	// TODO do we need both property name and details?
	/**
	 * Extracts a color for the given property name, from the passed element details.
	 * 
	 * @param propertyName
	 *            The name of the property to extract the color for.
	 * @param elem
	 *            The element details to extract the color for.
	 * @return The extracted color, or null if no color.
	 */
	private Color extractColorFor(String propertyName, ElementDetails elem)
	{
		Color color = null;

		if (elem.attributes.getValue(propertyName) != null)
		{
			if (COLORS.get(elem.attributes.getValue(propertyName).toLowerCase()) != null)
			{
				color = COLORS.get(elem.attributes.getValue(propertyName).toLowerCase());
			}
			else
			{
				Matcher m = colorDescriptionPattern.matcher(elem.attributes.getValue(propertyName));
				if (m.find())
				{
					try
					{
						int r = Integer.parseInt(m.group(1));
						int g = Integer.parseInt(m.group(2));
						int b = Integer.parseInt(m.group(3));

						color = new Color(r, g, b);

					}
					catch (NumberFormatException e)
					{
						// throw new SAXException (error);
						printError("[warning] value for '" + propertyName + "' attribute in " + elem.name + " element not understood");
					}
				}
				else
				{
					printError("[warning] value for '" + propertyName + "' attribute in " + elem.name + " element not understood");
				}
			}
		}

		return color;
	}

	/**
	 * Extracts a real value for the given property name, from the passed element details.
	 * 
	 * @param propertyName
	 *            The name of the property to extract the real value for.
	 * @param elem
	 *            The element details to extract the real value for.
	 * @param table
	 *            A Hashtable mapping strings to double values.
	 * @return The extracted real value.
	 * 
	 * @throws NumberFormatException
	 *             if the corresponding value was not formatted correctly
	 */
	private double extractRealFor(String propertyName, ElementDetails elem, Hashtable<String, Double> table) throws NumberFormatException
	{
		double realValue = 0.0;

		if (elem == null || propertyName == null || elem.attributes.getValue(propertyName) == null)
			throw new IllegalArgumentException("null parameters");

		if (elem.attributes.getValue(propertyName) != null)
		{
			if (table != null && table.get(elem.attributes.getValue(propertyName).toLowerCase()) != null)
			{
				realValue = table.get(elem.attributes.getValue(propertyName).toLowerCase()).doubleValue();
			}
			else
			{
				realValue = Double.parseDouble(elem.attributes.getValue(propertyName));
			}
		}

		return realValue;
	}

	/**
	 * Appends the location onto the passed error string.
	 * 
	 * @param error
	 *            The string which to append a location on.
	 * @return The error string + the location.
	 */
	private String appendLocation(String error)
	{
		String errorLocation = error;

		if (this.locator != null)
		{
			errorLocation = " in " + this.locator.getSystemId() + " at line " + this.locator.getLineNumber() + " column " + this.locator.getColumnNumber();
			if (error != null)
			{
				errorLocation = error + errorLocation;
			}
		}
		return errorLocation;
	}

	/**
	 * Prints out the error, handling location.
	 * 
	 * @param error
	 *            The error message to print.
	 */
	private void printError(String error)
	{
		System.err.println(appendLocation(error));
	}

	/**
	 * Initializes global constances when encountering a cgview tag.
	 */
	private void initializeCGView(int sequenceLength)
	{
		final double defaultRadius = 190.0;
		final Font defaultRulerLabelFont = new Font("SansSerif", Font.PLAIN, 8);

		SimpleSequenceFactory seqFactory = new SimpleSequenceFactory();
		SymbolList blankList = new BlankSymbolList(this.cgviewLength);
		this.currentSequence = seqFactory.createSequence(blankList, null, null, null);
		this.currentMapStyle = new MapStyle();
		this.featureSlotManager = new FeatureSlotManager(this.currentMapStyle.getDataStyle(), defaultLabelFont);

		// sets style for tooltips
		TooltipStyle tooltip = this.currentMapStyle.getGlobalStyle().getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(0, 0, 1.0f, 0.5f));
		tooltip.setTextPaint(Color.WHITE);

		// I probably shouldn't set default thickness here, but it works
		this.currentMapStyle.getGlobalStyle().getBackboneStyle().setThickness(5.0);
		this.currentMapStyle.getGlobalStyle().getBackboneStyle().setInitialBackboneLength(2*Math.PI*defaultRadius); // default

		RulerStyle rulerStyle = this.currentMapStyle.getGlobalStyle().getRulerStyle();

		rulerStyle.setFont(defaultRulerLabelFont);

		this.cgviewTagEncountered = true;
	}

	/**
	 * Handles the cgview element and its attributes.
	 * 
	 * @throws SAXException
	 */
	// required attributes: sequenceLength.
	// optional attributes: title, rulerUnits, rulerFont, rulerPadding, labelFont, useInnerLabels,
	// featureThickness, featureSlotSpacing, backboneThickness, arrowheadLength,
	// minimumFeatureLength, titleFont, titleFontColor, rulerFontColor, origin, tickThickness,
	// tickLength, labelLineThickness, labelLineLength, backboneColor, backgroundColor,
	// longTickColor, giveFeaturePositions, shortTickColor, zeroTickColor, width, height,
	// backboneRadius, labelPlacementQuality, useColoredLabelBackgrounds, showWarning, warningFont,
	// info, warningFontColor, showShading, showBorder, borderColor, moveInnerLabelsToOuter,
	// globalLabel, labelsToKeep, globalLabelColor, tickDensity.
	private void handleCgview() throws SAXException
	{

		for (int p = this.context.size() - 1; p >= 0; p--)
		{
			ElementDetails elem = (ElementDetails) this.context.elementAt(p);
			if (elem.name.equalsIgnoreCase("cgview"))
			{
				// gview.main cgview tag
				if (this.cgviewTagEncountered)
					throw new SAXException(appendLocation("cgview element encountered inside of another cgview element"));
				if (elem.attributes.getValue("sequenceLength") == null)
					throw new SAXException(appendLocation("cgview element is missing 'sequenceLength' attribute"));
				else
				{
					try
					{
						this.cgviewLength = Integer.parseInt(elem.attributes.getValue("sequenceLength"));
					}
					catch (NumberFormatException nfe)
					{
						throw new SAXException(appendLocation("value for 'sequenceLength' attribute in cgview element not understood"));
					}

					if (this.cgviewLength > MAX_BASES)
						throw new SAXException(
								appendLocation("value for 'sequenceLength' attribute in cgview element must be less than " + MAX_BASES));

					if (this.cgviewLength < MIN_BASES)
						throw new SAXException(appendLocation("value for 'sequenceLength' attribute in cgview element must be greater than "
								+ MIN_BASES));

					// currentCgview = new Cgview(cgviewLength);
					// creates a new currentSequence with correct currentSequence length
					initializeCGView(this.cgviewLength);
				}

				// useColoredLabelBackgrounds
				if (elem.attributes.getValue("useColoredLabelBackgrounds") != null)
				{
					Boolean useColoredLabelBackgrounds = BOOLEANS.get(elem.attributes.getValue("useColoredLabelBackgrounds"));

					if (useColoredLabelBackgrounds == null)
						throw new SAXException(appendLocation("value for 'useColoredLabelBackgrounds' attribute in cgview element not understood"));
					else
					{
						this.featureSlotManager.setUseColoredLabelBackgrounds(useColoredLabelBackgrounds.booleanValue());
					}
				}

				// rulerFont
				if (elem.attributes.getValue("rulerFont") != null)
				{
					this.currentMapStyle.getGlobalStyle().getRulerStyle().setFont(extractFontFor("rulerFont", elem));
				}

				// labelFont
				if (elem.attributes.getValue("labelFont") != null)
				{
					this.featureSlotManager.setLabelFont(extractFontFor("labelFont", elem));
				}

				// //titleFontColor
				// if (elem.attributes.getValue("titleFontColor") != null) {
				// // set title font color
				// }

				// globalLabelColor
				if (elem.attributes.getValue("globalLabelColor") != null)
				{
					this.featureSlotManager.setGlobalLabelColor(extractColorFor("globalLabelColor", elem));
				}

				// rulerFontColor
				if (elem.attributes.getValue("rulerFontColor") != null)
				{
					this.currentMapStyle.getGlobalStyle().getRulerStyle().setTextPaint(extractColorFor("rulerFontColor", elem));
				}

				// backboneColor
				if (elem.attributes.getValue("backboneColor") != null)
				{
					this.currentMapStyle.getGlobalStyle().getBackboneStyle().setPaint(extractColorFor("backboneColor", elem));
				}

				// backgroundColor
				if (elem.attributes.getValue("backgroundColor") != null)
				{
					Color backgroundColor = extractColorFor("backgroundColor", elem);

					this.currentMapStyle.getGlobalStyle().setBackgroundPaint(backgroundColor);

					// by default, set the ruler text background color to a translucent version of the background color
					this.currentMapStyle.getGlobalStyle().getRulerStyle().setTextBackgroundPaint(new Color(backgroundColor.getRed(),
							backgroundColor.getGreen(), backgroundColor.getBlue(), 100));
				}

				// longTickColor
				if (elem.attributes.getValue("longTickColor") != null)
				{
					this.currentMapStyle.getGlobalStyle().getRulerStyle().setMajorTickPaint(extractColorFor("longTickColor", elem));
				}

				// shortTickColor
				if (elem.attributes.getValue("shortTickColor") != null)
				{
					this.currentMapStyle.getGlobalStyle().getRulerStyle().setMinorTickPaint(extractColorFor("shortTickColor", elem));
				}

				// featureThickness
				if (elem.attributes.getValue("featureThickness") != null)
				{
					try
					{
						this.featureThickness = extractRealFor("featureThickness", elem, FEATURE_THICKNESSES);
					}
					catch (Exception e)
					{
						// throw new SAXException (error);
						printError("[warning] value for 'featureThickness' attribute in cgview element not understood");
					}
				}

				if (elem.attributes.getValue("featureSlotSpacing") != null)
				{
					double slotSpacing = 0;

					try
					{
						slotSpacing = extractRealFor("featureSlotSpacing", elem, FEATURESLOT_SPACINGS);
					}
					catch (NumberFormatException nfe)
					{
						throw new SAXException(appendLocation("value for 'featureSlotSpacing' attribute in cgview element not understood"));
					}

					if (slotSpacing < 0)
						throw new SAXException(appendLocation("value for 'featureSlotSpacing' attribute in cgview element must be non-negative"));

					// set slot spacing
					this.currentMapStyle.getGlobalStyle().setSlotSpacing(slotSpacing);
				}
				
				// show shading
				if (elem.attributes.getValue("showShading") != null)
				{
					Boolean showShadingValue = BOOLEANS.get(elem.attributes.getValue("showShading"));

					if (showShadingValue == null)
						throw new SAXException(appendLocation("value for 'showShading' attribute in cgview element not understood"));
					else
					{
						showShadingValue = true;
					}
				}

				// backboneThickness
				if (elem.attributes.getValue("backboneThickness") != null)
				{
					try
					{
						this.currentMapStyle.getGlobalStyle().getBackboneStyle().setThickness(
								extractRealFor("backboneThickness", elem, BACKBONE_THICKNESSES));
					}
					catch (NumberFormatException e)
					{
						// throw new SAXException (error);
						printError("[warning] value for 'backboneThickness' attribute in cgview element not understood");
					}
				}

				if (elem.attributes.getValue("tickDensity") != null)
				{
					float tickDensity = 0;

					try
					{
						tickDensity = (float) extractRealFor("tickDensity", elem, null);
					}
					catch (NumberFormatException nfe)
					{
						throw new SAXException(appendLocation("value for 'tickDensity' attribute in cgview element not understood"));
					}

					if (tickDensity < 0)
						throw new SAXException(appendLocation("value for 'tickDensity' attribute in cgview element must be within [0,1]"));
					else if (tickDensity > 1.0)
						throw new SAXException(appendLocation("value for 'tickDensity' attribute in cgview element must be within [0,1]"));

					// set slot spacing
					this.currentMapStyle.getGlobalStyle().getRulerStyle().setTickDensity(tickDensity);
				}

				// tickLength
				if (elem.attributes.getValue("tickLength") != null)
				{
					try
					{
						this.currentMapStyle.getGlobalStyle().getRulerStyle().setMajorTickLength(extractRealFor("tickLength", elem, TICK_LENGTHS));
					}
					catch (Exception e)
					{
						// throw new SAXException (error);
						printError("[warning] value for 'tickLength' attribute in cgview element not understood");
					}
				}

				// tickThickness
				if (elem.attributes.getValue("tickThickness") != null)
				{
					try
					{
						this.currentMapStyle.getGlobalStyle().getRulerStyle().setTickThickness(extractRealFor("tickThickness", elem, TICK_THICKNESSES));
					}
					catch (Exception e)
					{
						// throw new SAXException (error);
						printError("[warning] value for 'tickThickness' attribute in cgview element not understood");
					}
				}

				// labelLineThickness
				if (elem.attributes.getValue("labelLineThickness") != null)
				{
					double thickness;
					try
					{
						thickness = extractRealFor("labelLineThickness", elem, LABEL_LINE_THICKNESSES);
					}
					catch (NumberFormatException nfe)
					{
						throw new SAXException(appendLocation("value for 'labelLineThickness' attribute in cgview element not understood"));
					}

					if (thickness < 0.0f)
						throw new SAXException(
								appendLocation("value for 'labelLineThickness' attribute in cgview element must not be negative"));

					this.globalLabelLineThickness = (float)thickness;
				}

				// width
				if (elem.attributes.getValue("width") != null)
				{
					try
					{
						this.imageWidth = Integer.parseInt(elem.attributes.getValue("width"));
					}
					catch (NumberFormatException nfe)
					{
						throw new SAXException(appendLocation("value for 'width' attribute in cgview element not understood"));
					}

					if (this.imageWidth < MIN_IMAGE_WIDTH)
						throw new SAXException(appendLocation("value for 'width' attribute in cgview element must be greater than or equal to "
								+ MIN_IMAGE_WIDTH));

					if (this.imageWidth > MAX_IMAGE_WIDTH)
						throw new SAXException(appendLocation("value for 'width' attribute in cgview element must be less than or equal to "
								+ MAX_IMAGE_WIDTH));

					this.currentMapStyle.getGlobalStyle().setDefaultWidth(this.imageWidth);
				}

				// height
				if (elem.attributes.getValue("height") != null)
				{
					try
					{
						this.imageHeight = Integer.parseInt(elem.attributes.getValue("height"));
					}
					catch (NumberFormatException nfe)
					{
						throw new SAXException(appendLocation("value for 'height' attribute in cgview element not understood"));
					}

					if (this.imageHeight < MIN_IMAGE_HEIGHT)
						throw new SAXException(appendLocation("value for 'height' attribute in cgview element must be greater than or equal to "
								+ MIN_IMAGE_HEIGHT));

					if (this.imageHeight > MAX_IMAGE_HEIGHT)
						throw new SAXException(appendLocation("value for 'height' attribute in cgview element must be less than or equal to "
								+ MAX_IMAGE_HEIGHT));

					this.currentMapStyle.getGlobalStyle().setDefaultHeight(this.imageHeight);
				}

				// backboneRadius
				if (elem.attributes.getValue("backboneRadius") != null)
				{
					double backboneRadius;

					try
					{
						backboneRadius = Double.parseDouble(elem.attributes.getValue("backboneRadius"));
					}
					catch (NumberFormatException nfe)
					{
						throw new SAXException(appendLocation("value for 'backboneRadius' attribute in cgview element not understood"));
					}

					if (backboneRadius < MIN_BACKBONE_RADIUS)
						throw new SAXException(appendLocation("value for 'backboneRadius' attribute in cgview element must be greater than or equal to "
								+ MIN_BACKBONE_RADIUS));
					else if (backboneRadius > MAX_BACKBONE_RADIUS)
						throw new SAXException(appendLocation("value for 'backboneRadius' attribute in cgview element must be less than or equal to "
								+ MAX_BACKBONE_RADIUS));

					// Multiply by 2*PI to convert to length of backbone
					this.currentMapStyle.getGlobalStyle().getBackboneStyle().setInitialBackboneLength(2*Math.PI*backboneRadius);
				}


				// globalLabel
				if (elem.attributes.getValue("globalLabel") != null)
				{
					Boolean globalLabels = GLOBAL_LABEL_TYPES.get(elem.attributes.getValue("globalLabel"));

					if (globalLabels == null)
						throw new SAXException(appendLocation("value for 'globalLabel' attribute in cgview element not understood"));
					else
					{
						this.globalShowLabels = globalLabels;
					}
				}
			}
		} // end for
	}

	private void handleFeatureSlot() throws SAXException
	{

		for (int p = this.context.size() - 1; p >= 0; p--)
		{
			ElementDetails elem = (ElementDetails) this.context.elementAt(p);
			if (elem.name.equalsIgnoreCase("featureSlot"))
			{
				// TODO account for currentSlotStyle?
				if (this.currentFeatureSlot != null)
					// an error because already in a FeatureSlot tag
					throw new SAXException(appendLocation("featureSlot element encountered inside of another featureSlot element"));
				if (this.currentPlotSlot != null)
				{
					throw new SAXException(appendLocation("featureSlot element encountered inside of another featureSlot element"));
				}
				else if (this.currentSequence == null)
					// an error because no currentSequence
					throw new SAXException(appendLocation("featureSlot element encountered outside of a cgview element"));
				else if (elem.attributes.getValue("strand") == null)
					// an error because no strand given
					throw new SAXException(appendLocation("featureSlot element is missing 'strand' attribute"));
				else
				{
					if (elem.attributes.getValue("strand").equalsIgnoreCase("direct"))
					{
						this.currentFeatureSlot = this.featureSlotManager.createFeatureSlot(StrandedFeature.POSITIVE, this.globalShowLabels,
								this.globalLabelLineThickness);
						
						// set defaults
						this.currentFeatureSlot.setFeatureThickness(featureThickness);
						this.currentFeatureSlot.setShowShading(showShading);
					}
					else if (elem.attributes.getValue("strand").equalsIgnoreCase("reverse"))
					{
						this.currentFeatureSlot = this.featureSlotManager.createFeatureSlot(StrandedFeature.NEGATIVE, this.globalShowLabels,
								this.globalLabelLineThickness);
						

						// set defaults
						this.currentFeatureSlot.setFeatureThickness(featureThickness);
						this.currentFeatureSlot.setShowShading(showShading);
					}
					else
					{
						// an error because strand could not be understood
						this.currentFeatureSlot = null;
						throw new SAXException(appendLocation("value for 'strand' attribute in featureSlot element not understood"));
					}
				}

				// optional tags
				// featureThickness
				if (elem.attributes.getValue("featureThickness") != null)
				{
					try
					{
						this.currentFeatureSlot.setFeatureThickness(extractRealFor("featureThickness", elem, FEATURE_THICKNESSES));
					}
					catch (Exception e)
					{
						// throw new SAXException (error);
						printError("[warning] value for 'featureThickness' attribute in cgview element not understood");
					}
				}


				// show shading
				if (elem.attributes.getValue("showShading") != null)
				{
					Boolean showShading = BOOLEANS.get(elem.attributes.getValue("showShading"));

					if (showShading == null)
						throw new SAXException(appendLocation("value for 'showShading' attribute in feature element not understood"));
					else
					{
						this.currentFeatureSlot.setShowShading(showShading);
					}
				}
				// // showShading
				// if (elem.attributes.getValue("showShading") != null)
				// {
				// if (BOOLEANS
				// .get(((elem.attributes.getValue("showShading")))
				// .toLowerCase()) != null)
				// {
				// currentFeatureSlot
				// .setShowShading(((Boolean) BOOLEANS
				// .get(((elem.attributes
				// .getValue("showShading")))
				// .toLowerCase())).booleanValue());
				// } else
				// {
				// String error =
				// "value for 'showShading' attribute in featureSlot element not understood";
				// if (locator != null)
				// {
				// error = error + " in " + locator.getSystemId()
				// + " at line " + locator.getLineNumber()
				// + " column " + locator.getColumnNumber();
				// }
				// // throw new SAXException (error);
				// System.err.println("[warning] " + error);
				// }
				// }
			}
		}
	}

	/**
	 * Handles the feature element and its attributes.
	 * 
	 * @throws SAXException
	 */
	// required attributes:
	// optional attributes: color, opacity, proportionOfThickness, radiusAdjustment, decoration,
	// showLabel, font, label, showShading, hyperlink, mouseover
	private void handleFeature() throws SAXException
	{
		for (int p = this.context.size() - 1; p >= 0; p--)
		{
			ElementDetails elem = (ElementDetails) this.context.elementAt(p);
			if (elem.name.equalsIgnoreCase("feature"))
			{
				if (this.currPlot != null)
				{
					throw new SAXException(appendLocation("feature element encountered inside of another feature element"));
				}
				else if (this.currentFeature != null)
					// an error because already in a Feature tag
					throw new SAXException(appendLocation("feature element encountered inside of another feature element"));
				else if (this.currentSequence == null)
					// an error because no currentCgview
					throw new SAXException(appendLocation("feature element encountered outside of a cgview element"));
				else if (this.currentFeatureSlot == null && this.currentPlotSlot == null )
					// an error because no currentFeatureSlot
					throw new SAXException(appendLocation("feature element encountered outside of a featureSlot element"));
				else if (this.currentPlotSlot != null && this.currentFeatureSlot != null)
				{
					throw new SAXException(appendLocation("feature element encountered inside of multiple featureSlot elements"));
				}
				else
				{
					if( this.currentFeatureSlot != null ) // currentPlotSlot is null
					{
						this.currentFeature = this.currentFeatureSlot.createFeature();
					}
				}

				if (this.currentPlotSlot != null)
				{
					currPlot = new Plot();
				}
				else if( this.currentFeature != null )
				{
					// optional tags
					// color
					if (elem.attributes.getValue("color") != null)
					{
						Color color = extractColorFor("color", elem);
						if (color != null)
						{
							if( this.currentFeature != null )
							{
								this.currentFeature.setColor(color);
							}
						}
					}

					// opacity
					if (elem.attributes.getValue("opacity") != null)
					{
						double opacity;
						try
						{
							opacity = Float.parseFloat(elem.attributes.getValue("opacity"));
						}
						catch (NumberFormatException nfe)
						{
							throw new SAXException(appendLocation("value for 'opacity' attribute in feature element not understood"));
						}

						if (opacity > 1.0)
							throw new SAXException(appendLocation("value for 'opacity' attribute in feature element must be between 0 and 1"));

						if (opacity < 0.0)
							throw new SAXException(appendLocation("value for 'opacity' attribute in feature element must be between 0 and 1"));

						this.currentFeature.setOpacity(opacity);
					}

					// proportionOfThickness
					if (elem.attributes.getValue("proportionOfThickness") != null)
					{
						double thickness;
						try
						{
							thickness = Float.parseFloat(elem.attributes.getValue("proportionOfThickness"));
						}
						catch (NumberFormatException nfe)
						{
							throw new SAXException(appendLocation("value for 'proportionOfThickness' attribute in feature element not understood"));
						}

						if (thickness > 1.0)
							throw new SAXException(
									appendLocation("value for 'proportionOfThickness' attribute in feature element must be between 0 and 1"));

						if (thickness < 0.0f)
							throw new SAXException(
									appendLocation("value for 'proportionOfThickness' attribute in feature element must be between 0 and 1"));

						this.currentFeature.setProportionOfThickness(thickness);
					}

					// radiusAdjustment
					if (elem.attributes.getValue("radiusAdjustment") != null)
					{
						double radiusAdjustment;
						try
						{
							radiusAdjustment = Float.parseFloat(elem.attributes.getValue("radiusAdjustment"));
						}
						catch (NumberFormatException nfe)
						{
							throw new SAXException(appendLocation("value for 'radiusAdjustment' attribute in feature element not understood"));
						}

						if (radiusAdjustment > 1.0)
							throw new SAXException(appendLocation("value for 'radiusAdjustment' attribute in feature element must be between 0 and 1"));

						if (radiusAdjustment < 0.0f)
							throw new SAXException(appendLocation("value for 'radiusAdjustment' attribute in feature element must be between 0 and 1"));

						this.currentFeature.setRadiusAdjustment(radiusAdjustment); //
					}

					// decoration
					if (elem.attributes.getValue("decoration") != null)
					{
						FeatureShapeRealizer decoration = DECORATIONS.get(elem.attributes.getValue("decoration").toLowerCase());

						if (decoration == null)
							throw new SAXException(appendLocation("value for 'decoration' attribute in feature element not understood"));
						else
						{
							this.currentFeature.setDecoration(decoration);
						}
					}

					// showlabel
					if (elem.attributes.getValue("showLabel") != null)
					{
						Boolean showLabel = BOOLEANS.get(elem.attributes.getValue("showLabel"));

						if (showLabel == null)
							throw new SAXException(appendLocation("value for 'showLabel' attribute in feature element not understood"));
						else
						{
							this.currentFeature.setShowLabel(showLabel);
						}
					}

					// font for label
					if (elem.attributes.getValue("font") != null)
					{
						this.currentFeature.setLabelFont(extractFontFor("font", elem));
					}

					// label
					if (elem.attributes.getValue("label") != null)
					{
						this.currentFeature.setLabel(elem.attributes.getValue("label"));
					}

					// show shading
					if (elem.attributes.getValue("showShading") != null)
					{
						Boolean showShading = BOOLEANS.get(elem.attributes.getValue("showShading"));

						if (showShading == null)
							throw new SAXException(appendLocation("value for 'showShading' attribute in feature element not understood"));
						else
						{
							this.currentFeature.setShowShading(showShading);
						}
					}

					// mouseover
					if (elem.attributes.getValue("mouseover") != null)
					{
						this.currentFeature.setMouseover(elem.attributes.getValue("mouseover"));
					}
				}

			}
		}
	}

	/**
	 * Handles the featureRange element and its attributes.
	 * 
	 * @throws SAXException
	 */
	// required attributes: start, stop
	// optional attributes: color, opacity, proportionOfThickness, radiusAdjustment, decoration,
	// showLabel, font, label, showShading, hyperlink, mouseover
	private void handleFeatureRange() throws SAXException
	{
		for (int p = this.context.size() - 1; p >= 0; p--)
		{
			ElementDetails elem = (ElementDetails) this.context.elementAt(p);
			if (elem.name.equalsIgnoreCase("featureRange"))
			{
				if (this.currentFeatureRange != null)
					// an error because already in a FeatureRange
					throw new SAXException(appendLocation("featureRange element encountered inside of another featureRange element"));
				else if (this.currentFeature == null && this.currentPlotSlot == null)
					// an error because no current Feature
					throw new SAXException(appendLocation("featureRange element encountered outside of a feature element"));
				else if (this.currentSequence == null)
					// an error because no currentCgview
					throw new SAXException(appendLocation("featureRange element encountered outside of a cgview element"));
				else if (this.currentFeatureSlot == null && this.currentPlotSlot == null)
					// an error because no currentFeatureSlot
					throw new SAXException(appendLocation("featureRange element encountered outside of a featureSlot element"));
				else if (elem.attributes.getValue("start") == null)
					// an error because no length
					throw new SAXException(appendLocation("featureRange element is missing 'start' attribute"));
				else if (elem.attributes.getValue("stop") == null)
					// an error because no length
					throw new SAXException(appendLocation("featureRange element is missing 'stop' attribute"));
				else
				{
					int start = extractSequenceValue("start", elem);
					int stop = extractSequenceValue("stop", elem);


					double radiusAdjustement = 1.0; // Can't be this big
					if( this.currentFeature != null ) // currentPlotSlot is null
					{
						this.currentFeatureRange = new FeatureRange();
						this.currentFeatureRange.setStart(start);
						this.currentFeatureRange.setStop(stop);
						this.currentFeature.addFeatureRange(this.currentFeatureRange);
					}
					else if (this.currentPlotSlot != null)
					{
						Color plotColor = null;
						if( elem.attributes.getValue("radiusAdjustment" ) != null )
						{
							radiusAdjustement = Double.parseDouble(elem.attributes.getValue("radiusAdjustment"));
							if (radiusAdjustement > 1.0)
								throw new SAXException(
										appendLocation("value for 'proportionOfThickness' attribute in feature element must be between 0 and 1"));

							if (radiusAdjustement < 0.0)
								throw new SAXException(
										appendLocation("value for 'proportionOfThickness' attribute in feature element must be between 0 and 1"));
						}

						if( elem.attributes.getValue( "color" ) != null )
						{
							plotColor = extractColorFor("color", elem);
						}
						
						currPlot.addRange(start, stop, radiusAdjustement, plotColor);
						
//						Set<SlotItemStyle> styles = this.currentPlotSlot.getPlotStyles();
//						PlotStyle style = null;
//						if( plotColor == null )
//						{
//							plotColor = Color.BLUE;
//						}
//						for( SlotItemStyle sis : styles )
//						{
//							if( sis instanceof PlotStyle )
//							{
//								style = (PlotStyle) sis;
//								if( Arrays.equals(style.getPaint(), new Paint[]{plotColor}) )
//								{
//									((PlotBuilderRange)style.getPlotBuilder()).addRange( start, stop, thickness );
//									break; // break from the for loop
//								}
//								else
//								{
//									style = null;
//								}
//							}
//						}
//
//						if( style == null ) // plot style not found previously
//						{
//							PlotStyle plotStyle = new PlotStyle();
//							plotStyle.setPaint( plotColor );
//							PlotBuilderRange pbr = new PlotBuilderRange();
//							pbr.addRange( start, stop, thickness );
//							plotStyle.setPlotBuilder( pbr );
//							this.currentPlotSlot.addStyleItem( plotStyle );
//						}

						//this.currentPlotSlot.getPlotStyle().setPaint( new Color( Integer.parseInt( rgb[0] ), Integer.parseInt( rgb[1] ), Integer.parseInt( rgb[2] ) ) );
						//this.currentPlotBuilder.addRange( start, stop, thickness );
					}
				}
			}
		}
	}

	/**
	 * Used to store/tie together a name and attributes of some element in the file.
	 * 
	 * @author Aaron Petkau
	 * 
	 */
	private static class ElementDetails
	{

		public String name;
		public Attributes attributes;

		public ElementDetails(String name, Attributes atts)
		{
			this.name = name;
			this.attributes = new AttributesImpl(atts);
		}
	}

	/**
	 * Manages creation of feature slots. Need this to handle slot numbers, etc.
	 * 
	 * @author Aaron Petkau
	 * 
	 */
	private class FeatureSlotManager
	{
		// indicates which slot to use
		// public final static int POSITIVE = 1;
		// public final static int NEGATIVE = 0;

		private DataStyle dataStyle;

		// the current positive/negative slot numbers that are free
		private int currPositiveSlot = 1;
		private int currNegativeSlot = -1;

		private Font labelFont;
		private Color globalLabelColor;

		private boolean useColoredLabelBackgrounds = false;

		public FeatureSlotManager(DataStyle dataStyle, Font labelFont)
		{
			assert dataStyle != null;

			this.dataStyle = dataStyle;
			this.labelFont = labelFont;
		}

		public void setUseColoredLabelBackgrounds(boolean useColoredLabelBackgrounds)
		{
			this.useColoredLabelBackgrounds  = useColoredLabelBackgrounds;
		}

		public void setGlobalLabelColor(Color labelColor)
		{
			this.globalLabelColor = labelColor;
		}

		public void setLabelFont(Font labelFont)
		{
			this.labelFont = labelFont;
		}

		/**
		 * creates a new feature slot.
		 * 
		 * @param strand
		 *            The strandedness of this slot.
		 * @return The newly created FeatureSlot, or null if slot is invalid.
		 */
		public FeatureSlot createFeatureSlot(StrandedFeature.Strand strand,
				boolean globalShowLables,
				float labelLineThickness)
		{
			FeatureSlot slot = null;

			if (strand == StrandedFeature.POSITIVE)
			{
				SlotStyle slotStyle = this.dataStyle.createSlotStyle(this.currPositiveSlot++);
				slotStyle.setFeatureShapeRealizer(FeatureShapeRealizer.CLOCKWISE_ARROW);
				slot = new FeatureSlot(slotStyle, this.labelFont);
			}
			else if (strand == StrandedFeature.NEGATIVE)
			{
				SlotStyle slotStyle = this.dataStyle.createSlotStyle(this.currNegativeSlot--);
				slotStyle.setFeatureShapeRealizer(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW);
				slot = new FeatureSlot(slotStyle, this.labelFont);
			}
			else
				return null;

			slot.setStrand(strand);
			slot.setGlobalShowLabels(globalShowLables);
			slot.setGlobalLabelColor(this.globalLabelColor);
			slot.setLabelLineThickness(labelLineThickness);
			slot.setUseColoredLabelBackgrounds(this.useColoredLabelBackgrounds);

			return slot;
		}

		public SlotStyle createSlotStyle( StrandedFeature.Strand strand )
		{
			SlotStyle slotStyle = null;

			if( strand == StrandedFeature.POSITIVE )
			{
				slotStyle = this.dataStyle.createSlotStyle( this.currPositiveSlot++ );
			}
			else if( strand == StrandedFeature.NEGATIVE )
			{
				slotStyle = this.dataStyle.createSlotStyle( this.currNegativeSlot-- );
			}

			return slotStyle;
		}
	}

	/**
	 * A class used to deal with CGView feature slots.
	 * 
	 * @author Aaron Petkau
	 * 
	 */
	private class FeatureSlot
	{
		private SlotStyle slotStyle;


		// private Feature currentFeature;

		private StrandedFeature.Strand strand = StrandedFeature.UNKNOWN;

		private boolean globalShowLabels = false;

		private float labelLineThickness = 0.0f;

		private Font labelFont;
		private Color globalLabelColor;

		private boolean useColoredLabelBackgrounds = false;

		public FeatureSlot(SlotStyle style, Font labelFont)
		{
			// sufficient for a null check
			assert style != null;

			this.slotStyle = style;
			this.labelFont = labelFont;
			CGViewXMLReader.this.annotationHolder = new HashMap<FeatureHolderStyle, Annotation>();
			setShowShading(true);
		}

		public void setUseColoredLabelBackgrounds(
				boolean useColoredLabelBackgrounds)
		{
			this.useColoredLabelBackgrounds  = useColoredLabelBackgrounds;
		}

		public void setGlobalLabelColor(Color globalLabelColor)
		{
			this.globalLabelColor = globalLabelColor;
		}

		public void setLabelLineThickness(float labelLineThickness)
		{
			this.labelLineThickness = labelLineThickness;
		}

		public void setGlobalShowLabels(boolean globalShowLabels)
		{
			this.globalShowLabels = globalShowLabels;
		}

		public void setShowShading(Boolean showShading)
		{
			if (showShading)
			{
//				this.slotStyle.setShapeEffectRenderer(shadedEffect);
				this.slotStyle.setShapeEffectRenderer(normalEffect); // when shading is done correctly, turn above on
			}
			else
			{
				this.slotStyle.setShapeEffectRenderer(normalEffect);
			}
		}

		public void setStrand(StrandedFeature.Strand strand)
		{
			this.strand = strand;
		}

		public void setFeatureThickness(double featureThickness)
		{
			this.slotStyle.setThickness(featureThickness);
		}

		// creates a style which only matches a particular feature
		public FeatureHolderStyle createFeatureHolderStyle(org.biojava.bio.seq.Feature feature)
		{
			return this.slotStyle.createFeatureHolderStyle(new FeatureFilter.ByAnnotation(feature.getAnnotation().keys().iterator().next(), feature.getAnnotation().getProperty( feature.getAnnotation().keys().iterator().next() )));
		}

		public void unionFilters()
		{
			for( SlotItemStyle style : this.slotStyle.getStyles() )
			{
				if( style instanceof FeatureHolderStyle )
				{
					//FeatureHolderStyle fhs = (FeatureHolderStyle) style
				}
			}
		}

		public SlotStyle getStyle()
		{
			return this.slotStyle;
		}

		/**
		 * Creates a feature within this slot.
		 * 
		 * @return The newly created feature.
		 */
		public Feature createFeature()
		{
			StrandedFeature.Template featureTemplate = new StrandedFeature.Template();
			featureTemplate.strand = this.strand;

			Feature feature = new Feature(featureTemplate, this, this.globalShowLabels, this.labelLineThickness);
			feature.setLabelFont(this.labelFont);
			feature.setGlobalLabelColor(this.globalLabelColor);
			feature.setUseColoredLabelBackgrounds(this.useColoredLabelBackgrounds);

			return feature;
		}

		public ShapeEffectRenderer getShapeEffectRenderer()
		{
			return this.slotStyle.getShapeEffectRenderer();
		}
	}

	/**
	 * Used to handle Feature tags in cgview format.
	 * 
	 * @author Aaron Petkau
	 * 
	 */
	private class Feature
	{
		// public static final String COLOR_ID = "color"; // used to id this particular feature by
		// color (to seperate out features).
		// public static final String SLOT_ID = "slot";

		private static final String	FEATURE_FILTER_PROPTERY	= "FeatureFilter";
		private StrandedFeature.Template featureTemplate; // the biojava feature this Feature class defines
		private FeatureSlot enclosingSlot;

		private Color color;
		// decoration
		// font
		// hyperlink
		private String label;
		private String mouseover;
		private double opacity = 1.0;
		private double proportionOfThickness = 1.0; // default of 1
		private double radiusAdjustment = 0.0;

		private Font labelFont = null;

		private boolean showLabel = true;
		private boolean globalShowLabels = false;
		private boolean showShading = true;

		private float labelLineThickness = 0.0f;

		private FeatureShapeRealizer decoration = FeatureShapeRealizer.NO_ARROW;

		private ShapeEffectRenderer shapeEffect;
		private Color globalLabelColor = null;
		private boolean useColoredLabelBackgrounds = false;

		// showlabel
		// showshading

		/**
		 * Creates a new Feature from a featureTemplate within the passed slot.
		 * @param globalShowLabels
		 * @param labelLineThickness
		 */
		public Feature(StrandedFeature.Template featureTemplate, FeatureSlot enclosingSlot, boolean globalShowLabels,
				float labelLineThickness)
		{
			if (featureTemplate == null)
				throw new NullPointerException("featureTemplate is null");
			else if (enclosingSlot == null)
				throw new NullPointerException("enclosingSlot is null");
			else
			{
				this.featureTemplate = featureTemplate;
				this.enclosingSlot = enclosingSlot;

				// set annotations to properly id this feature
				setColor(Color.BLUE);

				// inherits shape effect from parent slot
				// handles shading effects
				this.shapeEffect = enclosingSlot.getShapeEffectRenderer();

				this.labelLineThickness = labelLineThickness;

				this.globalShowLabels = globalShowLabels;


			}
		}

		public void setUseColoredLabelBackgrounds(
				boolean useColoredLabelBackgrounds)
		{
			this.useColoredLabelBackgrounds  = useColoredLabelBackgrounds;
		}

		public void setGlobalLabelColor(Color globalLabelColor)
		{
			this.globalLabelColor = globalLabelColor;
		}

		public void setLabelFont(Font labelFont)
		{
			this.labelFont = labelFont;
		}

		public void setShowShading(Boolean showShading)
		{
			if (showShading)
			{
				this.shapeEffect = shadedEffect;
			}
			else
			{
				this.shapeEffect = normalEffect;
			}
		}

		/**
		 * Sets the docoration (arrow head style) of the feature.
		 * @param decoration  The decoration of the feature.
		 */
		public void setDecoration(FeatureShapeRealizer decoration)
		{
			this.decoration = decoration;
		}

		/**
		 * Sets if we should show a label for this feature or not.
		 * @param showLabel  A boolean value determining if we should show the label of this feature.
		 */
		public void setShowLabel(boolean showLabel)
		{
			this.showLabel = showLabel;
		}

		/**
		 * Sets the label to use for this feature.
		 * 
		 * @param label
		 */
		public void setLabel(String label)
		{
			this.label = label;
		}

		/**
		 * Gets the radius adjustment.
		 * 
		 * @return
		 */
		// public double getRadiusAdjustment()
		// {
		// return radiusAdjustment;
		// }

		public void setRadiusAdjustment(double radiusAdjustment)
		{
			this.radiusAdjustment = radiusAdjustment;
		}

		/**
		 * Sets the color to use for this feature.
		 * 
		 * @param color
		 */
		public void setColor(Color color)
		{
			this.color = color;
			// this.featureTemplate.annotation.setProperty(COLOR_ID, this.color);
		}

		/**
		 * Sets the mouseover text to use.
		 * 
		 * @param mouseover
		 */
		public void setMouseover(String mouseover)
		{
			this.mouseover = mouseover;
		}

		/**
		 * Sets the opacity to use.
		 * 
		 * @param opacity
		 */
		public void setOpacity(double opacity)
		{
			this.opacity = opacity;
		}

		/**
		 * Sets the proportion of thickness to use for features.
		 * 
		 * @param proportionOfThickness
		 */
		public void setProportionOfThickness(double proportionOfThickness)
		{
			this.proportionOfThickness = proportionOfThickness;
		}

		/**
		 * Adds a feature range within this feature.
		 * 
		 * @param range
		 */
		public void addFeatureRange(FeatureRange range)
		{
			if (range == null)
				return;

			Location location = new RangeLocation(range.getStart(), range.getStop());

			// creates new location, or joins to previous location of feature template
			if (this.featureTemplate.location == null)
			{
				this.featureTemplate.location = location;
			}
			else
			{
				this.featureTemplate.location = this.featureTemplate.location.union(location);
			}
		}
		
		private double convertToHeightAdjust(double radiusAdjust, double proportionOfThickness)
		{
			double heightAdjust = 0;
			
			// if proportionOfThickness is not equal to the default, then heightAdjust should apply
			if (this.proportionOfThickness < 1.0)
			{
				heightAdjust = this.radiusAdjustment * 2 - 1; // convert from value in [0,1] to value in [-1,1]
				// at 0, center of feature should be at bottom of slot, at 1 center should be at top
			}
			else // else, feature should be centered (heightAdjust = 0)
			{
				heightAdjust = 0;
			}
			
			return heightAdjust;
		}

		/**
		 * Tells this wrapper class to create the feature within the sequence.
		 */
		public void endFeature()
		{
			// TODO this uses a global variable outside of this class. Is this good?
			if (CGViewXMLReader.this.currentSequence != null)
			{
				try
				{
					org.biojava.bio.seq.Feature feature = CGViewXMLReader.this.currentSequence.createFeature(this.featureTemplate);
					// Remove the location from the featureTemplate and try to match a filter.

					Set<SlotItemStyle> styles = CGViewXMLReader.this.currentFeatureSlot.getStyle().getStyles();

					boolean found = false;

					for( SlotItemStyle style : styles )
					{
						if( style instanceof FeatureHolderStyle )
						{
							FeatureHolderStyle fhs = (FeatureHolderStyle)style;
							//FeatureFilter filter = fhs.getFilter();

							// Check all feature elements, and see if it matches this filter.
							// This is matching even when the fhs hasn't been put into the annotation holder.  What am I missing? Or is stylesMatch bad?
							if( stylesMatch( fhs, this.color, this.proportionOfThickness, (float) this.opacity, convertToHeightAdjust(this.radiusAdjustment, this.proportionOfThickness), this.decoration, this.shapeEffect,
									this.labelFont, this.labelLineThickness ) )
							{
								// Get the Annotation for this FeatureHolderStyle
								Annotation a = CGViewXMLReader.this.annotationHolder.get( fhs );

								Annotation b = feature.getAnnotation();
								if( a != null )
								{
									b.setProperty( FEATURE_FILTER_PROPTERY, a.getProperty( FEATURE_FILTER_PROPTERY ) );
									found = true;
									break; // Break out of the for loop.  We don't need to search any more FeatureHolderStyles
								}
							}
						}
					}

					if( !found )
					{
						// Create new FeatureHolderStyle and new Annotation.
						// Associate the Annotation with the new feature and make the FeatureHolderStyle match on the Annotation.
						// creates a style for each individual feature, and sets correct properties
						Annotation annotation = feature.getAnnotation();
						annotation.setProperty( FEATURE_FILTER_PROPTERY, CGViewXMLReader.this.annotationKey++ );
						FeatureHolderStyle featureStyle = this.enclosingSlot.createFeatureHolderStyle(feature);
						featureStyle.setPaint(this.color);
						featureStyle.setThickness(this.proportionOfThickness);
						featureStyle.setTransparency((float) this.opacity);
						
						featureStyle.setHeightAdjust(
								convertToHeightAdjust(this.radiusAdjustment, this.proportionOfThickness));

						featureStyle.setFeatureShapeRealizer(this.decoration);
						featureStyle.setShapeEffectRenderer(this.shapeEffect);

						LabelStyle labelStyle = featureStyle.getLabelStyle();
						labelStyle.setFont(this.labelFont);
						labelStyle.setLabelExtractor(new StringExtractor(this.label));
						labelStyle.setLineThickness(this.labelLineThickness);

						Color textColor;

						// globalLabelColor overrides color of label
						if (this.globalLabelColor != null)
						{
							textColor = this.globalLabelColor;
						}
						else // else, set label text color the same as the feature color
						{
							textColor = this.color;
						}

						// if useColoredLabelBackgrounds, adjust color of labels
						if (this.useColoredLabelBackgrounds)
						{
							labelStyle.setTextPaint(Color.white);
							labelStyle.setBackgroundPaint(textColor);
							labelStyle.setAutoLabelLinePaint(false);
							labelStyle.setLabelLinePaint(textColor);
						}
						else
						{
							labelStyle.setTextPaint(textColor);
						}

						// globalShowLabels overrides child showLabels
						if (this.globalShowLabels && this.label != null)
						{
							labelStyle.setShowLabels(true);
						}
						else if (this.label != null)
						{
							labelStyle.setShowLabels(this.showLabel);
						}
						else
						{
							labelStyle.setShowLabels(false);
						}


						// TODO handel labels/mouseover properly
						if (this.mouseover != null)
						{
							featureStyle.setToolTipExtractor(new StringExtractor(this.mouseover));
						}

						CGViewXMLReader.this.annotationHolder.put( featureStyle, annotation );
					}
				}
				catch (BioException be)
				{
					be.printStackTrace();
				}
			}
		}

		private boolean stylesMatch( FeatureHolderStyle fhs, Color color2, double proportionOfThickness2, float opacity2, double heightAdjust, FeatureShapeRealizer decoration2, ShapeEffectRenderer shapeEffect2, Font labelFont2, float labelLineThickness2 )
		{
			//TODO: This is a bad way of checking for matching styles.  Better option would be to create a hash function and see if hte
			// hashes match.
			boolean stylesMatch = true;

			if (!(fhs.getPaint() == null && color2 == null))
			{
				if (fhs.getPaint() == null)
				{
					stylesMatch = false;
				}
				else if (fhs.getPaint()[0] == null)
				{
					stylesMatch = false;
				}
				else if( !fhs.getPaint()[0].equals( color2 ) )
				{
					stylesMatch = false;
				}
			}
			
			if( fhs.getThickness() != proportionOfThickness2 )
			{
				stylesMatch = false;
			}
			
			if( fhs.getTransparency() != opacity2 )
			{
				stylesMatch = false;
			}
			
			if( fhs.getHeightAdjust() != heightAdjust )
			{
				stylesMatch = false;
			}
			
			if (!(fhs.getFeatureShapeRealizer() == null && decoration2 == null))
			{
				if( fhs.getFeatureShapeRealizer() == null )
				{
					stylesMatch = false;
				}
				else if( ! fhs.getFeatureShapeRealizer().equals( decoration2 ) )
				{
					stylesMatch = false;
				}
			}
			
			if ( !(fhs.getShapeEffectRenderer() == null && shapeEffect2 == null))
			{
				if( fhs.getShapeEffectRenderer() == null )
				{
					stylesMatch = false;
				}
				else if( ! fhs.getShapeEffectRenderer().equals( shapeEffect2 ) )
				{
					stylesMatch = false;
				}
			}
			
			if( fhs.getLabelStyle() == null )
			{
				stylesMatch = false;
			}
			else
			{
				if (!(fhs.getLabelStyle().getFont() == null && labelFont2 == null))
				{
					if( fhs.getLabelStyle().getFont() == null )
					{
						stylesMatch = false;
					}
					else if( ! fhs.getLabelStyle().getFont().equals( labelFont2 ) )
					{
						stylesMatch = false;
					}
				}

				if( fhs.getLabelStyle().getLineThickness() != labelLineThickness2 )
				{
					stylesMatch = false;
				}
			}

			return stylesMatch;
		}
	}

	/**
	 * A class used to handle FeatureRange tags in cgview format.
	 * 
	 * @author Aaron Petkau
	 * 
	 */
	private static class FeatureRange
	{
		private int start;
		private int stop;

		public int getStart()
		{
			return this.start;
		}

		public void setStart(int start)
		{
			this.start = start;
		}

		public int getStop()
		{
			return this.stop;
		}

		public void setStop(int stop)
		{
			this.stop = stop;
		}
	}
	
	private class Plot
	{
		private PlotStyle currPlotStyle = null;
		private PlotBuilderRange pbr = null;
		
		private Color posColor = null;
		private Color negColor = null;
		
		public Plot()
		{
			currPlotStyle = new PlotStyle();
			pbr = new PlotBuilderRange();
			
			currPlotStyle.setPlotBuilder(pbr);
		}
		
		public SlotItemStyle getPlotStyle()
		{
			return currPlotStyle;
		}

		/**
		 * 
		 * @param start
		 * @param stop
		 * @param radiusAdjustement Should be between 0 and 1
		 * @param color
		 */
		public void addRange(int start, int stop, double radiusAdjustement, Color color)
		{
			double thickness = -1.0 + 2.0*radiusAdjustement;
			
			if (thickness >= 0 && posColor == null) // positive
			{
				posColor = color;
			}
			else if (thickness < 0 && negColor == null)
			{
				negColor = color;
			}
			
			pbr.addRange(start, stop, thickness);
		}
		
		public void endPlot()
		{
			if (posColor == null)
			{
				posColor = Color.black;
			}
			else if (negColor == null)
			{
				negColor = Color.black;
			}
			
			currPlotStyle.setPaint(posColor);
			currPlotStyle.addPaint(negColor);
		}
	}
	
	private class Legend
	{
		private Paint fontColor = Color.black;
		private Paint backgroundColor;
		private LegendAlignment position = LegendAlignment.UPPER_RIGHT;
		private Font font = new Font("SansSerif", Font.PLAIN, 8);
		
		private List<LegendItem> legendItems;
	
		public Legend(Paint color)
		{
			this.backgroundColor = color;
			
			legendItems = new LinkedList<LegendItem>();
		}

		public LegendItem createLegendItem(String label)
		{
			LegendItem legendItem = new LegendItem(label);
			
			legendItem.setFontColor(fontColor);
			legendItem.setFont(font);
			
			legendItems.add(legendItem);
			
			return legendItem;
		}

		public void setFontColor(Paint color)
		{
			this.fontColor = color;
		}

		public void setBackgroundColor(Paint color)
		{
			this.backgroundColor = color;
		}

		public void setPosition(LegendAlignment position)
		{
			this.position = position;
		}

		public void setFont(Font font)
		{
			this.font = font;
		}	
		
		public void endLegend()
		{
			GlobalStyle globalStyle = currentMapStyle.getGlobalStyle();
			
			LegendStyle legendStyle = new LegendStyle();
			legendStyle.setBackgroundPaint(backgroundColor);
			legendStyle.setDefaultFont(font);
			legendStyle.setDefaultFontPaint(fontColor);
			legendStyle.setAlignment(position);
			
			for (LegendItem item : legendItems)
			{
				LegendItemStyle itemStyle = new LegendItemStyle(item.getLabel());
				itemStyle.setTextPaint(item.getFontColor());
				itemStyle.setTextFont(item.getFont());
				
				if (item.isDrawSwatch())
				{
					itemStyle.setSwatchPaint(item.getSwatchColor());
				}
				else
				{
					itemStyle.setSwatchPaint(null);
				}
				
				legendStyle.addLegendItem(itemStyle);
			}
			
			globalStyle.addLegendStyle(legendStyle);
		}
	}
	
	private class LegendItem
	{
		private String label;
		private boolean drawSwatch = false;
		private Paint swatchColor = Color.black;
		private Font font;
		private Paint fontColor;

		public LegendItem(String label)
		{
			this.label = label;
		}

		public boolean isDrawSwatch()
		{
			return drawSwatch;
		}

		public Paint getFontColor()
		{
			return fontColor;
		}

		public Font getFont()
		{
			return font;
		}

		public Paint getSwatchColor()
		{
			return swatchColor;
		}

		public String getLabel()
		{
			return label;
		}

		public void setDrawSwatch(Boolean drawSwatch)
		{
			this.drawSwatch = drawSwatch;
		}

		public void setSwatchColor(Paint color)
		{
			this.swatchColor = color;
		}

		public void setFont(Font font)
		{
			this.font = font;
		}

		public void setFontColor(Paint fontColor)
		{
			this.fontColor = fontColor;
		}
	}

	public boolean canRead(File file)
	{
		String extension = Util.extractExtension(file.getName());

		return extension != null && extension.equals("xml");
	}
}
