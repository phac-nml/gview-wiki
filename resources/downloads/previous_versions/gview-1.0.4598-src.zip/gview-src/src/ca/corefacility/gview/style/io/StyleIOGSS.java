package ca.corefacility.gview.style.io;


import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.io.gss.GeneralStyleConverter;

public class StyleIOGSS extends StyleIO
{
	private GeneralStyleConverter gssConverter;
	
	public StyleIOGSS()
	{
		gssConverter = new GeneralStyleConverter();
	}

	@Override
	public MapStyle readMapStyle(Reader styleReader, String uri)
	{
		return gssConverter.decode(styleReader, uri);
	}
	
	public void readMapStyle(MapStyle mapStyle, Reader styleReader, String uri)
	{
		gssConverter.decode(mapStyle, styleReader, uri);
	}

	@Override
	public void writeMapStyle(MapStyle mapStyle, Writer styleWriter) throws IOException
	{
		gssConverter.encode(mapStyle, styleWriter);
	}
}
