package ca.corefacility.gview.style.io.gss;


import org.w3c.css.sac.LexicalUnit;

import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;

public class BooleanHandler
{	
	public static String encode(boolean value)
	{
		return value ? "\"true\"" : "\"false\"";
	}
	
	public static Boolean decode(LexicalUnit value)
	{
		Boolean boolValue = null;
		
		if (value.getLexicalUnitType() == LexicalUnit.SAC_STRING_VALUE)
		{
			String stringValue = value.getStringValue();
			
			if (stringValue != null)
			{
				if (stringValue.equals("true"))
				{
					boolValue = true;
				}
				else if (stringValue.equals("false"))
				{
					boolValue = false;
				}
				else
				{
					// throw exception
				}
			}
			else
			{
				// throw exception
			}
		}
		else
		{
			// throw exception
		}

		return boolValue;
	}
}
