package ca.corefacility.gview.map;


import org.biojava.bio.seq.Sequence;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataImp;
import ca.corefacility.gview.layout.sequence.LayoutFactory;
import ca.corefacility.gview.style.MapStyle;

/**
 * Responsible for creating a new gViewMap with the appropriate info.
 */
public class GViewMapFactory
{
	/**
	 * Creates and sets up a new gViewMap from the passed data.
	 * 
	 * @param genomeData  The data defining the genome.
	 * @param style  The style defining how the data should be displayed.
	 * @param layoutFactory  An objected used to construct the layout of the GView map.
	 * 
	 * @return The newly created GView map.
	 */
	public static GViewMap createMap(GenomeData genomeData, MapStyle style, LayoutFactory layoutFactory)
	{
		GViewMap gViewMap = new GViewMapImp(genomeData, style, layoutFactory);

		return gViewMap;
	}

	/**
	 * Creates and sets up a new GView map from the passed sequence data.
	 * @param sequence  The sequence data to create the map around.
	 * @param style  The style information to build the map with.
	 * @param layoutFactory  The LayoutFactory used to construct the layout of the GView map.
	 * @return  The newly created gview map.
	 */
	public static GViewMap createMap(Sequence sequence, MapStyle style, LayoutFactory layoutFactory)
	{
		GenomeData gData = new GenomeDataImp(sequence);
		return createMap(gData, style, layoutFactory);
	}
}
