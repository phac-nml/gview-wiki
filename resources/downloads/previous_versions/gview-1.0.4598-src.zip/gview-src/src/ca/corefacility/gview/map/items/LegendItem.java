package ca.corefacility.gview.map.items;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Paint;
import java.awt.geom.Dimension2D;
import java.awt.geom.Rectangle2D;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import ca.corefacility.gview.managers.LegendAlignment;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.map.effects.StandardEffect;
import ca.corefacility.gview.style.items.LegendItemStyle;
import ca.corefacility.gview.style.items.LegendStyle;

import edu.umd.cs.piccolo.PLayer;
import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.nodes.PText;
import edu.umd.cs.piccolo.util.PBounds;

public class LegendItem extends Layer
{
	private LegendAlignment alignment;
	private boolean legendDisplayed;
	
	private LegendItem()
	{}
    
    public void alignLegend(Rectangle2D displayBounds)
    {
    	if (legendDisplayed)
    	{
			Rectangle2D legendBounds = getFullBounds();
			
			double newLeftX =  0;
			double newLeftY =  0;
			
			switch (alignment)
			{
				case UPPER_LEFT:
					newLeftX = 0;
					newLeftY = 0;
				break;
				
				case UPPER_CENTER:
					newLeftX = (displayBounds.getWidth() - legendBounds.getWidth())/2;
					newLeftY = 0;
				break;
				
				case UPPER_RIGHT:
					newLeftX =  displayBounds.getWidth() - legendBounds.getWidth();
					newLeftY =  0;
				break;
				
				case MIDDLE_LEFT:
					newLeftX = 0;
					newLeftY = (displayBounds.getHeight() - legendBounds.getHeight())/2;
				break;
				
				case MIDDLE_CENTER:
					newLeftX = (displayBounds.getWidth() - legendBounds.getWidth())/2;
					newLeftY = (displayBounds.getHeight() - legendBounds.getHeight())/2;
				break;
				
				case MIDDLE_RIGHT:
					newLeftX =  displayBounds.getWidth() - legendBounds.getWidth();
					newLeftY =  (displayBounds.getHeight() - legendBounds.getHeight())/2;
				break;
				
				case LOWER_LEFT:
					newLeftX =  0;
					newLeftY =  displayBounds.getHeight() - legendBounds.getHeight();
				break;
				
				case LOWER_CENTER:
					newLeftX =  (displayBounds.getWidth() - legendBounds.getWidth())/2;
					newLeftY =  displayBounds.getHeight() - legendBounds.getHeight();
				break;
				
				case LOWER_RIGHT:
					newLeftX =  displayBounds.getWidth() - legendBounds.getWidth();
					newLeftY =  displayBounds.getHeight() - legendBounds.getHeight();
				break;
			}
			
			this.setOffset(newLeftX, newLeftY);
    	}
    }
    
	/**
	 * Builds up a list of LegendItems from the appropriate data needing a legend.
	 * @param dataStyle
	 * @return  A list of LegendItems.
	 */
	private static List<LegendEntryItem> generateLegendItems(LegendStyle legendStyle)
	{
		List<LegendEntryItem> legendItems = new LinkedList<LegendEntryItem>();
		
		Iterator<LegendItemStyle> legendStylesIter = legendStyle.legendItems();
		while (legendStylesIter.hasNext())
		{
			LegendItemStyle itemStyle = legendStylesIter.next();
			
			String legendText = itemStyle.getText();
			Paint legendPaint = itemStyle.getSwatchPaint();
			Font legendFont = (itemStyle.getTextFont() != null) ? itemStyle.getTextFont() : legendStyle.getDefaultFont();
			Paint legendTextPaint = (itemStyle.getTextPaint() != null) ? itemStyle.getTextPaint() : legendStyle.getDefaultFontPaint();
			
			LegendEntryItem legendItem = new LegendEntryItem(legendText, legendFont, legendTextPaint, legendPaint);
			
			legendItems.add(legendItem);
		}
		
		return legendItems;
	}
    
	private static BasicItem buildLegend(LegendStyle lStyle, List<LegendEntryItem> legendItems)
	{	
		BasicItem mainLegendArea = new BasicItem();		
		float legendBorderSpacing = 5;
		
		// only display legend if there are items to display
		if (legendItems.size() > 0)
		{	
			mainLegendArea.setPaint(lStyle.getBackgroundPaint());
			
			// handles outline for legend area
			if (lStyle.getOutlinePaint() != null)
			{
				ShapeEffectRenderer outlineRenderer = new StandardEffect(lStyle.getOutlinePaint(), new BasicStroke());
				mainLegendArea.setShapeEffectRenderer(outlineRenderer);
			}
			
			float currOffsetY = legendBorderSpacing;		
			for (LegendEntryItem item : legendItems)
			{
				mainLegendArea.add(item);
				item.offset(legendBorderSpacing, currOffsetY);
				
				float trueLegendItemSpacing = (float)item.getFullBounds().getHeight()/2;
				
				currOffsetY += item.getFullBounds().getHeight() + trueLegendItemSpacing;
			}
			
			PBounds bounds = mainLegendArea.getFullBounds();
			
			// add in legendBoxPadding to account for padding at bottom of the box
			// multiply by 2 since there are two sides to add the padding to
			mainLegendArea.setShape(new Rectangle2D.Float(0,0, (float)bounds.getWidth() + 2*legendBorderSpacing
					, (float)bounds.getHeight() + 2*legendBorderSpacing));
		}
		
		return mainLegendArea;
	}
	
    public static LegendItem buildLegend(LegendStyle lStyle)
    {   	
    	LegendItem legendItem = new LegendItem();
    	
		legendItem.alignment = lStyle.getAlignment();
		legendItem.legendDisplayed = lStyle.isDisplayLegend();
		
		List<LegendEntryItem> legendItems = generateLegendItems(lStyle);
		BasicItem legendArea = buildLegend(lStyle, legendItems);
		legendItem.add(legendArea);
		
		
		return legendItem;
    }
}
