package ca.corefacility.gview.map.effects;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;

public class ShadowEffect extends AbstractAllEffectRenderer
{
	private Paint shadowPaint = new Color(0,0,0,100);
	private AffineTransform offset = new AffineTransform();
	
	public ShadowEffect()
	{
		offset.setToTranslation(5, 5);
	}
	
	private void paintShadow(Shape shape, Graphics2D g)
	{
		AffineTransform old = g.getTransform();
		g.transform(offset);
		
		g.setPaint(shadowPaint);
		g.fill(shape);
		
		g.setTransform(old);
	}
	
	protected void paintNormal(Shape shape, Graphics2D g, Paint paint)
	{
		paintShadow(shape, g);
		
		g.setPaint(paint);
		g.fill(shape);
	}

	protected void paintSelected(Shape shape, Graphics2D g, Paint paint)
	{
		paintShadow(shape, g);
		
		g.setPaint(Color.YELLOW);
		g.fill(shape);
	}
	
	protected void paintMouseOver(Shape shape, Graphics2D g, Paint paint)
	{
		paintShadow(shape, g);
		
		g.setPaint(Color.GREEN);
		g.fill(shape);
	}
	
	protected void paintMouseOverSelected(Shape shape, Graphics2D g, Paint paint)
	{
		paintShadow(shape, g);
		
		g.setPaint(Color.GREEN);
		g.fill(shape);
	}
}
