package ca.corefacility.gview.map.effects;


import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;

import ca.corefacility.gview.map.items.MapItemState;

public class StandardEffectSelect implements ShapeEffectRenderer
{
	public void paint(Shape shape, Graphics2D g, Paint paint, MapItemState state)
	{
		if (state.isSelected())
		{
			g.setPaint(paint);
			g.fill(shape);
			
			g.setPaint(Color.YELLOW);
			g.draw(shape);
		}
		else
		{
			g.setPaint(paint);
			g.fill(shape);
		}
	}

	public boolean paintChanged(MapItemState previousState,
			MapItemState nextState)
	{
		return (previousState.isSelected() && !nextState.isSelected()) || (!previousState.isSelected() && nextState.isSelected());
	}
}
