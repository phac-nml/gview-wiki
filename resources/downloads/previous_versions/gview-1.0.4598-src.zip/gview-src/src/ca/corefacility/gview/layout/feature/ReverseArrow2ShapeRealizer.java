package ca.corefacility.gview.layout.feature;

import ca.corefacility.gview.layout.Direction;
import ca.corefacility.gview.layout.prototype.BackboneShape;
import ca.corefacility.gview.layout.sequence.SlotPath;

/**
 * FeatureShapeRealizer used to draw an arrow which looks like
 * 
 * <---
 * 
 * @author Aaron Petkau
 *
 */
public class ReverseArrow2ShapeRealizer extends AbstractArrowShapeRealizer
{
	private final double HEIGHT_DECREASE;

	/**
	 * Constructs a ForwardArrow2ShapeRealizer to draw alternate arrow shapes with the passed arrow length and height decrease.
	 * @param arrowLength  The length of the arrow part to use.
	 * @param heightDecrease  A proportion of thickness of the straight part and arrow head part of the arrow (1.0 is no decrease).
	 * 							So controls difference between
	 * 							this (<---) and
	 * 							this(<==)
	 */
	public ReverseArrow2ShapeRealizer(double arrowLength, double heightDecrease)
	{
		super(arrowLength);
		HEIGHT_DECREASE = heightDecrease;
	}
	
	/**
	 * Constructs a ForwardArrow2ShapeRealizer to draw arrow shapes with the default settings
	 */
	public ReverseArrow2ShapeRealizer()
	{
		this(10, 0.7);
	}
	
	protected BackboneShape createArrowBlock(SlotPath path, int start,
			int stop, double top, double bottom)
	{
		double center = ((double)top + bottom)/2;
		
		path.moveTo(start, center);
		path.realLineTo(start, top, ARROW_LENGTH);
		path.realLineTo(start, top*HEIGHT_DECREASE, ARROW_LENGTH);
		path.lineTo(stop, Direction.INCREASING);
		path.lineTo(stop, bottom*HEIGHT_DECREASE, Direction.NONE);
		path.lineTo(start, bottom*HEIGHT_DECREASE, ARROW_LENGTH, Direction.DECREASING);
		path.realLineTo(start, bottom, ARROW_LENGTH);
		path.realLineTo(start, center, 0);
		path.closePath();
		
		return path.getShape();
	}
	
	protected BackboneShape createArrowHead(SlotPath path, int start, int stop, double top, double bottom)
	{
		double centerBase = ((double)start + stop)/2;
		
		double centerHeight = ((double)top + bottom)/2;
		
		path.moveTo(centerBase, centerHeight, -ARROW_LENGTH/2);
		path.realLineTo(centerBase, top, ARROW_LENGTH/2);
		path.realLineTo(centerBase, bottom, ARROW_LENGTH/2);
		path.realLineTo(centerBase, centerHeight, -ARROW_LENGTH/2);
		path.closePath();
		
		return path.getShape();
	}
}
