package ca.corefacility.gview.layout.sequence.circular;

import ca.corefacility.gview.layout.Direction;
import ca.corefacility.gview.layout.prototype.NonFragmentingStretchableShape;
import ca.corefacility.gview.layout.prototype.SequenceOffset;
import ca.corefacility.gview.layout.prototype.SequencePoint;
import ca.corefacility.gview.layout.prototype.SequencePointImp;
import ca.corefacility.gview.layout.prototype.segments.CircularArcSegment;
import ca.corefacility.gview.layout.prototype.segments.CloseSegment;
import ca.corefacility.gview.layout.prototype.segments.LineSegment;
import ca.corefacility.gview.layout.sequence.AbstractSequencePath;
import ca.corefacility.gview.layout.sequence.Backbone;

public class SequencePathCircular extends AbstractSequencePath
{
	// used to flip some arcs so that the start/end points are in the correct position
	//private final static AffineTransform MIRROR_Y = new AffineTransform(1,0,0,-1,0,0);
	
	public SequencePathCircular(Backbone backbone)
	{
		super(backbone);
		
		shape = new NonFragmentingStretchableShape(backbone);
	}
	
	public void closePath()
	{
		// TODO incorporate closing circular curves
		// 	also handle setting previous point
		shape.appendSegment(new CloseSegment());
		
		prevSequencePoint = new SequencePointImp();
	}

	public void lineTo(double base, double heightFromBackbone, Direction direction)
	{
		SequencePoint movePoint = new SequencePointImp(base, heightFromBackbone);
		
		shape.appendSegment(new LineSegment(movePoint));
		
		prevSequencePoint = movePoint;
	}
	
	public void lineTo(double base, Direction direction)
	{
		// this method more efficiently draws the curve, since we know it should be a circle
		// assumed that (0,0) is the centre of the circular backbone
		
		double heightFromBackbone = prevSequencePoint.getHeightFromBackbone();
		
		SequencePoint startPoint = (SequencePoint)prevSequencePoint.clone();
		SequencePoint endPoint = new SequencePointImp(base, heightFromBackbone);
		
		shape.appendSegment(new CircularArcSegment(startPoint, endPoint, direction));
		
		prevSequencePoint = endPoint;
	}
	
	public void lineTo(double base, double heightFromBackbone, double lengthFromBase, Direction direction)
	{
		SequencePoint startPoint = (SequencePoint)prevSequencePoint.clone();
		SequencePoint endPoint;
		
		endPoint = new SequenceOffset(base, heightFromBackbone, lengthFromBase);
		
		shape.appendSegment(new CircularArcSegment(startPoint, endPoint, direction));
		
		prevSequencePoint = endPoint;
	}
	
	public void clear()
	{
		super.clear();
		shape = new NonFragmentingStretchableShape(backbone);
	}
}
