package ca.corefacility.gview.map.items;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Paint;
import java.awt.geom.Dimension2D;
import java.awt.geom.Rectangle2D;

import edu.umd.cs.piccolo.PNode;
import edu.umd.cs.piccolo.nodes.PPath;
import edu.umd.cs.piccolo.nodes.PText;

public class LegendEntryItem extends Layer
{
    public LegendEntryItem(String legendText, Font textFont, Paint fontPaint, Paint swatchPaint)
    {
    	PText legendTextNode = new PText(legendText);
    	legendTextNode.setFont(textFont);
    	legendTextNode.setTextPaint(fontPaint);
    	addChild(legendTextNode);
    	
    	Rectangle2D bounds = legendTextNode.getFullBounds();
    	float swatchHeight = (float)bounds.getHeight();
    	float swatchWidth = swatchHeight;
    	float swatchTextSpacing = swatchWidth/2;
    	
    	if (swatchPaint != null)
    	{
    		
	    	PPath swatch = PPath.createRectangle(0, 0, swatchWidth, swatchHeight);
	    	
	    	swatch.setPaint(swatchPaint);
	    	swatch.setStrokePaint(null);
	    	swatch.setStroke(null);
	    	addChild(swatch);
	    	
	    	float legendTextHeight = (float)legendTextNode.getFullBounds().getHeight();
	    	float swatchBoxHeight = (float)swatch.getFullBounds().getHeight();
	    	
	    	if (legendTextHeight < swatchBoxHeight)
	    	{
		    	// offset center of text to center of legend item
		    	float newCenterY = (float)getFullBounds().getHeight()/2;
		    	float currCenterY = legendTextHeight/2;
		    	
		    	legendTextNode.offset(0, newCenterY-currCenterY);
	    	}
	    	else
	    	{
		    	// offset center of swatch to center legend item
		    	float newCenterY = (float)getFullBounds().getHeight()/2;
		    	float currCenterY = swatchBoxHeight/2;
	
		    	swatch.offset(0, (newCenterY-currCenterY));
	    	}
	    	
	    	legendTextNode.offset(swatchWidth+swatchTextSpacing, 0);
    	}
    }
}
