package ca.corefacility.gview.managers;

import java.awt.geom.AffineTransform;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import ca.corefacility.gview.map.event.DisplayUpdated;
import ca.corefacility.gview.map.event.GViewEvent;
import ca.corefacility.gview.map.event.GViewEventListener;
import ca.corefacility.gview.map.items.Layer;
import ca.corefacility.gview.map.items.LegendItem;
import ca.corefacility.gview.map.items.MapComponent;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.items.LegendStyle;


public class LegendManager implements GViewEventListener
{
	private MapComponent legendLayer;
	private boolean legendDisplayed = false;
	
	private List<LegendItem> legends;
	
	// used so, if we turn legends on, we can send the DisplayUpdated event
	private DisplayUpdated previousDisplayUpdatedEvent = null;

	public LegendManager(MapStyle mapStyle)
	{
		legendLayer = new Layer();

		legends = new LinkedList<LegendItem>();

		Iterator<LegendStyle> lStyles = mapStyle.getGlobalStyle().legendStyles();

		while (lStyles.hasNext())
		{
			LegendStyle currLegendStyle = lStyles.next();

			if (currLegendStyle.isDisplayLegend())
			{
				LegendItem currLegend = LegendItem.buildLegend(currLegendStyle);

				legendLayer.add(currLegend);
				legends.add(currLegend);
			}
		}
	}

	public MapComponent getLegendLayer()
	{
		return legendLayer;
	}
	
	public void setLegendDisplayed(boolean display)
	{
		this.legendDisplayed = display;
		
		if (display)
		{
			eventOccured(previousDisplayUpdatedEvent);
		}
	}

	@Override
	public void eventOccured(GViewEvent event)
	{
		if (event instanceof DisplayUpdated)
		{
			DisplayUpdated displayUpdatedEvent = (DisplayUpdated) event;
			
			if (displayUpdatedEvent.isDisplayBoundsChanged())
			{
				previousDisplayUpdatedEvent = displayUpdatedEvent;
				
				if (legendDisplayed)
				{
					for (LegendItem legend : legends)
					{
						legend.alignLegend(displayUpdatedEvent.getCameraBounds());
					}
				}
			}
		}
	}

	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + (legendDisplayed ? 1231 : 1237);
		result = prime * result
				+ ((legendLayer == null) ? 0 : legendLayer.hashCode());
		result = prime * result + ((legends == null) ? 0 : legends.hashCode());
		result = prime
				* result
				+ ((previousDisplayUpdatedEvent == null) ? 0
						: previousDisplayUpdatedEvent.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LegendManager other = (LegendManager) obj;
		if (legendDisplayed != other.legendDisplayed)
			return false;
		if (legendLayer == null)
		{
			if (other.legendLayer != null)
				return false;
		} else if (!legendLayer.equals(other.legendLayer))
			return false;
		if (legends == null)
		{
			if (other.legends != null)
				return false;
		} else if (!legends.equals(other.legends))
			return false;
		if (previousDisplayUpdatedEvent == null)
		{
			if (other.previousDisplayUpdatedEvent != null)
				return false;
		} else if (!previousDisplayUpdatedEvent
				.equals(other.previousDisplayUpdatedEvent))
			return false;
		return true;
	}
}
