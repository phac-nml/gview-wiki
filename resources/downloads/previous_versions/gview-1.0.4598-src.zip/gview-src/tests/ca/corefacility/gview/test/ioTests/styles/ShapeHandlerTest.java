package ca.corefacility.gview.test.ioTests.styles;


import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.layout.feature.FeatureShapeRealizer;
import ca.corefacility.gview.style.io.gss.FontHandler;
import ca.corefacility.gview.style.io.gss.ShapeHandler;
import ca.corefacility.gview.style.io.gss.FontHandler.MalformedFontStringException;
import ca.corefacility.gview.style.io.gss.exceptions.UnknownFunctionException;

public class ShapeHandlerTest
{
	private Parser parser;
	
	@Before
	public void setup()
	{
		 parser = new com.steadystate.css.parser.SACParserCSS2();
	}
	
	@Test
	public void encodeTests()
	{
	}
	
	@Test
	public void decodeTest() throws CSSException, IOException, UnknownFunctionException, MalformedFontStringException
	{
		InputSource currEncodedString;
		LexicalUnit currUnit;
				
		currEncodedString = new InputSource(new StringReader("shape(\"clockwise-arrow\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(FeatureShapeRealizer.CLOCKWISE_ARROW, ShapeHandler.decodeShape(currUnit));
		
		currEncodedString = new InputSource(new StringReader("shape(\"counterclockwise-arrow\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(FeatureShapeRealizer.COUNTERCLOCKWISE_ARROW, ShapeHandler.decodeShape(currUnit));
		
		currEncodedString = new InputSource(new StringReader("shape(\"block\")"));
		currUnit = parser.parsePropertyValue(currEncodedString);
		Assert.assertEquals(FeatureShapeRealizer.NO_ARROW, ShapeHandler.decodeShape(currUnit));
	}
}
