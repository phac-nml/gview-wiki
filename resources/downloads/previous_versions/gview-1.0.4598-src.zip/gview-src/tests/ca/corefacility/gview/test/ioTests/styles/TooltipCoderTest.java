package ca.corefacility.gview.test.ioTests.styles;


import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;
import org.w3c.css.sac.Selector;

import ca.corefacility.gview.map.effects.OutlineEffect;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.io.gss.FontHandler;
import ca.corefacility.gview.style.io.gss.PaintHandler;
import ca.corefacility.gview.style.io.gss.ShapeEffectHandler;
import ca.corefacility.gview.style.io.gss.PaintHandler.UnknownPaintException;
import ca.corefacility.gview.style.io.gss.coders.BackboneCoder;
import ca.corefacility.gview.style.io.gss.coders.GSSWriter;
import ca.corefacility.gview.style.io.gss.coders.TooltipCoder;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedDeclarationException;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedSelectorException;
import ca.corefacility.gview.style.io.gss.exceptions.NoStyleExistsException;
import ca.corefacility.gview.style.io.gss.exceptions.NoSuchFilterException;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.style.items.BackboneStyle;
import ca.corefacility.gview.style.items.TooltipStyle;

import com.steadystate.css.parser.selectors.ElementSelectorImpl;

public class TooltipCoderTest
{
	private TooltipCoder coder;
	
	@Before
	public void setup()
	{
		coder = new TooltipCoder();
	}
	
	@Test
	public void testDecode() throws ParseException
	{
		MapStyle map1;
		
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		TooltipStyle workingStyle;
		LexicalUnit currUnit;
		
		TooltipStyle expectedStyle;

		// setup encoding
		Selector selector;
		
		try
		{
			map1 = new MapStyle();
			workingStyle = map1.getGlobalStyle().getTooltipStyle();
			
			selector = new ElementSelectorImpl("tooltip");
			
			//setup parameters
			currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
			
			// setup expected style
			expectedStyle = new TooltipStyle(workingStyle);
			expectedStyle.setOutlinePaint(Color.red);
			
			coder.decodeProperty(selector, map1, null, "outline-color", currUnit, null);
			
			Assert.assertEquals(expectedStyle, workingStyle);
			
			//setup parameters
			currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"blue\")")));
			
			// setup expected style
			expectedStyle = new TooltipStyle(workingStyle);
			expectedStyle.setBackgroundPaint(Color.blue);
			
			coder.decodeProperty(selector, map1, null, "background-color", currUnit, null);
			
			Assert.assertEquals(expectedStyle, workingStyle);
			
			//setup parameters
			currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"green\")")));
			
			// setup expected style
			expectedStyle = new TooltipStyle(workingStyle);
			expectedStyle.setTextPaint(new Color(0, 128, 0));
			
			coder.decodeProperty(selector, map1, null, "text-color", currUnit, null);
			
			Assert.assertEquals(expectedStyle, workingStyle);
			
			//setup parameters
			currUnit = parser.parsePropertyValue(new InputSource(new StringReader("font(\"SansSerif\", \"plain\", 21)")));
			
			// setup expected style
			expectedStyle = new TooltipStyle(workingStyle);
			expectedStyle.setFont(new Font("SansSerif", Font.PLAIN, 21));
			
			coder.decodeProperty(selector, map1, null, "font", currUnit, null);
			
			Assert.assertEquals(expectedStyle, workingStyle);
		}
		catch (CSSException e)
		{
			Assert.fail();
		}
		catch (IOException e)
		{
			Assert.fail();
		}
		
		
		try
		{
			map1 = new MapStyle();
			workingStyle = map1.getGlobalStyle().getTooltipStyle();
			
			selector = new ElementSelectorImpl("tooltip");
			
			//setup parameters
			currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"blue\")")));
			
			// setup expected style
			expectedStyle = new TooltipStyle(workingStyle);
			expectedStyle.setOutlinePaint(Color.blue);
			
			coder.decodeProperty(selector, map1, null, "outline-color", currUnit, null);
			
			Assert.assertEquals(expectedStyle, workingStyle);
			
			//setup parameters
			currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"green\")")));
			
			// setup expected style
			expectedStyle = new TooltipStyle(workingStyle);
			expectedStyle.setBackgroundPaint(new Color(0, 128, 0));
			
			coder.decodeProperty(selector, map1, null, "background-color", currUnit, null);
			
			Assert.assertEquals(expectedStyle, workingStyle);
			
			//setup parameters
			currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
			
			// setup expected style
			expectedStyle = new TooltipStyle(workingStyle);
			expectedStyle.setTextPaint(Color.red);
			
			coder.decodeProperty(selector, map1, null, "text-color", currUnit, null);
			
			Assert.assertEquals(expectedStyle, workingStyle);
			
			//setup parameters
			currUnit = parser.parsePropertyValue(new InputSource(new StringReader("font(\"SansSerif\", \"bold\", 15)")));
			
			// setup expected style
			expectedStyle = new TooltipStyle(workingStyle);
			expectedStyle.setFont(new Font("SansSerif", Font.BOLD, 15));
			
			coder.decodeProperty(selector, map1, null, "font", currUnit, null);
			
			Assert.assertEquals(expectedStyle, workingStyle);
		}
		catch (CSSException e)
		{
			Assert.fail();
		}
		catch (IOException e)
		{
			Assert.fail();
		}
	}
	
	@Test
	public void testEncode()
	{
		try
		{
			MapStyle mapStyle = new MapStyle();
			
			TooltipStyle tooltipStyle = mapStyle.getGlobalStyle().getTooltipStyle();
			String expectedEncoding, actualEncoding;
			
			StringWriter expectedStringWriter;
			GSSWriter expectedGssWriter;
			
			StringWriter actualStringWriter;
			GSSWriter actualEncodingGSS;
			
			expectedStringWriter = new StringWriter();
			expectedGssWriter = new GSSWriter(expectedStringWriter);
			actualStringWriter = new StringWriter();
			actualEncodingGSS = new GSSWriter(actualStringWriter);
			
			// setup expected values
			expectedGssWriter.startSelector("tooltip");
			expectedGssWriter.writeProperty("text-color", PaintHandler.encode(Color.BLUE));
			expectedGssWriter.writeProperty("outline-color", PaintHandler.encode(Color.RED));
			expectedGssWriter.writeProperty("background-color", PaintHandler.encode(Color.GREEN));
			expectedGssWriter.writeProperty("font", FontHandler.encode(new Font("SansSerif", Font.BOLD + Font.ITALIC, 16)));
			expectedGssWriter.endSelector();
			expectedEncoding = expectedStringWriter.toString();
			
			// setup map
			tooltipStyle.setTextPaint(Color.blue);
			tooltipStyle.setOutlinePaint(Color.red);
			tooltipStyle.setBackgroundPaint(Color.green);
			tooltipStyle.setFont(new Font("SansSerif", Font.BOLD + Font.ITALIC, 16));
			
			coder.encodeSelector(mapStyle, null, actualEncodingGSS);
			Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
		}
		catch (UnknownPaintException e)
		{
			Assert.fail();
		}
	}
}
