package ca.corefacility.gview.test.ioTests.styles;


import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringReader;

import org.junit.Assert;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;

import ca.corefacility.gview.layout.PlotBuilder;
import ca.corefacility.gview.layout.PlotBuilderPoints;
import ca.corefacility.gview.style.datastyle.PlotStyle;
import ca.corefacility.gview.style.io.gss.PlotFileHandler;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;

public class PlotFileHandlerTest
{
	@Test
	public void testDecodePoint() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		// write values to file
		PrintWriter writer = new PrintWriter(new FileWriter(dataFile));
		writer.println("0,0.5"); // format base,value
		writer.println("1,0.75");
		writer.println("2,1.0");
		writer.println("3,2.0");
		writer.close();
		
		// setup expected plotbuilder
		PlotBuilderPoints expectedPlotBuilder = new PlotBuilderPoints();
		expectedPlotBuilder.addPoint(0,0.5);
		expectedPlotBuilder.addPoint(1,0.75);
		expectedPlotBuilder.addPoint(2,1.0);
		expectedPlotBuilder.addPoint(3,2.0);
		expectedPlotBuilder.autoScale();
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
				dataFile.getAbsolutePath() + "\")")));
		
		PlotBuilder actualPlotBuilder = PlotFileHandler.decode(new File("."), currUnit);
		
		Assert.assertEquals(expectedPlotBuilder, actualPlotBuilder);
	}
	
	// should not get an exception thrown
	@Test
	public void testAbolutePath() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
				dataFile.getAbsolutePath() + "\")")));
		
		PlotFileHandler.decode(new File("."), currUnit);
	}
	
	// should get an exception thrown as we are attempting to look for the file in the wrong directory
	@Test(expected=FileNotFoundException.class)
	public void testRelativePathWrongDirectory() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		File workingDirectory = new File(".");
		
		// create temp file for data, in default temp directory (not workingDirectory)
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		File dataFileCurrDirectory = new File(workingDirectory, dataFile.getName());
		
		// only run test if file does not exist in current directory
		if (!dataFileCurrDirectory.isFile())
		{
			// check to make sure if we pass the current working directory as the currentDirectory (not the temp directory), then
			//	we won't find the file
			
			File parentDirectory = dataFile.getParentFile();
			if (parentDirectory != null)
			{
				// want to make sure if we just pass the "name" of the file, it will look for the file in the current directory
				currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
						dataFile.getName() + "\")")));
				
				PlotFileHandler.decode(workingDirectory, currUnit);
			}
		}
	}
	
	// should not get an exception thrown
	// test if we list the file as "filename", then it will check for it as a relative path compared to the passed root directory
	@Test
	public void testRelativePath() throws CSSException, IOException, CloneNotSupportedException, ParseException
	{
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		LexicalUnit currUnit;
		
		// create temp file for data
		File dataFile = File.createTempFile("plotData", ".csv");
		dataFile.deleteOnExit();
		
		File parentDirectory = dataFile.getParentFile();
		if (parentDirectory != null)
		{
			currUnit = parser.parsePropertyValue(new InputSource(new StringReader("plot-file(\"point\",\"" +
					dataFile.getName() + "\")")));
			
			PlotFileHandler.decode(parentDirectory, currUnit);
		}
	}
}
