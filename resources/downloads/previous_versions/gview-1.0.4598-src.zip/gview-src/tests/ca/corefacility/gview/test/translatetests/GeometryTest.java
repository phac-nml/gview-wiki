package ca.corefacility.gview.test.translatetests;


import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import junit.framework.Assert;

import org.junit.Test;

import ca.corefacility.gview.layout.sequence.circular.DisplacementSolution;
import ca.corefacility.gview.layout.sequence.circular.Geometry;

public class GeometryTest
{
	private double delta = 0.0000000001;
	
	@Test
	public void testFindClosestOnLine()
	{
		Line2D line;
		Point2D point;
		
		Point2D closestPoint;
		
		line = new Line2D.Double(0, 0, 1, 1);
		
		point = new Point2D.Double(0,0);
		closestPoint = Geometry.findClosestOnLine(line.getX1(), line.getY1(), line.getX2(), line.getY2(), point.getX(), point.getY());
		Assert.assertEquals(0, closestPoint.getX(), delta);
		Assert.assertEquals(0, closestPoint.getY(), delta);
		
		point = new Point2D.Double(1,1);
		closestPoint = Geometry.findClosestOnLine(line.getX1(), line.getY1(), line.getX2(), line.getY2(), point.getX(), point.getY());
		Assert.assertEquals(1, closestPoint.getX(), delta);
		Assert.assertEquals(1, closestPoint.getY(), delta);
		
		point = new Point2D.Double(1,0);
		closestPoint = Geometry.findClosestOnLine(line.getX1(), line.getY1(), line.getX2(), line.getY2(), point.getX(), point.getY());
		Assert.assertEquals(0.5, closestPoint.getX(), delta);
		Assert.assertEquals(0.5, closestPoint.getY(), delta);
		
		point = new Point2D.Double(0,1);
		closestPoint = Geometry.findClosestOnLine(line.getX1(), line.getY1(), line.getX2(), line.getY2(), point.getX(), point.getY());
		Assert.assertEquals(0.5, closestPoint.getX(), delta);
		Assert.assertEquals(0.5, closestPoint.getY(), delta);
		
		point = new Point2D.Double(3,0);
		closestPoint = Geometry.findClosestOnLine(line.getX1(), line.getY1(), line.getX2(), line.getY2(), point.getX(), point.getY());
		Assert.assertEquals(1, closestPoint.getX(), delta);
		Assert.assertEquals(1, closestPoint.getY(), delta);
		
		point = new Point2D.Double(-3,0);
		closestPoint = Geometry.findClosestOnLine(line.getX1(), line.getY1(), line.getX2(), line.getY2(), point.getX(), point.getY());
		Assert.assertEquals(0, closestPoint.getX(), delta);
		Assert.assertEquals(0, closestPoint.getY(), delta);
		
		point = new Point2D.Double(0,3);
		closestPoint = Geometry.findClosestOnLine(line.getX1(), line.getY1(), line.getX2(), line.getY2(), point.getX(), point.getY());
		Assert.assertEquals(1, closestPoint.getX(), delta);
		Assert.assertEquals(1, closestPoint.getY(), delta);
		
		point = new Point2D.Double(0,-3);
		closestPoint = Geometry.findClosestOnLine(line.getX1(), line.getY1(), line.getX2(), line.getY2(), point.getX(), point.getY());
		Assert.assertEquals(0, closestPoint.getX(), delta);
		Assert.assertEquals(0, closestPoint.getY(), delta);
	}
	
	@Test
	public void testFindClosestOnRectangle()
	{
		Rectangle2D rectangle;
		Point2D point;
		
		Point2D closestPoint;
		
		rectangle = new Rectangle2D.Double(0, -10, 20, 10); // rectangle in 1st quadrant 20 units long
		
		// test bottom-left corner
		point = new Point2D.Double(0,0);
		closestPoint = Geometry.findClosestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(0, closestPoint.getX(), delta);
		Assert.assertEquals(0, closestPoint.getY(), delta);
		
		// test top-right corner
		point = new Point2D.Double(20, -10);
		closestPoint = Geometry.findClosestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(20, closestPoint.getX(), delta);
		Assert.assertEquals(-10, closestPoint.getY(), delta);
		
		// test point diagonal from bottom-left
		point = new Point2D.Double(-10, 10);
		closestPoint = Geometry.findClosestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(0, closestPoint.getX(), delta);
		Assert.assertEquals(0, closestPoint.getY(), delta);
		
		// test point under rectangle
		point = new Point2D.Double(15, 10);
		closestPoint = Geometry.findClosestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(15, closestPoint.getX(), delta);
		Assert.assertEquals(0, closestPoint.getY(), delta);
		
		// test point diagonal from bottom-right
		point = new Point2D.Double(30, 10);
		closestPoint = Geometry.findClosestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(20, closestPoint.getX(), delta);
		Assert.assertEquals(0, closestPoint.getY(), delta);
		
		// test point to right of rectangle
		point = new Point2D.Double(30, -5);
		closestPoint = Geometry.findClosestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(20, closestPoint.getX(), delta);
		Assert.assertEquals(-5, closestPoint.getY(), delta);
		
		// test point above rectangle
		point = new Point2D.Double(5, -20);
		closestPoint = Geometry.findClosestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(5, closestPoint.getX(), delta);
		Assert.assertEquals(-10, closestPoint.getY(), delta);
		
		// test point to left of rectangle
		point = new Point2D.Double(-10, -5);
		closestPoint = Geometry.findClosestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(0, closestPoint.getX(), delta);
		Assert.assertEquals(-5, closestPoint.getY(), delta);
	}
	
	@Test
	public void testFindFurthestOnRectangle()
	{
		Rectangle2D rectangle;
		Point2D point;
		
		Point2D closestPoint;
		
		rectangle = new Rectangle2D.Double(0, -10, 20, 10); // rectangle in 1st quadrant 20 units long
		
		// test bottom-left corner
		point = new Point2D.Double(0,0);
		closestPoint = Geometry.findFurthestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(20, closestPoint.getX(), delta);
		Assert.assertEquals(-10, closestPoint.getY(), delta);
		
		// test top-right corner
		point = new Point2D.Double(20, -10);
		closestPoint = Geometry.findFurthestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(0, closestPoint.getX(), delta);
		Assert.assertEquals(0, closestPoint.getY(), delta);
		
		// test point diagonal from bottom-left
		point = new Point2D.Double(-10, 10);
		closestPoint = Geometry.findFurthestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(20, closestPoint.getX(), delta);
		Assert.assertEquals(-10, closestPoint.getY(), delta);
		
		// test point under rectangle
		point = new Point2D.Double(15, 10);
		closestPoint = Geometry.findFurthestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(0, closestPoint.getX(), delta);
		Assert.assertEquals(-10, closestPoint.getY(), delta);
		
		// test point diagonal from bottom-right
		point = new Point2D.Double(30, 10);
		closestPoint = Geometry.findFurthestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(0, closestPoint.getX(), delta);
		Assert.assertEquals(-10, closestPoint.getY(), delta);
		
		// test point to right of rectangle
		point = new Point2D.Double(30, -6);
		closestPoint = Geometry.findFurthestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(0, closestPoint.getX(), delta);
		Assert.assertEquals(0, closestPoint.getY(), delta);
		
		// test point above rectangle
		point = new Point2D.Double(5, -20);
		closestPoint = Geometry.findFurthestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(20, closestPoint.getX(), delta);
		Assert.assertEquals(0, closestPoint.getY(), delta);
		
		// test point to left of rectangle
		point = new Point2D.Double(-10, -6);
		closestPoint = Geometry.findFurthestOnRectangle(rectangle.getX(), rectangle.getY(), rectangle.getWidth(), rectangle.getHeight(), point.getX(), point.getY());
		Assert.assertEquals(20, closestPoint.getX(), delta);
		Assert.assertEquals(0, closestPoint.getY(), delta);
	}
	
	private void assertDisplacementSolutionEquivalent(DisplacementSolution expected, DisplacementSolution actual)
	{
		Assert.assertTrue((expected == null && actual == null) || (expected != null && actual != null));
		
		if (expected != null && actual != null)
		{
			Assert.assertTrue(Math.abs(actual.getSolution1() - expected.getSolution1()) <= delta || Math.abs(actual.getSolution1() - expected.getSolution2()) <= delta);
			
			if (Math.abs(actual.getSolution1() - expected.getSolution1()) <= delta)
			{
				Assert.assertTrue(Math.abs(actual.getSolution2() - expected.getSolution2()) <= delta);
			}
			else if (Math.abs(actual.getSolution1() - expected.getSolution2()) <= delta)
			{
				Assert.assertTrue(Math.abs(actual.getSolution2() - expected.getSolution1()) <= delta);
			}
		}
	}
	
	@Test
	public void findDisplacementToIntersectionTest()
	{
		Point2D point;
		Point2D circleCenter;
		Point2D direction;
		double radius;
		
		DisplacementSolution displacement;
		DisplacementSolution expected;
		
		circleCenter = new Point2D.Double(0,0);
		radius = 50;
		

		point = new Point2D.Double(0,0);
		
		// direction up
		direction = new Point2D.Double(0,-1);
		expected = new DisplacementSolution(50, -50);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// direction down
		direction = new Point2D.Double(0,1);
		expected = new DisplacementSolution(50, -50);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// going left
		direction = new Point2D.Double(-1,0);
		expected = new DisplacementSolution(50, -50);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// going right
		direction = new Point2D.Double(1,0);
		expected = new DisplacementSolution(50, -50);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		
		// point inside circle, not center
		point = new Point2D.Double(1,0);
		
		// going up
		direction = new Point2D.Double(0,-1);
		expected = new DisplacementSolution(Math.sqrt(50*50-1*1), -Math.sqrt(50*50-1*1));
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);

		// going down
		direction = new Point2D.Double(0,1);
		expected = new DisplacementSolution(Math.sqrt(50*50-1*1), -Math.sqrt(50*50-1*1));
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// going left
		direction = new Point2D.Double(-1,0);
		expected = new DisplacementSolution(51, -49);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// going right
		direction = new Point2D.Double(1,0);
		expected = new DisplacementSolution(-51, 49);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		
		// point outside circle
		point = new Point2D.Double(60,0);
		
		// going up
		// only one solution here
		direction = new Point2D.Double(0,-1);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		Assert.assertNull(displacement);
		
		// going down
		direction = new Point2D.Double(0,1);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		Assert.assertNull(displacement);
		
		// going left
		direction = new Point2D.Double(-1,0);
		expected = new DisplacementSolution(110, 10);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// going right
		direction = new Point2D.Double(1,0);
		expected = new DisplacementSolution(-110, -10);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		

		// different center
		circleCenter = new Point2D.Double(10,10);
		
		// center point
		point = new Point2D.Double(10,10);
		
		// direction up
		direction = new Point2D.Double(0,-1);
		expected = new DisplacementSolution(50, -50);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// direction down
		direction = new Point2D.Double(0,1);
		expected = new DisplacementSolution(50, -50);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// going left
		direction = new Point2D.Double(-1,0);
		expected = new DisplacementSolution(50, -50);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// going right
		direction = new Point2D.Double(1,0);
		expected = new DisplacementSolution(50, -50);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		
		// point inside circle, not center
		point = new Point2D.Double(11,10);
		
		// going up
		direction = new Point2D.Double(0,-1);
		expected = new DisplacementSolution(Math.sqrt(50*50-1*1), -Math.sqrt(50*50-1*1));
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// going down
		direction = new Point2D.Double(0,1);
		expected = new DisplacementSolution(Math.sqrt(50*50-1*1), -Math.sqrt(50*50-1*1));
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// going left
		direction = new Point2D.Double(-1,0);
		expected = new DisplacementSolution(51, -49);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// going right
		direction = new Point2D.Double(1,0);
		expected = new DisplacementSolution(49, -51);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		
		// point outside circle
		point = new Point2D.Double(70,10);
		
		// going up
		// only one solution here
		direction = new Point2D.Double(0,-1);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		Assert.assertNull(displacement);
		
		// going down
		direction = new Point2D.Double(0,1);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		Assert.assertNull(displacement);
		
		// going left
		direction = new Point2D.Double(-1,0);
		expected = new DisplacementSolution(10, 110);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
		
		// going right
		direction = new Point2D.Double(1,0);
		expected = new DisplacementSolution(-10, -110);
		displacement = Geometry.findDisplacementToIntersection(point, direction, circleCenter, radius);
		assertDisplacementSolutionEquivalent(expected, displacement);
	}
}
