package ca.corefacility.gview.test.translatetests;


import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.impl.SimpleSequence;
import org.biojava.bio.symbol.Location;
import org.biojava.bio.symbol.RangeLocation;
import org.biojava.bio.symbol.SymbolList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.sequence.LocationConverter;

public class LocationConverterTest
{
	private LocationConverter locationConverter;
	
	@Before
	public void setup()
	{
		SymbolList list = new BlankSymbolList(100);
		Sequence seq = new SimpleSequence(list, null, null, null);
		
		locationConverter = new LocationConverter(GenomeDataFactory.createGenomeData(seq));
	}
	
	@Test
	public void testConvertLocation()
	{
		Location expectedLocation;
		
		Assert.assertNull(locationConverter.convertLocation(null));
	
		expectedLocation = new RangeLocation(0, 100);
		Assert.assertEquals(expectedLocation, locationConverter.convertLocation(Location.full));
		
		expectedLocation = new RangeLocation(0,0);
		Assert.assertEquals(expectedLocation, locationConverter.convertLocation(expectedLocation));
		
		expectedLocation = new RangeLocation(0,50);
		Assert.assertEquals(expectedLocation, locationConverter.convertLocation(expectedLocation));
		
		expectedLocation = new RangeLocation(0,100);
		Assert.assertEquals(expectedLocation, locationConverter.convertLocation(expectedLocation));
		
		expectedLocation = new RangeLocation(100,100);
		Assert.assertEquals(expectedLocation, locationConverter.convertLocation(expectedLocation));
	}
}
