package ca.corefacility.gview.test.translatetests;


import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;

import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.impl.SimpleSequence;
import org.biojava.bio.symbol.SymbolList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.Direction;
import ca.corefacility.gview.layout.prototype.SequencePoint;
import ca.corefacility.gview.layout.prototype.SequencePointImp;
import ca.corefacility.gview.layout.prototype.segments.CircularArcSegment;
import ca.corefacility.gview.layout.sequence.Backbone;
import ca.corefacility.gview.layout.sequence.LocationConverter;
import ca.corefacility.gview.layout.sequence.circular.BackboneCircular;
import ca.corefacility.gview.layout.sequence.circular.Polar;
import ca.corefacility.gview.map.event.ZoomEvent;

public class CircularArcSegmentTest
{
	private Backbone backbone = null;

	private GenomeData data = null;

	private double delta = 0.000000001;

	private double initialRadius = 50;

	private final static int sequenceLength = 100; // must be divisible by 4

	final private AffineTransform MIRROR_Y = new AffineTransform(1, 0, 0, -1, 0, 0);

	@Before
	public void setup()
	{
		SymbolList list = new BlankSymbolList(sequenceLength);
		Sequence seq = new SimpleSequence(list, null, null, null);

		data = GenomeDataFactory.createGenomeData(seq);

		backbone = new BackboneCircular(new LocationConverter(data), initialRadius, 0);
	}

	@Test
	public void testAppendWithScale()
	{
		// test 0 height
		testAppendAtHeight(0.0);

		// test other heights
		for (double height = -25.0; height < 25.0; height += 2.0)
		{
			testAppendAtHeight(height);
		}
	}

	@Test
	public void testPoints()
	{
		SequencePoint startPoint = new SequencePointImp(0, 0);
		SequencePoint endPoint = new SequencePointImp(sequenceLength, 0);

		// double radius;
		// double startAngle;
		// double extentAngle;
		Point2D startPointScaled;
		Point2D endPointScaled;
		Polar polarStart;
		Polar polarEnd;
		double scale = 1;

		// test at scale 1
		startPointScaled = backbone.translate(startPoint);
		Assert.assertNotNull(startPointScaled);

		endPointScaled = backbone.translate(endPoint);
		Assert.assertNotNull(endPointScaled);

		// this is done to account for mirrored y-coords
		startPointScaled.setLocation(startPointScaled.getX(), -startPointScaled.getY());
		endPointScaled.setLocation(endPointScaled.getX(), -endPointScaled.getY());

		polarStart = Polar.createPolar(startPointScaled);
		polarEnd = Polar.createPolar(endPointScaled);
		Assert.assertEquals(polarStart.getRadius(), polarEnd.getRadius(), delta);
		Assert.assertEquals(polarStart.getRadius(), initialRadius * scale, delta);

		// test at lower scale
		scale = 0.01;
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		startPointScaled = backbone.translate(startPoint);
		Assert.assertNotNull(startPointScaled);

		endPointScaled = backbone.translate(endPoint);
		Assert.assertNotNull(endPointScaled);

		// this is done to account for mirrored y-coords
		startPointScaled.setLocation(startPointScaled.getX(), -startPointScaled.getY());
		endPointScaled.setLocation(endPointScaled.getX(), -endPointScaled.getY());

		polarStart = Polar.createPolar(startPointScaled);
		polarEnd = Polar.createPolar(endPointScaled);
		Assert.assertEquals(polarStart.getRadius(), polarEnd.getRadius(), delta);
		Assert.assertEquals(polarStart.getRadius(), initialRadius * scale, delta);

		// test at higher scale
		scale = backbone.getMaxScale();
		backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));
		startPointScaled = backbone.translate(startPoint);
		Assert.assertNotNull(startPointScaled);

		endPointScaled = backbone.translate(endPoint);
		Assert.assertNotNull(endPointScaled);

		// this is done to account for mirrored y-coords
		startPointScaled.setLocation(startPointScaled.getX(), -startPointScaled.getY());
		endPointScaled.setLocation(endPointScaled.getX(), -endPointScaled.getY());

		polarStart = Polar.createPolar(startPointScaled);
		polarEnd = Polar.createPolar(endPointScaled);
		Assert.assertEquals(polarStart.getRadius(), polarEnd.getRadius(), delta);
		Assert.assertEquals(polarStart.getRadius(), initialRadius * scale, delta);
	}

	@SuppressWarnings("unused")
	private void testAppendAtHeight(double height)
	{

		CircularArcSegment fullSegment;
		CircularArcSegment quarter1;
		CircularArcSegment quarter2;
		CircularArcSegment quarter3;
		CircularArcSegment quarter4;

		SequencePointImp start, end;

		// create a circular arc which wraps all the way around
		// SequencePointImp start = new SequencePointImp(0, height);
		// SequencePointImp end = new SequencePointImp(sequenceLength, height);
		// fullSegment = new CircularArcSegment(start, end, Direction.INCREASING);

		start = new SequencePointImp(0, height);
		end = new SequencePointImp(sequenceLength / 4, height);
		quarter1 = new CircularArcSegment(start, end, Direction.INCREASING);

		start = new SequencePointImp(sequenceLength / 4, height);
		end = new SequencePointImp(2 * sequenceLength / 4, height);
		quarter2 = new CircularArcSegment(start, end, Direction.INCREASING);

		start = new SequencePointImp(2 * sequenceLength / 4, height);
		end = new SequencePointImp(3 * sequenceLength / 4, height);
		quarter3 = new CircularArcSegment(start, end, Direction.INCREASING);

		// start = new SequencePointImp(3 * sequenceLength / 4, height); end = new
		// SequencePointImp(4 * sequenceLength / 4, height); quarter4 = new
		// CircularArcSegment(start, end, Direction.INCREASING);

		double maxScale = Math.min(backbone.getMaxScale(), 1000);

		// test the different segments with different scales
		for (int i = 0; i < maxScale; i += 10)
		{
			double scale = i + 1;

			backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));

			// testArcAppendAt(initialRadius*scale + height, 90, 360, fullSegment);

			testArcAppendAt(initialRadius * scale + height, 90, 90, quarter1);
			testArcAppendAt(initialRadius * scale + height, 0, 90, quarter2);
			testArcAppendAt(initialRadius * scale + height, 270, 90, quarter3);
			// testArcAppendAt(initialRadius*scale + height, -180, 90, quarter4);
		}
	}

	// tests if a circle of defined by the passed angles is created correctly at the given actual
	// radius of the circle
	private void testArcAppendAt(double actualRadius, double startDeg, double extentDeg, CircularArcSegment segment)
	{
		Path2D actualPath = new Path2D.Double();
		Path2D expectedPath = new Path2D.Double();

		actualPath.reset();
		expectedPath.reset();

		actualPath.moveTo(0, actualRadius);
		expectedPath.moveTo(0, actualRadius);

		segment.appendWithScale(actualPath, backbone);

		expectedPath.append(MIRROR_Y.createTransformedShape(TestUtils.createCircle(actualRadius, -startDeg, extentDeg)), true);

		TestUtils.assertShapeEqual(expectedPath, actualPath, delta);
	}
}
