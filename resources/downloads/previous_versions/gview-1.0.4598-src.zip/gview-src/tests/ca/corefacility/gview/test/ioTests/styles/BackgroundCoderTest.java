package ca.corefacility.gview.test.ioTests.styles;


import java.awt.Color;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;
import org.w3c.css.sac.Selector;

import ca.corefacility.gview.map.effects.OutlineEffect;
import ca.corefacility.gview.map.effects.ShapeEffectRenderer;
import ca.corefacility.gview.style.GlobalStyle;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.io.gss.PaintHandler;
import ca.corefacility.gview.style.io.gss.ShapeEffectHandler;
import ca.corefacility.gview.style.io.gss.PaintHandler.UnknownPaintException;
import ca.corefacility.gview.style.io.gss.coders.BackgroundCoder;
import ca.corefacility.gview.style.io.gss.coders.GSSWriter;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedDeclarationException;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedSelectorException;
import ca.corefacility.gview.style.io.gss.exceptions.NoStyleExistsException;
import ca.corefacility.gview.style.io.gss.exceptions.NoSuchFilterException;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.style.items.BackboneStyle;

import com.steadystate.css.parser.selectors.ElementSelectorImpl;

public class BackgroundCoderTest
{
	private BackgroundCoder coder;
	
	@Before
	public void setup()
	{
		coder = new BackgroundCoder();
	}
	
	@Test
	public void testDecode() throws CSSException, IOException, ParseException
	{
		MapStyle map1;
		
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		GlobalStyle workingStyle;
		LexicalUnit currUnit;
		
		GlobalStyle expectedStyle;

		// setup encoding
		Selector selector;
		
		boolean exceptionCheck;
		
		map1 = new MapStyle();
		workingStyle = map1.getGlobalStyle();
		
		selector = new ElementSelectorImpl("background");
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		// setup expected style
		expectedStyle = new GlobalStyle(workingStyle);
		expectedStyle.setBackgroundPaint(new Color(255,0,0));
		
		coder.decodeProperty(selector, map1, null, "color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("colorl(\"red\")"))); // incorrect function, should do nothing here
		
		// setup expected style
		expectedStyle = new GlobalStyle(workingStyle);
		
		try
		{
			exceptionCheck = false;
			// should throw CSSException due to unknown function name
			coder.decodeProperty(selector, map1, null, "color", currUnit, null);
		}
		catch (CSSException e)
		{
			exceptionCheck = true;
		}
		Assert.assertTrue(exceptionCheck);
		
		
		// another encoding
		map1 = new MapStyle();
		workingStyle = map1.getGlobalStyle();
		
		selector = new ElementSelectorImpl("background");
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"green\")")));
		
		// setup expected style
		expectedStyle = new GlobalStyle(workingStyle);
		expectedStyle.setBackgroundPaint(new Color(0, 128, 0));
		
		coder.decodeProperty(selector, map1, null, "color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testEncode() throws UnknownPaintException
	{
		MapStyle mapStyle = new MapStyle();
		
		GlobalStyle globalStyle = mapStyle.getGlobalStyle();
		String expectedEncoding, actualEncoding;
		
		StringWriter expectedStringWriter;
		GSSWriter expectedGssWriter;
		
		StringWriter actualStringWriter;
		GSSWriter actualEncodingGSS;
		
		expectedStringWriter = new StringWriter();
		expectedGssWriter = new GSSWriter(expectedStringWriter);
		actualStringWriter = new StringWriter();
		actualEncodingGSS = new GSSWriter(actualStringWriter);
		
		// setup expected values
		expectedGssWriter.startSelector("background");
		expectedGssWriter.writeProperty("color", PaintHandler.encode(Color.BLUE));
		expectedGssWriter.endSelector();
		expectedEncoding = expectedStringWriter.toString();
		
		// setup map
		globalStyle.setBackgroundPaint(Color.BLUE);
		
		coder.encodeSelector(mapStyle, null, actualEncodingGSS);
		Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
	}
}
