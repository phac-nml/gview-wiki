package ca.corefacility.gview.test.translatetests;


import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;

import org.biojava.bio.seq.Sequence;
import org.biojava.bio.seq.impl.SimpleSequence;
import org.biojava.bio.symbol.SymbolList;
import org.junit.Before;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.Direction;
import ca.corefacility.gview.layout.prototype.NonFragmentingStretchableShape;
import ca.corefacility.gview.layout.prototype.SequencePointImp;
import ca.corefacility.gview.layout.prototype.StretchableShape;
import ca.corefacility.gview.layout.prototype.segments.CircularArcSegment;
import ca.corefacility.gview.layout.prototype.segments.LineSegment;
import ca.corefacility.gview.layout.prototype.segments.MoveSegment;
import ca.corefacility.gview.layout.sequence.Backbone;
import ca.corefacility.gview.layout.sequence.LocationConverter;
import ca.corefacility.gview.layout.sequence.circular.BackboneCircular;
import ca.corefacility.gview.map.event.ZoomEvent;

public class StretchableShapeTest
{
	private GenomeData data = null;

	private double delta = 0.00000001;

	private double initialRadius = 50;

	private int sequenceLength = 100;

	private final static double THICKNESS = 2.0; // thickness of shape to test

	final private AffineTransform MIRROR_Y = new AffineTransform(1, 0, 0, -1, 0, 0);

	@Before
	public void setup()
	{
		SymbolList list = new BlankSymbolList(sequenceLength);
		Sequence seq = new SimpleSequence(list, null, null, null);

		data = GenomeDataFactory.createGenomeData(seq);
	}

	@Test
	public void testBackboneZoomEventCircular()
	{
		Backbone backbone = new BackboneCircular(new LocationConverter(data), initialRadius, 0);

		// test multiple heights
		for (double height = -50; height < 50; height += 5.0)
		{
			Shape actualShape = buildStretchableShapeCircular(backbone, height);

			// test initial scale
			backbone.eventOccured(new ZoomEvent(1.0, new Point2D.Double(), this));
			Shape expectedShape = buildShapeCircular(initialRadius, height);

			// double w = actualShape.getBounds2D().getWidth();
			// double h = actualShape.getBounds2D().getHeight();
			// System.out.println("width=" + w + ", height=" + h +
			// ", center=(" + actualShape.getBounds2D().getCenterX() + "," +
			// actualShape.getBounds2D().getCenterY());

			TestUtils.assertShapeEqual(expectedShape, actualShape, delta);

			double maxScale = Math.min(backbone.getMaxScale(), 100000);

			// test at other scale levels
			for (int i = 0; i < maxScale; i += 10)
			{
				double scale = i + 1;
				backbone.eventOccured(new ZoomEvent(scale, new Point2D.Double(), this));

				expectedShape = buildShapeCircular(initialRadius * scale, height);

				TestUtils.assertShapeEqual(expectedShape, actualShape, delta);
			}
		}
	}

	private StretchableShape buildStretchableShapeCircular(Backbone backbone, double centerHeight)
	{
		StretchableShape shape = null;

		double top = centerHeight + THICKNESS / 2;
		double bottom = centerHeight - THICKNESS / 2;

		SequencePointImp startTop = new SequencePointImp(0, top);
		SequencePointImp endTop = new SequencePointImp(sequenceLength / 2.0, top);
		SequencePointImp endBottom = new SequencePointImp(sequenceLength / 2.0, bottom);
		SequencePointImp startBottom = new SequencePointImp(0, bottom);

		shape = new NonFragmentingStretchableShape(backbone);

		shape.appendSegment(new MoveSegment(startTop));
		shape.appendSegment(new CircularArcSegment(startTop, endTop, Direction.INCREASING));
		shape.appendSegment(new LineSegment(endBottom));
		shape.appendSegment(new CircularArcSegment(endBottom, startBottom, Direction.DECREASING));
		// shape.appendSegment(new LineSegment(startTop));

		backbone.addEventListener(shape);

		return shape;
	}

	private Shape buildShapeCircular(double scaledRadius, double centerHeight)
	{
		Path2D circularShape = new Path2D.Double();

		double topRadius = scaledRadius + centerHeight + THICKNESS / 2;
		double bottomRadius = scaledRadius + centerHeight - THICKNESS / 2;

		circularShape.moveTo(0, -topRadius);
		circularShape.append(MIRROR_Y.createTransformedShape(TestUtils.createCircle(topRadius, -90, 180)), false); // false
																													// is
																													// to
																													// account
																													// for
																													// creating
																													// an
																													// infintesimal
																													// line
																													// segment
																													// when
																													// appending
		circularShape.lineTo(0, bottomRadius);
		circularShape.append(TestUtils.createCircle(bottomRadius, -90, 180), true);
		// circularShape.lineTo(0, -topRadius);

		return circularShape;
	}
}
