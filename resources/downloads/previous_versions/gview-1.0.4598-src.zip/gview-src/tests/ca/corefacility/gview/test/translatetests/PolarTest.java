package ca.corefacility.gview.test.translatetests;


import java.awt.geom.Point2D;

import org.junit.Assert;
import org.junit.Test;

import ca.corefacility.gview.layout.sequence.circular.Polar;

/**
 * Tests the Polar class.
 * 
 * @author Aaron Petkau
 */
public class PolarTest
{
	private Point2D[] points;

	private double delta = 0.0000000001;

	@Test
	public void testConversion()
	{
		Polar[] polar;

		double radius = 10;

		points = new Point2D.Double[5];
		points[0] = new Point2D.Double(0, 0);

		points[1] = new Point2D.Double(radius, 0);
		points[2] = new Point2D.Double(0, radius);
		points[3] = new Point2D.Double(-radius, 0);
		points[4] = new Point2D.Double(0, -radius);

		// convert points to polar coords
		polar = new Polar[points.length];
		for (int i = 0; i < polar.length; i++)
		{
			polar[i] = Polar.createPolar(points[i]);
		}

		// check 0 point
		Assert.assertEquals(0, polar[0].getRadius(), delta);
		Assert.assertEquals(0, polar[0].getTheta(), delta); // theta set to default 0 if radius = 0

		// check radius
		for (int i = 1; i < polar.length; i++)
		{
			Assert.assertEquals(radius, polar[i].getRadius(), delta);
		}

		// check angles
		Assert.assertEquals(0, polar[1].getTheta(), delta);
		Assert.assertEquals(Math.PI / 2, polar[2].getTheta(), delta);
		Assert.assertEquals(Math.PI, polar[3].getTheta(), delta);
		Assert.assertEquals(3 * Math.PI / 2, polar[4].getTheta(), delta);
	}
}
