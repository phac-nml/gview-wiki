package ca.corefacility.gview.test.ioTests.styles;


import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LexicalUnit;
import org.w3c.css.sac.Parser;
import org.w3c.css.sac.Selector;

import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.io.gss.FontHandler;
import ca.corefacility.gview.style.io.gss.PaintHandler;
import ca.corefacility.gview.style.io.gss.PaintHandler.UnknownPaintException;
import ca.corefacility.gview.style.io.gss.coders.GSSWriter;
import ca.corefacility.gview.style.io.gss.coders.RulerCoder;
import ca.corefacility.gview.style.io.gss.coders.TooltipCoder;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedDeclarationException;
import ca.corefacility.gview.style.io.gss.exceptions.MalformedSelectorException;
import ca.corefacility.gview.style.io.gss.exceptions.NoStyleExistsException;
import ca.corefacility.gview.style.io.gss.exceptions.NoSuchFilterException;
import ca.corefacility.gview.style.io.gss.exceptions.ParseException;
import ca.corefacility.gview.style.items.RulerStyle;
import ca.corefacility.gview.style.items.TooltipStyle;

import com.steadystate.css.parser.selectors.ElementSelectorImpl;

public class RulerCoderTest
{
	private RulerCoder coder;
	
	@Before
	public void setup()
	{
		coder = new RulerCoder();
	}
	
	@Test
	public void testDecode() throws ParseException, CSSException, IOException
	{
		MapStyle map1;
		
		Parser parser = new com.steadystate.css.parser.SACParserCSS2();
		
		RulerStyle workingStyle;
		LexicalUnit currUnit;
		
		RulerStyle expectedStyle;

		// setup encoding
		Selector selector;
		
		map1 = new MapStyle();
		workingStyle = map1.getGlobalStyle().getRulerStyle();
		
		selector = new ElementSelectorImpl("ruler");
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setMajorTickPaint(Color.red);
		
		coder.decodeProperty(selector, map1, null, "major-tick-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"green\")")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setMinorTickPaint(new Color(0, 128, 0));
		
		coder.decodeProperty(selector, map1, null, "minor-tick-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"blue\")")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setTextPaint(Color.blue);
		
		coder.decodeProperty(selector, map1, null, "label-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"yellow\")")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setTextBackgroundPaint(Color.yellow);
		
		coder.decodeProperty(selector, map1, null, "label-background-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("font(\"SansSerif\", \"plain\", 21)")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setFont(new Font("SansSerif", Font.PLAIN, 21));
		
		coder.decodeProperty(selector, map1, null, "label-font", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("10.0")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setMajorTickLength(10.0);
		coder.decodeProperty(selector, map1, null, "major-tick-length", currUnit, null);
		Assert.assertEquals(expectedStyle, workingStyle);
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("0.5")));
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("10.0")));
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setMinorTickLength(10.0);
		coder.decodeProperty(selector, map1, null, "minor-tick-length", currUnit, null);
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("0.5")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setTickDensity(0.5f);
		
		coder.decodeProperty(selector, map1, null, "tick-density", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("15.5")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setTickThickness(15.5);
		
		coder.decodeProperty(selector, map1, null, "tick-thickness", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("17.5")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setPadding(17.5);
		
		coder.decodeProperty(selector, map1, null, "tick-padding", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	
		
		map1 = new MapStyle();
		workingStyle = map1.getGlobalStyle().getRulerStyle();
		
		selector = new ElementSelectorImpl("ruler");
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"green\")")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setMajorTickPaint(new Color(0, 128, 0));
		
		coder.decodeProperty(selector, map1, null, "major-tick-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"blue\")")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setMinorTickPaint(Color.blue);
		
		coder.decodeProperty(selector, map1, null, "minor-tick-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"red\")")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setTextPaint(Color.red);
		
		coder.decodeProperty(selector, map1, null, "label-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("color(\"blue\")")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setTextBackgroundPaint(Color.blue);
		
		coder.decodeProperty(selector, map1, null, "label-background-color", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("font(\"SansSerif\", \"bold\", 25)")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setFont(new Font("SansSerif", Font.BOLD, 25));
		
		coder.decodeProperty(selector, map1, null, "label-font", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("0.7")));
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setTickDensity(0.7f);
		coder.decodeProperty(selector, map1, null, "tick-density", currUnit, null);
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("17.5")));
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setTickThickness(17.5);
		coder.decodeProperty(selector, map1, null, "tick-thickness", currUnit, null);
		Assert.assertEquals(expectedStyle, workingStyle);
		
		//setup parameters
		currUnit = parser.parsePropertyValue(new InputSource(new StringReader("19.5")));
		
		// setup expected style
		expectedStyle = new RulerStyle(workingStyle);
		expectedStyle.setPadding(19.5);
		
		coder.decodeProperty(selector, map1, null, "tick-padding", currUnit, null);
		
		Assert.assertEquals(expectedStyle, workingStyle);
	}
	
	@Test
	public void testEncode()
	{
		try
		{
			MapStyle mapStyle = new MapStyle();
			
			RulerStyle rulerStyle = mapStyle.getGlobalStyle().getRulerStyle();
			String expectedEncoding, actualEncoding;
			
			StringWriter expectedStringWriter;
			GSSWriter expectedGssWriter;
			
			StringWriter actualStringWriter;
			GSSWriter actualEncodingGSS;
			
			expectedStringWriter = new StringWriter();
			expectedGssWriter = new GSSWriter(expectedStringWriter);
			actualStringWriter = new StringWriter();
			actualEncodingGSS = new GSSWriter(actualStringWriter);
			
			// setup expected values
			expectedGssWriter.startSelector("ruler");
			expectedGssWriter.writeProperty("major-tick-color", PaintHandler.encode(Color.BLUE));
	
			expectedGssWriter.writeProperty("minor-tick-color", PaintHandler.encode(Color.RED));
			expectedGssWriter.writeProperty("label-color", PaintHandler.encode(Color.BLACK));
			expectedGssWriter.writeProperty("label-background-color", PaintHandler.encode(Color.YELLOW));
			expectedGssWriter.writeProperty("major-tick-length", Double.toString(10.0));
			expectedGssWriter.writeProperty("minor-tick-length", Double.toString(5.0));
			expectedGssWriter.writeProperty("tick-density", Float.toString(0.2f));
			expectedGssWriter.writeProperty("tick-thickness", Double.toString(5));
			expectedGssWriter.writeProperty("tick-padding", Double.toString(2.0));
			expectedGssWriter.writeProperty("label-font", FontHandler.encode(new Font("SansSerif", Font.BOLD + Font.ITALIC, 16)));
			expectedGssWriter.endSelector();
			expectedEncoding = expectedStringWriter.toString();
			
			// setup map
			rulerStyle.setMajorTickPaint(Color.BLUE);
			rulerStyle.setMinorTickPaint(Color.red);
			rulerStyle.setTextPaint(Color.BLACK);
			rulerStyle.setTextBackgroundPaint(Color.YELLOW);
			rulerStyle.setMajorTickLength(10.0);
			rulerStyle.setMinorTickLength(5.0);
			rulerStyle.setTickDensity(0.2f);
			rulerStyle.setTickThickness(5);
			rulerStyle.setPadding(2.0);
			rulerStyle.setFont(new Font("SansSerif", Font.BOLD + Font.ITALIC, 16));
			
			coder.encodeSelector(mapStyle, null, actualEncodingGSS);
			Assert.assertEquals(expectedEncoding, actualStringWriter.toString());
		}
		catch (UnknownPaintException e)
		{
			Assert.fail();
		}
	}
}
