package ca.corefacility.gview.test.managerTests;


import java.awt.geom.Rectangle2D;
import java.util.LinkedList;
import java.util.List;

import org.biojava.bio.seq.impl.SimpleSequence;
import org.junit.Assert;
import org.junit.Test;

import ca.corefacility.gview.data.BlankSymbolList;
import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.GenomeDataFactory;
import ca.corefacility.gview.layout.prototype.SequencePointImp;
import ca.corefacility.gview.layout.sequence.Backbone;
import ca.corefacility.gview.layout.sequence.BaseRange;
import ca.corefacility.gview.layout.sequence.LocationConverter;
import ca.corefacility.gview.layout.sequence.linear.BackboneLinear;
import ca.corefacility.gview.managers.ResolutionManager;
import ca.corefacility.gview.managers.SectionID;
import ca.corefacility.gview.managers.SectionManager;
import ca.corefacility.gview.map.event.DisplayUpdated;
import ca.corefacility.gview.map.event.GViewEvent;
import ca.corefacility.gview.map.event.GViewEventListener;
import ca.corefacility.gview.map.event.ResolutionSwitchEvent;
import ca.corefacility.gview.map.event.SectionChangedEvent;

public class SectionManagerTest
{
	private double delta = 0.0000000001;

	private final static double WIDTH = 100;
	private final static int initialNumberOfSections = 4;

	private double leftX;

	private Backbone backbone;

	private SectionManager sectionManager;
	private SectionChangedEventStorage eventStore;

	private void setup(int sequenceLength)
	{
		GenomeData data = GenomeDataFactory.createGenomeData(new SimpleSequence(new BlankSymbolList(sequenceLength), null, null, null));

		backbone = new BackboneLinear(new LocationConverter(data), WIDTH);
		leftX = backbone.translate(new SequencePointImp(0, 0)).getX();

		sectionManager = new SectionManager(sequenceLength, initialNumberOfSections, backbone);
		eventStore = new SectionChangedEventStorage();
		sectionManager.addEventListener(eventStore);
	}

	@Test
	public void toBaseRangeTest()
	{
		setup(100);

		SectionID section = new SectionID(1, 0);

		double expectedInitialBase = 0;
		double expectedFinalBase = 25;

		BaseRange resultBaseRange = sectionManager.toBaseRange(section);

		Assert.assertEquals(expectedInitialBase, resultBaseRange.getStartBase(), delta);
		Assert.assertEquals(expectedFinalBase, resultBaseRange.getEndBase(), delta);

		section = new SectionID(1, 1);

		expectedInitialBase = 25;
		expectedFinalBase = 50;

		resultBaseRange = sectionManager.toBaseRange(section);

		Assert.assertEquals(expectedInitialBase, resultBaseRange.getStartBase(), delta);
		Assert.assertEquals(expectedFinalBase, resultBaseRange.getEndBase(), delta);

		section = new SectionID(1, 3);

		expectedInitialBase = 75;
		expectedFinalBase = 100;

		resultBaseRange = sectionManager.toBaseRange(section);

		Assert.assertEquals(expectedInitialBase, resultBaseRange.getStartBase(), delta);
		Assert.assertEquals(expectedFinalBase, resultBaseRange.getEndBase(), delta);

		setup(10000000); // test with different sequence length

		// increase the total number of sections available (increase section level to 7)
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 7));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 7));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 7));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 7));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 7));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 7));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 7));
		Assert.assertEquals(512, sectionManager.getTotalSections());

		// bases per section in this case = 10000000/512
		double basesPerSection = 10000000 / 512d;

		section = new SectionID(7, 0);
		expectedInitialBase = 0;
		expectedFinalBase = basesPerSection;
		resultBaseRange = sectionManager.toBaseRange(section);
		Assert.assertEquals(expectedInitialBase, resultBaseRange.getStartBase(), delta);
		Assert.assertEquals(expectedFinalBase, resultBaseRange.getEndBase(), delta);

		section = new SectionID(7, 511);
		expectedInitialBase = 10000000 - basesPerSection;
		expectedFinalBase = 10000000;
		resultBaseRange = sectionManager.toBaseRange(section);
		Assert.assertEquals(expectedInitialBase, resultBaseRange.getStartBase(), delta);
		Assert.assertEquals(expectedFinalBase, resultBaseRange.getEndBase(), delta);

		setup(10000000); // test with different sequence length

		// increase the total number of sections to some higher value (increase section level to 10)
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 10));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 10));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 10));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 10));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 10));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 10));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 10));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 10));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 10));
		sectionManager.eventOccured(new ResolutionSwitchEvent(backbone, ResolutionManager.Direction.INCREASE, 10));
		Assert.assertEquals(4096, sectionManager.getTotalSections());

		// bases per section in this case = 10000000/4096
		basesPerSection = 10000000 / 4096d;

		section = new SectionID(10, 0);
		expectedInitialBase = 0;
		expectedFinalBase = basesPerSection;
		resultBaseRange = sectionManager.toBaseRange(section);
		Assert.assertEquals(expectedInitialBase, resultBaseRange.getStartBase(), delta);
		Assert.assertEquals(expectedFinalBase, resultBaseRange.getEndBase(), delta);

		section = new SectionID(10, 4095);
		expectedInitialBase = 10000000 - basesPerSection;
		expectedFinalBase = 10000000;
		resultBaseRange = sectionManager.toBaseRange(section);
		Assert.assertEquals(expectedInitialBase, resultBaseRange.getStartBase(), delta);
		Assert.assertEquals(expectedFinalBase, resultBaseRange.getEndBase(), delta);
	}

	private void compareSections(List<SectionID> expectedSections, double viewLeftX, double viewLength)
	{
		setup(100);

		// rectangle across section in middle
		Rectangle2D view = new Rectangle2D.Double(viewLeftX, -10, viewLength, 20);

		sectionManager.eventOccured(new DisplayUpdated(this, view, view, true));
		SectionChangedEvent receivedEvent = eventStore.getCurrentEvent();
		Assert.assertEquals(expectedSections, receivedEvent.getCurrentDisplayedSections());
	}

	// TODO add tests involving different numbers of sections?

	@Test
	public void toSectionRangeTest()
	{
		setup(100);

		List<SectionID> expectedSections = new LinkedList<SectionID>();

		BaseRange baseRange;

		Assert.assertNull(sectionManager.toSectionRange(null));

		baseRange = new BaseRange(0, 100);
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 0));
		expectedSections.add(new SectionID(0, 1));
		expectedSections.add(new SectionID(0, 2));
		expectedSections.add(new SectionID(0, 3));
		Assert.assertEquals(expectedSections, sectionManager.toSectionRange(baseRange));

		baseRange = new BaseRange(0, 50);
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 0));
		expectedSections.add(new SectionID(0, 1));
		expectedSections.add(new SectionID(0, 2));
		Assert.assertEquals(expectedSections, sectionManager.toSectionRange(baseRange));

		baseRange = new BaseRange(50, 100);
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 2));
		expectedSections.add(new SectionID(0, 3));
		Assert.assertEquals(expectedSections, sectionManager.toSectionRange(baseRange));

		baseRange = new BaseRange(-50, 40);
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 0));
		expectedSections.add(new SectionID(0, 1));
		Assert.assertEquals(expectedSections, sectionManager.toSectionRange(baseRange));

		baseRange = new BaseRange(70, 150);
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 2));
		expectedSections.add(new SectionID(0, 3));
		Assert.assertEquals(expectedSections, sectionManager.toSectionRange(baseRange));

		// bases overlapping 0 base
		baseRange = new BaseRange(75, 25);
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 3));
		expectedSections.add(new SectionID(0, 0));
		expectedSections.add(new SectionID(0, 1));
		Assert.assertEquals(expectedSections, sectionManager.toSectionRange(baseRange));

		baseRange = new BaseRange(50, 25);
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 2));
		expectedSections.add(new SectionID(0, 3));
		expectedSections.add(new SectionID(0, 0));
		expectedSections.add(new SectionID(0, 1));
		Assert.assertEquals(expectedSections, sectionManager.toSectionRange(baseRange));
	}

	@Test
	public void sectionChangedEventTest()
	{
		setup(100);

		List<SectionID> expectedSections = new LinkedList<SectionID>();

		/*
		 * since initialNumberOfSections = 4, we should expected sections to be like the following
		 * (sectionLevel, sectionNumber) = (0,0) : (baseStart, baseEnd) = (0,25) (sectionLevel,
		 * sectionNumber) = (0,1) : (baseStart, baseEnd) = (25,50) (sectionLevel, sectionNumber) =
		 * (0,2) : (baseStart, baseEnd) = (50,75) (sectionLevel, sectionNumber) = (0,3) :
		 * (baseStart, baseEnd) = (75,100)
		 */

		// expected section 0
		BaseRange resultBaseRange = sectionManager.toBaseRange(new SectionID(0, 0));
		Assert.assertEquals(0, resultBaseRange.getStartBase(), delta);
		Assert.assertEquals(25, resultBaseRange.getEndBase(), delta);

		// expected section 1
		resultBaseRange = sectionManager.toBaseRange(new SectionID(0, 1));
		Assert.assertEquals(25, resultBaseRange.getStartBase(), delta);
		Assert.assertEquals(50, resultBaseRange.getEndBase(), delta);

		// expected section 2
		resultBaseRange = sectionManager.toBaseRange(new SectionID(0, 2));
		Assert.assertEquals(50, resultBaseRange.getStartBase(), delta);
		Assert.assertEquals(75, resultBaseRange.getEndBase(), delta);

		// expected section 3
		resultBaseRange = sectionManager.toBaseRange(new SectionID(0, 3));
		Assert.assertEquals(75, resultBaseRange.getStartBase(), delta);
		Assert.assertEquals(100, resultBaseRange.getEndBase(), delta);

		// now we test that SectionManager is giving the right sections

		// rectangle at left, across one section
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 0));
		compareSections(expectedSections, leftX, 24.9);

		// rectangle across section in middle
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 1));
		compareSections(expectedSections, leftX + 25, 24.9);

		// rectangle across section at end
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 3));
		compareSections(expectedSections, leftX + 75, 24.9);

		// rectangle across 2 sections at beginning
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 0));
		expectedSections.add(new SectionID(0, 1));
		compareSections(expectedSections, leftX, 30);

		// rectangle across 2 sections in middle
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 1));
		expectedSections.add(new SectionID(0, 2));
		compareSections(expectedSections, leftX + 30, 30);

		// rectangle across all sections
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 0));
		expectedSections.add(new SectionID(0, 1));
		expectedSections.add(new SectionID(0, 2));
		expectedSections.add(new SectionID(0, 3));
		compareSections(expectedSections, leftX, 100);

		// rectangle before beginning
		expectedSections.clear();
		compareSections(expectedSections, leftX - 30, 20);

		// rectangle after end
		expectedSections.clear();
		compareSections(expectedSections, leftX + 110, 20);

		// rectangle overlapping beginning
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 0));
		expectedSections.add(new SectionID(0, 1));
		compareSections(expectedSections, leftX - 10, 40);

		// rectangle overlapping end
		expectedSections.clear();
		expectedSections.add(new SectionID(0, 2));
		expectedSections.add(new SectionID(0, 3));
		compareSections(expectedSections, leftX + 70, 40);
	}

	// used to receive/store SectionChangedEvents for testing
	private static class SectionChangedEventStorage implements GViewEventListener
	{
		private SectionChangedEvent event = null;

		public void eventOccured(GViewEvent event)
		{
			Assert.assertTrue(event instanceof SectionChangedEvent);

			if (event instanceof SectionChangedEvent)
				this.event = (SectionChangedEvent) event;
		}

		public SectionChangedEvent getCurrentEvent()
		{
			return event;
		}
	}
}
