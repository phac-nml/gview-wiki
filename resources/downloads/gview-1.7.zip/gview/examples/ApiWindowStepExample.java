import java.awt.Color;
import java.io.IOException;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.Slot;
import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.GViewFileData;
import ca.corefacility.gview.data.readers.GViewFileReader;
import ca.corefacility.gview.layout.sequence.LayoutFactory;
import ca.corefacility.gview.layout.sequence.linear.LayoutFactoryLinear;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.GViewMapFactory;
import ca.corefacility.gview.map.gui.GUIManager;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.StyleFactory;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.PlotBuilderType;
import ca.corefacility.gview.style.datastyle.PlotDrawerType;
import ca.corefacility.gview.style.datastyle.PlotStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;

public class ApiWindowStepExample
{	
	private static MapStyle buildStyle()
	{	
		MapStyle mapStyle = StyleFactory.createDefaultStyle2();
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		PlotStyle gcContentPlot;
		SlotStyle gcContentSlot;
		
		PlotStyle gcSkewPlot;
		SlotStyle gcSkewSlot;
		
		/**Plots**/	
		
		// creates GC content slot, with auto step/window size
		gcContentSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER-1);

		gcContentPlot = new PlotStyle();
		gcContentPlot.setPaint(new Color[]{Color.black,Color.black});
		gcContentPlot.setPlotDrawerType( new PlotDrawerType.Center());
		gcContentPlot.setPlotBuilderType(new PlotBuilderType.GCContent());
		
		gcContentSlot.addStyleItem(gcContentPlot);
		
		// creates GC content slot, with custom step/window size
		gcContentSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER-2);

		gcContentPlot = new PlotStyle();
		gcContentPlot.setPaint(new Color[]{Color.black,Color.black});
		gcContentPlot.setPlotDrawerType( new PlotDrawerType.Center());
		gcContentPlot.setPlotBuilderType(new PlotBuilderType.GCContent(200000,50000));
		
		gcContentSlot.addStyleItem(gcContentPlot);
		
		// creates GC skew slot, with custom step/window size
		gcSkewSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER-3);

		gcSkewPlot = new PlotStyle();
		gcSkewPlot.setPaint(new Color[]{Color.gray,Color.gray});
		gcSkewPlot.setPlotDrawerType( new PlotDrawerType.Center());
		gcSkewPlot.setPlotBuilderType(new PlotBuilderType.GCSkew(200000,50000));
		
		gcSkewSlot.addStyleItem(gcSkewPlot);
		
		return mapStyle;
	}
	
	
	public static void main(String[] args)
	{
		try
		{
			// read in genome data
			GViewFileData fileData = GViewFileReader.read("example_data/NC_007622.gbk");
			
			GenomeData data = fileData.getGenomeData();
			
	  		MapStyle style = buildStyle(); // creates style, buildStyle() code not shown
			LayoutFactory layoutFactory = new LayoutFactoryLinear();
	  		
	  		GViewMap gViewMap = GViewMapFactory.createMap(data, style, layoutFactory);
	  		
	  		// builds a frame which can be used to display/navigate around on the map
			GUIManager.getInstance().buildGUIFrame("GView", gViewMap);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (GViewDataParseException e)
		{
			e.printStackTrace();
		}
	}
}
