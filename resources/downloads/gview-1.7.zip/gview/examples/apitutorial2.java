import java.awt.Color;
import java.awt.Font;
import java.io.IOException;

import org.biojava.bio.seq.FeatureFilter;
import org.biojava.bio.seq.StrandedFeature;
import org.biojava.bio.symbol.RangeLocation;

import ca.corefacility.gview.data.GenomeData;
import ca.corefacility.gview.data.Slot;
import ca.corefacility.gview.data.readers.GViewDataParseException;
import ca.corefacility.gview.data.readers.GViewFileData;
import ca.corefacility.gview.data.readers.GViewFileReader;
import ca.corefacility.gview.layout.sequence.LayoutFactory;
import ca.corefacility.gview.layout.sequence.linear.LayoutFactoryLinear;
import ca.corefacility.gview.map.GViewMap;
import ca.corefacility.gview.map.GViewMapFactory;
import ca.corefacility.gview.map.gui.GUIManager;
import ca.corefacility.gview.style.GlobalStyle;
import ca.corefacility.gview.style.MapStyle;
import ca.corefacility.gview.style.datastyle.DataStyle;
import ca.corefacility.gview.style.datastyle.FeatureHolderStyle;
import ca.corefacility.gview.style.datastyle.SlotStyle;
import ca.corefacility.gview.style.items.BackboneStyle;
import ca.corefacility.gview.style.items.RulerStyle;
import ca.corefacility.gview.style.items.TooltipStyle;
import ca.corefacility.gview.textextractor.LocationExtractor;

public class apitutorial2
{
	private static final long serialVersionUID = 8222742913175964340L;
	
	/**
	 * @return  The style used to build the GView map.
	 */
	private static MapStyle buildStyle()
	{
		/**Global Style**/
		
		MapStyle mapStyle = new MapStyle();
		
		// extract associated GlobalStyle from newly created MapStyle object
		GlobalStyle global = mapStyle.getGlobalStyle();
		
		// set initial height/width of the map
		global.setDefaultHeight(700);
		global.setDefaultWidth(700);
		
		global.setBackgroundPaint(Color.WHITE);
		
		// set tool tip style.  This is used to display extra information about various items on the map.
		TooltipStyle tooltip = global.getTooltipStyle();
		tooltip.setFont(new Font("SansSerif", Font.PLAIN, 12));
		tooltip.setBackgroundPaint(new Color(134, 134, 255)); // set background paint to (r,g,b)=(134,134,255)
		tooltip.setOutlinePaint(new Color(0.0f, 0.0f, 0.0f, 0.5f)); // set outline paint of tool tip item to (r,g,b) = (0,0,0) and alpha=0.5
		tooltip.setTextPaint(Color.BLACK);  // set the paint of the text for the tool tip item
		
		// set style information dealing with the backbone.  This is the item displayed in the very centre of the slots.
		BackboneStyle backbone = global.getBackboneStyle();
		backbone.setPaint(Color.GRAY.darker());
		backbone.setThickness(5.0);
		
		// set information dealing with the ruler style
		RulerStyle ruler = global.getRulerStyle();
		ruler.setMajorTickLength(10.0);  // 
		ruler.setMinorTickLength(2.0);
		ruler.setTickDensity(0.5f);
		ruler.setTickThickness(2.0);
		ruler.setMinorTickPaint(Color.GREEN.darker().darker());
		ruler.setMajorTickPaint(Color.GREEN.darker().darker());
		ruler.setFont(new Font("SansSerif", Font.BOLD, 12));  // font/font paint set information dealing with the text label of the ruler
		ruler.setTextPaint(Color.BLACK);
		
		/**Slots**/
		
		// assumes mapStyle created as above
		
		// extract data style from map style
		DataStyle dataStyle = mapStyle.getDataStyle();
		
		// creates the first two slots
		SlotStyle firstUpperSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER); // first slot above backbone
		SlotStyle firstLowerSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER); // first slot below backbone
		
		// creates slots right next to the first slots
		SlotStyle secondUpperSlot = dataStyle.createSlotStyle(Slot.FIRST_UPPER + 1);
		SlotStyle secondLowerSlot = dataStyle.createSlotStyle(Slot.FIRST_LOWER - 1);
		
		// sets the default color of any features in these slots
		firstUpperSlot.setPaint(Color.BLACK);
		firstLowerSlot.setPaint(Color.BLACK);
		secondUpperSlot.setPaint(Color.BLACK);
		secondLowerSlot.setPaint(Color.BLACK);
		
		 // sets the thickness of the respective slots
		firstUpperSlot.setThickness(30);
		firstLowerSlot.setThickness(30);
		secondUpperSlot.setThickness(30);
		secondLowerSlot.setThickness(30);
		
		/**FeatureHolderStyle**/
		
		// assumes SlotStyles were created as above
		
		// creates a feature holder style in the first upper slot containing all the positive stranded CDS features
		FeatureHolderStyle positiveFeatures = firstUpperSlot.createFeatureHolderStyle(
				new FeatureFilter.And(new FeatureFilter.ByType("CDS"),
									  new FeatureFilter.StrandFilter(StrandedFeature.POSITIVE)));
		positiveFeatures.setThickness(0.7); // sets the thickness of these features as a proportion of the thickness of the slot
		positiveFeatures.setTransparency(0.9f); // sets transparency of all features drawn within this slot
		positiveFeatures.setToolTipExtractor(new LocationExtractor()); 	// sets how to extract text to be displayed for tool tips on these features
		positiveFeatures.setPaint(Color.BLUE); // sets default color of the positive features
		
		// Creates a sub feature holder style below the positiveFeatures feature holder.  This can be used to extract and override style information
		//	for features that would be contained within the positiveFeatures feature holder.
		// In this example, we will override the blue color for positive features that overlap bases [5000,50000] and color them a darker blue.
		FeatureHolderStyle subPositiveFeatures = positiveFeatures.createFeatureHolderStyle(new FeatureFilter.OverlapsLocation(new RangeLocation(5000,50000)));
		subPositiveFeatures.setPaint(Color.BLUE.darker().darker().darker().darker()); // overrides the color for these features, making it darker
		
		// creates a holder containing all negative CDS features in the first lower slot
		FeatureHolderStyle negativeFeatures = firstLowerSlot.createFeatureHolderStyle(
				new FeatureFilter.And(new FeatureFilter.ByType("CDS"),
						  new FeatureFilter.StrandFilter(StrandedFeature.NEGATIVE)));
		negativeFeatures.setThickness(0.7);
		negativeFeatures.setToolTipExtractor(new LocationExtractor());
		negativeFeatures.setPaint(Color.RED);
		
		// creates a holder containing all features in the second upper slot
		FeatureHolderStyle allFeatures = secondUpperSlot.createFeatureHolderStyle(FeatureFilter.all);
		allFeatures.setThickness(0.7);
		allFeatures.setToolTipExtractor(new LocationExtractor());
		allFeatures.setPaint(Color.GREEN);
		
		// creates a holder containing only CDS features overlapping bases [5000,50000] in the second lower slot
		FeatureHolderStyle locationFeatures = secondLowerSlot.createFeatureHolderStyle(new FeatureFilter.And(
				new FeatureFilter.OverlapsLocation(new RangeLocation(5000,50000)),
				new FeatureFilter.ByType("CDS")));
		locationFeatures.setThickness(0.7);
		locationFeatures.setToolTipExtractor(new LocationExtractor());
		locationFeatures.setPaint(Color.BLACK);
		
		return mapStyle;
	}
	
	private static GenomeData getGenomeData()
	{
		try
		{
			GViewFileData fileData = GViewFileReader.read("example_data/NC_007622.gbk");
			
			return fileData.getGenomeData();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		catch (GViewDataParseException e)
		{
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static void main(String[] args)
	{
		// creates the 3 components necessary to build the map
		GenomeData data = getGenomeData();
		MapStyle style = buildStyle();
		LayoutFactory layoutFactory;
		
		// change this to change between linear/circular layouts
		layoutFactory = new LayoutFactoryLinear();
//		layoutFactory = new LayoutFactoryCircular();
		
		// builds the map from the data/style/layout information
		GViewMap gViewMap = GViewMapFactory.createMap(data, style, layoutFactory);
		gViewMap.setVisible(true);
		
		// places the map inside of a Frame (GViewGUIFrame)
		GUIManager.getInstance().buildGUIFrame("ApiTutorial2", gViewMap);
	}
}
