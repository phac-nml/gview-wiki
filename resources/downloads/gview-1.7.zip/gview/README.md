GView - The Genome Viewer
=========================

Complete documentation and new releases can be found at:
http://www.gview.ca/

This program is free software; you can redistribute it and/or it under
the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2 of the License, or (at your
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
USA.

GView was developed by Aaron Petkau, Matthew Stuart-Edwards, and Eric Marinier.
Special thanks to Paul Stothard for developing CGView
(http://wishart.biology.ualberta.ca/cgview/) a circular genome viewer
which GView is based on.  Some icons are copyright © Yusuke Kamiyamane. 
All rights reserved. Licensed under a Creative Commons Attribution 3.0 license.

Contact:
GView: gview@phac-aspc.gc.ca
Aaron Petkau:  aaron.petkau@phac-aspc.gc.ca
Matthew Stuart-Edwards:  matthew.stuart-edwards@phac-aspc.gc.ca

Running GView
=============

usage: java -jar gview.jar [OPTION]...
-h, --help                  Print the usage.
-H, --height <integer>      Specifies the height in pixels for the image.
-c, --centerBase <integer>  Specifies the base pair value to center on.
-i, --inputFile <file>      The input file to parse.
-l, --layout <layout>       The layout of the input, 'circular' or 'linear'.
-f, --imageFormat <format>  The format of the output: [png, jpg, svg, svgz] (default:png)
-o, --outputFile <file>     The image file to create.
-v, --viewer                Loads up the input file in the genome viewer.
-s, --style <file>          The file to read the style information from.
-b, --birdsEyeView          Displays a birds eye view of the map.
                              This is ignored if -v is not used.
-g, --gffFile <file>        Specifies a .gff file with additional annotations to include.
                              Can be used multiple times for multiple files.
-W, --width <integer>       Specifies the width in pixels for the image.
-z, --zoomAmount <real>     The factor to zoom in by.
-t, --threads <integer>     The number of threads to use.
                              The default is the maximum threads the JVM can acquire.
-q, --quality <quality>     The initial rendering quality of the display, 'low' or 'high'.
                              The default quality is high.
--version                   Print version information.

Examples
--------

1.  This command will open a window which allows for selecting the specific files/layout to use to render a GView map.

	java -jar gview.jar

2.  This command will read the genbank file NC_007622.gbk and render a linear
view to a 1200x900 PNG image file.  The style information is supplied by the
file basicStyle.gss.

	java -jar gview.jar -i example_data/NC_007622.gbk -s example_styles/basicStyle.gss -l linear -W 1200 -H 900 -f png -o image.png

3.  This command will read the genbank file NC_001823.gbk and render a circular
view to an interactive viewer, along with a birds eye view.  The style
information is supplied by the file gssExample.gss.

	java -jar gview.jar -i example_data/NC_007622.gbk -s example_styles/gssExample.gss -l circular -v -b

4.  This command will read the CGView input file roseobacter_denitrificans.xml and render a
circular view of the data.  The result will be displayed in an interactive
viewer.

	java -jar gview.jar -i example_data/roseobacter_denitrificans.xml -l circular -v



Note: If you obtain an "Out of Memory" error when drawing a very large
map, try increasing Java's heap size using the -Xmx option. For
example:

	java -Xmx1024m -jar gview.jar -i example_data/roseobacter_denitrificans.xml -l circular -v

Viewer Usage
============

Movement & Zooming
------------------

* Hold Left Mouse Button + Move Mouse:  Panning movement.
* Mouse Wheel Ctrl + '+' or Ctrl + '-':  Perform a contextual zoom in/out. 
* Ctrl + '0':  Reset the contextual zoom. 
* Ctrl + Mouse Wheel:  Performs a traditional zoom in/out. 
* Ctrl + '<':  Center the camera view on the first base in the genome.
* Ctrl + '>':  Center the camera view on the last base in the genome.

View
----

* F11:  Full Screen. 
* Ctrl + 'B':  Shows the Bird's Eye View.
* Ctrl + 'L':  Turn display of legends on or off.
* Ctrl + 'V':  Set the zoom level so that the entire genome is visible.
* Ctrl + 'R':  Resets the view. This will reset both the contextual zoom level and the scaling.
* Ctrl + 'Q':  Toggles the quality between high and low.

Interaction
-----------

* Left Mouse Button:  Select a single item on the map.
* Ctrl + Left Mouse Button:  Select multiple items on the map.
* Middle Mouse Button:  Opens the website corresponding the selected feature.
* Ctrl + Alt + Left Mouse Button:  Opens the website corresponding the selected feature.
* Ctrl + 'E':  Opens the style editor.
* Ctrl + 'Z':  Opens the custom contextual zoom dialog.
* Ctrl + 'C':  Opens the custom scale dialog.
* Ctrl + 'M':  Opens the custom move dialog.

File Management
---------------

* Ctrl + 'O':  Open a new GView map.
* Ctrl + 'X':  Export (save) the current view to a file.

Using the GView API
===================

Documentation about the GView API can be found at http://www.gview.ca/wiki/GViewDocumentation/GViewAPI.
Some example files can be found within the examples/ directory.  To compile or run code using 
the GView API the gview.jar file must be placed on the CLASSPATH.  For example, to compile and 
run the file examples/apitutorial1.java, the following commands can be used.

	javac -cp ../gview.jar:. apitutorial1.java
	java -cp ../gview.jar:. apitutorial1

The above assumes that you are running from within the examples/ directory.

Building GView
==============

GView can be built using Apache Ant http://ant.apache.org/.
To build a standalone executable JAR, the command `ant gview`
can be run.  For a list of all possible tasks, run `ant -p`.

Dependencies
============

GView makes use of the following projects:

* [Batik SVG Toolkit](http://xmlgraphics.apache.org/batik/)
* [Biojava](http://biojava.org/)
* [Colorpicker](http://javagraphics.blogspot.com/2007/04/jcolorchooser-making-alternative.html)
* [CSS Parser](http://cssparser.sourceforge.net/)
* [JArgs](http://jargs.sourceforge.net/)
* [JGoodies Forms](http://www.jgoodies.com/freeware/forms/)
* [Opencsv](http://opencsv.sourceforge.net/)
* [Piccolo2D](http://www.piccolo2d.org/)
* [SAC](http://www.w3.org/Style/CSS/SAC/)
    
These projects are included with GView in the gview.jar file.  The licenses can
be found within the license/ directory.
    
Some icons are copyright © Yusuke Kamiyamane -- http://p.yusukekamiyamane.com/. 
All rights reserved. Licensed under a Creative Commons Attribution 3.0 license.
