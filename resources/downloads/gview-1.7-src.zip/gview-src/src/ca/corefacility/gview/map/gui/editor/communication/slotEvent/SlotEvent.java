package ca.corefacility.gview.map.gui.editor.communication.slotEvent;

import ca.corefacility.gview.map.gui.editor.communication.GUIEvent;

/**
 * A slot action.
 * 
 * @author Eric Marinier
 * 
 */
public abstract class SlotEvent extends GUIEvent
{
}
