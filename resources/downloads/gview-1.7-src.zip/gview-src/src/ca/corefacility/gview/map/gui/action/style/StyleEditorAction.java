package ca.corefacility.gview.map.gui.action.style;

import ca.corefacility.gview.map.gui.action.map.MapAction;

/**
 * Style editor action class.
 * 
 * @author Eric Marinier
 *
 */
public abstract class StyleEditorAction extends MapAction 
{

}
