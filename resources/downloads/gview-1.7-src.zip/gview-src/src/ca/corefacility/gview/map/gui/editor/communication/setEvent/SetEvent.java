package ca.corefacility.gview.map.gui.editor.communication.setEvent;

import ca.corefacility.gview.map.gui.editor.communication.GUIEvent;


/**
 * A set action.
 * 
 * @author Eric Marinier
 *
 */
public abstract class SetEvent extends GUIEvent
{
}
