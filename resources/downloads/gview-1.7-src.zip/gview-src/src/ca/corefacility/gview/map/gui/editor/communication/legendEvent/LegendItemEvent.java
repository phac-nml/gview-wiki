package ca.corefacility.gview.map.gui.editor.communication.legendEvent;

import ca.corefacility.gview.map.gui.editor.communication.GUIEvent;

/**
 * A legend item event.
 * 
 * @author Eric Marinier
 *
 */
public abstract class LegendItemEvent extends GUIEvent
{

}
