package ca.corefacility.gview.map.gui.editor.communication.propertyMapperEvent;

import ca.corefacility.gview.map.gui.editor.communication.GUIEvent;

/**
 * A property mapper event.
 * 
 * @author Eric Marinier
 * 
 */
public abstract class PropertyMapperEvent extends GUIEvent
{
}
