package ca.corefacility.gview.map.gui.editor.panel;

public class BackboneSlotPanel extends StylePanel
{
	private static final long serialVersionUID = 1L;	//requested by java

	@Override
	public void update()
	{
		// Do nothing.	
	}

	@Override
	protected void doApply()
	{
		
	}		
}