package ca.corefacility.gview.map;

public interface BirdsEyeView
{
	// what do I need in here?
	
	// connects this BirdsEyeView to a particular map.
	public void connect(GViewMap gViewMap);
			
	// updates the birdseyeview from the state of the viewed canvas.
	//public void updateFromViewed();
}
