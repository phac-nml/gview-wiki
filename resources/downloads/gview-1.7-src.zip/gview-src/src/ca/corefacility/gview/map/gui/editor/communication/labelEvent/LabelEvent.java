package ca.corefacility.gview.map.gui.editor.communication.labelEvent;

import ca.corefacility.gview.map.gui.editor.communication.GUIEvent;

/**
 * A label event.
 * 
 * @author Eric Marinier
 * 
 */
public abstract class LabelEvent extends GUIEvent
{
}
