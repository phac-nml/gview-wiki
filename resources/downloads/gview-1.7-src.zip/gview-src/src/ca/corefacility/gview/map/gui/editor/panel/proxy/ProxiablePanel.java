package ca.corefacility.gview.map.gui.editor.panel.proxy;

import ca.corefacility.gview.map.gui.editor.panel.StylePanel;

public interface ProxiablePanel
{
	public StylePanel createProxy();
}
