package ca.corefacility.gview.map.gui.editor.communication.plotEvent;

import ca.corefacility.gview.map.gui.editor.communication.GUIEvent;

/**
 * A plot event.
 * 
 * @author Eric Marinier
 * 
 */
public abstract class PlotEvent extends GUIEvent
{
}
