package ca.corefacility.gview.map.gui.editor.communication.legendEvent;

import ca.corefacility.gview.map.gui.editor.communication.GUIEvent;

/**
 * A legend event.
 * 
 * @author Eric Marinier
 * 
 */
public abstract class LegendEvent extends GUIEvent
{

}
