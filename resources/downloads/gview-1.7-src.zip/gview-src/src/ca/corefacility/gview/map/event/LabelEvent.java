package ca.corefacility.gview.map.event;

public class LabelEvent extends GViewEvent
{
	private static final long serialVersionUID = -4426973411099532491L;

	public LabelEvent(Object source)
	{
		super(source);
	}
}
